var _=function(exports){"use strict";var __defProp=Object.defineProperty;var __name=(target,value)=>__defProp(target,"name",{value,configurable:!0});var _a,_b,_c,_d,_e,_f;var react={exports:{}},react_production_min={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var hasRequiredReact_production_min;function requireReact_production_min(){if(hasRequiredReact_production_min)return react_production_min;hasRequiredReact_production_min=1;var l2=Symbol.for("react.element"),n2=Symbol.for("react.portal"),p2=Symbol.for("react.fragment"),q2=Symbol.for("react.strict_mode"),r2=Symbol.for("react.profiler"),t2=Symbol.for("react.provider"),u2=Symbol.for("react.context"),v2=Symbol.for("react.forward_ref"),w2=Symbol.for("react.suspense"),x2=Symbol.for("react.memo"),y2=Symbol.for("react.lazy"),z2=Symbol.iterator;function A2(a2){return a2===null||typeof a2!="object"?null:(a2=z2&&a2[z2]||a2["@@iterator"],typeof a2=="function"?a2:null)}__name(A2,"A");var B2={isMounted:__name(function(){return!1},"isMounted"),enqueueForceUpdate:__name(function(){},"enqueueForceUpdate"),enqueueReplaceState:__name(function(){},"enqueueReplaceState"),enqueueSetState:__name(function(){},"enqueueSetState")},C2=Object.assign,D2={};function E2(a2,b2,e2){this.props=a2,this.context=b2,this.refs=D2,this.updater=e2||B2}__name(E2,"E"),E2.prototype.isReactComponent={},E2.prototype.setState=function(a2,b2){if(typeof a2!="object"&&typeof a2!="function"&&a2!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,a2,b2,"setState")},E2.prototype.forceUpdate=function(a2){this.updater.enqueueForceUpdate(this,a2,"forceUpdate")};function F2(){}__name(F2,"F"),F2.prototype=E2.prototype;function G2(a2,b2,e2){this.props=a2,this.context=b2,this.refs=D2,this.updater=e2||B2}__name(G2,"G");var H2=G2.prototype=new F2;H2.constructor=G2,C2(H2,E2.prototype),H2.isPureReactComponent=!0;var I2=Array.isArray,J2=Object.prototype.hasOwnProperty,K2={current:null},L2={key:!0,ref:!0,__self:!0,__source:!0};function M2(a2,b2,e2){var d2,c2={},k2=null,h2=null;if(b2!=null)for(d2 in b2.ref!==void 0&&(h2=b2.ref),b2.key!==void 0&&(k2=""+b2.key),b2)J2.call(b2,d2)&&!L2.hasOwnProperty(d2)&&(c2[d2]=b2[d2]);var g2=arguments.length-2;if(g2===1)c2.children=e2;else if(1<g2){for(var f2=Array(g2),m2=0;m2<g2;m2++)f2[m2]=arguments[m2+2];c2.children=f2}if(a2&&a2.defaultProps)for(d2 in g2=a2.defaultProps,g2)c2[d2]===void 0&&(c2[d2]=g2[d2]);return{$$typeof:l2,type:a2,key:k2,ref:h2,props:c2,_owner:K2.current}}__name(M2,"M");function N2(a2,b2){return{$$typeof:l2,type:a2.type,key:b2,ref:a2.ref,props:a2.props,_owner:a2._owner}}__name(N2,"N");function O2(a2){return typeof a2=="object"&&a2!==null&&a2.$$typeof===l2}__name(O2,"O");function escape(a2){var b2={"=":"=0",":":"=2"};return"$"+a2.replace(/[=:]/g,function(a3){return b2[a3]})}__name(escape,"escape");var P2=/\/+/g;function Q2(a2,b2){return typeof a2=="object"&&a2!==null&&a2.key!=null?escape(""+a2.key):b2.toString(36)}__name(Q2,"Q");function R(a2,b2,e2,d2,c2){var k2=typeof a2;(k2==="undefined"||k2==="boolean")&&(a2=null);var h2=!1;if(a2===null)h2=!0;else switch(k2){case"string":case"number":h2=!0;break;case"object":switch(a2.$$typeof){case l2:case n2:h2=!0}}if(h2)return h2=a2,c2=c2(h2),a2=d2===""?"."+Q2(h2,0):d2,I2(c2)?(e2="",a2!=null&&(e2=a2.replace(P2,"$&/")+"/"),R(c2,b2,e2,"",function(a3){return a3})):c2!=null&&(O2(c2)&&(c2=N2(c2,e2+(!c2.key||h2&&h2.key===c2.key?"":(""+c2.key).replace(P2,"$&/")+"/")+a2)),b2.push(c2)),1;if(h2=0,d2=d2===""?".":d2+":",I2(a2))for(var g2=0;g2<a2.length;g2++){k2=a2[g2];var f2=d2+Q2(k2,g2);h2+=R(k2,b2,e2,f2,c2)}else if(f2=A2(a2),typeof f2=="function")for(a2=f2.call(a2),g2=0;!(k2=a2.next()).done;)k2=k2.value,f2=d2+Q2(k2,g2++),h2+=R(k2,b2,e2,f2,c2);else if(k2==="object")throw b2=String(a2),Error("Objects are not valid as a React child (found: "+(b2==="[object Object]"?"object with keys {"+Object.keys(a2).join(", ")+"}":b2)+"). If you meant to render a collection of children, use an array instead.");return h2}__name(R,"R");function S2(a2,b2,e2){if(a2==null)return a2;var d2=[],c2=0;return R(a2,d2,"","",function(a3){return b2.call(e2,a3,c2++)}),d2}__name(S2,"S");function T2(a2){if(a2._status===-1){var b2=a2._result;b2=b2(),b2.then(function(b3){(a2._status===0||a2._status===-1)&&(a2._status=1,a2._result=b3)},function(b3){(a2._status===0||a2._status===-1)&&(a2._status=2,a2._result=b3)}),a2._status===-1&&(a2._status=0,a2._result=b2)}if(a2._status===1)return a2._result.default;throw a2._result}__name(T2,"T");var U2={current:null},V2={transition:null},W2={ReactCurrentDispatcher:U2,ReactCurrentBatchConfig:V2,ReactCurrentOwner:K2};return react_production_min.Children={map:S2,forEach:__name(function(a2,b2,e2){S2(a2,function(){b2.apply(this,arguments)},e2)},"forEach"),count:__name(function(a2){var b2=0;return S2(a2,function(){b2++}),b2},"count"),toArray:__name(function(a2){return S2(a2,function(a3){return a3})||[]},"toArray"),only:__name(function(a2){if(!O2(a2))throw Error("React.Children.only expected to receive a single React element child.");return a2},"only")},react_production_min.Component=E2,react_production_min.Fragment=p2,react_production_min.Profiler=r2,react_production_min.PureComponent=G2,react_production_min.StrictMode=q2,react_production_min.Suspense=w2,react_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=W2,react_production_min.cloneElement=function(a2,b2,e2){if(a2==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+a2+".");var d2=C2({},a2.props),c2=a2.key,k2=a2.ref,h2=a2._owner;if(b2!=null){if(b2.ref!==void 0&&(k2=b2.ref,h2=K2.current),b2.key!==void 0&&(c2=""+b2.key),a2.type&&a2.type.defaultProps)var g2=a2.type.defaultProps;for(f2 in b2)J2.call(b2,f2)&&!L2.hasOwnProperty(f2)&&(d2[f2]=b2[f2]===void 0&&g2!==void 0?g2[f2]:b2[f2])}var f2=arguments.length-2;if(f2===1)d2.children=e2;else if(1<f2){g2=Array(f2);for(var m2=0;m2<f2;m2++)g2[m2]=arguments[m2+2];d2.children=g2}return{$$typeof:l2,type:a2.type,key:c2,ref:k2,props:d2,_owner:h2}},react_production_min.createContext=function(a2){return a2={$$typeof:u2,_currentValue:a2,_currentValue2:a2,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},a2.Provider={$$typeof:t2,_context:a2},a2.Consumer=a2},react_production_min.createElement=M2,react_production_min.createFactory=function(a2){var b2=M2.bind(null,a2);return b2.type=a2,b2},react_production_min.createRef=function(){return{current:null}},react_production_min.forwardRef=function(a2){return{$$typeof:v2,render:a2}},react_production_min.isValidElement=O2,react_production_min.lazy=function(a2){return{$$typeof:y2,_payload:{_status:-1,_result:a2},_init:T2}},react_production_min.memo=function(a2,b2){return{$$typeof:x2,type:a2,compare:b2===void 0?null:b2}},react_production_min.startTransition=function(a2){var b2=V2.transition;V2.transition={};try{a2()}finally{V2.transition=b2}},react_production_min.unstable_act=function(){throw Error("act(...) is not supported in production builds of React.")},react_production_min.useCallback=function(a2,b2){return U2.current.useCallback(a2,b2)},react_production_min.useContext=function(a2){return U2.current.useContext(a2)},react_production_min.useDebugValue=function(){},react_production_min.useDeferredValue=function(a2){return U2.current.useDeferredValue(a2)},react_production_min.useEffect=function(a2,b2){return U2.current.useEffect(a2,b2)},react_production_min.useId=function(){return U2.current.useId()},react_production_min.useImperativeHandle=function(a2,b2,e2){return U2.current.useImperativeHandle(a2,b2,e2)},react_production_min.useInsertionEffect=function(a2,b2){return U2.current.useInsertionEffect(a2,b2)},react_production_min.useLayoutEffect=function(a2,b2){return U2.current.useLayoutEffect(a2,b2)},react_production_min.useMemo=function(a2,b2){return U2.current.useMemo(a2,b2)},react_production_min.useReducer=function(a2,b2,e2){return U2.current.useReducer(a2,b2,e2)},react_production_min.useRef=function(a2){return U2.current.useRef(a2)},react_production_min.useState=function(a2){return U2.current.useState(a2)},react_production_min.useSyncExternalStore=function(a2,b2,e2){return U2.current.useSyncExternalStore(a2,b2,e2)},react_production_min.useTransition=function(){return U2.current.useTransition()},react_production_min.version="18.2.0",react_production_min}__name(requireReact_production_min,"requireReact_production_min");var hasRequiredReact;function requireReact(){return hasRequiredReact||(hasRequiredReact=1,react.exports=requireReact_production_min()),react.exports}__name(requireReact,"requireReact");var reactExports=requireReact(),jsxRuntime={exports:{}},reactJsxRuntime_production_min={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var hasRequiredReactJsxRuntime_production_min;function requireReactJsxRuntime_production_min(){if(hasRequiredReactJsxRuntime_production_min)return reactJsxRuntime_production_min;hasRequiredReactJsxRuntime_production_min=1;var f2=requireReact(),k2=Symbol.for("react.element"),l2=Symbol.for("react.fragment"),m2=Object.prototype.hasOwnProperty,n2=f2.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,p2={key:!0,ref:!0,__self:!0,__source:!0};function q2(c2,a2,g2){var b2,d2={},e2=null,h2=null;g2!==void 0&&(e2=""+g2),a2.key!==void 0&&(e2=""+a2.key),a2.ref!==void 0&&(h2=a2.ref);for(b2 in a2)m2.call(a2,b2)&&!p2.hasOwnProperty(b2)&&(d2[b2]=a2[b2]);if(c2&&c2.defaultProps)for(b2 in a2=c2.defaultProps,a2)d2[b2]===void 0&&(d2[b2]=a2[b2]);return{$$typeof:k2,type:c2,key:e2,ref:h2,props:d2,_owner:n2.current}}return __name(q2,"q"),reactJsxRuntime_production_min.Fragment=l2,reactJsxRuntime_production_min.jsx=q2,reactJsxRuntime_production_min.jsxs=q2,reactJsxRuntime_production_min}__name(requireReactJsxRuntime_production_min,"requireReactJsxRuntime_production_min");var hasRequiredJsxRuntime;function requireJsxRuntime(){return hasRequiredJsxRuntime||(hasRequiredJsxRuntime=1,jsxRuntime.exports=requireReactJsxRuntime_production_min()),jsxRuntime.exports}__name(requireJsxRuntime,"requireJsxRuntime");var jsxRuntimeExports=requireJsxRuntime(),client={},reactDom={exports:{}},reactDom_production_min={},scheduler={exports:{}},scheduler_production_min={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var hasRequiredScheduler_production_min;function requireScheduler_production_min(){return hasRequiredScheduler_production_min||(hasRequiredScheduler_production_min=1,function(exports2){function f2(a2,b2){var c2=a2.length;a2.push(b2);a:for(;0<c2;){var d2=c2-1>>>1,e2=a2[d2];if(0<g2(e2,b2))a2[d2]=b2,a2[c2]=e2,c2=d2;else break a}}__name(f2,"f");function h2(a2){return a2.length===0?null:a2[0]}__name(h2,"h");function k2(a2){if(a2.length===0)return null;var b2=a2[0],c2=a2.pop();if(c2!==b2){a2[0]=c2;a:for(var d2=0,e2=a2.length,w2=e2>>>1;d2<w2;){var m2=2*(d2+1)-1,C2=a2[m2],n2=m2+1,x2=a2[n2];if(0>g2(C2,c2))n2<e2&&0>g2(x2,C2)?(a2[d2]=x2,a2[n2]=c2,d2=n2):(a2[d2]=C2,a2[m2]=c2,d2=m2);else if(n2<e2&&0>g2(x2,c2))a2[d2]=x2,a2[n2]=c2,d2=n2;else break a}}return b2}__name(k2,"k");function g2(a2,b2){var c2=a2.sortIndex-b2.sortIndex;return c2!==0?c2:a2.id-b2.id}if(__name(g2,"g"),typeof performance=="object"&&typeof performance.now=="function"){var l2=performance;exports2.unstable_now=function(){return l2.now()}}else{var p2=Date,q2=p2.now();exports2.unstable_now=function(){return p2.now()-q2}}var r2=[],t2=[],u2=1,v2=null,y2=3,z2=!1,A2=!1,B2=!1,D2=typeof setTimeout=="function"?setTimeout:null,E2=typeof clearTimeout=="function"?clearTimeout:null,F2=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function G2(a2){for(var b2=h2(t2);b2!==null;){if(b2.callback===null)k2(t2);else if(b2.startTime<=a2)k2(t2),b2.sortIndex=b2.expirationTime,f2(r2,b2);else break;b2=h2(t2)}}__name(G2,"G");function H2(a2){if(B2=!1,G2(a2),!A2)if(h2(r2)!==null)A2=!0,I2(J2);else{var b2=h2(t2);b2!==null&&K2(H2,b2.startTime-a2)}}__name(H2,"H");function J2(a2,b2){A2=!1,B2&&(B2=!1,E2(L2),L2=-1),z2=!0;var c2=y2;try{for(G2(b2),v2=h2(r2);v2!==null&&(!(v2.expirationTime>b2)||a2&&!M2());){var d2=v2.callback;if(typeof d2=="function"){v2.callback=null,y2=v2.priorityLevel;var e2=d2(v2.expirationTime<=b2);b2=exports2.unstable_now(),typeof e2=="function"?v2.callback=e2:v2===h2(r2)&&k2(r2),G2(b2)}else k2(r2);v2=h2(r2)}if(v2!==null)var w2=!0;else{var m2=h2(t2);m2!==null&&K2(H2,m2.startTime-b2),w2=!1}return w2}finally{v2=null,y2=c2,z2=!1}}__name(J2,"J");var N2=!1,O2=null,L2=-1,P2=5,Q2=-1;function M2(){return!(exports2.unstable_now()-Q2<P2)}__name(M2,"M");function R(){if(O2!==null){var a2=exports2.unstable_now();Q2=a2;var b2=!0;try{b2=O2(!0,a2)}finally{b2?S2():(N2=!1,O2=null)}}else N2=!1}__name(R,"R");var S2;if(typeof F2=="function")S2=__name(function(){F2(R)},"S");else if(typeof MessageChannel<"u"){var T2=new MessageChannel,U2=T2.port2;T2.port1.onmessage=R,S2=__name(function(){U2.postMessage(null)},"S")}else S2=__name(function(){D2(R,0)},"S");function I2(a2){O2=a2,N2||(N2=!0,S2())}__name(I2,"I");function K2(a2,b2){L2=D2(function(){a2(exports2.unstable_now())},b2)}__name(K2,"K"),exports2.unstable_IdlePriority=5,exports2.unstable_ImmediatePriority=1,exports2.unstable_LowPriority=4,exports2.unstable_NormalPriority=3,exports2.unstable_Profiling=null,exports2.unstable_UserBlockingPriority=2,exports2.unstable_cancelCallback=function(a2){a2.callback=null},exports2.unstable_continueExecution=function(){A2||z2||(A2=!0,I2(J2))},exports2.unstable_forceFrameRate=function(a2){0>a2||125<a2?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):P2=0<a2?Math.floor(1e3/a2):5},exports2.unstable_getCurrentPriorityLevel=function(){return y2},exports2.unstable_getFirstCallbackNode=function(){return h2(r2)},exports2.unstable_next=function(a2){switch(y2){case 1:case 2:case 3:var b2=3;break;default:b2=y2}var c2=y2;y2=b2;try{return a2()}finally{y2=c2}},exports2.unstable_pauseExecution=function(){},exports2.unstable_requestPaint=function(){},exports2.unstable_runWithPriority=function(a2,b2){switch(a2){case 1:case 2:case 3:case 4:case 5:break;default:a2=3}var c2=y2;y2=a2;try{return b2()}finally{y2=c2}},exports2.unstable_scheduleCallback=function(a2,b2,c2){var d2=exports2.unstable_now();switch(typeof c2=="object"&&c2!==null?(c2=c2.delay,c2=typeof c2=="number"&&0<c2?d2+c2:d2):c2=d2,a2){case 1:var e2=-1;break;case 2:e2=250;break;case 5:e2=1073741823;break;case 4:e2=1e4;break;default:e2=5e3}return e2=c2+e2,a2={id:u2++,callback:b2,priorityLevel:a2,startTime:c2,expirationTime:e2,sortIndex:-1},c2>d2?(a2.sortIndex=c2,f2(t2,a2),h2(r2)===null&&a2===h2(t2)&&(B2?(E2(L2),L2=-1):B2=!0,K2(H2,c2-d2))):(a2.sortIndex=e2,f2(r2,a2),A2||z2||(A2=!0,I2(J2))),a2},exports2.unstable_shouldYield=M2,exports2.unstable_wrapCallback=function(a2){var b2=y2;return function(){var c2=y2;y2=b2;try{return a2.apply(this,arguments)}finally{y2=c2}}}}(scheduler_production_min)),scheduler_production_min}__name(requireScheduler_production_min,"requireScheduler_production_min");var hasRequiredScheduler;function requireScheduler(){return hasRequiredScheduler||(hasRequiredScheduler=1,scheduler.exports=requireScheduler_production_min()),scheduler.exports}__name(requireScheduler,"requireScheduler");/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var hasRequiredReactDom_production_min;function requireReactDom_production_min(){if(hasRequiredReactDom_production_min)return reactDom_production_min;hasRequiredReactDom_production_min=1;var aa=requireReact(),ca=requireScheduler();function p2(a2){for(var b2="https://reactjs.org/docs/error-decoder.html?invariant="+a2,c2=1;c2<arguments.length;c2++)b2+="&args[]="+encodeURIComponent(arguments[c2]);return"Minified React error #"+a2+"; visit "+b2+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}__name(p2,"p");var da=new Set,ea={};function fa(a2,b2){ha(a2,b2),ha(a2+"Capture",b2)}__name(fa,"fa");function ha(a2,b2){for(ea[a2]=b2,a2=0;a2<b2.length;a2++)da.add(b2[a2])}__name(ha,"ha");var ia=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),ja=Object.prototype.hasOwnProperty,ka=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,la={},ma={};function oa(a2){return ja.call(ma,a2)?!0:ja.call(la,a2)?!1:ka.test(a2)?ma[a2]=!0:(la[a2]=!0,!1)}__name(oa,"oa");function pa(a2,b2,c2,d2){if(c2!==null&&c2.type===0)return!1;switch(typeof b2){case"function":case"symbol":return!0;case"boolean":return d2?!1:c2!==null?!c2.acceptsBooleans:(a2=a2.toLowerCase().slice(0,5),a2!=="data-"&&a2!=="aria-");default:return!1}}__name(pa,"pa");function qa(a2,b2,c2,d2){if(b2===null||typeof b2>"u"||pa(a2,b2,c2,d2))return!0;if(d2)return!1;if(c2!==null)switch(c2.type){case 3:return!b2;case 4:return b2===!1;case 5:return isNaN(b2);case 6:return isNaN(b2)||1>b2}return!1}__name(qa,"qa");function v2(a2,b2,c2,d2,e2,f2,g2){this.acceptsBooleans=b2===2||b2===3||b2===4,this.attributeName=d2,this.attributeNamespace=e2,this.mustUseProperty=c2,this.propertyName=a2,this.type=b2,this.sanitizeURL=f2,this.removeEmptyString=g2}__name(v2,"v");var z2={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a2){z2[a2]=new v2(a2,0,!1,a2,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a2){var b2=a2[0];z2[b2]=new v2(b2,1,!1,a2[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(a2){z2[a2]=new v2(a2,2,!1,a2.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a2){z2[a2]=new v2(a2,2,!1,a2,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a2){z2[a2]=new v2(a2,3,!1,a2.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(a2){z2[a2]=new v2(a2,3,!0,a2,null,!1,!1)}),["capture","download"].forEach(function(a2){z2[a2]=new v2(a2,4,!1,a2,null,!1,!1)}),["cols","rows","size","span"].forEach(function(a2){z2[a2]=new v2(a2,6,!1,a2,null,!1,!1)}),["rowSpan","start"].forEach(function(a2){z2[a2]=new v2(a2,5,!1,a2.toLowerCase(),null,!1,!1)});var ra=/[\-:]([a-z])/g;function sa(a2){return a2[1].toUpperCase()}__name(sa,"sa"),"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a2){var b2=a2.replace(ra,sa);z2[b2]=new v2(b2,1,!1,a2,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a2){var b2=a2.replace(ra,sa);z2[b2]=new v2(b2,1,!1,a2,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(a2){var b2=a2.replace(ra,sa);z2[b2]=new v2(b2,1,!1,a2,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(a2){z2[a2]=new v2(a2,1,!1,a2.toLowerCase(),null,!1,!1)}),z2.xlinkHref=new v2("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(a2){z2[a2]=new v2(a2,1,!1,a2.toLowerCase(),null,!0,!0)});function ta(a2,b2,c2,d2){var e2=z2.hasOwnProperty(b2)?z2[b2]:null;(e2!==null?e2.type!==0:d2||!(2<b2.length)||b2[0]!=="o"&&b2[0]!=="O"||b2[1]!=="n"&&b2[1]!=="N")&&(qa(b2,c2,e2,d2)&&(c2=null),d2||e2===null?oa(b2)&&(c2===null?a2.removeAttribute(b2):a2.setAttribute(b2,""+c2)):e2.mustUseProperty?a2[e2.propertyName]=c2===null?e2.type===3?!1:"":c2:(b2=e2.attributeName,d2=e2.attributeNamespace,c2===null?a2.removeAttribute(b2):(e2=e2.type,c2=e2===3||e2===4&&c2===!0?"":""+c2,d2?a2.setAttributeNS(d2,b2,c2):a2.setAttribute(b2,c2))))}__name(ta,"ta");var ua=aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,va=Symbol.for("react.element"),wa=Symbol.for("react.portal"),ya=Symbol.for("react.fragment"),za=Symbol.for("react.strict_mode"),Aa=Symbol.for("react.profiler"),Ba=Symbol.for("react.provider"),Ca=Symbol.for("react.context"),Da=Symbol.for("react.forward_ref"),Ea=Symbol.for("react.suspense"),Fa=Symbol.for("react.suspense_list"),Ga=Symbol.for("react.memo"),Ha=Symbol.for("react.lazy"),Ia=Symbol.for("react.offscreen"),Ja=Symbol.iterator;function Ka(a2){return a2===null||typeof a2!="object"?null:(a2=Ja&&a2[Ja]||a2["@@iterator"],typeof a2=="function"?a2:null)}__name(Ka,"Ka");var A2=Object.assign,La;function Ma(a2){if(La===void 0)try{throw Error()}catch(c2){var b2=c2.stack.trim().match(/\n( *(at )?)/);La=b2&&b2[1]||""}return`
`+La+a2}__name(Ma,"Ma");var Na=!1;function Oa(a2,b2){if(!a2||Na)return"";Na=!0;var c2=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(b2)if(b2=__name(function(){throw Error()},"b"),Object.defineProperty(b2.prototype,"props",{set:__name(function(){throw Error()},"set")}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(b2,[])}catch(l2){var d2=l2}Reflect.construct(a2,[],b2)}else{try{b2.call()}catch(l2){d2=l2}a2.call(b2.prototype)}else{try{throw Error()}catch(l2){d2=l2}a2()}}catch(l2){if(l2&&d2&&typeof l2.stack=="string"){for(var e2=l2.stack.split(`
`),f2=d2.stack.split(`
`),g2=e2.length-1,h2=f2.length-1;1<=g2&&0<=h2&&e2[g2]!==f2[h2];)h2--;for(;1<=g2&&0<=h2;g2--,h2--)if(e2[g2]!==f2[h2]){if(g2!==1||h2!==1)do if(g2--,h2--,0>h2||e2[g2]!==f2[h2]){var k2=`
`+e2[g2].replace(" at new "," at ");return a2.displayName&&k2.includes("<anonymous>")&&(k2=k2.replace("<anonymous>",a2.displayName)),k2}while(1<=g2&&0<=h2);break}}}finally{Na=!1,Error.prepareStackTrace=c2}return(a2=a2?a2.displayName||a2.name:"")?Ma(a2):""}__name(Oa,"Oa");function Pa(a2){switch(a2.tag){case 5:return Ma(a2.type);case 16:return Ma("Lazy");case 13:return Ma("Suspense");case 19:return Ma("SuspenseList");case 0:case 2:case 15:return a2=Oa(a2.type,!1),a2;case 11:return a2=Oa(a2.type.render,!1),a2;case 1:return a2=Oa(a2.type,!0),a2;default:return""}}__name(Pa,"Pa");function Qa(a2){if(a2==null)return null;if(typeof a2=="function")return a2.displayName||a2.name||null;if(typeof a2=="string")return a2;switch(a2){case ya:return"Fragment";case wa:return"Portal";case Aa:return"Profiler";case za:return"StrictMode";case Ea:return"Suspense";case Fa:return"SuspenseList"}if(typeof a2=="object")switch(a2.$$typeof){case Ca:return(a2.displayName||"Context")+".Consumer";case Ba:return(a2._context.displayName||"Context")+".Provider";case Da:var b2=a2.render;return a2=a2.displayName,a2||(a2=b2.displayName||b2.name||"",a2=a2!==""?"ForwardRef("+a2+")":"ForwardRef"),a2;case Ga:return b2=a2.displayName||null,b2!==null?b2:Qa(a2.type)||"Memo";case Ha:b2=a2._payload,a2=a2._init;try{return Qa(a2(b2))}catch{}}return null}__name(Qa,"Qa");function Ra(a2){var b2=a2.type;switch(a2.tag){case 24:return"Cache";case 9:return(b2.displayName||"Context")+".Consumer";case 10:return(b2._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return a2=b2.render,a2=a2.displayName||a2.name||"",b2.displayName||(a2!==""?"ForwardRef("+a2+")":"ForwardRef");case 7:return"Fragment";case 5:return b2;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Qa(b2);case 8:return b2===za?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof b2=="function")return b2.displayName||b2.name||null;if(typeof b2=="string")return b2}return null}__name(Ra,"Ra");function Sa(a2){switch(typeof a2){case"boolean":case"number":case"string":case"undefined":return a2;case"object":return a2;default:return""}}__name(Sa,"Sa");function Ta(a2){var b2=a2.type;return(a2=a2.nodeName)&&a2.toLowerCase()==="input"&&(b2==="checkbox"||b2==="radio")}__name(Ta,"Ta");function Ua(a2){var b2=Ta(a2)?"checked":"value",c2=Object.getOwnPropertyDescriptor(a2.constructor.prototype,b2),d2=""+a2[b2];if(!a2.hasOwnProperty(b2)&&typeof c2<"u"&&typeof c2.get=="function"&&typeof c2.set=="function"){var e2=c2.get,f2=c2.set;return Object.defineProperty(a2,b2,{configurable:!0,get:__name(function(){return e2.call(this)},"get"),set:__name(function(a3){d2=""+a3,f2.call(this,a3)},"set")}),Object.defineProperty(a2,b2,{enumerable:c2.enumerable}),{getValue:__name(function(){return d2},"getValue"),setValue:__name(function(a3){d2=""+a3},"setValue"),stopTracking:__name(function(){a2._valueTracker=null,delete a2[b2]},"stopTracking")}}}__name(Ua,"Ua");function Va(a2){a2._valueTracker||(a2._valueTracker=Ua(a2))}__name(Va,"Va");function Wa(a2){if(!a2)return!1;var b2=a2._valueTracker;if(!b2)return!0;var c2=b2.getValue(),d2="";return a2&&(d2=Ta(a2)?a2.checked?"true":"false":a2.value),a2=d2,a2!==c2?(b2.setValue(a2),!0):!1}__name(Wa,"Wa");function Xa(a2){if(a2=a2||(typeof document<"u"?document:void 0),typeof a2>"u")return null;try{return a2.activeElement||a2.body}catch{return a2.body}}__name(Xa,"Xa");function Ya(a2,b2){var c2=b2.checked;return A2({},b2,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:c2??a2._wrapperState.initialChecked})}__name(Ya,"Ya");function Za(a2,b2){var c2=b2.defaultValue==null?"":b2.defaultValue,d2=b2.checked!=null?b2.checked:b2.defaultChecked;c2=Sa(b2.value!=null?b2.value:c2),a2._wrapperState={initialChecked:d2,initialValue:c2,controlled:b2.type==="checkbox"||b2.type==="radio"?b2.checked!=null:b2.value!=null}}__name(Za,"Za");function ab(a2,b2){b2=b2.checked,b2!=null&&ta(a2,"checked",b2,!1)}__name(ab,"ab");function bb(a2,b2){ab(a2,b2);var c2=Sa(b2.value),d2=b2.type;if(c2!=null)d2==="number"?(c2===0&&a2.value===""||a2.value!=c2)&&(a2.value=""+c2):a2.value!==""+c2&&(a2.value=""+c2);else if(d2==="submit"||d2==="reset"){a2.removeAttribute("value");return}b2.hasOwnProperty("value")?cb(a2,b2.type,c2):b2.hasOwnProperty("defaultValue")&&cb(a2,b2.type,Sa(b2.defaultValue)),b2.checked==null&&b2.defaultChecked!=null&&(a2.defaultChecked=!!b2.defaultChecked)}__name(bb,"bb");function db(a2,b2,c2){if(b2.hasOwnProperty("value")||b2.hasOwnProperty("defaultValue")){var d2=b2.type;if(!(d2!=="submit"&&d2!=="reset"||b2.value!==void 0&&b2.value!==null))return;b2=""+a2._wrapperState.initialValue,c2||b2===a2.value||(a2.value=b2),a2.defaultValue=b2}c2=a2.name,c2!==""&&(a2.name=""),a2.defaultChecked=!!a2._wrapperState.initialChecked,c2!==""&&(a2.name=c2)}__name(db,"db");function cb(a2,b2,c2){(b2!=="number"||Xa(a2.ownerDocument)!==a2)&&(c2==null?a2.defaultValue=""+a2._wrapperState.initialValue:a2.defaultValue!==""+c2&&(a2.defaultValue=""+c2))}__name(cb,"cb");var eb=Array.isArray;function fb(a2,b2,c2,d2){if(a2=a2.options,b2){b2={};for(var e2=0;e2<c2.length;e2++)b2["$"+c2[e2]]=!0;for(c2=0;c2<a2.length;c2++)e2=b2.hasOwnProperty("$"+a2[c2].value),a2[c2].selected!==e2&&(a2[c2].selected=e2),e2&&d2&&(a2[c2].defaultSelected=!0)}else{for(c2=""+Sa(c2),b2=null,e2=0;e2<a2.length;e2++){if(a2[e2].value===c2){a2[e2].selected=!0,d2&&(a2[e2].defaultSelected=!0);return}b2!==null||a2[e2].disabled||(b2=a2[e2])}b2!==null&&(b2.selected=!0)}}__name(fb,"fb");function gb(a2,b2){if(b2.dangerouslySetInnerHTML!=null)throw Error(p2(91));return A2({},b2,{value:void 0,defaultValue:void 0,children:""+a2._wrapperState.initialValue})}__name(gb,"gb");function hb(a2,b2){var c2=b2.value;if(c2==null){if(c2=b2.children,b2=b2.defaultValue,c2!=null){if(b2!=null)throw Error(p2(92));if(eb(c2)){if(1<c2.length)throw Error(p2(93));c2=c2[0]}b2=c2}b2==null&&(b2=""),c2=b2}a2._wrapperState={initialValue:Sa(c2)}}__name(hb,"hb");function ib(a2,b2){var c2=Sa(b2.value),d2=Sa(b2.defaultValue);c2!=null&&(c2=""+c2,c2!==a2.value&&(a2.value=c2),b2.defaultValue==null&&a2.defaultValue!==c2&&(a2.defaultValue=c2)),d2!=null&&(a2.defaultValue=""+d2)}__name(ib,"ib");function jb(a2){var b2=a2.textContent;b2===a2._wrapperState.initialValue&&b2!==""&&b2!==null&&(a2.value=b2)}__name(jb,"jb");function kb(a2){switch(a2){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}__name(kb,"kb");function lb(a2,b2){return a2==null||a2==="http://www.w3.org/1999/xhtml"?kb(b2):a2==="http://www.w3.org/2000/svg"&&b2==="foreignObject"?"http://www.w3.org/1999/xhtml":a2}__name(lb,"lb");var mb,nb=function(a2){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(b2,c2,d2,e2){MSApp.execUnsafeLocalFunction(function(){return a2(b2,c2,d2,e2)})}:a2}(function(a2,b2){if(a2.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in a2)a2.innerHTML=b2;else{for(mb=mb||document.createElement("div"),mb.innerHTML="<svg>"+b2.valueOf().toString()+"</svg>",b2=mb.firstChild;a2.firstChild;)a2.removeChild(a2.firstChild);for(;b2.firstChild;)a2.appendChild(b2.firstChild)}});function ob(a2,b2){if(b2){var c2=a2.firstChild;if(c2&&c2===a2.lastChild&&c2.nodeType===3){c2.nodeValue=b2;return}}a2.textContent=b2}__name(ob,"ob");var pb={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},qb=["Webkit","ms","Moz","O"];Object.keys(pb).forEach(function(a2){qb.forEach(function(b2){b2=b2+a2.charAt(0).toUpperCase()+a2.substring(1),pb[b2]=pb[a2]})});function rb(a2,b2,c2){return b2==null||typeof b2=="boolean"||b2===""?"":c2||typeof b2!="number"||b2===0||pb.hasOwnProperty(a2)&&pb[a2]?(""+b2).trim():b2+"px"}__name(rb,"rb");function sb(a2,b2){a2=a2.style;for(var c2 in b2)if(b2.hasOwnProperty(c2)){var d2=c2.indexOf("--")===0,e2=rb(c2,b2[c2],d2);c2==="float"&&(c2="cssFloat"),d2?a2.setProperty(c2,e2):a2[c2]=e2}}__name(sb,"sb");var tb=A2({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function ub(a2,b2){if(b2){if(tb[a2]&&(b2.children!=null||b2.dangerouslySetInnerHTML!=null))throw Error(p2(137,a2));if(b2.dangerouslySetInnerHTML!=null){if(b2.children!=null)throw Error(p2(60));if(typeof b2.dangerouslySetInnerHTML!="object"||!("__html"in b2.dangerouslySetInnerHTML))throw Error(p2(61))}if(b2.style!=null&&typeof b2.style!="object")throw Error(p2(62))}}__name(ub,"ub");function vb(a2,b2){if(a2.indexOf("-")===-1)return typeof b2.is=="string";switch(a2){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}__name(vb,"vb");var wb=null;function xb(a2){return a2=a2.target||a2.srcElement||window,a2.correspondingUseElement&&(a2=a2.correspondingUseElement),a2.nodeType===3?a2.parentNode:a2}__name(xb,"xb");var yb=null,zb=null,Ab=null;function Bb(a2){if(a2=Cb(a2)){if(typeof yb!="function")throw Error(p2(280));var b2=a2.stateNode;b2&&(b2=Db(b2),yb(a2.stateNode,a2.type,b2))}}__name(Bb,"Bb");function Eb(a2){zb?Ab?Ab.push(a2):Ab=[a2]:zb=a2}__name(Eb,"Eb");function Fb(){if(zb){var a2=zb,b2=Ab;if(Ab=zb=null,Bb(a2),b2)for(a2=0;a2<b2.length;a2++)Bb(b2[a2])}}__name(Fb,"Fb");function Gb(a2,b2){return a2(b2)}__name(Gb,"Gb");function Hb(){}__name(Hb,"Hb");var Ib=!1;function Jb(a2,b2,c2){if(Ib)return a2(b2,c2);Ib=!0;try{return Gb(a2,b2,c2)}finally{Ib=!1,(zb!==null||Ab!==null)&&(Hb(),Fb())}}__name(Jb,"Jb");function Kb(a2,b2){var c2=a2.stateNode;if(c2===null)return null;var d2=Db(c2);if(d2===null)return null;c2=d2[b2];a:switch(b2){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(d2=!d2.disabled)||(a2=a2.type,d2=!(a2==="button"||a2==="input"||a2==="select"||a2==="textarea")),a2=!d2;break a;default:a2=!1}if(a2)return null;if(c2&&typeof c2!="function")throw Error(p2(231,b2,typeof c2));return c2}__name(Kb,"Kb");var Lb=!1;if(ia)try{var Mb={};Object.defineProperty(Mb,"passive",{get:__name(function(){Lb=!0},"get")}),window.addEventListener("test",Mb,Mb),window.removeEventListener("test",Mb,Mb)}catch{Lb=!1}function Nb(a2,b2,c2,d2,e2,f2,g2,h2,k2){var l2=Array.prototype.slice.call(arguments,3);try{b2.apply(c2,l2)}catch(m2){this.onError(m2)}}__name(Nb,"Nb");var Ob=!1,Pb=null,Qb=!1,Rb=null,Sb={onError:__name(function(a2){Ob=!0,Pb=a2},"onError")};function Tb(a2,b2,c2,d2,e2,f2,g2,h2,k2){Ob=!1,Pb=null,Nb.apply(Sb,arguments)}__name(Tb,"Tb");function Ub(a2,b2,c2,d2,e2,f2,g2,h2,k2){if(Tb.apply(this,arguments),Ob){if(Ob){var l2=Pb;Ob=!1,Pb=null}else throw Error(p2(198));Qb||(Qb=!0,Rb=l2)}}__name(Ub,"Ub");function Vb(a2){var b2=a2,c2=a2;if(a2.alternate)for(;b2.return;)b2=b2.return;else{a2=b2;do b2=a2,(b2.flags&4098)!==0&&(c2=b2.return),a2=b2.return;while(a2)}return b2.tag===3?c2:null}__name(Vb,"Vb");function Wb(a2){if(a2.tag===13){var b2=a2.memoizedState;if(b2===null&&(a2=a2.alternate,a2!==null&&(b2=a2.memoizedState)),b2!==null)return b2.dehydrated}return null}__name(Wb,"Wb");function Xb(a2){if(Vb(a2)!==a2)throw Error(p2(188))}__name(Xb,"Xb");function Yb(a2){var b2=a2.alternate;if(!b2){if(b2=Vb(a2),b2===null)throw Error(p2(188));return b2!==a2?null:a2}for(var c2=a2,d2=b2;;){var e2=c2.return;if(e2===null)break;var f2=e2.alternate;if(f2===null){if(d2=e2.return,d2!==null){c2=d2;continue}break}if(e2.child===f2.child){for(f2=e2.child;f2;){if(f2===c2)return Xb(e2),a2;if(f2===d2)return Xb(e2),b2;f2=f2.sibling}throw Error(p2(188))}if(c2.return!==d2.return)c2=e2,d2=f2;else{for(var g2=!1,h2=e2.child;h2;){if(h2===c2){g2=!0,c2=e2,d2=f2;break}if(h2===d2){g2=!0,d2=e2,c2=f2;break}h2=h2.sibling}if(!g2){for(h2=f2.child;h2;){if(h2===c2){g2=!0,c2=f2,d2=e2;break}if(h2===d2){g2=!0,d2=f2,c2=e2;break}h2=h2.sibling}if(!g2)throw Error(p2(189))}}if(c2.alternate!==d2)throw Error(p2(190))}if(c2.tag!==3)throw Error(p2(188));return c2.stateNode.current===c2?a2:b2}__name(Yb,"Yb");function Zb(a2){return a2=Yb(a2),a2!==null?$b(a2):null}__name(Zb,"Zb");function $b(a2){if(a2.tag===5||a2.tag===6)return a2;for(a2=a2.child;a2!==null;){var b2=$b(a2);if(b2!==null)return b2;a2=a2.sibling}return null}__name($b,"$b");var ac=ca.unstable_scheduleCallback,bc=ca.unstable_cancelCallback,cc=ca.unstable_shouldYield,dc=ca.unstable_requestPaint,B2=ca.unstable_now,ec=ca.unstable_getCurrentPriorityLevel,fc=ca.unstable_ImmediatePriority,gc=ca.unstable_UserBlockingPriority,hc=ca.unstable_NormalPriority,ic=ca.unstable_LowPriority,jc=ca.unstable_IdlePriority,kc=null,lc=null;function mc(a2){if(lc&&typeof lc.onCommitFiberRoot=="function")try{lc.onCommitFiberRoot(kc,a2,void 0,(a2.current.flags&128)===128)}catch{}}__name(mc,"mc");var oc=Math.clz32?Math.clz32:nc,pc=Math.log,qc=Math.LN2;function nc(a2){return a2>>>=0,a2===0?32:31-(pc(a2)/qc|0)|0}__name(nc,"nc");var rc=64,sc=4194304;function tc(a2){switch(a2&-a2){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return a2&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return a2&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return a2}}__name(tc,"tc");function uc(a2,b2){var c2=a2.pendingLanes;if(c2===0)return 0;var d2=0,e2=a2.suspendedLanes,f2=a2.pingedLanes,g2=c2&268435455;if(g2!==0){var h2=g2&~e2;h2!==0?d2=tc(h2):(f2&=g2,f2!==0&&(d2=tc(f2)))}else g2=c2&~e2,g2!==0?d2=tc(g2):f2!==0&&(d2=tc(f2));if(d2===0)return 0;if(b2!==0&&b2!==d2&&(b2&e2)===0&&(e2=d2&-d2,f2=b2&-b2,e2>=f2||e2===16&&(f2&4194240)!==0))return b2;if((d2&4)!==0&&(d2|=c2&16),b2=a2.entangledLanes,b2!==0)for(a2=a2.entanglements,b2&=d2;0<b2;)c2=31-oc(b2),e2=1<<c2,d2|=a2[c2],b2&=~e2;return d2}__name(uc,"uc");function vc(a2,b2){switch(a2){case 1:case 2:case 4:return b2+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return b2+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}__name(vc,"vc");function wc(a2,b2){for(var c2=a2.suspendedLanes,d2=a2.pingedLanes,e2=a2.expirationTimes,f2=a2.pendingLanes;0<f2;){var g2=31-oc(f2),h2=1<<g2,k2=e2[g2];k2===-1?((h2&c2)===0||(h2&d2)!==0)&&(e2[g2]=vc(h2,b2)):k2<=b2&&(a2.expiredLanes|=h2),f2&=~h2}}__name(wc,"wc");function xc(a2){return a2=a2.pendingLanes&-1073741825,a2!==0?a2:a2&1073741824?1073741824:0}__name(xc,"xc");function yc(){var a2=rc;return rc<<=1,(rc&4194240)===0&&(rc=64),a2}__name(yc,"yc");function zc(a2){for(var b2=[],c2=0;31>c2;c2++)b2.push(a2);return b2}__name(zc,"zc");function Ac(a2,b2,c2){a2.pendingLanes|=b2,b2!==536870912&&(a2.suspendedLanes=0,a2.pingedLanes=0),a2=a2.eventTimes,b2=31-oc(b2),a2[b2]=c2}__name(Ac,"Ac");function Bc(a2,b2){var c2=a2.pendingLanes&~b2;a2.pendingLanes=b2,a2.suspendedLanes=0,a2.pingedLanes=0,a2.expiredLanes&=b2,a2.mutableReadLanes&=b2,a2.entangledLanes&=b2,b2=a2.entanglements;var d2=a2.eventTimes;for(a2=a2.expirationTimes;0<c2;){var e2=31-oc(c2),f2=1<<e2;b2[e2]=0,d2[e2]=-1,a2[e2]=-1,c2&=~f2}}__name(Bc,"Bc");function Cc(a2,b2){var c2=a2.entangledLanes|=b2;for(a2=a2.entanglements;c2;){var d2=31-oc(c2),e2=1<<d2;e2&b2|a2[d2]&b2&&(a2[d2]|=b2),c2&=~e2}}__name(Cc,"Cc");var C2=0;function Dc(a2){return a2&=-a2,1<a2?4<a2?(a2&268435455)!==0?16:536870912:4:1}__name(Dc,"Dc");var Ec,Fc,Gc,Hc,Ic,Jc=!1,Kc=[],Lc=null,Mc=null,Nc=null,Oc=new Map,Pc=new Map,Qc=[],Rc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Sc(a2,b2){switch(a2){case"focusin":case"focusout":Lc=null;break;case"dragenter":case"dragleave":Mc=null;break;case"mouseover":case"mouseout":Nc=null;break;case"pointerover":case"pointerout":Oc.delete(b2.pointerId);break;case"gotpointercapture":case"lostpointercapture":Pc.delete(b2.pointerId)}}__name(Sc,"Sc");function Tc(a2,b2,c2,d2,e2,f2){return a2===null||a2.nativeEvent!==f2?(a2={blockedOn:b2,domEventName:c2,eventSystemFlags:d2,nativeEvent:f2,targetContainers:[e2]},b2!==null&&(b2=Cb(b2),b2!==null&&Fc(b2)),a2):(a2.eventSystemFlags|=d2,b2=a2.targetContainers,e2!==null&&b2.indexOf(e2)===-1&&b2.push(e2),a2)}__name(Tc,"Tc");function Uc(a2,b2,c2,d2,e2){switch(b2){case"focusin":return Lc=Tc(Lc,a2,b2,c2,d2,e2),!0;case"dragenter":return Mc=Tc(Mc,a2,b2,c2,d2,e2),!0;case"mouseover":return Nc=Tc(Nc,a2,b2,c2,d2,e2),!0;case"pointerover":var f2=e2.pointerId;return Oc.set(f2,Tc(Oc.get(f2)||null,a2,b2,c2,d2,e2)),!0;case"gotpointercapture":return f2=e2.pointerId,Pc.set(f2,Tc(Pc.get(f2)||null,a2,b2,c2,d2,e2)),!0}return!1}__name(Uc,"Uc");function Vc(a2){var b2=Wc(a2.target);if(b2!==null){var c2=Vb(b2);if(c2!==null){if(b2=c2.tag,b2===13){if(b2=Wb(c2),b2!==null){a2.blockedOn=b2,Ic(a2.priority,function(){Gc(c2)});return}}else if(b2===3&&c2.stateNode.current.memoizedState.isDehydrated){a2.blockedOn=c2.tag===3?c2.stateNode.containerInfo:null;return}}}a2.blockedOn=null}__name(Vc,"Vc");function Xc(a2){if(a2.blockedOn!==null)return!1;for(var b2=a2.targetContainers;0<b2.length;){var c2=Yc(a2.domEventName,a2.eventSystemFlags,b2[0],a2.nativeEvent);if(c2===null){c2=a2.nativeEvent;var d2=new c2.constructor(c2.type,c2);wb=d2,c2.target.dispatchEvent(d2),wb=null}else return b2=Cb(c2),b2!==null&&Fc(b2),a2.blockedOn=c2,!1;b2.shift()}return!0}__name(Xc,"Xc");function Zc(a2,b2,c2){Xc(a2)&&c2.delete(b2)}__name(Zc,"Zc");function $c(){Jc=!1,Lc!==null&&Xc(Lc)&&(Lc=null),Mc!==null&&Xc(Mc)&&(Mc=null),Nc!==null&&Xc(Nc)&&(Nc=null),Oc.forEach(Zc),Pc.forEach(Zc)}__name($c,"$c");function ad(a2,b2){a2.blockedOn===b2&&(a2.blockedOn=null,Jc||(Jc=!0,ca.unstable_scheduleCallback(ca.unstable_NormalPriority,$c)))}__name(ad,"ad");function bd(a2){function b2(b3){return ad(b3,a2)}if(__name(b2,"b"),0<Kc.length){ad(Kc[0],a2);for(var c2=1;c2<Kc.length;c2++){var d2=Kc[c2];d2.blockedOn===a2&&(d2.blockedOn=null)}}for(Lc!==null&&ad(Lc,a2),Mc!==null&&ad(Mc,a2),Nc!==null&&ad(Nc,a2),Oc.forEach(b2),Pc.forEach(b2),c2=0;c2<Qc.length;c2++)d2=Qc[c2],d2.blockedOn===a2&&(d2.blockedOn=null);for(;0<Qc.length&&(c2=Qc[0],c2.blockedOn===null);)Vc(c2),c2.blockedOn===null&&Qc.shift()}__name(bd,"bd");var cd=ua.ReactCurrentBatchConfig,dd=!0;function ed(a2,b2,c2,d2){var e2=C2,f2=cd.transition;cd.transition=null;try{C2=1,fd(a2,b2,c2,d2)}finally{C2=e2,cd.transition=f2}}__name(ed,"ed");function gd(a2,b2,c2,d2){var e2=C2,f2=cd.transition;cd.transition=null;try{C2=4,fd(a2,b2,c2,d2)}finally{C2=e2,cd.transition=f2}}__name(gd,"gd");function fd(a2,b2,c2,d2){if(dd){var e2=Yc(a2,b2,c2,d2);if(e2===null)hd(a2,b2,d2,id,c2),Sc(a2,d2);else if(Uc(e2,a2,b2,c2,d2))d2.stopPropagation();else if(Sc(a2,d2),b2&4&&-1<Rc.indexOf(a2)){for(;e2!==null;){var f2=Cb(e2);if(f2!==null&&Ec(f2),f2=Yc(a2,b2,c2,d2),f2===null&&hd(a2,b2,d2,id,c2),f2===e2)break;e2=f2}e2!==null&&d2.stopPropagation()}else hd(a2,b2,d2,null,c2)}}__name(fd,"fd");var id=null;function Yc(a2,b2,c2,d2){if(id=null,a2=xb(d2),a2=Wc(a2),a2!==null)if(b2=Vb(a2),b2===null)a2=null;else if(c2=b2.tag,c2===13){if(a2=Wb(b2),a2!==null)return a2;a2=null}else if(c2===3){if(b2.stateNode.current.memoizedState.isDehydrated)return b2.tag===3?b2.stateNode.containerInfo:null;a2=null}else b2!==a2&&(a2=null);return id=a2,null}__name(Yc,"Yc");function jd(a2){switch(a2){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(ec()){case fc:return 1;case gc:return 4;case hc:case ic:return 16;case jc:return 536870912;default:return 16}default:return 16}}__name(jd,"jd");var kd=null,ld=null,md=null;function nd(){if(md)return md;var a2,b2=ld,c2=b2.length,d2,e2="value"in kd?kd.value:kd.textContent,f2=e2.length;for(a2=0;a2<c2&&b2[a2]===e2[a2];a2++);var g2=c2-a2;for(d2=1;d2<=g2&&b2[c2-d2]===e2[f2-d2];d2++);return md=e2.slice(a2,1<d2?1-d2:void 0)}__name(nd,"nd");function od(a2){var b2=a2.keyCode;return"charCode"in a2?(a2=a2.charCode,a2===0&&b2===13&&(a2=13)):a2=b2,a2===10&&(a2=13),32<=a2||a2===13?a2:0}__name(od,"od");function pd(){return!0}__name(pd,"pd");function qd(){return!1}__name(qd,"qd");function rd(a2){function b2(b3,d2,e2,f2,g2){this._reactName=b3,this._targetInst=e2,this.type=d2,this.nativeEvent=f2,this.target=g2,this.currentTarget=null;for(var c2 in a2)a2.hasOwnProperty(c2)&&(b3=a2[c2],this[c2]=b3?b3(f2):f2[c2]);return this.isDefaultPrevented=(f2.defaultPrevented!=null?f2.defaultPrevented:f2.returnValue===!1)?pd:qd,this.isPropagationStopped=qd,this}return __name(b2,"b"),A2(b2.prototype,{preventDefault:__name(function(){this.defaultPrevented=!0;var a3=this.nativeEvent;a3&&(a3.preventDefault?a3.preventDefault():typeof a3.returnValue!="unknown"&&(a3.returnValue=!1),this.isDefaultPrevented=pd)},"preventDefault"),stopPropagation:__name(function(){var a3=this.nativeEvent;a3&&(a3.stopPropagation?a3.stopPropagation():typeof a3.cancelBubble!="unknown"&&(a3.cancelBubble=!0),this.isPropagationStopped=pd)},"stopPropagation"),persist:__name(function(){},"persist"),isPersistent:pd}),b2}__name(rd,"rd");var sd={eventPhase:0,bubbles:0,cancelable:0,timeStamp:__name(function(a2){return a2.timeStamp||Date.now()},"timeStamp"),defaultPrevented:0,isTrusted:0},td=rd(sd),ud=A2({},sd,{view:0,detail:0}),vd=rd(ud),wd,xd,yd,Ad=A2({},ud,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zd,button:0,buttons:0,relatedTarget:__name(function(a2){return a2.relatedTarget===void 0?a2.fromElement===a2.srcElement?a2.toElement:a2.fromElement:a2.relatedTarget},"relatedTarget"),movementX:__name(function(a2){return"movementX"in a2?a2.movementX:(a2!==yd&&(yd&&a2.type==="mousemove"?(wd=a2.screenX-yd.screenX,xd=a2.screenY-yd.screenY):xd=wd=0,yd=a2),wd)},"movementX"),movementY:__name(function(a2){return"movementY"in a2?a2.movementY:xd},"movementY")}),Bd=rd(Ad),Cd=A2({},Ad,{dataTransfer:0}),Dd=rd(Cd),Ed=A2({},ud,{relatedTarget:0}),Fd=rd(Ed),Gd=A2({},sd,{animationName:0,elapsedTime:0,pseudoElement:0}),Hd=rd(Gd),Id=A2({},sd,{clipboardData:__name(function(a2){return"clipboardData"in a2?a2.clipboardData:window.clipboardData},"clipboardData")}),Jd=rd(Id),Kd=A2({},sd,{data:0}),Ld=rd(Kd),Md={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nd={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Od={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pd(a2){var b2=this.nativeEvent;return b2.getModifierState?b2.getModifierState(a2):(a2=Od[a2])?!!b2[a2]:!1}__name(Pd,"Pd");function zd(){return Pd}__name(zd,"zd");var Qd=A2({},ud,{key:__name(function(a2){if(a2.key){var b2=Md[a2.key]||a2.key;if(b2!=="Unidentified")return b2}return a2.type==="keypress"?(a2=od(a2),a2===13?"Enter":String.fromCharCode(a2)):a2.type==="keydown"||a2.type==="keyup"?Nd[a2.keyCode]||"Unidentified":""},"key"),code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zd,charCode:__name(function(a2){return a2.type==="keypress"?od(a2):0},"charCode"),keyCode:__name(function(a2){return a2.type==="keydown"||a2.type==="keyup"?a2.keyCode:0},"keyCode"),which:__name(function(a2){return a2.type==="keypress"?od(a2):a2.type==="keydown"||a2.type==="keyup"?a2.keyCode:0},"which")}),Rd=rd(Qd),Sd=A2({},Ad,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Td=rd(Sd),Ud=A2({},ud,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zd}),Vd=rd(Ud),Wd=A2({},sd,{propertyName:0,elapsedTime:0,pseudoElement:0}),Xd=rd(Wd),Yd=A2({},Ad,{deltaX:__name(function(a2){return"deltaX"in a2?a2.deltaX:"wheelDeltaX"in a2?-a2.wheelDeltaX:0},"deltaX"),deltaY:__name(function(a2){return"deltaY"in a2?a2.deltaY:"wheelDeltaY"in a2?-a2.wheelDeltaY:"wheelDelta"in a2?-a2.wheelDelta:0},"deltaY"),deltaZ:0,deltaMode:0}),Zd=rd(Yd),$d=[9,13,27,32],ae=ia&&"CompositionEvent"in window,be=null;ia&&"documentMode"in document&&(be=document.documentMode);var ce=ia&&"TextEvent"in window&&!be,de=ia&&(!ae||be&&8<be&&11>=be),ee=" ",fe=!1;function ge(a2,b2){switch(a2){case"keyup":return $d.indexOf(b2.keyCode)!==-1;case"keydown":return b2.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}__name(ge,"ge");function he(a2){return a2=a2.detail,typeof a2=="object"&&"data"in a2?a2.data:null}__name(he,"he");var ie=!1;function je(a2,b2){switch(a2){case"compositionend":return he(b2);case"keypress":return b2.which!==32?null:(fe=!0,ee);case"textInput":return a2=b2.data,a2===ee&&fe?null:a2;default:return null}}__name(je,"je");function ke(a2,b2){if(ie)return a2==="compositionend"||!ae&&ge(a2,b2)?(a2=nd(),md=ld=kd=null,ie=!1,a2):null;switch(a2){case"paste":return null;case"keypress":if(!(b2.ctrlKey||b2.altKey||b2.metaKey)||b2.ctrlKey&&b2.altKey){if(b2.char&&1<b2.char.length)return b2.char;if(b2.which)return String.fromCharCode(b2.which)}return null;case"compositionend":return de&&b2.locale!=="ko"?null:b2.data;default:return null}}__name(ke,"ke");var le={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function me(a2){var b2=a2&&a2.nodeName&&a2.nodeName.toLowerCase();return b2==="input"?!!le[a2.type]:b2==="textarea"}__name(me,"me");function ne(a2,b2,c2,d2){Eb(d2),b2=oe(b2,"onChange"),0<b2.length&&(c2=new td("onChange","change",null,c2,d2),a2.push({event:c2,listeners:b2}))}__name(ne,"ne");var pe=null,qe=null;function re(a2){se(a2,0)}__name(re,"re");function te(a2){var b2=ue(a2);if(Wa(b2))return a2}__name(te,"te");function ve(a2,b2){if(a2==="change")return b2}__name(ve,"ve");var we=!1;if(ia){var xe;if(ia){var ye="oninput"in document;if(!ye){var ze=document.createElement("div");ze.setAttribute("oninput","return;"),ye=typeof ze.oninput=="function"}xe=ye}else xe=!1;we=xe&&(!document.documentMode||9<document.documentMode)}function Ae(){pe&&(pe.detachEvent("onpropertychange",Be),qe=pe=null)}__name(Ae,"Ae");function Be(a2){if(a2.propertyName==="value"&&te(qe)){var b2=[];ne(b2,qe,a2,xb(a2)),Jb(re,b2)}}__name(Be,"Be");function Ce(a2,b2,c2){a2==="focusin"?(Ae(),pe=b2,qe=c2,pe.attachEvent("onpropertychange",Be)):a2==="focusout"&&Ae()}__name(Ce,"Ce");function De(a2){if(a2==="selectionchange"||a2==="keyup"||a2==="keydown")return te(qe)}__name(De,"De");function Ee(a2,b2){if(a2==="click")return te(b2)}__name(Ee,"Ee");function Fe(a2,b2){if(a2==="input"||a2==="change")return te(b2)}__name(Fe,"Fe");function Ge(a2,b2){return a2===b2&&(a2!==0||1/a2===1/b2)||a2!==a2&&b2!==b2}__name(Ge,"Ge");var He=typeof Object.is=="function"?Object.is:Ge;function Ie(a2,b2){if(He(a2,b2))return!0;if(typeof a2!="object"||a2===null||typeof b2!="object"||b2===null)return!1;var c2=Object.keys(a2),d2=Object.keys(b2);if(c2.length!==d2.length)return!1;for(d2=0;d2<c2.length;d2++){var e2=c2[d2];if(!ja.call(b2,e2)||!He(a2[e2],b2[e2]))return!1}return!0}__name(Ie,"Ie");function Je(a2){for(;a2&&a2.firstChild;)a2=a2.firstChild;return a2}__name(Je,"Je");function Ke(a2,b2){var c2=Je(a2);a2=0;for(var d2;c2;){if(c2.nodeType===3){if(d2=a2+c2.textContent.length,a2<=b2&&d2>=b2)return{node:c2,offset:b2-a2};a2=d2}a:{for(;c2;){if(c2.nextSibling){c2=c2.nextSibling;break a}c2=c2.parentNode}c2=void 0}c2=Je(c2)}}__name(Ke,"Ke");function Le(a2,b2){return a2&&b2?a2===b2?!0:a2&&a2.nodeType===3?!1:b2&&b2.nodeType===3?Le(a2,b2.parentNode):"contains"in a2?a2.contains(b2):a2.compareDocumentPosition?!!(a2.compareDocumentPosition(b2)&16):!1:!1}__name(Le,"Le");function Me(){for(var a2=window,b2=Xa();b2 instanceof a2.HTMLIFrameElement;){try{var c2=typeof b2.contentWindow.location.href=="string"}catch{c2=!1}if(c2)a2=b2.contentWindow;else break;b2=Xa(a2.document)}return b2}__name(Me,"Me");function Ne(a2){var b2=a2&&a2.nodeName&&a2.nodeName.toLowerCase();return b2&&(b2==="input"&&(a2.type==="text"||a2.type==="search"||a2.type==="tel"||a2.type==="url"||a2.type==="password")||b2==="textarea"||a2.contentEditable==="true")}__name(Ne,"Ne");function Oe(a2){var b2=Me(),c2=a2.focusedElem,d2=a2.selectionRange;if(b2!==c2&&c2&&c2.ownerDocument&&Le(c2.ownerDocument.documentElement,c2)){if(d2!==null&&Ne(c2)){if(b2=d2.start,a2=d2.end,a2===void 0&&(a2=b2),"selectionStart"in c2)c2.selectionStart=b2,c2.selectionEnd=Math.min(a2,c2.value.length);else if(a2=(b2=c2.ownerDocument||document)&&b2.defaultView||window,a2.getSelection){a2=a2.getSelection();var e2=c2.textContent.length,f2=Math.min(d2.start,e2);d2=d2.end===void 0?f2:Math.min(d2.end,e2),!a2.extend&&f2>d2&&(e2=d2,d2=f2,f2=e2),e2=Ke(c2,f2);var g2=Ke(c2,d2);e2&&g2&&(a2.rangeCount!==1||a2.anchorNode!==e2.node||a2.anchorOffset!==e2.offset||a2.focusNode!==g2.node||a2.focusOffset!==g2.offset)&&(b2=b2.createRange(),b2.setStart(e2.node,e2.offset),a2.removeAllRanges(),f2>d2?(a2.addRange(b2),a2.extend(g2.node,g2.offset)):(b2.setEnd(g2.node,g2.offset),a2.addRange(b2)))}}for(b2=[],a2=c2;a2=a2.parentNode;)a2.nodeType===1&&b2.push({element:a2,left:a2.scrollLeft,top:a2.scrollTop});for(typeof c2.focus=="function"&&c2.focus(),c2=0;c2<b2.length;c2++)a2=b2[c2],a2.element.scrollLeft=a2.left,a2.element.scrollTop=a2.top}}__name(Oe,"Oe");var Pe=ia&&"documentMode"in document&&11>=document.documentMode,Qe=null,Re=null,Se=null,Te=!1;function Ue(a2,b2,c2){var d2=c2.window===c2?c2.document:c2.nodeType===9?c2:c2.ownerDocument;Te||Qe==null||Qe!==Xa(d2)||(d2=Qe,"selectionStart"in d2&&Ne(d2)?d2={start:d2.selectionStart,end:d2.selectionEnd}:(d2=(d2.ownerDocument&&d2.ownerDocument.defaultView||window).getSelection(),d2={anchorNode:d2.anchorNode,anchorOffset:d2.anchorOffset,focusNode:d2.focusNode,focusOffset:d2.focusOffset}),Se&&Ie(Se,d2)||(Se=d2,d2=oe(Re,"onSelect"),0<d2.length&&(b2=new td("onSelect","select",null,b2,c2),a2.push({event:b2,listeners:d2}),b2.target=Qe)))}__name(Ue,"Ue");function Ve(a2,b2){var c2={};return c2[a2.toLowerCase()]=b2.toLowerCase(),c2["Webkit"+a2]="webkit"+b2,c2["Moz"+a2]="moz"+b2,c2}__name(Ve,"Ve");var We={animationend:Ve("Animation","AnimationEnd"),animationiteration:Ve("Animation","AnimationIteration"),animationstart:Ve("Animation","AnimationStart"),transitionend:Ve("Transition","TransitionEnd")},Xe={},Ye={};ia&&(Ye=document.createElement("div").style,"AnimationEvent"in window||(delete We.animationend.animation,delete We.animationiteration.animation,delete We.animationstart.animation),"TransitionEvent"in window||delete We.transitionend.transition);function Ze(a2){if(Xe[a2])return Xe[a2];if(!We[a2])return a2;var b2=We[a2],c2;for(c2 in b2)if(b2.hasOwnProperty(c2)&&c2 in Ye)return Xe[a2]=b2[c2];return a2}__name(Ze,"Ze");var $e=Ze("animationend"),af=Ze("animationiteration"),bf=Ze("animationstart"),cf=Ze("transitionend"),df=new Map,ef="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function ff(a2,b2){df.set(a2,b2),fa(b2,[a2])}__name(ff,"ff");for(var gf=0;gf<ef.length;gf++){var hf=ef[gf],jf=hf.toLowerCase(),kf=hf[0].toUpperCase()+hf.slice(1);ff(jf,"on"+kf)}ff($e,"onAnimationEnd"),ff(af,"onAnimationIteration"),ff(bf,"onAnimationStart"),ff("dblclick","onDoubleClick"),ff("focusin","onFocus"),ff("focusout","onBlur"),ff(cf,"onTransitionEnd"),ha("onMouseEnter",["mouseout","mouseover"]),ha("onMouseLeave",["mouseout","mouseover"]),ha("onPointerEnter",["pointerout","pointerover"]),ha("onPointerLeave",["pointerout","pointerover"]),fa("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),fa("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),fa("onBeforeInput",["compositionend","keypress","textInput","paste"]),fa("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),fa("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),fa("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var lf="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),mf=new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));function nf(a2,b2,c2){var d2=a2.type||"unknown-event";a2.currentTarget=c2,Ub(d2,b2,void 0,a2),a2.currentTarget=null}__name(nf,"nf");function se(a2,b2){b2=(b2&4)!==0;for(var c2=0;c2<a2.length;c2++){var d2=a2[c2],e2=d2.event;d2=d2.listeners;a:{var f2=void 0;if(b2)for(var g2=d2.length-1;0<=g2;g2--){var h2=d2[g2],k2=h2.instance,l2=h2.currentTarget;if(h2=h2.listener,k2!==f2&&e2.isPropagationStopped())break a;nf(e2,h2,l2),f2=k2}else for(g2=0;g2<d2.length;g2++){if(h2=d2[g2],k2=h2.instance,l2=h2.currentTarget,h2=h2.listener,k2!==f2&&e2.isPropagationStopped())break a;nf(e2,h2,l2),f2=k2}}}if(Qb)throw a2=Rb,Qb=!1,Rb=null,a2}__name(se,"se");function D2(a2,b2){var c2=b2[of];c2===void 0&&(c2=b2[of]=new Set);var d2=a2+"__bubble";c2.has(d2)||(pf(b2,a2,2,!1),c2.add(d2))}__name(D2,"D");function qf(a2,b2,c2){var d2=0;b2&&(d2|=4),pf(c2,a2,d2,b2)}__name(qf,"qf");var rf="_reactListening"+Math.random().toString(36).slice(2);function sf(a2){if(!a2[rf]){a2[rf]=!0,da.forEach(function(b3){b3!=="selectionchange"&&(mf.has(b3)||qf(b3,!1,a2),qf(b3,!0,a2))});var b2=a2.nodeType===9?a2:a2.ownerDocument;b2===null||b2[rf]||(b2[rf]=!0,qf("selectionchange",!1,b2))}}__name(sf,"sf");function pf(a2,b2,c2,d2){switch(jd(b2)){case 1:var e2=ed;break;case 4:e2=gd;break;default:e2=fd}c2=e2.bind(null,b2,c2,a2),e2=void 0,!Lb||b2!=="touchstart"&&b2!=="touchmove"&&b2!=="wheel"||(e2=!0),d2?e2!==void 0?a2.addEventListener(b2,c2,{capture:!0,passive:e2}):a2.addEventListener(b2,c2,!0):e2!==void 0?a2.addEventListener(b2,c2,{passive:e2}):a2.addEventListener(b2,c2,!1)}__name(pf,"pf");function hd(a2,b2,c2,d2,e2){var f2=d2;if((b2&1)===0&&(b2&2)===0&&d2!==null)a:for(;;){if(d2===null)return;var g2=d2.tag;if(g2===3||g2===4){var h2=d2.stateNode.containerInfo;if(h2===e2||h2.nodeType===8&&h2.parentNode===e2)break;if(g2===4)for(g2=d2.return;g2!==null;){var k2=g2.tag;if((k2===3||k2===4)&&(k2=g2.stateNode.containerInfo,k2===e2||k2.nodeType===8&&k2.parentNode===e2))return;g2=g2.return}for(;h2!==null;){if(g2=Wc(h2),g2===null)return;if(k2=g2.tag,k2===5||k2===6){d2=f2=g2;continue a}h2=h2.parentNode}}d2=d2.return}Jb(function(){var d3=f2,e3=xb(c2),g3=[];a:{var h3=df.get(a2);if(h3!==void 0){var k3=td,n2=a2;switch(a2){case"keypress":if(od(c2)===0)break a;case"keydown":case"keyup":k3=Rd;break;case"focusin":n2="focus",k3=Fd;break;case"focusout":n2="blur",k3=Fd;break;case"beforeblur":case"afterblur":k3=Fd;break;case"click":if(c2.button===2)break a;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":k3=Bd;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":k3=Dd;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":k3=Vd;break;case $e:case af:case bf:k3=Hd;break;case cf:k3=Xd;break;case"scroll":k3=vd;break;case"wheel":k3=Zd;break;case"copy":case"cut":case"paste":k3=Jd;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":k3=Td}var t2=(b2&4)!==0,J2=!t2&&a2==="scroll",x2=t2?h3!==null?h3+"Capture":null:h3;t2=[];for(var w2=d3,u2;w2!==null;){u2=w2;var F2=u2.stateNode;if(u2.tag===5&&F2!==null&&(u2=F2,x2!==null&&(F2=Kb(w2,x2),F2!=null&&t2.push(tf(w2,F2,u2)))),J2)break;w2=w2.return}0<t2.length&&(h3=new k3(h3,n2,null,c2,e3),g3.push({event:h3,listeners:t2}))}}if((b2&7)===0){a:{if(h3=a2==="mouseover"||a2==="pointerover",k3=a2==="mouseout"||a2==="pointerout",h3&&c2!==wb&&(n2=c2.relatedTarget||c2.fromElement)&&(Wc(n2)||n2[uf]))break a;if((k3||h3)&&(h3=e3.window===e3?e3:(h3=e3.ownerDocument)?h3.defaultView||h3.parentWindow:window,k3?(n2=c2.relatedTarget||c2.toElement,k3=d3,n2=n2?Wc(n2):null,n2!==null&&(J2=Vb(n2),n2!==J2||n2.tag!==5&&n2.tag!==6)&&(n2=null)):(k3=null,n2=d3),k3!==n2)){if(t2=Bd,F2="onMouseLeave",x2="onMouseEnter",w2="mouse",(a2==="pointerout"||a2==="pointerover")&&(t2=Td,F2="onPointerLeave",x2="onPointerEnter",w2="pointer"),J2=k3==null?h3:ue(k3),u2=n2==null?h3:ue(n2),h3=new t2(F2,w2+"leave",k3,c2,e3),h3.target=J2,h3.relatedTarget=u2,F2=null,Wc(e3)===d3&&(t2=new t2(x2,w2+"enter",n2,c2,e3),t2.target=u2,t2.relatedTarget=J2,F2=t2),J2=F2,k3&&n2)b:{for(t2=k3,x2=n2,w2=0,u2=t2;u2;u2=vf(u2))w2++;for(u2=0,F2=x2;F2;F2=vf(F2))u2++;for(;0<w2-u2;)t2=vf(t2),w2--;for(;0<u2-w2;)x2=vf(x2),u2--;for(;w2--;){if(t2===x2||x2!==null&&t2===x2.alternate)break b;t2=vf(t2),x2=vf(x2)}t2=null}else t2=null;k3!==null&&wf(g3,h3,k3,t2,!1),n2!==null&&J2!==null&&wf(g3,J2,n2,t2,!0)}}a:{if(h3=d3?ue(d3):window,k3=h3.nodeName&&h3.nodeName.toLowerCase(),k3==="select"||k3==="input"&&h3.type==="file")var na=ve;else if(me(h3))if(we)na=Fe;else{na=De;var xa=Ce}else(k3=h3.nodeName)&&k3.toLowerCase()==="input"&&(h3.type==="checkbox"||h3.type==="radio")&&(na=Ee);if(na&&(na=na(a2,d3))){ne(g3,na,c2,e3);break a}xa&&xa(a2,h3,d3),a2==="focusout"&&(xa=h3._wrapperState)&&xa.controlled&&h3.type==="number"&&cb(h3,"number",h3.value)}switch(xa=d3?ue(d3):window,a2){case"focusin":(me(xa)||xa.contentEditable==="true")&&(Qe=xa,Re=d3,Se=null);break;case"focusout":Se=Re=Qe=null;break;case"mousedown":Te=!0;break;case"contextmenu":case"mouseup":case"dragend":Te=!1,Ue(g3,c2,e3);break;case"selectionchange":if(Pe)break;case"keydown":case"keyup":Ue(g3,c2,e3)}var $a;if(ae)b:{switch(a2){case"compositionstart":var ba="onCompositionStart";break b;case"compositionend":ba="onCompositionEnd";break b;case"compositionupdate":ba="onCompositionUpdate";break b}ba=void 0}else ie?ge(a2,c2)&&(ba="onCompositionEnd"):a2==="keydown"&&c2.keyCode===229&&(ba="onCompositionStart");ba&&(de&&c2.locale!=="ko"&&(ie||ba!=="onCompositionStart"?ba==="onCompositionEnd"&&ie&&($a=nd()):(kd=e3,ld="value"in kd?kd.value:kd.textContent,ie=!0)),xa=oe(d3,ba),0<xa.length&&(ba=new Ld(ba,a2,null,c2,e3),g3.push({event:ba,listeners:xa}),$a?ba.data=$a:($a=he(c2),$a!==null&&(ba.data=$a)))),($a=ce?je(a2,c2):ke(a2,c2))&&(d3=oe(d3,"onBeforeInput"),0<d3.length&&(e3=new Ld("onBeforeInput","beforeinput",null,c2,e3),g3.push({event:e3,listeners:d3}),e3.data=$a))}se(g3,b2)})}__name(hd,"hd");function tf(a2,b2,c2){return{instance:a2,listener:b2,currentTarget:c2}}__name(tf,"tf");function oe(a2,b2){for(var c2=b2+"Capture",d2=[];a2!==null;){var e2=a2,f2=e2.stateNode;e2.tag===5&&f2!==null&&(e2=f2,f2=Kb(a2,c2),f2!=null&&d2.unshift(tf(a2,f2,e2)),f2=Kb(a2,b2),f2!=null&&d2.push(tf(a2,f2,e2))),a2=a2.return}return d2}__name(oe,"oe");function vf(a2){if(a2===null)return null;do a2=a2.return;while(a2&&a2.tag!==5);return a2||null}__name(vf,"vf");function wf(a2,b2,c2,d2,e2){for(var f2=b2._reactName,g2=[];c2!==null&&c2!==d2;){var h2=c2,k2=h2.alternate,l2=h2.stateNode;if(k2!==null&&k2===d2)break;h2.tag===5&&l2!==null&&(h2=l2,e2?(k2=Kb(c2,f2),k2!=null&&g2.unshift(tf(c2,k2,h2))):e2||(k2=Kb(c2,f2),k2!=null&&g2.push(tf(c2,k2,h2)))),c2=c2.return}g2.length!==0&&a2.push({event:b2,listeners:g2})}__name(wf,"wf");var xf=/\r\n?/g,yf=/\u0000|\uFFFD/g;function zf(a2){return(typeof a2=="string"?a2:""+a2).replace(xf,`
`).replace(yf,"")}__name(zf,"zf");function Af(a2,b2,c2){if(b2=zf(b2),zf(a2)!==b2&&c2)throw Error(p2(425))}__name(Af,"Af");function Bf(){}__name(Bf,"Bf");var Cf=null,Df=null;function Ef(a2,b2){return a2==="textarea"||a2==="noscript"||typeof b2.children=="string"||typeof b2.children=="number"||typeof b2.dangerouslySetInnerHTML=="object"&&b2.dangerouslySetInnerHTML!==null&&b2.dangerouslySetInnerHTML.__html!=null}__name(Ef,"Ef");var Ff=typeof setTimeout=="function"?setTimeout:void 0,Gf=typeof clearTimeout=="function"?clearTimeout:void 0,Hf=typeof Promise=="function"?Promise:void 0,Jf=typeof queueMicrotask=="function"?queueMicrotask:typeof Hf<"u"?function(a2){return Hf.resolve(null).then(a2).catch(If)}:Ff;function If(a2){setTimeout(function(){throw a2})}__name(If,"If");function Kf(a2,b2){var c2=b2,d2=0;do{var e2=c2.nextSibling;if(a2.removeChild(c2),e2&&e2.nodeType===8)if(c2=e2.data,c2==="/$"){if(d2===0){a2.removeChild(e2),bd(b2);return}d2--}else c2!=="$"&&c2!=="$?"&&c2!=="$!"||d2++;c2=e2}while(c2);bd(b2)}__name(Kf,"Kf");function Lf(a2){for(;a2!=null;a2=a2.nextSibling){var b2=a2.nodeType;if(b2===1||b2===3)break;if(b2===8){if(b2=a2.data,b2==="$"||b2==="$!"||b2==="$?")break;if(b2==="/$")return null}}return a2}__name(Lf,"Lf");function Mf(a2){a2=a2.previousSibling;for(var b2=0;a2;){if(a2.nodeType===8){var c2=a2.data;if(c2==="$"||c2==="$!"||c2==="$?"){if(b2===0)return a2;b2--}else c2==="/$"&&b2++}a2=a2.previousSibling}return null}__name(Mf,"Mf");var Nf=Math.random().toString(36).slice(2),Of="__reactFiber$"+Nf,Pf="__reactProps$"+Nf,uf="__reactContainer$"+Nf,of="__reactEvents$"+Nf,Qf="__reactListeners$"+Nf,Rf="__reactHandles$"+Nf;function Wc(a2){var b2=a2[Of];if(b2)return b2;for(var c2=a2.parentNode;c2;){if(b2=c2[uf]||c2[Of]){if(c2=b2.alternate,b2.child!==null||c2!==null&&c2.child!==null)for(a2=Mf(a2);a2!==null;){if(c2=a2[Of])return c2;a2=Mf(a2)}return b2}a2=c2,c2=a2.parentNode}return null}__name(Wc,"Wc");function Cb(a2){return a2=a2[Of]||a2[uf],!a2||a2.tag!==5&&a2.tag!==6&&a2.tag!==13&&a2.tag!==3?null:a2}__name(Cb,"Cb");function ue(a2){if(a2.tag===5||a2.tag===6)return a2.stateNode;throw Error(p2(33))}__name(ue,"ue");function Db(a2){return a2[Pf]||null}__name(Db,"Db");var Sf=[],Tf=-1;function Uf(a2){return{current:a2}}__name(Uf,"Uf");function E2(a2){0>Tf||(a2.current=Sf[Tf],Sf[Tf]=null,Tf--)}__name(E2,"E");function G2(a2,b2){Tf++,Sf[Tf]=a2.current,a2.current=b2}__name(G2,"G");var Vf={},H2=Uf(Vf),Wf=Uf(!1),Xf=Vf;function Yf(a2,b2){var c2=a2.type.contextTypes;if(!c2)return Vf;var d2=a2.stateNode;if(d2&&d2.__reactInternalMemoizedUnmaskedChildContext===b2)return d2.__reactInternalMemoizedMaskedChildContext;var e2={},f2;for(f2 in c2)e2[f2]=b2[f2];return d2&&(a2=a2.stateNode,a2.__reactInternalMemoizedUnmaskedChildContext=b2,a2.__reactInternalMemoizedMaskedChildContext=e2),e2}__name(Yf,"Yf");function Zf(a2){return a2=a2.childContextTypes,a2!=null}__name(Zf,"Zf");function $f(){E2(Wf),E2(H2)}__name($f,"$f");function ag(a2,b2,c2){if(H2.current!==Vf)throw Error(p2(168));G2(H2,b2),G2(Wf,c2)}__name(ag,"ag");function bg(a2,b2,c2){var d2=a2.stateNode;if(b2=b2.childContextTypes,typeof d2.getChildContext!="function")return c2;d2=d2.getChildContext();for(var e2 in d2)if(!(e2 in b2))throw Error(p2(108,Ra(a2)||"Unknown",e2));return A2({},c2,d2)}__name(bg,"bg");function cg(a2){return a2=(a2=a2.stateNode)&&a2.__reactInternalMemoizedMergedChildContext||Vf,Xf=H2.current,G2(H2,a2),G2(Wf,Wf.current),!0}__name(cg,"cg");function dg(a2,b2,c2){var d2=a2.stateNode;if(!d2)throw Error(p2(169));c2?(a2=bg(a2,b2,Xf),d2.__reactInternalMemoizedMergedChildContext=a2,E2(Wf),E2(H2),G2(H2,a2)):E2(Wf),G2(Wf,c2)}__name(dg,"dg");var eg=null,fg=!1,gg=!1;function hg(a2){eg===null?eg=[a2]:eg.push(a2)}__name(hg,"hg");function ig(a2){fg=!0,hg(a2)}__name(ig,"ig");function jg(){if(!gg&&eg!==null){gg=!0;var a2=0,b2=C2;try{var c2=eg;for(C2=1;a2<c2.length;a2++){var d2=c2[a2];do d2=d2(!0);while(d2!==null)}eg=null,fg=!1}catch(e2){throw eg!==null&&(eg=eg.slice(a2+1)),ac(fc,jg),e2}finally{C2=b2,gg=!1}}return null}__name(jg,"jg");var kg=[],lg=0,mg=null,ng=0,og=[],pg=0,qg=null,rg=1,sg="";function tg(a2,b2){kg[lg++]=ng,kg[lg++]=mg,mg=a2,ng=b2}__name(tg,"tg");function ug(a2,b2,c2){og[pg++]=rg,og[pg++]=sg,og[pg++]=qg,qg=a2;var d2=rg;a2=sg;var e2=32-oc(d2)-1;d2&=~(1<<e2),c2+=1;var f2=32-oc(b2)+e2;if(30<f2){var g2=e2-e2%5;f2=(d2&(1<<g2)-1).toString(32),d2>>=g2,e2-=g2,rg=1<<32-oc(b2)+e2|c2<<e2|d2,sg=f2+a2}else rg=1<<f2|c2<<e2|d2,sg=a2}__name(ug,"ug");function vg(a2){a2.return!==null&&(tg(a2,1),ug(a2,1,0))}__name(vg,"vg");function wg(a2){for(;a2===mg;)mg=kg[--lg],kg[lg]=null,ng=kg[--lg],kg[lg]=null;for(;a2===qg;)qg=og[--pg],og[pg]=null,sg=og[--pg],og[pg]=null,rg=og[--pg],og[pg]=null}__name(wg,"wg");var xg=null,yg=null,I2=!1,zg=null;function Ag(a2,b2){var c2=Bg(5,null,null,0);c2.elementType="DELETED",c2.stateNode=b2,c2.return=a2,b2=a2.deletions,b2===null?(a2.deletions=[c2],a2.flags|=16):b2.push(c2)}__name(Ag,"Ag");function Cg(a2,b2){switch(a2.tag){case 5:var c2=a2.type;return b2=b2.nodeType!==1||c2.toLowerCase()!==b2.nodeName.toLowerCase()?null:b2,b2!==null?(a2.stateNode=b2,xg=a2,yg=Lf(b2.firstChild),!0):!1;case 6:return b2=a2.pendingProps===""||b2.nodeType!==3?null:b2,b2!==null?(a2.stateNode=b2,xg=a2,yg=null,!0):!1;case 13:return b2=b2.nodeType!==8?null:b2,b2!==null?(c2=qg!==null?{id:rg,overflow:sg}:null,a2.memoizedState={dehydrated:b2,treeContext:c2,retryLane:1073741824},c2=Bg(18,null,null,0),c2.stateNode=b2,c2.return=a2,a2.child=c2,xg=a2,yg=null,!0):!1;default:return!1}}__name(Cg,"Cg");function Dg(a2){return(a2.mode&1)!==0&&(a2.flags&128)===0}__name(Dg,"Dg");function Eg(a2){if(I2){var b2=yg;if(b2){var c2=b2;if(!Cg(a2,b2)){if(Dg(a2))throw Error(p2(418));b2=Lf(c2.nextSibling);var d2=xg;b2&&Cg(a2,b2)?Ag(d2,c2):(a2.flags=a2.flags&-4097|2,I2=!1,xg=a2)}}else{if(Dg(a2))throw Error(p2(418));a2.flags=a2.flags&-4097|2,I2=!1,xg=a2}}}__name(Eg,"Eg");function Fg(a2){for(a2=a2.return;a2!==null&&a2.tag!==5&&a2.tag!==3&&a2.tag!==13;)a2=a2.return;xg=a2}__name(Fg,"Fg");function Gg(a2){if(a2!==xg)return!1;if(!I2)return Fg(a2),I2=!0,!1;var b2;if((b2=a2.tag!==3)&&!(b2=a2.tag!==5)&&(b2=a2.type,b2=b2!=="head"&&b2!=="body"&&!Ef(a2.type,a2.memoizedProps)),b2&&(b2=yg)){if(Dg(a2))throw Hg(),Error(p2(418));for(;b2;)Ag(a2,b2),b2=Lf(b2.nextSibling)}if(Fg(a2),a2.tag===13){if(a2=a2.memoizedState,a2=a2!==null?a2.dehydrated:null,!a2)throw Error(p2(317));a:{for(a2=a2.nextSibling,b2=0;a2;){if(a2.nodeType===8){var c2=a2.data;if(c2==="/$"){if(b2===0){yg=Lf(a2.nextSibling);break a}b2--}else c2!=="$"&&c2!=="$!"&&c2!=="$?"||b2++}a2=a2.nextSibling}yg=null}}else yg=xg?Lf(a2.stateNode.nextSibling):null;return!0}__name(Gg,"Gg");function Hg(){for(var a2=yg;a2;)a2=Lf(a2.nextSibling)}__name(Hg,"Hg");function Ig(){yg=xg=null,I2=!1}__name(Ig,"Ig");function Jg(a2){zg===null?zg=[a2]:zg.push(a2)}__name(Jg,"Jg");var Kg=ua.ReactCurrentBatchConfig;function Lg(a2,b2){if(a2&&a2.defaultProps){b2=A2({},b2),a2=a2.defaultProps;for(var c2 in a2)b2[c2]===void 0&&(b2[c2]=a2[c2]);return b2}return b2}__name(Lg,"Lg");var Mg=Uf(null),Ng=null,Og=null,Pg=null;function Qg(){Pg=Og=Ng=null}__name(Qg,"Qg");function Rg(a2){var b2=Mg.current;E2(Mg),a2._currentValue=b2}__name(Rg,"Rg");function Sg(a2,b2,c2){for(;a2!==null;){var d2=a2.alternate;if((a2.childLanes&b2)!==b2?(a2.childLanes|=b2,d2!==null&&(d2.childLanes|=b2)):d2!==null&&(d2.childLanes&b2)!==b2&&(d2.childLanes|=b2),a2===c2)break;a2=a2.return}}__name(Sg,"Sg");function Tg(a2,b2){Ng=a2,Pg=Og=null,a2=a2.dependencies,a2!==null&&a2.firstContext!==null&&((a2.lanes&b2)!==0&&(Ug=!0),a2.firstContext=null)}__name(Tg,"Tg");function Vg(a2){var b2=a2._currentValue;if(Pg!==a2)if(a2={context:a2,memoizedValue:b2,next:null},Og===null){if(Ng===null)throw Error(p2(308));Og=a2,Ng.dependencies={lanes:0,firstContext:a2}}else Og=Og.next=a2;return b2}__name(Vg,"Vg");var Wg=null;function Xg(a2){Wg===null?Wg=[a2]:Wg.push(a2)}__name(Xg,"Xg");function Yg(a2,b2,c2,d2){var e2=b2.interleaved;return e2===null?(c2.next=c2,Xg(b2)):(c2.next=e2.next,e2.next=c2),b2.interleaved=c2,Zg(a2,d2)}__name(Yg,"Yg");function Zg(a2,b2){a2.lanes|=b2;var c2=a2.alternate;for(c2!==null&&(c2.lanes|=b2),c2=a2,a2=a2.return;a2!==null;)a2.childLanes|=b2,c2=a2.alternate,c2!==null&&(c2.childLanes|=b2),c2=a2,a2=a2.return;return c2.tag===3?c2.stateNode:null}__name(Zg,"Zg");var $g=!1;function ah(a2){a2.updateQueue={baseState:a2.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}__name(ah,"ah");function bh(a2,b2){a2=a2.updateQueue,b2.updateQueue===a2&&(b2.updateQueue={baseState:a2.baseState,firstBaseUpdate:a2.firstBaseUpdate,lastBaseUpdate:a2.lastBaseUpdate,shared:a2.shared,effects:a2.effects})}__name(bh,"bh");function ch(a2,b2){return{eventTime:a2,lane:b2,tag:0,payload:null,callback:null,next:null}}__name(ch,"ch");function dh(a2,b2,c2){var d2=a2.updateQueue;if(d2===null)return null;if(d2=d2.shared,(K2&2)!==0){var e2=d2.pending;return e2===null?b2.next=b2:(b2.next=e2.next,e2.next=b2),d2.pending=b2,Zg(a2,c2)}return e2=d2.interleaved,e2===null?(b2.next=b2,Xg(d2)):(b2.next=e2.next,e2.next=b2),d2.interleaved=b2,Zg(a2,c2)}__name(dh,"dh");function eh(a2,b2,c2){if(b2=b2.updateQueue,b2!==null&&(b2=b2.shared,(c2&4194240)!==0)){var d2=b2.lanes;d2&=a2.pendingLanes,c2|=d2,b2.lanes=c2,Cc(a2,c2)}}__name(eh,"eh");function fh(a2,b2){var c2=a2.updateQueue,d2=a2.alternate;if(d2!==null&&(d2=d2.updateQueue,c2===d2)){var e2=null,f2=null;if(c2=c2.firstBaseUpdate,c2!==null){do{var g2={eventTime:c2.eventTime,lane:c2.lane,tag:c2.tag,payload:c2.payload,callback:c2.callback,next:null};f2===null?e2=f2=g2:f2=f2.next=g2,c2=c2.next}while(c2!==null);f2===null?e2=f2=b2:f2=f2.next=b2}else e2=f2=b2;c2={baseState:d2.baseState,firstBaseUpdate:e2,lastBaseUpdate:f2,shared:d2.shared,effects:d2.effects},a2.updateQueue=c2;return}a2=c2.lastBaseUpdate,a2===null?c2.firstBaseUpdate=b2:a2.next=b2,c2.lastBaseUpdate=b2}__name(fh,"fh");function gh(a2,b2,c2,d2){var e2=a2.updateQueue;$g=!1;var f2=e2.firstBaseUpdate,g2=e2.lastBaseUpdate,h2=e2.shared.pending;if(h2!==null){e2.shared.pending=null;var k2=h2,l2=k2.next;k2.next=null,g2===null?f2=l2:g2.next=l2,g2=k2;var m2=a2.alternate;m2!==null&&(m2=m2.updateQueue,h2=m2.lastBaseUpdate,h2!==g2&&(h2===null?m2.firstBaseUpdate=l2:h2.next=l2,m2.lastBaseUpdate=k2))}if(f2!==null){var q2=e2.baseState;g2=0,m2=l2=k2=null,h2=f2;do{var r2=h2.lane,y2=h2.eventTime;if((d2&r2)===r2){m2!==null&&(m2=m2.next={eventTime:y2,lane:0,tag:h2.tag,payload:h2.payload,callback:h2.callback,next:null});a:{var n2=a2,t2=h2;switch(r2=b2,y2=c2,t2.tag){case 1:if(n2=t2.payload,typeof n2=="function"){q2=n2.call(y2,q2,r2);break a}q2=n2;break a;case 3:n2.flags=n2.flags&-65537|128;case 0:if(n2=t2.payload,r2=typeof n2=="function"?n2.call(y2,q2,r2):n2,r2==null)break a;q2=A2({},q2,r2);break a;case 2:$g=!0}}h2.callback!==null&&h2.lane!==0&&(a2.flags|=64,r2=e2.effects,r2===null?e2.effects=[h2]:r2.push(h2))}else y2={eventTime:y2,lane:r2,tag:h2.tag,payload:h2.payload,callback:h2.callback,next:null},m2===null?(l2=m2=y2,k2=q2):m2=m2.next=y2,g2|=r2;if(h2=h2.next,h2===null){if(h2=e2.shared.pending,h2===null)break;r2=h2,h2=r2.next,r2.next=null,e2.lastBaseUpdate=r2,e2.shared.pending=null}}while(!0);if(m2===null&&(k2=q2),e2.baseState=k2,e2.firstBaseUpdate=l2,e2.lastBaseUpdate=m2,b2=e2.shared.interleaved,b2!==null){e2=b2;do g2|=e2.lane,e2=e2.next;while(e2!==b2)}else f2===null&&(e2.shared.lanes=0);hh|=g2,a2.lanes=g2,a2.memoizedState=q2}}__name(gh,"gh");function ih(a2,b2,c2){if(a2=b2.effects,b2.effects=null,a2!==null)for(b2=0;b2<a2.length;b2++){var d2=a2[b2],e2=d2.callback;if(e2!==null){if(d2.callback=null,d2=c2,typeof e2!="function")throw Error(p2(191,e2));e2.call(d2)}}}__name(ih,"ih");var jh=new aa.Component().refs;function kh(a2,b2,c2,d2){b2=a2.memoizedState,c2=c2(d2,b2),c2=c2==null?b2:A2({},b2,c2),a2.memoizedState=c2,a2.lanes===0&&(a2.updateQueue.baseState=c2)}__name(kh,"kh");var nh={isMounted:__name(function(a2){return(a2=a2._reactInternals)?Vb(a2)===a2:!1},"isMounted"),enqueueSetState:__name(function(a2,b2,c2){a2=a2._reactInternals;var d2=L2(),e2=lh(a2),f2=ch(d2,e2);f2.payload=b2,c2!=null&&(f2.callback=c2),b2=dh(a2,f2,e2),b2!==null&&(mh(b2,a2,e2,d2),eh(b2,a2,e2))},"enqueueSetState"),enqueueReplaceState:__name(function(a2,b2,c2){a2=a2._reactInternals;var d2=L2(),e2=lh(a2),f2=ch(d2,e2);f2.tag=1,f2.payload=b2,c2!=null&&(f2.callback=c2),b2=dh(a2,f2,e2),b2!==null&&(mh(b2,a2,e2,d2),eh(b2,a2,e2))},"enqueueReplaceState"),enqueueForceUpdate:__name(function(a2,b2){a2=a2._reactInternals;var c2=L2(),d2=lh(a2),e2=ch(c2,d2);e2.tag=2,b2!=null&&(e2.callback=b2),b2=dh(a2,e2,d2),b2!==null&&(mh(b2,a2,d2,c2),eh(b2,a2,d2))},"enqueueForceUpdate")};function oh(a2,b2,c2,d2,e2,f2,g2){return a2=a2.stateNode,typeof a2.shouldComponentUpdate=="function"?a2.shouldComponentUpdate(d2,f2,g2):b2.prototype&&b2.prototype.isPureReactComponent?!Ie(c2,d2)||!Ie(e2,f2):!0}__name(oh,"oh");function ph(a2,b2,c2){var d2=!1,e2=Vf,f2=b2.contextType;return typeof f2=="object"&&f2!==null?f2=Vg(f2):(e2=Zf(b2)?Xf:H2.current,d2=b2.contextTypes,f2=(d2=d2!=null)?Yf(a2,e2):Vf),b2=new b2(c2,f2),a2.memoizedState=b2.state!==null&&b2.state!==void 0?b2.state:null,b2.updater=nh,a2.stateNode=b2,b2._reactInternals=a2,d2&&(a2=a2.stateNode,a2.__reactInternalMemoizedUnmaskedChildContext=e2,a2.__reactInternalMemoizedMaskedChildContext=f2),b2}__name(ph,"ph");function qh(a2,b2,c2,d2){a2=b2.state,typeof b2.componentWillReceiveProps=="function"&&b2.componentWillReceiveProps(c2,d2),typeof b2.UNSAFE_componentWillReceiveProps=="function"&&b2.UNSAFE_componentWillReceiveProps(c2,d2),b2.state!==a2&&nh.enqueueReplaceState(b2,b2.state,null)}__name(qh,"qh");function rh(a2,b2,c2,d2){var e2=a2.stateNode;e2.props=c2,e2.state=a2.memoizedState,e2.refs=jh,ah(a2);var f2=b2.contextType;typeof f2=="object"&&f2!==null?e2.context=Vg(f2):(f2=Zf(b2)?Xf:H2.current,e2.context=Yf(a2,f2)),e2.state=a2.memoizedState,f2=b2.getDerivedStateFromProps,typeof f2=="function"&&(kh(a2,b2,f2,c2),e2.state=a2.memoizedState),typeof b2.getDerivedStateFromProps=="function"||typeof e2.getSnapshotBeforeUpdate=="function"||typeof e2.UNSAFE_componentWillMount!="function"&&typeof e2.componentWillMount!="function"||(b2=e2.state,typeof e2.componentWillMount=="function"&&e2.componentWillMount(),typeof e2.UNSAFE_componentWillMount=="function"&&e2.UNSAFE_componentWillMount(),b2!==e2.state&&nh.enqueueReplaceState(e2,e2.state,null),gh(a2,c2,e2,d2),e2.state=a2.memoizedState),typeof e2.componentDidMount=="function"&&(a2.flags|=4194308)}__name(rh,"rh");function sh(a2,b2,c2){if(a2=c2.ref,a2!==null&&typeof a2!="function"&&typeof a2!="object"){if(c2._owner){if(c2=c2._owner,c2){if(c2.tag!==1)throw Error(p2(309));var d2=c2.stateNode}if(!d2)throw Error(p2(147,a2));var e2=d2,f2=""+a2;return b2!==null&&b2.ref!==null&&typeof b2.ref=="function"&&b2.ref._stringRef===f2?b2.ref:(b2=__name(function(a3){var b3=e2.refs;b3===jh&&(b3=e2.refs={}),a3===null?delete b3[f2]:b3[f2]=a3},"b"),b2._stringRef=f2,b2)}if(typeof a2!="string")throw Error(p2(284));if(!c2._owner)throw Error(p2(290,a2))}return a2}__name(sh,"sh");function th(a2,b2){throw a2=Object.prototype.toString.call(b2),Error(p2(31,a2==="[object Object]"?"object with keys {"+Object.keys(b2).join(", ")+"}":a2))}__name(th,"th");function uh(a2){var b2=a2._init;return b2(a2._payload)}__name(uh,"uh");function vh(a2){function b2(b3,c3){if(a2){var d3=b3.deletions;d3===null?(b3.deletions=[c3],b3.flags|=16):d3.push(c3)}}__name(b2,"b");function c2(c3,d3){if(!a2)return null;for(;d3!==null;)b2(c3,d3),d3=d3.sibling;return null}__name(c2,"c");function d2(a3,b3){for(a3=new Map;b3!==null;)b3.key!==null?a3.set(b3.key,b3):a3.set(b3.index,b3),b3=b3.sibling;return a3}__name(d2,"d");function e2(a3,b3){return a3=wh(a3,b3),a3.index=0,a3.sibling=null,a3}__name(e2,"e");function f2(b3,c3,d3){return b3.index=d3,a2?(d3=b3.alternate,d3!==null?(d3=d3.index,d3<c3?(b3.flags|=2,c3):d3):(b3.flags|=2,c3)):(b3.flags|=1048576,c3)}__name(f2,"f");function g2(b3){return a2&&b3.alternate===null&&(b3.flags|=2),b3}__name(g2,"g");function h2(a3,b3,c3,d3){return b3===null||b3.tag!==6?(b3=xh(c3,a3.mode,d3),b3.return=a3,b3):(b3=e2(b3,c3),b3.return=a3,b3)}__name(h2,"h");function k2(a3,b3,c3,d3){var f3=c3.type;return f3===ya?m2(a3,b3,c3.props.children,d3,c3.key):b3!==null&&(b3.elementType===f3||typeof f3=="object"&&f3!==null&&f3.$$typeof===Ha&&uh(f3)===b3.type)?(d3=e2(b3,c3.props),d3.ref=sh(a3,b3,c3),d3.return=a3,d3):(d3=yh(c3.type,c3.key,c3.props,null,a3.mode,d3),d3.ref=sh(a3,b3,c3),d3.return=a3,d3)}__name(k2,"k");function l2(a3,b3,c3,d3){return b3===null||b3.tag!==4||b3.stateNode.containerInfo!==c3.containerInfo||b3.stateNode.implementation!==c3.implementation?(b3=zh(c3,a3.mode,d3),b3.return=a3,b3):(b3=e2(b3,c3.children||[]),b3.return=a3,b3)}__name(l2,"l");function m2(a3,b3,c3,d3,f3){return b3===null||b3.tag!==7?(b3=Ah(c3,a3.mode,d3,f3),b3.return=a3,b3):(b3=e2(b3,c3),b3.return=a3,b3)}__name(m2,"m");function q2(a3,b3,c3){if(typeof b3=="string"&&b3!==""||typeof b3=="number")return b3=xh(""+b3,a3.mode,c3),b3.return=a3,b3;if(typeof b3=="object"&&b3!==null){switch(b3.$$typeof){case va:return c3=yh(b3.type,b3.key,b3.props,null,a3.mode,c3),c3.ref=sh(a3,null,b3),c3.return=a3,c3;case wa:return b3=zh(b3,a3.mode,c3),b3.return=a3,b3;case Ha:var d3=b3._init;return q2(a3,d3(b3._payload),c3)}if(eb(b3)||Ka(b3))return b3=Ah(b3,a3.mode,c3,null),b3.return=a3,b3;th(a3,b3)}return null}__name(q2,"q");function r2(a3,b3,c3,d3){var e3=b3!==null?b3.key:null;if(typeof c3=="string"&&c3!==""||typeof c3=="number")return e3!==null?null:h2(a3,b3,""+c3,d3);if(typeof c3=="object"&&c3!==null){switch(c3.$$typeof){case va:return c3.key===e3?k2(a3,b3,c3,d3):null;case wa:return c3.key===e3?l2(a3,b3,c3,d3):null;case Ha:return e3=c3._init,r2(a3,b3,e3(c3._payload),d3)}if(eb(c3)||Ka(c3))return e3!==null?null:m2(a3,b3,c3,d3,null);th(a3,c3)}return null}__name(r2,"r");function y2(a3,b3,c3,d3,e3){if(typeof d3=="string"&&d3!==""||typeof d3=="number")return a3=a3.get(c3)||null,h2(b3,a3,""+d3,e3);if(typeof d3=="object"&&d3!==null){switch(d3.$$typeof){case va:return a3=a3.get(d3.key===null?c3:d3.key)||null,k2(b3,a3,d3,e3);case wa:return a3=a3.get(d3.key===null?c3:d3.key)||null,l2(b3,a3,d3,e3);case Ha:var f3=d3._init;return y2(a3,b3,c3,f3(d3._payload),e3)}if(eb(d3)||Ka(d3))return a3=a3.get(c3)||null,m2(b3,a3,d3,e3,null);th(b3,d3)}return null}__name(y2,"y");function n2(e3,g3,h3,k3){for(var l3=null,m3=null,u2=g3,w2=g3=0,x2=null;u2!==null&&w2<h3.length;w2++){u2.index>w2?(x2=u2,u2=null):x2=u2.sibling;var n3=r2(e3,u2,h3[w2],k3);if(n3===null){u2===null&&(u2=x2);break}a2&&u2&&n3.alternate===null&&b2(e3,u2),g3=f2(n3,g3,w2),m3===null?l3=n3:m3.sibling=n3,m3=n3,u2=x2}if(w2===h3.length)return c2(e3,u2),I2&&tg(e3,w2),l3;if(u2===null){for(;w2<h3.length;w2++)u2=q2(e3,h3[w2],k3),u2!==null&&(g3=f2(u2,g3,w2),m3===null?l3=u2:m3.sibling=u2,m3=u2);return I2&&tg(e3,w2),l3}for(u2=d2(e3,u2);w2<h3.length;w2++)x2=y2(u2,e3,w2,h3[w2],k3),x2!==null&&(a2&&x2.alternate!==null&&u2.delete(x2.key===null?w2:x2.key),g3=f2(x2,g3,w2),m3===null?l3=x2:m3.sibling=x2,m3=x2);return a2&&u2.forEach(function(a3){return b2(e3,a3)}),I2&&tg(e3,w2),l3}__name(n2,"n");function t2(e3,g3,h3,k3){var l3=Ka(h3);if(typeof l3!="function")throw Error(p2(150));if(h3=l3.call(h3),h3==null)throw Error(p2(151));for(var u2=l3=null,m3=g3,w2=g3=0,x2=null,n3=h3.next();m3!==null&&!n3.done;w2++,n3=h3.next()){m3.index>w2?(x2=m3,m3=null):x2=m3.sibling;var t3=r2(e3,m3,n3.value,k3);if(t3===null){m3===null&&(m3=x2);break}a2&&m3&&t3.alternate===null&&b2(e3,m3),g3=f2(t3,g3,w2),u2===null?l3=t3:u2.sibling=t3,u2=t3,m3=x2}if(n3.done)return c2(e3,m3),I2&&tg(e3,w2),l3;if(m3===null){for(;!n3.done;w2++,n3=h3.next())n3=q2(e3,n3.value,k3),n3!==null&&(g3=f2(n3,g3,w2),u2===null?l3=n3:u2.sibling=n3,u2=n3);return I2&&tg(e3,w2),l3}for(m3=d2(e3,m3);!n3.done;w2++,n3=h3.next())n3=y2(m3,e3,w2,n3.value,k3),n3!==null&&(a2&&n3.alternate!==null&&m3.delete(n3.key===null?w2:n3.key),g3=f2(n3,g3,w2),u2===null?l3=n3:u2.sibling=n3,u2=n3);return a2&&m3.forEach(function(a3){return b2(e3,a3)}),I2&&tg(e3,w2),l3}__name(t2,"t");function J2(a3,d3,f3,h3){if(typeof f3=="object"&&f3!==null&&f3.type===ya&&f3.key===null&&(f3=f3.props.children),typeof f3=="object"&&f3!==null){switch(f3.$$typeof){case va:a:{for(var k3=f3.key,l3=d3;l3!==null;){if(l3.key===k3){if(k3=f3.type,k3===ya){if(l3.tag===7){c2(a3,l3.sibling),d3=e2(l3,f3.props.children),d3.return=a3,a3=d3;break a}}else if(l3.elementType===k3||typeof k3=="object"&&k3!==null&&k3.$$typeof===Ha&&uh(k3)===l3.type){c2(a3,l3.sibling),d3=e2(l3,f3.props),d3.ref=sh(a3,l3,f3),d3.return=a3,a3=d3;break a}c2(a3,l3);break}else b2(a3,l3);l3=l3.sibling}f3.type===ya?(d3=Ah(f3.props.children,a3.mode,h3,f3.key),d3.return=a3,a3=d3):(h3=yh(f3.type,f3.key,f3.props,null,a3.mode,h3),h3.ref=sh(a3,d3,f3),h3.return=a3,a3=h3)}return g2(a3);case wa:a:{for(l3=f3.key;d3!==null;){if(d3.key===l3)if(d3.tag===4&&d3.stateNode.containerInfo===f3.containerInfo&&d3.stateNode.implementation===f3.implementation){c2(a3,d3.sibling),d3=e2(d3,f3.children||[]),d3.return=a3,a3=d3;break a}else{c2(a3,d3);break}else b2(a3,d3);d3=d3.sibling}d3=zh(f3,a3.mode,h3),d3.return=a3,a3=d3}return g2(a3);case Ha:return l3=f3._init,J2(a3,d3,l3(f3._payload),h3)}if(eb(f3))return n2(a3,d3,f3,h3);if(Ka(f3))return t2(a3,d3,f3,h3);th(a3,f3)}return typeof f3=="string"&&f3!==""||typeof f3=="number"?(f3=""+f3,d3!==null&&d3.tag===6?(c2(a3,d3.sibling),d3=e2(d3,f3),d3.return=a3,a3=d3):(c2(a3,d3),d3=xh(f3,a3.mode,h3),d3.return=a3,a3=d3),g2(a3)):c2(a3,d3)}return __name(J2,"J"),J2}__name(vh,"vh");var Bh=vh(!0),Ch=vh(!1),Dh={},Eh=Uf(Dh),Fh=Uf(Dh),Gh=Uf(Dh);function Hh(a2){if(a2===Dh)throw Error(p2(174));return a2}__name(Hh,"Hh");function Ih(a2,b2){switch(G2(Gh,b2),G2(Fh,a2),G2(Eh,Dh),a2=b2.nodeType,a2){case 9:case 11:b2=(b2=b2.documentElement)?b2.namespaceURI:lb(null,"");break;default:a2=a2===8?b2.parentNode:b2,b2=a2.namespaceURI||null,a2=a2.tagName,b2=lb(b2,a2)}E2(Eh),G2(Eh,b2)}__name(Ih,"Ih");function Jh(){E2(Eh),E2(Fh),E2(Gh)}__name(Jh,"Jh");function Kh(a2){Hh(Gh.current);var b2=Hh(Eh.current),c2=lb(b2,a2.type);b2!==c2&&(G2(Fh,a2),G2(Eh,c2))}__name(Kh,"Kh");function Lh(a2){Fh.current===a2&&(E2(Eh),E2(Fh))}__name(Lh,"Lh");var M2=Uf(0);function Mh(a2){for(var b2=a2;b2!==null;){if(b2.tag===13){var c2=b2.memoizedState;if(c2!==null&&(c2=c2.dehydrated,c2===null||c2.data==="$?"||c2.data==="$!"))return b2}else if(b2.tag===19&&b2.memoizedProps.revealOrder!==void 0){if((b2.flags&128)!==0)return b2}else if(b2.child!==null){b2.child.return=b2,b2=b2.child;continue}if(b2===a2)break;for(;b2.sibling===null;){if(b2.return===null||b2.return===a2)return null;b2=b2.return}b2.sibling.return=b2.return,b2=b2.sibling}return null}__name(Mh,"Mh");var Nh=[];function Oh(){for(var a2=0;a2<Nh.length;a2++)Nh[a2]._workInProgressVersionPrimary=null;Nh.length=0}__name(Oh,"Oh");var Ph=ua.ReactCurrentDispatcher,Qh=ua.ReactCurrentBatchConfig,Rh=0,N2=null,O2=null,P2=null,Sh=!1,Th=!1,Uh=0,Vh=0;function Q2(){throw Error(p2(321))}__name(Q2,"Q");function Wh(a2,b2){if(b2===null)return!1;for(var c2=0;c2<b2.length&&c2<a2.length;c2++)if(!He(a2[c2],b2[c2]))return!1;return!0}__name(Wh,"Wh");function Xh(a2,b2,c2,d2,e2,f2){if(Rh=f2,N2=b2,b2.memoizedState=null,b2.updateQueue=null,b2.lanes=0,Ph.current=a2===null||a2.memoizedState===null?Yh:Zh,a2=c2(d2,e2),Th){f2=0;do{if(Th=!1,Uh=0,25<=f2)throw Error(p2(301));f2+=1,P2=O2=null,b2.updateQueue=null,Ph.current=$h,a2=c2(d2,e2)}while(Th)}if(Ph.current=ai,b2=O2!==null&&O2.next!==null,Rh=0,P2=O2=N2=null,Sh=!1,b2)throw Error(p2(300));return a2}__name(Xh,"Xh");function bi(){var a2=Uh!==0;return Uh=0,a2}__name(bi,"bi");function ci(){var a2={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return P2===null?N2.memoizedState=P2=a2:P2=P2.next=a2,P2}__name(ci,"ci");function di(){if(O2===null){var a2=N2.alternate;a2=a2!==null?a2.memoizedState:null}else a2=O2.next;var b2=P2===null?N2.memoizedState:P2.next;if(b2!==null)P2=b2,O2=a2;else{if(a2===null)throw Error(p2(310));O2=a2,a2={memoizedState:O2.memoizedState,baseState:O2.baseState,baseQueue:O2.baseQueue,queue:O2.queue,next:null},P2===null?N2.memoizedState=P2=a2:P2=P2.next=a2}return P2}__name(di,"di");function ei(a2,b2){return typeof b2=="function"?b2(a2):b2}__name(ei,"ei");function fi(a2){var b2=di(),c2=b2.queue;if(c2===null)throw Error(p2(311));c2.lastRenderedReducer=a2;var d2=O2,e2=d2.baseQueue,f2=c2.pending;if(f2!==null){if(e2!==null){var g2=e2.next;e2.next=f2.next,f2.next=g2}d2.baseQueue=e2=f2,c2.pending=null}if(e2!==null){f2=e2.next,d2=d2.baseState;var h2=g2=null,k2=null,l2=f2;do{var m2=l2.lane;if((Rh&m2)===m2)k2!==null&&(k2=k2.next={lane:0,action:l2.action,hasEagerState:l2.hasEagerState,eagerState:l2.eagerState,next:null}),d2=l2.hasEagerState?l2.eagerState:a2(d2,l2.action);else{var q2={lane:m2,action:l2.action,hasEagerState:l2.hasEagerState,eagerState:l2.eagerState,next:null};k2===null?(h2=k2=q2,g2=d2):k2=k2.next=q2,N2.lanes|=m2,hh|=m2}l2=l2.next}while(l2!==null&&l2!==f2);k2===null?g2=d2:k2.next=h2,He(d2,b2.memoizedState)||(Ug=!0),b2.memoizedState=d2,b2.baseState=g2,b2.baseQueue=k2,c2.lastRenderedState=d2}if(a2=c2.interleaved,a2!==null){e2=a2;do f2=e2.lane,N2.lanes|=f2,hh|=f2,e2=e2.next;while(e2!==a2)}else e2===null&&(c2.lanes=0);return[b2.memoizedState,c2.dispatch]}__name(fi,"fi");function gi(a2){var b2=di(),c2=b2.queue;if(c2===null)throw Error(p2(311));c2.lastRenderedReducer=a2;var d2=c2.dispatch,e2=c2.pending,f2=b2.memoizedState;if(e2!==null){c2.pending=null;var g2=e2=e2.next;do f2=a2(f2,g2.action),g2=g2.next;while(g2!==e2);He(f2,b2.memoizedState)||(Ug=!0),b2.memoizedState=f2,b2.baseQueue===null&&(b2.baseState=f2),c2.lastRenderedState=f2}return[f2,d2]}__name(gi,"gi");function hi(){}__name(hi,"hi");function ii(a2,b2){var c2=N2,d2=di(),e2=b2(),f2=!He(d2.memoizedState,e2);if(f2&&(d2.memoizedState=e2,Ug=!0),d2=d2.queue,ji(ki.bind(null,c2,d2,a2),[a2]),d2.getSnapshot!==b2||f2||P2!==null&&P2.memoizedState.tag&1){if(c2.flags|=2048,li(9,mi.bind(null,c2,d2,e2,b2),void 0,null),R===null)throw Error(p2(349));(Rh&30)!==0||ni(c2,b2,e2)}return e2}__name(ii,"ii");function ni(a2,b2,c2){a2.flags|=16384,a2={getSnapshot:b2,value:c2},b2=N2.updateQueue,b2===null?(b2={lastEffect:null,stores:null},N2.updateQueue=b2,b2.stores=[a2]):(c2=b2.stores,c2===null?b2.stores=[a2]:c2.push(a2))}__name(ni,"ni");function mi(a2,b2,c2,d2){b2.value=c2,b2.getSnapshot=d2,oi(b2)&&pi(a2)}__name(mi,"mi");function ki(a2,b2,c2){return c2(function(){oi(b2)&&pi(a2)})}__name(ki,"ki");function oi(a2){var b2=a2.getSnapshot;a2=a2.value;try{var c2=b2();return!He(a2,c2)}catch{return!0}}__name(oi,"oi");function pi(a2){var b2=Zg(a2,1);b2!==null&&mh(b2,a2,1,-1)}__name(pi,"pi");function qi(a2){var b2=ci();return typeof a2=="function"&&(a2=a2()),b2.memoizedState=b2.baseState=a2,a2={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:ei,lastRenderedState:a2},b2.queue=a2,a2=a2.dispatch=ri.bind(null,N2,a2),[b2.memoizedState,a2]}__name(qi,"qi");function li(a2,b2,c2,d2){return a2={tag:a2,create:b2,destroy:c2,deps:d2,next:null},b2=N2.updateQueue,b2===null?(b2={lastEffect:null,stores:null},N2.updateQueue=b2,b2.lastEffect=a2.next=a2):(c2=b2.lastEffect,c2===null?b2.lastEffect=a2.next=a2:(d2=c2.next,c2.next=a2,a2.next=d2,b2.lastEffect=a2)),a2}__name(li,"li");function si(){return di().memoizedState}__name(si,"si");function ti(a2,b2,c2,d2){var e2=ci();N2.flags|=a2,e2.memoizedState=li(1|b2,c2,void 0,d2===void 0?null:d2)}__name(ti,"ti");function ui(a2,b2,c2,d2){var e2=di();d2=d2===void 0?null:d2;var f2=void 0;if(O2!==null){var g2=O2.memoizedState;if(f2=g2.destroy,d2!==null&&Wh(d2,g2.deps)){e2.memoizedState=li(b2,c2,f2,d2);return}}N2.flags|=a2,e2.memoizedState=li(1|b2,c2,f2,d2)}__name(ui,"ui");function vi(a2,b2){return ti(8390656,8,a2,b2)}__name(vi,"vi");function ji(a2,b2){return ui(2048,8,a2,b2)}__name(ji,"ji");function wi(a2,b2){return ui(4,2,a2,b2)}__name(wi,"wi");function xi(a2,b2){return ui(4,4,a2,b2)}__name(xi,"xi");function yi(a2,b2){if(typeof b2=="function")return a2=a2(),b2(a2),function(){b2(null)};if(b2!=null)return a2=a2(),b2.current=a2,function(){b2.current=null}}__name(yi,"yi");function zi(a2,b2,c2){return c2=c2!=null?c2.concat([a2]):null,ui(4,4,yi.bind(null,b2,a2),c2)}__name(zi,"zi");function Ai(){}__name(Ai,"Ai");function Bi(a2,b2){var c2=di();b2=b2===void 0?null:b2;var d2=c2.memoizedState;return d2!==null&&b2!==null&&Wh(b2,d2[1])?d2[0]:(c2.memoizedState=[a2,b2],a2)}__name(Bi,"Bi");function Ci(a2,b2){var c2=di();b2=b2===void 0?null:b2;var d2=c2.memoizedState;return d2!==null&&b2!==null&&Wh(b2,d2[1])?d2[0]:(a2=a2(),c2.memoizedState=[a2,b2],a2)}__name(Ci,"Ci");function Di(a2,b2,c2){return(Rh&21)===0?(a2.baseState&&(a2.baseState=!1,Ug=!0),a2.memoizedState=c2):(He(c2,b2)||(c2=yc(),N2.lanes|=c2,hh|=c2,a2.baseState=!0),b2)}__name(Di,"Di");function Ei(a2,b2){var c2=C2;C2=c2!==0&&4>c2?c2:4,a2(!0);var d2=Qh.transition;Qh.transition={};try{a2(!1),b2()}finally{C2=c2,Qh.transition=d2}}__name(Ei,"Ei");function Fi(){return di().memoizedState}__name(Fi,"Fi");function Gi(a2,b2,c2){var d2=lh(a2);if(c2={lane:d2,action:c2,hasEagerState:!1,eagerState:null,next:null},Hi(a2))Ii(b2,c2);else if(c2=Yg(a2,b2,c2,d2),c2!==null){var e2=L2();mh(c2,a2,d2,e2),Ji(c2,b2,d2)}}__name(Gi,"Gi");function ri(a2,b2,c2){var d2=lh(a2),e2={lane:d2,action:c2,hasEagerState:!1,eagerState:null,next:null};if(Hi(a2))Ii(b2,e2);else{var f2=a2.alternate;if(a2.lanes===0&&(f2===null||f2.lanes===0)&&(f2=b2.lastRenderedReducer,f2!==null))try{var g2=b2.lastRenderedState,h2=f2(g2,c2);if(e2.hasEagerState=!0,e2.eagerState=h2,He(h2,g2)){var k2=b2.interleaved;k2===null?(e2.next=e2,Xg(b2)):(e2.next=k2.next,k2.next=e2),b2.interleaved=e2;return}}catch{}finally{}c2=Yg(a2,b2,e2,d2),c2!==null&&(e2=L2(),mh(c2,a2,d2,e2),Ji(c2,b2,d2))}}__name(ri,"ri");function Hi(a2){var b2=a2.alternate;return a2===N2||b2!==null&&b2===N2}__name(Hi,"Hi");function Ii(a2,b2){Th=Sh=!0;var c2=a2.pending;c2===null?b2.next=b2:(b2.next=c2.next,c2.next=b2),a2.pending=b2}__name(Ii,"Ii");function Ji(a2,b2,c2){if((c2&4194240)!==0){var d2=b2.lanes;d2&=a2.pendingLanes,c2|=d2,b2.lanes=c2,Cc(a2,c2)}}__name(Ji,"Ji");var ai={readContext:Vg,useCallback:Q2,useContext:Q2,useEffect:Q2,useImperativeHandle:Q2,useInsertionEffect:Q2,useLayoutEffect:Q2,useMemo:Q2,useReducer:Q2,useRef:Q2,useState:Q2,useDebugValue:Q2,useDeferredValue:Q2,useTransition:Q2,useMutableSource:Q2,useSyncExternalStore:Q2,useId:Q2,unstable_isNewReconciler:!1},Yh={readContext:Vg,useCallback:__name(function(a2,b2){return ci().memoizedState=[a2,b2===void 0?null:b2],a2},"useCallback"),useContext:Vg,useEffect:vi,useImperativeHandle:__name(function(a2,b2,c2){return c2=c2!=null?c2.concat([a2]):null,ti(4194308,4,yi.bind(null,b2,a2),c2)},"useImperativeHandle"),useLayoutEffect:__name(function(a2,b2){return ti(4194308,4,a2,b2)},"useLayoutEffect"),useInsertionEffect:__name(function(a2,b2){return ti(4,2,a2,b2)},"useInsertionEffect"),useMemo:__name(function(a2,b2){var c2=ci();return b2=b2===void 0?null:b2,a2=a2(),c2.memoizedState=[a2,b2],a2},"useMemo"),useReducer:__name(function(a2,b2,c2){var d2=ci();return b2=c2!==void 0?c2(b2):b2,d2.memoizedState=d2.baseState=b2,a2={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:a2,lastRenderedState:b2},d2.queue=a2,a2=a2.dispatch=Gi.bind(null,N2,a2),[d2.memoizedState,a2]},"useReducer"),useRef:__name(function(a2){var b2=ci();return a2={current:a2},b2.memoizedState=a2},"useRef"),useState:qi,useDebugValue:Ai,useDeferredValue:__name(function(a2){return ci().memoizedState=a2},"useDeferredValue"),useTransition:__name(function(){var a2=qi(!1),b2=a2[0];return a2=Ei.bind(null,a2[1]),ci().memoizedState=a2,[b2,a2]},"useTransition"),useMutableSource:__name(function(){},"useMutableSource"),useSyncExternalStore:__name(function(a2,b2,c2){var d2=N2,e2=ci();if(I2){if(c2===void 0)throw Error(p2(407));c2=c2()}else{if(c2=b2(),R===null)throw Error(p2(349));(Rh&30)!==0||ni(d2,b2,c2)}e2.memoizedState=c2;var f2={value:c2,getSnapshot:b2};return e2.queue=f2,vi(ki.bind(null,d2,f2,a2),[a2]),d2.flags|=2048,li(9,mi.bind(null,d2,f2,c2,b2),void 0,null),c2},"useSyncExternalStore"),useId:__name(function(){var a2=ci(),b2=R.identifierPrefix;if(I2){var c2=sg,d2=rg;c2=(d2&~(1<<32-oc(d2)-1)).toString(32)+c2,b2=":"+b2+"R"+c2,c2=Uh++,0<c2&&(b2+="H"+c2.toString(32)),b2+=":"}else c2=Vh++,b2=":"+b2+"r"+c2.toString(32)+":";return a2.memoizedState=b2},"useId"),unstable_isNewReconciler:!1},Zh={readContext:Vg,useCallback:Bi,useContext:Vg,useEffect:ji,useImperativeHandle:zi,useInsertionEffect:wi,useLayoutEffect:xi,useMemo:Ci,useReducer:fi,useRef:si,useState:__name(function(){return fi(ei)},"useState"),useDebugValue:Ai,useDeferredValue:__name(function(a2){var b2=di();return Di(b2,O2.memoizedState,a2)},"useDeferredValue"),useTransition:__name(function(){var a2=fi(ei)[0],b2=di().memoizedState;return[a2,b2]},"useTransition"),useMutableSource:hi,useSyncExternalStore:ii,useId:Fi,unstable_isNewReconciler:!1},$h={readContext:Vg,useCallback:Bi,useContext:Vg,useEffect:ji,useImperativeHandle:zi,useInsertionEffect:wi,useLayoutEffect:xi,useMemo:Ci,useReducer:gi,useRef:si,useState:__name(function(){return gi(ei)},"useState"),useDebugValue:Ai,useDeferredValue:__name(function(a2){var b2=di();return O2===null?b2.memoizedState=a2:Di(b2,O2.memoizedState,a2)},"useDeferredValue"),useTransition:__name(function(){var a2=gi(ei)[0],b2=di().memoizedState;return[a2,b2]},"useTransition"),useMutableSource:hi,useSyncExternalStore:ii,useId:Fi,unstable_isNewReconciler:!1};function Ki(a2,b2){try{var c2="",d2=b2;do c2+=Pa(d2),d2=d2.return;while(d2);var e2=c2}catch(f2){e2=`
Error generating stack: `+f2.message+`
`+f2.stack}return{value:a2,source:b2,stack:e2,digest:null}}__name(Ki,"Ki");function Li(a2,b2,c2){return{value:a2,source:null,stack:c2??null,digest:b2??null}}__name(Li,"Li");function Mi(a2,b2){try{console.error(b2.value)}catch(c2){setTimeout(function(){throw c2})}}__name(Mi,"Mi");var Ni=typeof WeakMap=="function"?WeakMap:Map;function Oi(a2,b2,c2){c2=ch(-1,c2),c2.tag=3,c2.payload={element:null};var d2=b2.value;return c2.callback=function(){Pi||(Pi=!0,Qi=d2),Mi(a2,b2)},c2}__name(Oi,"Oi");function Ri(a2,b2,c2){c2=ch(-1,c2),c2.tag=3;var d2=a2.type.getDerivedStateFromError;if(typeof d2=="function"){var e2=b2.value;c2.payload=function(){return d2(e2)},c2.callback=function(){Mi(a2,b2)}}var f2=a2.stateNode;return f2!==null&&typeof f2.componentDidCatch=="function"&&(c2.callback=function(){Mi(a2,b2),typeof d2!="function"&&(Si===null?Si=new Set([this]):Si.add(this));var c3=b2.stack;this.componentDidCatch(b2.value,{componentStack:c3!==null?c3:""})}),c2}__name(Ri,"Ri");function Ti(a2,b2,c2){var d2=a2.pingCache;if(d2===null){d2=a2.pingCache=new Ni;var e2=new Set;d2.set(b2,e2)}else e2=d2.get(b2),e2===void 0&&(e2=new Set,d2.set(b2,e2));e2.has(c2)||(e2.add(c2),a2=Ui.bind(null,a2,b2,c2),b2.then(a2,a2))}__name(Ti,"Ti");function Vi(a2){do{var b2;if((b2=a2.tag===13)&&(b2=a2.memoizedState,b2=b2!==null?b2.dehydrated!==null:!0),b2)return a2;a2=a2.return}while(a2!==null);return null}__name(Vi,"Vi");function Wi(a2,b2,c2,d2,e2){return(a2.mode&1)===0?(a2===b2?a2.flags|=65536:(a2.flags|=128,c2.flags|=131072,c2.flags&=-52805,c2.tag===1&&(c2.alternate===null?c2.tag=17:(b2=ch(-1,1),b2.tag=2,dh(c2,b2,1))),c2.lanes|=1),a2):(a2.flags|=65536,a2.lanes=e2,a2)}__name(Wi,"Wi");var Xi=ua.ReactCurrentOwner,Ug=!1;function Yi(a2,b2,c2,d2){b2.child=a2===null?Ch(b2,null,c2,d2):Bh(b2,a2.child,c2,d2)}__name(Yi,"Yi");function Zi(a2,b2,c2,d2,e2){c2=c2.render;var f2=b2.ref;return Tg(b2,e2),d2=Xh(a2,b2,c2,d2,f2,e2),c2=bi(),a2!==null&&!Ug?(b2.updateQueue=a2.updateQueue,b2.flags&=-2053,a2.lanes&=~e2,$i(a2,b2,e2)):(I2&&c2&&vg(b2),b2.flags|=1,Yi(a2,b2,d2,e2),b2.child)}__name(Zi,"Zi");function aj(a2,b2,c2,d2,e2){if(a2===null){var f2=c2.type;return typeof f2=="function"&&!bj(f2)&&f2.defaultProps===void 0&&c2.compare===null&&c2.defaultProps===void 0?(b2.tag=15,b2.type=f2,cj(a2,b2,f2,d2,e2)):(a2=yh(c2.type,null,d2,b2,b2.mode,e2),a2.ref=b2.ref,a2.return=b2,b2.child=a2)}if(f2=a2.child,(a2.lanes&e2)===0){var g2=f2.memoizedProps;if(c2=c2.compare,c2=c2!==null?c2:Ie,c2(g2,d2)&&a2.ref===b2.ref)return $i(a2,b2,e2)}return b2.flags|=1,a2=wh(f2,d2),a2.ref=b2.ref,a2.return=b2,b2.child=a2}__name(aj,"aj");function cj(a2,b2,c2,d2,e2){if(a2!==null){var f2=a2.memoizedProps;if(Ie(f2,d2)&&a2.ref===b2.ref)if(Ug=!1,b2.pendingProps=d2=f2,(a2.lanes&e2)!==0)(a2.flags&131072)!==0&&(Ug=!0);else return b2.lanes=a2.lanes,$i(a2,b2,e2)}return dj(a2,b2,c2,d2,e2)}__name(cj,"cj");function ej(a2,b2,c2){var d2=b2.pendingProps,e2=d2.children,f2=a2!==null?a2.memoizedState:null;if(d2.mode==="hidden")if((b2.mode&1)===0)b2.memoizedState={baseLanes:0,cachePool:null,transitions:null},G2(fj,gj),gj|=c2;else{if((c2&1073741824)===0)return a2=f2!==null?f2.baseLanes|c2:c2,b2.lanes=b2.childLanes=1073741824,b2.memoizedState={baseLanes:a2,cachePool:null,transitions:null},b2.updateQueue=null,G2(fj,gj),gj|=a2,null;b2.memoizedState={baseLanes:0,cachePool:null,transitions:null},d2=f2!==null?f2.baseLanes:c2,G2(fj,gj),gj|=d2}else f2!==null?(d2=f2.baseLanes|c2,b2.memoizedState=null):d2=c2,G2(fj,gj),gj|=d2;return Yi(a2,b2,e2,c2),b2.child}__name(ej,"ej");function hj(a2,b2){var c2=b2.ref;(a2===null&&c2!==null||a2!==null&&a2.ref!==c2)&&(b2.flags|=512,b2.flags|=2097152)}__name(hj,"hj");function dj(a2,b2,c2,d2,e2){var f2=Zf(c2)?Xf:H2.current;return f2=Yf(b2,f2),Tg(b2,e2),c2=Xh(a2,b2,c2,d2,f2,e2),d2=bi(),a2!==null&&!Ug?(b2.updateQueue=a2.updateQueue,b2.flags&=-2053,a2.lanes&=~e2,$i(a2,b2,e2)):(I2&&d2&&vg(b2),b2.flags|=1,Yi(a2,b2,c2,e2),b2.child)}__name(dj,"dj");function ij(a2,b2,c2,d2,e2){if(Zf(c2)){var f2=!0;cg(b2)}else f2=!1;if(Tg(b2,e2),b2.stateNode===null)jj(a2,b2),ph(b2,c2,d2),rh(b2,c2,d2,e2),d2=!0;else if(a2===null){var g2=b2.stateNode,h2=b2.memoizedProps;g2.props=h2;var k2=g2.context,l2=c2.contextType;typeof l2=="object"&&l2!==null?l2=Vg(l2):(l2=Zf(c2)?Xf:H2.current,l2=Yf(b2,l2));var m2=c2.getDerivedStateFromProps,q2=typeof m2=="function"||typeof g2.getSnapshotBeforeUpdate=="function";q2||typeof g2.UNSAFE_componentWillReceiveProps!="function"&&typeof g2.componentWillReceiveProps!="function"||(h2!==d2||k2!==l2)&&qh(b2,g2,d2,l2),$g=!1;var r2=b2.memoizedState;g2.state=r2,gh(b2,d2,g2,e2),k2=b2.memoizedState,h2!==d2||r2!==k2||Wf.current||$g?(typeof m2=="function"&&(kh(b2,c2,m2,d2),k2=b2.memoizedState),(h2=$g||oh(b2,c2,h2,d2,r2,k2,l2))?(q2||typeof g2.UNSAFE_componentWillMount!="function"&&typeof g2.componentWillMount!="function"||(typeof g2.componentWillMount=="function"&&g2.componentWillMount(),typeof g2.UNSAFE_componentWillMount=="function"&&g2.UNSAFE_componentWillMount()),typeof g2.componentDidMount=="function"&&(b2.flags|=4194308)):(typeof g2.componentDidMount=="function"&&(b2.flags|=4194308),b2.memoizedProps=d2,b2.memoizedState=k2),g2.props=d2,g2.state=k2,g2.context=l2,d2=h2):(typeof g2.componentDidMount=="function"&&(b2.flags|=4194308),d2=!1)}else{g2=b2.stateNode,bh(a2,b2),h2=b2.memoizedProps,l2=b2.type===b2.elementType?h2:Lg(b2.type,h2),g2.props=l2,q2=b2.pendingProps,r2=g2.context,k2=c2.contextType,typeof k2=="object"&&k2!==null?k2=Vg(k2):(k2=Zf(c2)?Xf:H2.current,k2=Yf(b2,k2));var y2=c2.getDerivedStateFromProps;(m2=typeof y2=="function"||typeof g2.getSnapshotBeforeUpdate=="function")||typeof g2.UNSAFE_componentWillReceiveProps!="function"&&typeof g2.componentWillReceiveProps!="function"||(h2!==q2||r2!==k2)&&qh(b2,g2,d2,k2),$g=!1,r2=b2.memoizedState,g2.state=r2,gh(b2,d2,g2,e2);var n2=b2.memoizedState;h2!==q2||r2!==n2||Wf.current||$g?(typeof y2=="function"&&(kh(b2,c2,y2,d2),n2=b2.memoizedState),(l2=$g||oh(b2,c2,l2,d2,r2,n2,k2)||!1)?(m2||typeof g2.UNSAFE_componentWillUpdate!="function"&&typeof g2.componentWillUpdate!="function"||(typeof g2.componentWillUpdate=="function"&&g2.componentWillUpdate(d2,n2,k2),typeof g2.UNSAFE_componentWillUpdate=="function"&&g2.UNSAFE_componentWillUpdate(d2,n2,k2)),typeof g2.componentDidUpdate=="function"&&(b2.flags|=4),typeof g2.getSnapshotBeforeUpdate=="function"&&(b2.flags|=1024)):(typeof g2.componentDidUpdate!="function"||h2===a2.memoizedProps&&r2===a2.memoizedState||(b2.flags|=4),typeof g2.getSnapshotBeforeUpdate!="function"||h2===a2.memoizedProps&&r2===a2.memoizedState||(b2.flags|=1024),b2.memoizedProps=d2,b2.memoizedState=n2),g2.props=d2,g2.state=n2,g2.context=k2,d2=l2):(typeof g2.componentDidUpdate!="function"||h2===a2.memoizedProps&&r2===a2.memoizedState||(b2.flags|=4),typeof g2.getSnapshotBeforeUpdate!="function"||h2===a2.memoizedProps&&r2===a2.memoizedState||(b2.flags|=1024),d2=!1)}return kj(a2,b2,c2,d2,f2,e2)}__name(ij,"ij");function kj(a2,b2,c2,d2,e2,f2){hj(a2,b2);var g2=(b2.flags&128)!==0;if(!d2&&!g2)return e2&&dg(b2,c2,!1),$i(a2,b2,f2);d2=b2.stateNode,Xi.current=b2;var h2=g2&&typeof c2.getDerivedStateFromError!="function"?null:d2.render();return b2.flags|=1,a2!==null&&g2?(b2.child=Bh(b2,a2.child,null,f2),b2.child=Bh(b2,null,h2,f2)):Yi(a2,b2,h2,f2),b2.memoizedState=d2.state,e2&&dg(b2,c2,!0),b2.child}__name(kj,"kj");function lj(a2){var b2=a2.stateNode;b2.pendingContext?ag(a2,b2.pendingContext,b2.pendingContext!==b2.context):b2.context&&ag(a2,b2.context,!1),Ih(a2,b2.containerInfo)}__name(lj,"lj");function mj(a2,b2,c2,d2,e2){return Ig(),Jg(e2),b2.flags|=256,Yi(a2,b2,c2,d2),b2.child}__name(mj,"mj");var nj={dehydrated:null,treeContext:null,retryLane:0};function oj(a2){return{baseLanes:a2,cachePool:null,transitions:null}}__name(oj,"oj");function pj(a2,b2,c2){var d2=b2.pendingProps,e2=M2.current,f2=!1,g2=(b2.flags&128)!==0,h2;if((h2=g2)||(h2=a2!==null&&a2.memoizedState===null?!1:(e2&2)!==0),h2?(f2=!0,b2.flags&=-129):(a2===null||a2.memoizedState!==null)&&(e2|=1),G2(M2,e2&1),a2===null)return Eg(b2),a2=b2.memoizedState,a2!==null&&(a2=a2.dehydrated,a2!==null)?((b2.mode&1)===0?b2.lanes=1:a2.data==="$!"?b2.lanes=8:b2.lanes=1073741824,null):(g2=d2.children,a2=d2.fallback,f2?(d2=b2.mode,f2=b2.child,g2={mode:"hidden",children:g2},(d2&1)===0&&f2!==null?(f2.childLanes=0,f2.pendingProps=g2):f2=qj(g2,d2,0,null),a2=Ah(a2,d2,c2,null),f2.return=b2,a2.return=b2,f2.sibling=a2,b2.child=f2,b2.child.memoizedState=oj(c2),b2.memoizedState=nj,a2):rj(b2,g2));if(e2=a2.memoizedState,e2!==null&&(h2=e2.dehydrated,h2!==null))return sj(a2,b2,g2,d2,h2,e2,c2);if(f2){f2=d2.fallback,g2=b2.mode,e2=a2.child,h2=e2.sibling;var k2={mode:"hidden",children:d2.children};return(g2&1)===0&&b2.child!==e2?(d2=b2.child,d2.childLanes=0,d2.pendingProps=k2,b2.deletions=null):(d2=wh(e2,k2),d2.subtreeFlags=e2.subtreeFlags&14680064),h2!==null?f2=wh(h2,f2):(f2=Ah(f2,g2,c2,null),f2.flags|=2),f2.return=b2,d2.return=b2,d2.sibling=f2,b2.child=d2,d2=f2,f2=b2.child,g2=a2.child.memoizedState,g2=g2===null?oj(c2):{baseLanes:g2.baseLanes|c2,cachePool:null,transitions:g2.transitions},f2.memoizedState=g2,f2.childLanes=a2.childLanes&~c2,b2.memoizedState=nj,d2}return f2=a2.child,a2=f2.sibling,d2=wh(f2,{mode:"visible",children:d2.children}),(b2.mode&1)===0&&(d2.lanes=c2),d2.return=b2,d2.sibling=null,a2!==null&&(c2=b2.deletions,c2===null?(b2.deletions=[a2],b2.flags|=16):c2.push(a2)),b2.child=d2,b2.memoizedState=null,d2}__name(pj,"pj");function rj(a2,b2){return b2=qj({mode:"visible",children:b2},a2.mode,0,null),b2.return=a2,a2.child=b2}__name(rj,"rj");function tj(a2,b2,c2,d2){return d2!==null&&Jg(d2),Bh(b2,a2.child,null,c2),a2=rj(b2,b2.pendingProps.children),a2.flags|=2,b2.memoizedState=null,a2}__name(tj,"tj");function sj(a2,b2,c2,d2,e2,f2,g2){if(c2)return b2.flags&256?(b2.flags&=-257,d2=Li(Error(p2(422))),tj(a2,b2,g2,d2)):b2.memoizedState!==null?(b2.child=a2.child,b2.flags|=128,null):(f2=d2.fallback,e2=b2.mode,d2=qj({mode:"visible",children:d2.children},e2,0,null),f2=Ah(f2,e2,g2,null),f2.flags|=2,d2.return=b2,f2.return=b2,d2.sibling=f2,b2.child=d2,(b2.mode&1)!==0&&Bh(b2,a2.child,null,g2),b2.child.memoizedState=oj(g2),b2.memoizedState=nj,f2);if((b2.mode&1)===0)return tj(a2,b2,g2,null);if(e2.data==="$!"){if(d2=e2.nextSibling&&e2.nextSibling.dataset,d2)var h2=d2.dgst;return d2=h2,f2=Error(p2(419)),d2=Li(f2,d2,void 0),tj(a2,b2,g2,d2)}if(h2=(g2&a2.childLanes)!==0,Ug||h2){if(d2=R,d2!==null){switch(g2&-g2){case 4:e2=2;break;case 16:e2=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:e2=32;break;case 536870912:e2=268435456;break;default:e2=0}e2=(e2&(d2.suspendedLanes|g2))!==0?0:e2,e2!==0&&e2!==f2.retryLane&&(f2.retryLane=e2,Zg(a2,e2),mh(d2,a2,e2,-1))}return uj(),d2=Li(Error(p2(421))),tj(a2,b2,g2,d2)}return e2.data==="$?"?(b2.flags|=128,b2.child=a2.child,b2=vj.bind(null,a2),e2._reactRetry=b2,null):(a2=f2.treeContext,yg=Lf(e2.nextSibling),xg=b2,I2=!0,zg=null,a2!==null&&(og[pg++]=rg,og[pg++]=sg,og[pg++]=qg,rg=a2.id,sg=a2.overflow,qg=b2),b2=rj(b2,d2.children),b2.flags|=4096,b2)}__name(sj,"sj");function wj(a2,b2,c2){a2.lanes|=b2;var d2=a2.alternate;d2!==null&&(d2.lanes|=b2),Sg(a2.return,b2,c2)}__name(wj,"wj");function xj(a2,b2,c2,d2,e2){var f2=a2.memoizedState;f2===null?a2.memoizedState={isBackwards:b2,rendering:null,renderingStartTime:0,last:d2,tail:c2,tailMode:e2}:(f2.isBackwards=b2,f2.rendering=null,f2.renderingStartTime=0,f2.last=d2,f2.tail=c2,f2.tailMode=e2)}__name(xj,"xj");function yj(a2,b2,c2){var d2=b2.pendingProps,e2=d2.revealOrder,f2=d2.tail;if(Yi(a2,b2,d2.children,c2),d2=M2.current,(d2&2)!==0)d2=d2&1|2,b2.flags|=128;else{if(a2!==null&&(a2.flags&128)!==0)a:for(a2=b2.child;a2!==null;){if(a2.tag===13)a2.memoizedState!==null&&wj(a2,c2,b2);else if(a2.tag===19)wj(a2,c2,b2);else if(a2.child!==null){a2.child.return=a2,a2=a2.child;continue}if(a2===b2)break a;for(;a2.sibling===null;){if(a2.return===null||a2.return===b2)break a;a2=a2.return}a2.sibling.return=a2.return,a2=a2.sibling}d2&=1}if(G2(M2,d2),(b2.mode&1)===0)b2.memoizedState=null;else switch(e2){case"forwards":for(c2=b2.child,e2=null;c2!==null;)a2=c2.alternate,a2!==null&&Mh(a2)===null&&(e2=c2),c2=c2.sibling;c2=e2,c2===null?(e2=b2.child,b2.child=null):(e2=c2.sibling,c2.sibling=null),xj(b2,!1,e2,c2,f2);break;case"backwards":for(c2=null,e2=b2.child,b2.child=null;e2!==null;){if(a2=e2.alternate,a2!==null&&Mh(a2)===null){b2.child=e2;break}a2=e2.sibling,e2.sibling=c2,c2=e2,e2=a2}xj(b2,!0,c2,null,f2);break;case"together":xj(b2,!1,null,null,void 0);break;default:b2.memoizedState=null}return b2.child}__name(yj,"yj");function jj(a2,b2){(b2.mode&1)===0&&a2!==null&&(a2.alternate=null,b2.alternate=null,b2.flags|=2)}__name(jj,"jj");function $i(a2,b2,c2){if(a2!==null&&(b2.dependencies=a2.dependencies),hh|=b2.lanes,(c2&b2.childLanes)===0)return null;if(a2!==null&&b2.child!==a2.child)throw Error(p2(153));if(b2.child!==null){for(a2=b2.child,c2=wh(a2,a2.pendingProps),b2.child=c2,c2.return=b2;a2.sibling!==null;)a2=a2.sibling,c2=c2.sibling=wh(a2,a2.pendingProps),c2.return=b2;c2.sibling=null}return b2.child}__name($i,"$i");function zj(a2,b2,c2){switch(b2.tag){case 3:lj(b2),Ig();break;case 5:Kh(b2);break;case 1:Zf(b2.type)&&cg(b2);break;case 4:Ih(b2,b2.stateNode.containerInfo);break;case 10:var d2=b2.type._context,e2=b2.memoizedProps.value;G2(Mg,d2._currentValue),d2._currentValue=e2;break;case 13:if(d2=b2.memoizedState,d2!==null)return d2.dehydrated!==null?(G2(M2,M2.current&1),b2.flags|=128,null):(c2&b2.child.childLanes)!==0?pj(a2,b2,c2):(G2(M2,M2.current&1),a2=$i(a2,b2,c2),a2!==null?a2.sibling:null);G2(M2,M2.current&1);break;case 19:if(d2=(c2&b2.childLanes)!==0,(a2.flags&128)!==0){if(d2)return yj(a2,b2,c2);b2.flags|=128}if(e2=b2.memoizedState,e2!==null&&(e2.rendering=null,e2.tail=null,e2.lastEffect=null),G2(M2,M2.current),d2)break;return null;case 22:case 23:return b2.lanes=0,ej(a2,b2,c2)}return $i(a2,b2,c2)}__name(zj,"zj");var Aj,Bj,Cj,Dj;Aj=__name(function(a2,b2){for(var c2=b2.child;c2!==null;){if(c2.tag===5||c2.tag===6)a2.appendChild(c2.stateNode);else if(c2.tag!==4&&c2.child!==null){c2.child.return=c2,c2=c2.child;continue}if(c2===b2)break;for(;c2.sibling===null;){if(c2.return===null||c2.return===b2)return;c2=c2.return}c2.sibling.return=c2.return,c2=c2.sibling}},"Aj"),Bj=__name(function(){},"Bj"),Cj=__name(function(a2,b2,c2,d2){var e2=a2.memoizedProps;if(e2!==d2){a2=b2.stateNode,Hh(Eh.current);var f2=null;switch(c2){case"input":e2=Ya(a2,e2),d2=Ya(a2,d2),f2=[];break;case"select":e2=A2({},e2,{value:void 0}),d2=A2({},d2,{value:void 0}),f2=[];break;case"textarea":e2=gb(a2,e2),d2=gb(a2,d2),f2=[];break;default:typeof e2.onClick!="function"&&typeof d2.onClick=="function"&&(a2.onclick=Bf)}ub(c2,d2);var g2;c2=null;for(l2 in e2)if(!d2.hasOwnProperty(l2)&&e2.hasOwnProperty(l2)&&e2[l2]!=null)if(l2==="style"){var h2=e2[l2];for(g2 in h2)h2.hasOwnProperty(g2)&&(c2||(c2={}),c2[g2]="")}else l2!=="dangerouslySetInnerHTML"&&l2!=="children"&&l2!=="suppressContentEditableWarning"&&l2!=="suppressHydrationWarning"&&l2!=="autoFocus"&&(ea.hasOwnProperty(l2)?f2||(f2=[]):(f2=f2||[]).push(l2,null));for(l2 in d2){var k2=d2[l2];if(h2=e2!=null?e2[l2]:void 0,d2.hasOwnProperty(l2)&&k2!==h2&&(k2!=null||h2!=null))if(l2==="style")if(h2){for(g2 in h2)!h2.hasOwnProperty(g2)||k2&&k2.hasOwnProperty(g2)||(c2||(c2={}),c2[g2]="");for(g2 in k2)k2.hasOwnProperty(g2)&&h2[g2]!==k2[g2]&&(c2||(c2={}),c2[g2]=k2[g2])}else c2||(f2||(f2=[]),f2.push(l2,c2)),c2=k2;else l2==="dangerouslySetInnerHTML"?(k2=k2?k2.__html:void 0,h2=h2?h2.__html:void 0,k2!=null&&h2!==k2&&(f2=f2||[]).push(l2,k2)):l2==="children"?typeof k2!="string"&&typeof k2!="number"||(f2=f2||[]).push(l2,""+k2):l2!=="suppressContentEditableWarning"&&l2!=="suppressHydrationWarning"&&(ea.hasOwnProperty(l2)?(k2!=null&&l2==="onScroll"&&D2("scroll",a2),f2||h2===k2||(f2=[])):(f2=f2||[]).push(l2,k2))}c2&&(f2=f2||[]).push("style",c2);var l2=f2;(b2.updateQueue=l2)&&(b2.flags|=4)}},"Cj"),Dj=__name(function(a2,b2,c2,d2){c2!==d2&&(b2.flags|=4)},"Dj");function Ej(a2,b2){if(!I2)switch(a2.tailMode){case"hidden":b2=a2.tail;for(var c2=null;b2!==null;)b2.alternate!==null&&(c2=b2),b2=b2.sibling;c2===null?a2.tail=null:c2.sibling=null;break;case"collapsed":c2=a2.tail;for(var d2=null;c2!==null;)c2.alternate!==null&&(d2=c2),c2=c2.sibling;d2===null?b2||a2.tail===null?a2.tail=null:a2.tail.sibling=null:d2.sibling=null}}__name(Ej,"Ej");function S2(a2){var b2=a2.alternate!==null&&a2.alternate.child===a2.child,c2=0,d2=0;if(b2)for(var e2=a2.child;e2!==null;)c2|=e2.lanes|e2.childLanes,d2|=e2.subtreeFlags&14680064,d2|=e2.flags&14680064,e2.return=a2,e2=e2.sibling;else for(e2=a2.child;e2!==null;)c2|=e2.lanes|e2.childLanes,d2|=e2.subtreeFlags,d2|=e2.flags,e2.return=a2,e2=e2.sibling;return a2.subtreeFlags|=d2,a2.childLanes=c2,b2}__name(S2,"S");function Fj(a2,b2,c2){var d2=b2.pendingProps;switch(wg(b2),b2.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return S2(b2),null;case 1:return Zf(b2.type)&&$f(),S2(b2),null;case 3:return d2=b2.stateNode,Jh(),E2(Wf),E2(H2),Oh(),d2.pendingContext&&(d2.context=d2.pendingContext,d2.pendingContext=null),(a2===null||a2.child===null)&&(Gg(b2)?b2.flags|=4:a2===null||a2.memoizedState.isDehydrated&&(b2.flags&256)===0||(b2.flags|=1024,zg!==null&&(Gj(zg),zg=null))),Bj(a2,b2),S2(b2),null;case 5:Lh(b2);var e2=Hh(Gh.current);if(c2=b2.type,a2!==null&&b2.stateNode!=null)Cj(a2,b2,c2,d2,e2),a2.ref!==b2.ref&&(b2.flags|=512,b2.flags|=2097152);else{if(!d2){if(b2.stateNode===null)throw Error(p2(166));return S2(b2),null}if(a2=Hh(Eh.current),Gg(b2)){d2=b2.stateNode,c2=b2.type;var f2=b2.memoizedProps;switch(d2[Of]=b2,d2[Pf]=f2,a2=(b2.mode&1)!==0,c2){case"dialog":D2("cancel",d2),D2("close",d2);break;case"iframe":case"object":case"embed":D2("load",d2);break;case"video":case"audio":for(e2=0;e2<lf.length;e2++)D2(lf[e2],d2);break;case"source":D2("error",d2);break;case"img":case"image":case"link":D2("error",d2),D2("load",d2);break;case"details":D2("toggle",d2);break;case"input":Za(d2,f2),D2("invalid",d2);break;case"select":d2._wrapperState={wasMultiple:!!f2.multiple},D2("invalid",d2);break;case"textarea":hb(d2,f2),D2("invalid",d2)}ub(c2,f2),e2=null;for(var g2 in f2)if(f2.hasOwnProperty(g2)){var h2=f2[g2];g2==="children"?typeof h2=="string"?d2.textContent!==h2&&(f2.suppressHydrationWarning!==!0&&Af(d2.textContent,h2,a2),e2=["children",h2]):typeof h2=="number"&&d2.textContent!==""+h2&&(f2.suppressHydrationWarning!==!0&&Af(d2.textContent,h2,a2),e2=["children",""+h2]):ea.hasOwnProperty(g2)&&h2!=null&&g2==="onScroll"&&D2("scroll",d2)}switch(c2){case"input":Va(d2),db(d2,f2,!0);break;case"textarea":Va(d2),jb(d2);break;case"select":case"option":break;default:typeof f2.onClick=="function"&&(d2.onclick=Bf)}d2=e2,b2.updateQueue=d2,d2!==null&&(b2.flags|=4)}else{g2=e2.nodeType===9?e2:e2.ownerDocument,a2==="http://www.w3.org/1999/xhtml"&&(a2=kb(c2)),a2==="http://www.w3.org/1999/xhtml"?c2==="script"?(a2=g2.createElement("div"),a2.innerHTML="<script><\/script>",a2=a2.removeChild(a2.firstChild)):typeof d2.is=="string"?a2=g2.createElement(c2,{is:d2.is}):(a2=g2.createElement(c2),c2==="select"&&(g2=a2,d2.multiple?g2.multiple=!0:d2.size&&(g2.size=d2.size))):a2=g2.createElementNS(a2,c2),a2[Of]=b2,a2[Pf]=d2,Aj(a2,b2,!1,!1),b2.stateNode=a2;a:{switch(g2=vb(c2,d2),c2){case"dialog":D2("cancel",a2),D2("close",a2),e2=d2;break;case"iframe":case"object":case"embed":D2("load",a2),e2=d2;break;case"video":case"audio":for(e2=0;e2<lf.length;e2++)D2(lf[e2],a2);e2=d2;break;case"source":D2("error",a2),e2=d2;break;case"img":case"image":case"link":D2("error",a2),D2("load",a2),e2=d2;break;case"details":D2("toggle",a2),e2=d2;break;case"input":Za(a2,d2),e2=Ya(a2,d2),D2("invalid",a2);break;case"option":e2=d2;break;case"select":a2._wrapperState={wasMultiple:!!d2.multiple},e2=A2({},d2,{value:void 0}),D2("invalid",a2);break;case"textarea":hb(a2,d2),e2=gb(a2,d2),D2("invalid",a2);break;default:e2=d2}ub(c2,e2),h2=e2;for(f2 in h2)if(h2.hasOwnProperty(f2)){var k2=h2[f2];f2==="style"?sb(a2,k2):f2==="dangerouslySetInnerHTML"?(k2=k2?k2.__html:void 0,k2!=null&&nb(a2,k2)):f2==="children"?typeof k2=="string"?(c2!=="textarea"||k2!=="")&&ob(a2,k2):typeof k2=="number"&&ob(a2,""+k2):f2!=="suppressContentEditableWarning"&&f2!=="suppressHydrationWarning"&&f2!=="autoFocus"&&(ea.hasOwnProperty(f2)?k2!=null&&f2==="onScroll"&&D2("scroll",a2):k2!=null&&ta(a2,f2,k2,g2))}switch(c2){case"input":Va(a2),db(a2,d2,!1);break;case"textarea":Va(a2),jb(a2);break;case"option":d2.value!=null&&a2.setAttribute("value",""+Sa(d2.value));break;case"select":a2.multiple=!!d2.multiple,f2=d2.value,f2!=null?fb(a2,!!d2.multiple,f2,!1):d2.defaultValue!=null&&fb(a2,!!d2.multiple,d2.defaultValue,!0);break;default:typeof e2.onClick=="function"&&(a2.onclick=Bf)}switch(c2){case"button":case"input":case"select":case"textarea":d2=!!d2.autoFocus;break a;case"img":d2=!0;break a;default:d2=!1}}d2&&(b2.flags|=4)}b2.ref!==null&&(b2.flags|=512,b2.flags|=2097152)}return S2(b2),null;case 6:if(a2&&b2.stateNode!=null)Dj(a2,b2,a2.memoizedProps,d2);else{if(typeof d2!="string"&&b2.stateNode===null)throw Error(p2(166));if(c2=Hh(Gh.current),Hh(Eh.current),Gg(b2)){if(d2=b2.stateNode,c2=b2.memoizedProps,d2[Of]=b2,(f2=d2.nodeValue!==c2)&&(a2=xg,a2!==null))switch(a2.tag){case 3:Af(d2.nodeValue,c2,(a2.mode&1)!==0);break;case 5:a2.memoizedProps.suppressHydrationWarning!==!0&&Af(d2.nodeValue,c2,(a2.mode&1)!==0)}f2&&(b2.flags|=4)}else d2=(c2.nodeType===9?c2:c2.ownerDocument).createTextNode(d2),d2[Of]=b2,b2.stateNode=d2}return S2(b2),null;case 13:if(E2(M2),d2=b2.memoizedState,a2===null||a2.memoizedState!==null&&a2.memoizedState.dehydrated!==null){if(I2&&yg!==null&&(b2.mode&1)!==0&&(b2.flags&128)===0)Hg(),Ig(),b2.flags|=98560,f2=!1;else if(f2=Gg(b2),d2!==null&&d2.dehydrated!==null){if(a2===null){if(!f2)throw Error(p2(318));if(f2=b2.memoizedState,f2=f2!==null?f2.dehydrated:null,!f2)throw Error(p2(317));f2[Of]=b2}else Ig(),(b2.flags&128)===0&&(b2.memoizedState=null),b2.flags|=4;S2(b2),f2=!1}else zg!==null&&(Gj(zg),zg=null),f2=!0;if(!f2)return b2.flags&65536?b2:null}return(b2.flags&128)!==0?(b2.lanes=c2,b2):(d2=d2!==null,d2!==(a2!==null&&a2.memoizedState!==null)&&d2&&(b2.child.flags|=8192,(b2.mode&1)!==0&&(a2===null||(M2.current&1)!==0?T2===0&&(T2=3):uj())),b2.updateQueue!==null&&(b2.flags|=4),S2(b2),null);case 4:return Jh(),Bj(a2,b2),a2===null&&sf(b2.stateNode.containerInfo),S2(b2),null;case 10:return Rg(b2.type._context),S2(b2),null;case 17:return Zf(b2.type)&&$f(),S2(b2),null;case 19:if(E2(M2),f2=b2.memoizedState,f2===null)return S2(b2),null;if(d2=(b2.flags&128)!==0,g2=f2.rendering,g2===null)if(d2)Ej(f2,!1);else{if(T2!==0||a2!==null&&(a2.flags&128)!==0)for(a2=b2.child;a2!==null;){if(g2=Mh(a2),g2!==null){for(b2.flags|=128,Ej(f2,!1),d2=g2.updateQueue,d2!==null&&(b2.updateQueue=d2,b2.flags|=4),b2.subtreeFlags=0,d2=c2,c2=b2.child;c2!==null;)f2=c2,a2=d2,f2.flags&=14680066,g2=f2.alternate,g2===null?(f2.childLanes=0,f2.lanes=a2,f2.child=null,f2.subtreeFlags=0,f2.memoizedProps=null,f2.memoizedState=null,f2.updateQueue=null,f2.dependencies=null,f2.stateNode=null):(f2.childLanes=g2.childLanes,f2.lanes=g2.lanes,f2.child=g2.child,f2.subtreeFlags=0,f2.deletions=null,f2.memoizedProps=g2.memoizedProps,f2.memoizedState=g2.memoizedState,f2.updateQueue=g2.updateQueue,f2.type=g2.type,a2=g2.dependencies,f2.dependencies=a2===null?null:{lanes:a2.lanes,firstContext:a2.firstContext}),c2=c2.sibling;return G2(M2,M2.current&1|2),b2.child}a2=a2.sibling}f2.tail!==null&&B2()>Hj&&(b2.flags|=128,d2=!0,Ej(f2,!1),b2.lanes=4194304)}else{if(!d2)if(a2=Mh(g2),a2!==null){if(b2.flags|=128,d2=!0,c2=a2.updateQueue,c2!==null&&(b2.updateQueue=c2,b2.flags|=4),Ej(f2,!0),f2.tail===null&&f2.tailMode==="hidden"&&!g2.alternate&&!I2)return S2(b2),null}else 2*B2()-f2.renderingStartTime>Hj&&c2!==1073741824&&(b2.flags|=128,d2=!0,Ej(f2,!1),b2.lanes=4194304);f2.isBackwards?(g2.sibling=b2.child,b2.child=g2):(c2=f2.last,c2!==null?c2.sibling=g2:b2.child=g2,f2.last=g2)}return f2.tail!==null?(b2=f2.tail,f2.rendering=b2,f2.tail=b2.sibling,f2.renderingStartTime=B2(),b2.sibling=null,c2=M2.current,G2(M2,d2?c2&1|2:c2&1),b2):(S2(b2),null);case 22:case 23:return Ij(),d2=b2.memoizedState!==null,a2!==null&&a2.memoizedState!==null!==d2&&(b2.flags|=8192),d2&&(b2.mode&1)!==0?(gj&1073741824)!==0&&(S2(b2),b2.subtreeFlags&6&&(b2.flags|=8192)):S2(b2),null;case 24:return null;case 25:return null}throw Error(p2(156,b2.tag))}__name(Fj,"Fj");function Jj(a2,b2){switch(wg(b2),b2.tag){case 1:return Zf(b2.type)&&$f(),a2=b2.flags,a2&65536?(b2.flags=a2&-65537|128,b2):null;case 3:return Jh(),E2(Wf),E2(H2),Oh(),a2=b2.flags,(a2&65536)!==0&&(a2&128)===0?(b2.flags=a2&-65537|128,b2):null;case 5:return Lh(b2),null;case 13:if(E2(M2),a2=b2.memoizedState,a2!==null&&a2.dehydrated!==null){if(b2.alternate===null)throw Error(p2(340));Ig()}return a2=b2.flags,a2&65536?(b2.flags=a2&-65537|128,b2):null;case 19:return E2(M2),null;case 4:return Jh(),null;case 10:return Rg(b2.type._context),null;case 22:case 23:return Ij(),null;case 24:return null;default:return null}}__name(Jj,"Jj");var Kj=!1,U2=!1,Lj=typeof WeakSet=="function"?WeakSet:Set,V2=null;function Mj(a2,b2){var c2=a2.ref;if(c2!==null)if(typeof c2=="function")try{c2(null)}catch(d2){W2(a2,b2,d2)}else c2.current=null}__name(Mj,"Mj");function Nj(a2,b2,c2){try{c2()}catch(d2){W2(a2,b2,d2)}}__name(Nj,"Nj");var Oj=!1;function Pj(a2,b2){if(Cf=dd,a2=Me(),Ne(a2)){if("selectionStart"in a2)var c2={start:a2.selectionStart,end:a2.selectionEnd};else a:{c2=(c2=a2.ownerDocument)&&c2.defaultView||window;var d2=c2.getSelection&&c2.getSelection();if(d2&&d2.rangeCount!==0){c2=d2.anchorNode;var e2=d2.anchorOffset,f2=d2.focusNode;d2=d2.focusOffset;try{c2.nodeType,f2.nodeType}catch{c2=null;break a}var g2=0,h2=-1,k2=-1,l2=0,m2=0,q2=a2,r2=null;b:for(;;){for(var y2;q2!==c2||e2!==0&&q2.nodeType!==3||(h2=g2+e2),q2!==f2||d2!==0&&q2.nodeType!==3||(k2=g2+d2),q2.nodeType===3&&(g2+=q2.nodeValue.length),(y2=q2.firstChild)!==null;)r2=q2,q2=y2;for(;;){if(q2===a2)break b;if(r2===c2&&++l2===e2&&(h2=g2),r2===f2&&++m2===d2&&(k2=g2),(y2=q2.nextSibling)!==null)break;q2=r2,r2=q2.parentNode}q2=y2}c2=h2===-1||k2===-1?null:{start:h2,end:k2}}else c2=null}c2=c2||{start:0,end:0}}else c2=null;for(Df={focusedElem:a2,selectionRange:c2},dd=!1,V2=b2;V2!==null;)if(b2=V2,a2=b2.child,(b2.subtreeFlags&1028)!==0&&a2!==null)a2.return=b2,V2=a2;else for(;V2!==null;){b2=V2;try{var n2=b2.alternate;if((b2.flags&1024)!==0)switch(b2.tag){case 0:case 11:case 15:break;case 1:if(n2!==null){var t2=n2.memoizedProps,J2=n2.memoizedState,x2=b2.stateNode,w2=x2.getSnapshotBeforeUpdate(b2.elementType===b2.type?t2:Lg(b2.type,t2),J2);x2.__reactInternalSnapshotBeforeUpdate=w2}break;case 3:var u2=b2.stateNode.containerInfo;u2.nodeType===1?u2.textContent="":u2.nodeType===9&&u2.documentElement&&u2.removeChild(u2.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(p2(163))}}catch(F2){W2(b2,b2.return,F2)}if(a2=b2.sibling,a2!==null){a2.return=b2.return,V2=a2;break}V2=b2.return}return n2=Oj,Oj=!1,n2}__name(Pj,"Pj");function Qj(a2,b2,c2){var d2=b2.updateQueue;if(d2=d2!==null?d2.lastEffect:null,d2!==null){var e2=d2=d2.next;do{if((e2.tag&a2)===a2){var f2=e2.destroy;e2.destroy=void 0,f2!==void 0&&Nj(b2,c2,f2)}e2=e2.next}while(e2!==d2)}}__name(Qj,"Qj");function Rj(a2,b2){if(b2=b2.updateQueue,b2=b2!==null?b2.lastEffect:null,b2!==null){var c2=b2=b2.next;do{if((c2.tag&a2)===a2){var d2=c2.create;c2.destroy=d2()}c2=c2.next}while(c2!==b2)}}__name(Rj,"Rj");function Sj(a2){var b2=a2.ref;if(b2!==null){var c2=a2.stateNode;switch(a2.tag){case 5:a2=c2;break;default:a2=c2}typeof b2=="function"?b2(a2):b2.current=a2}}__name(Sj,"Sj");function Tj(a2){var b2=a2.alternate;b2!==null&&(a2.alternate=null,Tj(b2)),a2.child=null,a2.deletions=null,a2.sibling=null,a2.tag===5&&(b2=a2.stateNode,b2!==null&&(delete b2[Of],delete b2[Pf],delete b2[of],delete b2[Qf],delete b2[Rf])),a2.stateNode=null,a2.return=null,a2.dependencies=null,a2.memoizedProps=null,a2.memoizedState=null,a2.pendingProps=null,a2.stateNode=null,a2.updateQueue=null}__name(Tj,"Tj");function Uj(a2){return a2.tag===5||a2.tag===3||a2.tag===4}__name(Uj,"Uj");function Vj(a2){a:for(;;){for(;a2.sibling===null;){if(a2.return===null||Uj(a2.return))return null;a2=a2.return}for(a2.sibling.return=a2.return,a2=a2.sibling;a2.tag!==5&&a2.tag!==6&&a2.tag!==18;){if(a2.flags&2||a2.child===null||a2.tag===4)continue a;a2.child.return=a2,a2=a2.child}if(!(a2.flags&2))return a2.stateNode}}__name(Vj,"Vj");function Wj(a2,b2,c2){var d2=a2.tag;if(d2===5||d2===6)a2=a2.stateNode,b2?c2.nodeType===8?c2.parentNode.insertBefore(a2,b2):c2.insertBefore(a2,b2):(c2.nodeType===8?(b2=c2.parentNode,b2.insertBefore(a2,c2)):(b2=c2,b2.appendChild(a2)),c2=c2._reactRootContainer,c2!=null||b2.onclick!==null||(b2.onclick=Bf));else if(d2!==4&&(a2=a2.child,a2!==null))for(Wj(a2,b2,c2),a2=a2.sibling;a2!==null;)Wj(a2,b2,c2),a2=a2.sibling}__name(Wj,"Wj");function Xj(a2,b2,c2){var d2=a2.tag;if(d2===5||d2===6)a2=a2.stateNode,b2?c2.insertBefore(a2,b2):c2.appendChild(a2);else if(d2!==4&&(a2=a2.child,a2!==null))for(Xj(a2,b2,c2),a2=a2.sibling;a2!==null;)Xj(a2,b2,c2),a2=a2.sibling}__name(Xj,"Xj");var X=null,Yj=!1;function Zj(a2,b2,c2){for(c2=c2.child;c2!==null;)ak(a2,b2,c2),c2=c2.sibling}__name(Zj,"Zj");function ak(a2,b2,c2){if(lc&&typeof lc.onCommitFiberUnmount=="function")try{lc.onCommitFiberUnmount(kc,c2)}catch{}switch(c2.tag){case 5:U2||Mj(c2,b2);case 6:var d2=X,e2=Yj;X=null,Zj(a2,b2,c2),X=d2,Yj=e2,X!==null&&(Yj?(a2=X,c2=c2.stateNode,a2.nodeType===8?a2.parentNode.removeChild(c2):a2.removeChild(c2)):X.removeChild(c2.stateNode));break;case 18:X!==null&&(Yj?(a2=X,c2=c2.stateNode,a2.nodeType===8?Kf(a2.parentNode,c2):a2.nodeType===1&&Kf(a2,c2),bd(a2)):Kf(X,c2.stateNode));break;case 4:d2=X,e2=Yj,X=c2.stateNode.containerInfo,Yj=!0,Zj(a2,b2,c2),X=d2,Yj=e2;break;case 0:case 11:case 14:case 15:if(!U2&&(d2=c2.updateQueue,d2!==null&&(d2=d2.lastEffect,d2!==null))){e2=d2=d2.next;do{var f2=e2,g2=f2.destroy;f2=f2.tag,g2!==void 0&&((f2&2)!==0||(f2&4)!==0)&&Nj(c2,b2,g2),e2=e2.next}while(e2!==d2)}Zj(a2,b2,c2);break;case 1:if(!U2&&(Mj(c2,b2),d2=c2.stateNode,typeof d2.componentWillUnmount=="function"))try{d2.props=c2.memoizedProps,d2.state=c2.memoizedState,d2.componentWillUnmount()}catch(h2){W2(c2,b2,h2)}Zj(a2,b2,c2);break;case 21:Zj(a2,b2,c2);break;case 22:c2.mode&1?(U2=(d2=U2)||c2.memoizedState!==null,Zj(a2,b2,c2),U2=d2):Zj(a2,b2,c2);break;default:Zj(a2,b2,c2)}}__name(ak,"ak");function bk(a2){var b2=a2.updateQueue;if(b2!==null){a2.updateQueue=null;var c2=a2.stateNode;c2===null&&(c2=a2.stateNode=new Lj),b2.forEach(function(b3){var d2=ck.bind(null,a2,b3);c2.has(b3)||(c2.add(b3),b3.then(d2,d2))})}}__name(bk,"bk");function dk(a2,b2){var c2=b2.deletions;if(c2!==null)for(var d2=0;d2<c2.length;d2++){var e2=c2[d2];try{var f2=a2,g2=b2,h2=g2;a:for(;h2!==null;){switch(h2.tag){case 5:X=h2.stateNode,Yj=!1;break a;case 3:X=h2.stateNode.containerInfo,Yj=!0;break a;case 4:X=h2.stateNode.containerInfo,Yj=!0;break a}h2=h2.return}if(X===null)throw Error(p2(160));ak(f2,g2,e2),X=null,Yj=!1;var k2=e2.alternate;k2!==null&&(k2.return=null),e2.return=null}catch(l2){W2(e2,b2,l2)}}if(b2.subtreeFlags&12854)for(b2=b2.child;b2!==null;)ek(b2,a2),b2=b2.sibling}__name(dk,"dk");function ek(a2,b2){var c2=a2.alternate,d2=a2.flags;switch(a2.tag){case 0:case 11:case 14:case 15:if(dk(b2,a2),fk(a2),d2&4){try{Qj(3,a2,a2.return),Rj(3,a2)}catch(t2){W2(a2,a2.return,t2)}try{Qj(5,a2,a2.return)}catch(t2){W2(a2,a2.return,t2)}}break;case 1:dk(b2,a2),fk(a2),d2&512&&c2!==null&&Mj(c2,c2.return);break;case 5:if(dk(b2,a2),fk(a2),d2&512&&c2!==null&&Mj(c2,c2.return),a2.flags&32){var e2=a2.stateNode;try{ob(e2,"")}catch(t2){W2(a2,a2.return,t2)}}if(d2&4&&(e2=a2.stateNode,e2!=null)){var f2=a2.memoizedProps,g2=c2!==null?c2.memoizedProps:f2,h2=a2.type,k2=a2.updateQueue;if(a2.updateQueue=null,k2!==null)try{h2==="input"&&f2.type==="radio"&&f2.name!=null&&ab(e2,f2),vb(h2,g2);var l2=vb(h2,f2);for(g2=0;g2<k2.length;g2+=2){var m2=k2[g2],q2=k2[g2+1];m2==="style"?sb(e2,q2):m2==="dangerouslySetInnerHTML"?nb(e2,q2):m2==="children"?ob(e2,q2):ta(e2,m2,q2,l2)}switch(h2){case"input":bb(e2,f2);break;case"textarea":ib(e2,f2);break;case"select":var r2=e2._wrapperState.wasMultiple;e2._wrapperState.wasMultiple=!!f2.multiple;var y2=f2.value;y2!=null?fb(e2,!!f2.multiple,y2,!1):r2!==!!f2.multiple&&(f2.defaultValue!=null?fb(e2,!!f2.multiple,f2.defaultValue,!0):fb(e2,!!f2.multiple,f2.multiple?[]:"",!1))}e2[Pf]=f2}catch(t2){W2(a2,a2.return,t2)}}break;case 6:if(dk(b2,a2),fk(a2),d2&4){if(a2.stateNode===null)throw Error(p2(162));e2=a2.stateNode,f2=a2.memoizedProps;try{e2.nodeValue=f2}catch(t2){W2(a2,a2.return,t2)}}break;case 3:if(dk(b2,a2),fk(a2),d2&4&&c2!==null&&c2.memoizedState.isDehydrated)try{bd(b2.containerInfo)}catch(t2){W2(a2,a2.return,t2)}break;case 4:dk(b2,a2),fk(a2);break;case 13:dk(b2,a2),fk(a2),e2=a2.child,e2.flags&8192&&(f2=e2.memoizedState!==null,e2.stateNode.isHidden=f2,!f2||e2.alternate!==null&&e2.alternate.memoizedState!==null||(gk=B2())),d2&4&&bk(a2);break;case 22:if(m2=c2!==null&&c2.memoizedState!==null,a2.mode&1?(U2=(l2=U2)||m2,dk(b2,a2),U2=l2):dk(b2,a2),fk(a2),d2&8192){if(l2=a2.memoizedState!==null,(a2.stateNode.isHidden=l2)&&!m2&&(a2.mode&1)!==0)for(V2=a2,m2=a2.child;m2!==null;){for(q2=V2=m2;V2!==null;){switch(r2=V2,y2=r2.child,r2.tag){case 0:case 11:case 14:case 15:Qj(4,r2,r2.return);break;case 1:Mj(r2,r2.return);var n2=r2.stateNode;if(typeof n2.componentWillUnmount=="function"){d2=r2,c2=r2.return;try{b2=d2,n2.props=b2.memoizedProps,n2.state=b2.memoizedState,n2.componentWillUnmount()}catch(t2){W2(d2,c2,t2)}}break;case 5:Mj(r2,r2.return);break;case 22:if(r2.memoizedState!==null){hk(q2);continue}}y2!==null?(y2.return=r2,V2=y2):hk(q2)}m2=m2.sibling}a:for(m2=null,q2=a2;;){if(q2.tag===5){if(m2===null){m2=q2;try{e2=q2.stateNode,l2?(f2=e2.style,typeof f2.setProperty=="function"?f2.setProperty("display","none","important"):f2.display="none"):(h2=q2.stateNode,k2=q2.memoizedProps.style,g2=k2!=null&&k2.hasOwnProperty("display")?k2.display:null,h2.style.display=rb("display",g2))}catch(t2){W2(a2,a2.return,t2)}}}else if(q2.tag===6){if(m2===null)try{q2.stateNode.nodeValue=l2?"":q2.memoizedProps}catch(t2){W2(a2,a2.return,t2)}}else if((q2.tag!==22&&q2.tag!==23||q2.memoizedState===null||q2===a2)&&q2.child!==null){q2.child.return=q2,q2=q2.child;continue}if(q2===a2)break a;for(;q2.sibling===null;){if(q2.return===null||q2.return===a2)break a;m2===q2&&(m2=null),q2=q2.return}m2===q2&&(m2=null),q2.sibling.return=q2.return,q2=q2.sibling}}break;case 19:dk(b2,a2),fk(a2),d2&4&&bk(a2);break;case 21:break;default:dk(b2,a2),fk(a2)}}__name(ek,"ek");function fk(a2){var b2=a2.flags;if(b2&2){try{a:{for(var c2=a2.return;c2!==null;){if(Uj(c2)){var d2=c2;break a}c2=c2.return}throw Error(p2(160))}switch(d2.tag){case 5:var e2=d2.stateNode;d2.flags&32&&(ob(e2,""),d2.flags&=-33);var f2=Vj(a2);Xj(a2,f2,e2);break;case 3:case 4:var g2=d2.stateNode.containerInfo,h2=Vj(a2);Wj(a2,h2,g2);break;default:throw Error(p2(161))}}catch(k2){W2(a2,a2.return,k2)}a2.flags&=-3}b2&4096&&(a2.flags&=-4097)}__name(fk,"fk");function ik(a2,b2,c2){V2=a2,jk(a2)}__name(ik,"ik");function jk(a2,b2,c2){for(var d2=(a2.mode&1)!==0;V2!==null;){var e2=V2,f2=e2.child;if(e2.tag===22&&d2){var g2=e2.memoizedState!==null||Kj;if(!g2){var h2=e2.alternate,k2=h2!==null&&h2.memoizedState!==null||U2;h2=Kj;var l2=U2;if(Kj=g2,(U2=k2)&&!l2)for(V2=e2;V2!==null;)g2=V2,k2=g2.child,g2.tag===22&&g2.memoizedState!==null?kk(e2):k2!==null?(k2.return=g2,V2=k2):kk(e2);for(;f2!==null;)V2=f2,jk(f2),f2=f2.sibling;V2=e2,Kj=h2,U2=l2}lk(a2)}else(e2.subtreeFlags&8772)!==0&&f2!==null?(f2.return=e2,V2=f2):lk(a2)}}__name(jk,"jk");function lk(a2){for(;V2!==null;){var b2=V2;if((b2.flags&8772)!==0){var c2=b2.alternate;try{if((b2.flags&8772)!==0)switch(b2.tag){case 0:case 11:case 15:U2||Rj(5,b2);break;case 1:var d2=b2.stateNode;if(b2.flags&4&&!U2)if(c2===null)d2.componentDidMount();else{var e2=b2.elementType===b2.type?c2.memoizedProps:Lg(b2.type,c2.memoizedProps);d2.componentDidUpdate(e2,c2.memoizedState,d2.__reactInternalSnapshotBeforeUpdate)}var f2=b2.updateQueue;f2!==null&&ih(b2,f2,d2);break;case 3:var g2=b2.updateQueue;if(g2!==null){if(c2=null,b2.child!==null)switch(b2.child.tag){case 5:c2=b2.child.stateNode;break;case 1:c2=b2.child.stateNode}ih(b2,g2,c2)}break;case 5:var h2=b2.stateNode;if(c2===null&&b2.flags&4){c2=h2;var k2=b2.memoizedProps;switch(b2.type){case"button":case"input":case"select":case"textarea":k2.autoFocus&&c2.focus();break;case"img":k2.src&&(c2.src=k2.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(b2.memoizedState===null){var l2=b2.alternate;if(l2!==null){var m2=l2.memoizedState;if(m2!==null){var q2=m2.dehydrated;q2!==null&&bd(q2)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(p2(163))}U2||b2.flags&512&&Sj(b2)}catch(r2){W2(b2,b2.return,r2)}}if(b2===a2){V2=null;break}if(c2=b2.sibling,c2!==null){c2.return=b2.return,V2=c2;break}V2=b2.return}}__name(lk,"lk");function hk(a2){for(;V2!==null;){var b2=V2;if(b2===a2){V2=null;break}var c2=b2.sibling;if(c2!==null){c2.return=b2.return,V2=c2;break}V2=b2.return}}__name(hk,"hk");function kk(a2){for(;V2!==null;){var b2=V2;try{switch(b2.tag){case 0:case 11:case 15:var c2=b2.return;try{Rj(4,b2)}catch(k2){W2(b2,c2,k2)}break;case 1:var d2=b2.stateNode;if(typeof d2.componentDidMount=="function"){var e2=b2.return;try{d2.componentDidMount()}catch(k2){W2(b2,e2,k2)}}var f2=b2.return;try{Sj(b2)}catch(k2){W2(b2,f2,k2)}break;case 5:var g2=b2.return;try{Sj(b2)}catch(k2){W2(b2,g2,k2)}}}catch(k2){W2(b2,b2.return,k2)}if(b2===a2){V2=null;break}var h2=b2.sibling;if(h2!==null){h2.return=b2.return,V2=h2;break}V2=b2.return}}__name(kk,"kk");var mk=Math.ceil,nk=ua.ReactCurrentDispatcher,ok=ua.ReactCurrentOwner,pk=ua.ReactCurrentBatchConfig,K2=0,R=null,Y2=null,Z2=0,gj=0,fj=Uf(0),T2=0,qk=null,hh=0,rk=0,sk=0,tk=null,uk=null,gk=0,Hj=1/0,vk=null,Pi=!1,Qi=null,Si=null,wk=!1,xk=null,yk=0,zk=0,Ak=null,Bk=-1,Ck=0;function L2(){return(K2&6)!==0?B2():Bk!==-1?Bk:Bk=B2()}__name(L2,"L");function lh(a2){return(a2.mode&1)===0?1:(K2&2)!==0&&Z2!==0?Z2&-Z2:Kg.transition!==null?(Ck===0&&(Ck=yc()),Ck):(a2=C2,a2!==0||(a2=window.event,a2=a2===void 0?16:jd(a2.type)),a2)}__name(lh,"lh");function mh(a2,b2,c2,d2){if(50<zk)throw zk=0,Ak=null,Error(p2(185));Ac(a2,c2,d2),((K2&2)===0||a2!==R)&&(a2===R&&((K2&2)===0&&(rk|=c2),T2===4&&Dk(a2,Z2)),Ek(a2,d2),c2===1&&K2===0&&(b2.mode&1)===0&&(Hj=B2()+500,fg&&jg()))}__name(mh,"mh");function Ek(a2,b2){var c2=a2.callbackNode;wc(a2,b2);var d2=uc(a2,a2===R?Z2:0);if(d2===0)c2!==null&&bc(c2),a2.callbackNode=null,a2.callbackPriority=0;else if(b2=d2&-d2,a2.callbackPriority!==b2){if(c2!=null&&bc(c2),b2===1)a2.tag===0?ig(Fk.bind(null,a2)):hg(Fk.bind(null,a2)),Jf(function(){(K2&6)===0&&jg()}),c2=null;else{switch(Dc(d2)){case 1:c2=fc;break;case 4:c2=gc;break;case 16:c2=hc;break;case 536870912:c2=jc;break;default:c2=hc}c2=Gk(c2,Hk.bind(null,a2))}a2.callbackPriority=b2,a2.callbackNode=c2}}__name(Ek,"Ek");function Hk(a2,b2){if(Bk=-1,Ck=0,(K2&6)!==0)throw Error(p2(327));var c2=a2.callbackNode;if(Ik()&&a2.callbackNode!==c2)return null;var d2=uc(a2,a2===R?Z2:0);if(d2===0)return null;if((d2&30)!==0||(d2&a2.expiredLanes)!==0||b2)b2=Jk(a2,d2);else{b2=d2;var e2=K2;K2|=2;var f2=Kk();(R!==a2||Z2!==b2)&&(vk=null,Hj=B2()+500,Lk(a2,b2));do try{Mk();break}catch(h2){Nk(a2,h2)}while(!0);Qg(),nk.current=f2,K2=e2,Y2!==null?b2=0:(R=null,Z2=0,b2=T2)}if(b2!==0){if(b2===2&&(e2=xc(a2),e2!==0&&(d2=e2,b2=Ok(a2,e2))),b2===1)throw c2=qk,Lk(a2,0),Dk(a2,d2),Ek(a2,B2()),c2;if(b2===6)Dk(a2,d2);else{if(e2=a2.current.alternate,(d2&30)===0&&!Pk(e2)&&(b2=Jk(a2,d2),b2===2&&(f2=xc(a2),f2!==0&&(d2=f2,b2=Ok(a2,f2))),b2===1))throw c2=qk,Lk(a2,0),Dk(a2,d2),Ek(a2,B2()),c2;switch(a2.finishedWork=e2,a2.finishedLanes=d2,b2){case 0:case 1:throw Error(p2(345));case 2:Qk(a2,uk,vk);break;case 3:if(Dk(a2,d2),(d2&130023424)===d2&&(b2=gk+500-B2(),10<b2)){if(uc(a2,0)!==0)break;if(e2=a2.suspendedLanes,(e2&d2)!==d2){L2(),a2.pingedLanes|=a2.suspendedLanes&e2;break}a2.timeoutHandle=Ff(Qk.bind(null,a2,uk,vk),b2);break}Qk(a2,uk,vk);break;case 4:if(Dk(a2,d2),(d2&4194240)===d2)break;for(b2=a2.eventTimes,e2=-1;0<d2;){var g2=31-oc(d2);f2=1<<g2,g2=b2[g2],g2>e2&&(e2=g2),d2&=~f2}if(d2=e2,d2=B2()-d2,d2=(120>d2?120:480>d2?480:1080>d2?1080:1920>d2?1920:3e3>d2?3e3:4320>d2?4320:1960*mk(d2/1960))-d2,10<d2){a2.timeoutHandle=Ff(Qk.bind(null,a2,uk,vk),d2);break}Qk(a2,uk,vk);break;case 5:Qk(a2,uk,vk);break;default:throw Error(p2(329))}}}return Ek(a2,B2()),a2.callbackNode===c2?Hk.bind(null,a2):null}__name(Hk,"Hk");function Ok(a2,b2){var c2=tk;return a2.current.memoizedState.isDehydrated&&(Lk(a2,b2).flags|=256),a2=Jk(a2,b2),a2!==2&&(b2=uk,uk=c2,b2!==null&&Gj(b2)),a2}__name(Ok,"Ok");function Gj(a2){uk===null?uk=a2:uk.push.apply(uk,a2)}__name(Gj,"Gj");function Pk(a2){for(var b2=a2;;){if(b2.flags&16384){var c2=b2.updateQueue;if(c2!==null&&(c2=c2.stores,c2!==null))for(var d2=0;d2<c2.length;d2++){var e2=c2[d2],f2=e2.getSnapshot;e2=e2.value;try{if(!He(f2(),e2))return!1}catch{return!1}}}if(c2=b2.child,b2.subtreeFlags&16384&&c2!==null)c2.return=b2,b2=c2;else{if(b2===a2)break;for(;b2.sibling===null;){if(b2.return===null||b2.return===a2)return!0;b2=b2.return}b2.sibling.return=b2.return,b2=b2.sibling}}return!0}__name(Pk,"Pk");function Dk(a2,b2){for(b2&=~sk,b2&=~rk,a2.suspendedLanes|=b2,a2.pingedLanes&=~b2,a2=a2.expirationTimes;0<b2;){var c2=31-oc(b2),d2=1<<c2;a2[c2]=-1,b2&=~d2}}__name(Dk,"Dk");function Fk(a2){if((K2&6)!==0)throw Error(p2(327));Ik();var b2=uc(a2,0);if((b2&1)===0)return Ek(a2,B2()),null;var c2=Jk(a2,b2);if(a2.tag!==0&&c2===2){var d2=xc(a2);d2!==0&&(b2=d2,c2=Ok(a2,d2))}if(c2===1)throw c2=qk,Lk(a2,0),Dk(a2,b2),Ek(a2,B2()),c2;if(c2===6)throw Error(p2(345));return a2.finishedWork=a2.current.alternate,a2.finishedLanes=b2,Qk(a2,uk,vk),Ek(a2,B2()),null}__name(Fk,"Fk");function Rk(a2,b2){var c2=K2;K2|=1;try{return a2(b2)}finally{K2=c2,K2===0&&(Hj=B2()+500,fg&&jg())}}__name(Rk,"Rk");function Sk(a2){xk!==null&&xk.tag===0&&(K2&6)===0&&Ik();var b2=K2;K2|=1;var c2=pk.transition,d2=C2;try{if(pk.transition=null,C2=1,a2)return a2()}finally{C2=d2,pk.transition=c2,K2=b2,(K2&6)===0&&jg()}}__name(Sk,"Sk");function Ij(){gj=fj.current,E2(fj)}__name(Ij,"Ij");function Lk(a2,b2){a2.finishedWork=null,a2.finishedLanes=0;var c2=a2.timeoutHandle;if(c2!==-1&&(a2.timeoutHandle=-1,Gf(c2)),Y2!==null)for(c2=Y2.return;c2!==null;){var d2=c2;switch(wg(d2),d2.tag){case 1:d2=d2.type.childContextTypes,d2!=null&&$f();break;case 3:Jh(),E2(Wf),E2(H2),Oh();break;case 5:Lh(d2);break;case 4:Jh();break;case 13:E2(M2);break;case 19:E2(M2);break;case 10:Rg(d2.type._context);break;case 22:case 23:Ij()}c2=c2.return}if(R=a2,Y2=a2=wh(a2.current,null),Z2=gj=b2,T2=0,qk=null,sk=rk=hh=0,uk=tk=null,Wg!==null){for(b2=0;b2<Wg.length;b2++)if(c2=Wg[b2],d2=c2.interleaved,d2!==null){c2.interleaved=null;var e2=d2.next,f2=c2.pending;if(f2!==null){var g2=f2.next;f2.next=e2,d2.next=g2}c2.pending=d2}Wg=null}return a2}__name(Lk,"Lk");function Nk(a2,b2){do{var c2=Y2;try{if(Qg(),Ph.current=ai,Sh){for(var d2=N2.memoizedState;d2!==null;){var e2=d2.queue;e2!==null&&(e2.pending=null),d2=d2.next}Sh=!1}if(Rh=0,P2=O2=N2=null,Th=!1,Uh=0,ok.current=null,c2===null||c2.return===null){T2=1,qk=b2,Y2=null;break}a:{var f2=a2,g2=c2.return,h2=c2,k2=b2;if(b2=Z2,h2.flags|=32768,k2!==null&&typeof k2=="object"&&typeof k2.then=="function"){var l2=k2,m2=h2,q2=m2.tag;if((m2.mode&1)===0&&(q2===0||q2===11||q2===15)){var r2=m2.alternate;r2?(m2.updateQueue=r2.updateQueue,m2.memoizedState=r2.memoizedState,m2.lanes=r2.lanes):(m2.updateQueue=null,m2.memoizedState=null)}var y2=Vi(g2);if(y2!==null){y2.flags&=-257,Wi(y2,g2,h2,f2,b2),y2.mode&1&&Ti(f2,l2,b2),b2=y2,k2=l2;var n2=b2.updateQueue;if(n2===null){var t2=new Set;t2.add(k2),b2.updateQueue=t2}else n2.add(k2);break a}else{if((b2&1)===0){Ti(f2,l2,b2),uj();break a}k2=Error(p2(426))}}else if(I2&&h2.mode&1){var J2=Vi(g2);if(J2!==null){(J2.flags&65536)===0&&(J2.flags|=256),Wi(J2,g2,h2,f2,b2),Jg(Ki(k2,h2));break a}}f2=k2=Ki(k2,h2),T2!==4&&(T2=2),tk===null?tk=[f2]:tk.push(f2),f2=g2;do{switch(f2.tag){case 3:f2.flags|=65536,b2&=-b2,f2.lanes|=b2;var x2=Oi(f2,k2,b2);fh(f2,x2);break a;case 1:h2=k2;var w2=f2.type,u2=f2.stateNode;if((f2.flags&128)===0&&(typeof w2.getDerivedStateFromError=="function"||u2!==null&&typeof u2.componentDidCatch=="function"&&(Si===null||!Si.has(u2)))){f2.flags|=65536,b2&=-b2,f2.lanes|=b2;var F2=Ri(f2,h2,b2);fh(f2,F2);break a}}f2=f2.return}while(f2!==null)}Tk(c2)}catch(na){b2=na,Y2===c2&&c2!==null&&(Y2=c2=c2.return);continue}break}while(!0)}__name(Nk,"Nk");function Kk(){var a2=nk.current;return nk.current=ai,a2===null?ai:a2}__name(Kk,"Kk");function uj(){(T2===0||T2===3||T2===2)&&(T2=4),R===null||(hh&268435455)===0&&(rk&268435455)===0||Dk(R,Z2)}__name(uj,"uj");function Jk(a2,b2){var c2=K2;K2|=2;var d2=Kk();(R!==a2||Z2!==b2)&&(vk=null,Lk(a2,b2));do try{Uk();break}catch(e2){Nk(a2,e2)}while(!0);if(Qg(),K2=c2,nk.current=d2,Y2!==null)throw Error(p2(261));return R=null,Z2=0,T2}__name(Jk,"Jk");function Uk(){for(;Y2!==null;)Vk(Y2)}__name(Uk,"Uk");function Mk(){for(;Y2!==null&&!cc();)Vk(Y2)}__name(Mk,"Mk");function Vk(a2){var b2=Wk(a2.alternate,a2,gj);a2.memoizedProps=a2.pendingProps,b2===null?Tk(a2):Y2=b2,ok.current=null}__name(Vk,"Vk");function Tk(a2){var b2=a2;do{var c2=b2.alternate;if(a2=b2.return,(b2.flags&32768)===0){if(c2=Fj(c2,b2,gj),c2!==null){Y2=c2;return}}else{if(c2=Jj(c2,b2),c2!==null){c2.flags&=32767,Y2=c2;return}if(a2!==null)a2.flags|=32768,a2.subtreeFlags=0,a2.deletions=null;else{T2=6,Y2=null;return}}if(b2=b2.sibling,b2!==null){Y2=b2;return}Y2=b2=a2}while(b2!==null);T2===0&&(T2=5)}__name(Tk,"Tk");function Qk(a2,b2,c2){var d2=C2,e2=pk.transition;try{pk.transition=null,C2=1,Xk(a2,b2,c2,d2)}finally{pk.transition=e2,C2=d2}return null}__name(Qk,"Qk");function Xk(a2,b2,c2,d2){do Ik();while(xk!==null);if((K2&6)!==0)throw Error(p2(327));c2=a2.finishedWork;var e2=a2.finishedLanes;if(c2===null)return null;if(a2.finishedWork=null,a2.finishedLanes=0,c2===a2.current)throw Error(p2(177));a2.callbackNode=null,a2.callbackPriority=0;var f2=c2.lanes|c2.childLanes;if(Bc(a2,f2),a2===R&&(Y2=R=null,Z2=0),(c2.subtreeFlags&2064)===0&&(c2.flags&2064)===0||wk||(wk=!0,Gk(hc,function(){return Ik(),null})),f2=(c2.flags&15990)!==0,(c2.subtreeFlags&15990)!==0||f2){f2=pk.transition,pk.transition=null;var g2=C2;C2=1;var h2=K2;K2|=4,ok.current=null,Pj(a2,c2),ek(c2,a2),Oe(Df),dd=!!Cf,Df=Cf=null,a2.current=c2,ik(c2),dc(),K2=h2,C2=g2,pk.transition=f2}else a2.current=c2;if(wk&&(wk=!1,xk=a2,yk=e2),f2=a2.pendingLanes,f2===0&&(Si=null),mc(c2.stateNode),Ek(a2,B2()),b2!==null)for(d2=a2.onRecoverableError,c2=0;c2<b2.length;c2++)e2=b2[c2],d2(e2.value,{componentStack:e2.stack,digest:e2.digest});if(Pi)throw Pi=!1,a2=Qi,Qi=null,a2;return(yk&1)!==0&&a2.tag!==0&&Ik(),f2=a2.pendingLanes,(f2&1)!==0?a2===Ak?zk++:(zk=0,Ak=a2):zk=0,jg(),null}__name(Xk,"Xk");function Ik(){if(xk!==null){var a2=Dc(yk),b2=pk.transition,c2=C2;try{if(pk.transition=null,C2=16>a2?16:a2,xk===null)var d2=!1;else{if(a2=xk,xk=null,yk=0,(K2&6)!==0)throw Error(p2(331));var e2=K2;for(K2|=4,V2=a2.current;V2!==null;){var f2=V2,g2=f2.child;if((V2.flags&16)!==0){var h2=f2.deletions;if(h2!==null){for(var k2=0;k2<h2.length;k2++){var l2=h2[k2];for(V2=l2;V2!==null;){var m2=V2;switch(m2.tag){case 0:case 11:case 15:Qj(8,m2,f2)}var q2=m2.child;if(q2!==null)q2.return=m2,V2=q2;else for(;V2!==null;){m2=V2;var r2=m2.sibling,y2=m2.return;if(Tj(m2),m2===l2){V2=null;break}if(r2!==null){r2.return=y2,V2=r2;break}V2=y2}}}var n2=f2.alternate;if(n2!==null){var t2=n2.child;if(t2!==null){n2.child=null;do{var J2=t2.sibling;t2.sibling=null,t2=J2}while(t2!==null)}}V2=f2}}if((f2.subtreeFlags&2064)!==0&&g2!==null)g2.return=f2,V2=g2;else b:for(;V2!==null;){if(f2=V2,(f2.flags&2048)!==0)switch(f2.tag){case 0:case 11:case 15:Qj(9,f2,f2.return)}var x2=f2.sibling;if(x2!==null){x2.return=f2.return,V2=x2;break b}V2=f2.return}}var w2=a2.current;for(V2=w2;V2!==null;){g2=V2;var u2=g2.child;if((g2.subtreeFlags&2064)!==0&&u2!==null)u2.return=g2,V2=u2;else b:for(g2=w2;V2!==null;){if(h2=V2,(h2.flags&2048)!==0)try{switch(h2.tag){case 0:case 11:case 15:Rj(9,h2)}}catch(na){W2(h2,h2.return,na)}if(h2===g2){V2=null;break b}var F2=h2.sibling;if(F2!==null){F2.return=h2.return,V2=F2;break b}V2=h2.return}}if(K2=e2,jg(),lc&&typeof lc.onPostCommitFiberRoot=="function")try{lc.onPostCommitFiberRoot(kc,a2)}catch{}d2=!0}return d2}finally{C2=c2,pk.transition=b2}}return!1}__name(Ik,"Ik");function Yk(a2,b2,c2){b2=Ki(c2,b2),b2=Oi(a2,b2,1),a2=dh(a2,b2,1),b2=L2(),a2!==null&&(Ac(a2,1,b2),Ek(a2,b2))}__name(Yk,"Yk");function W2(a2,b2,c2){if(a2.tag===3)Yk(a2,a2,c2);else for(;b2!==null;){if(b2.tag===3){Yk(b2,a2,c2);break}else if(b2.tag===1){var d2=b2.stateNode;if(typeof b2.type.getDerivedStateFromError=="function"||typeof d2.componentDidCatch=="function"&&(Si===null||!Si.has(d2))){a2=Ki(c2,a2),a2=Ri(b2,a2,1),b2=dh(b2,a2,1),a2=L2(),b2!==null&&(Ac(b2,1,a2),Ek(b2,a2));break}}b2=b2.return}}__name(W2,"W");function Ui(a2,b2,c2){var d2=a2.pingCache;d2!==null&&d2.delete(b2),b2=L2(),a2.pingedLanes|=a2.suspendedLanes&c2,R===a2&&(Z2&c2)===c2&&(T2===4||T2===3&&(Z2&130023424)===Z2&&500>B2()-gk?Lk(a2,0):sk|=c2),Ek(a2,b2)}__name(Ui,"Ui");function Zk(a2,b2){b2===0&&((a2.mode&1)===0?b2=1:(b2=sc,sc<<=1,(sc&130023424)===0&&(sc=4194304)));var c2=L2();a2=Zg(a2,b2),a2!==null&&(Ac(a2,b2,c2),Ek(a2,c2))}__name(Zk,"Zk");function vj(a2){var b2=a2.memoizedState,c2=0;b2!==null&&(c2=b2.retryLane),Zk(a2,c2)}__name(vj,"vj");function ck(a2,b2){var c2=0;switch(a2.tag){case 13:var d2=a2.stateNode,e2=a2.memoizedState;e2!==null&&(c2=e2.retryLane);break;case 19:d2=a2.stateNode;break;default:throw Error(p2(314))}d2!==null&&d2.delete(b2),Zk(a2,c2)}__name(ck,"ck");var Wk;Wk=__name(function(a2,b2,c2){if(a2!==null)if(a2.memoizedProps!==b2.pendingProps||Wf.current)Ug=!0;else{if((a2.lanes&c2)===0&&(b2.flags&128)===0)return Ug=!1,zj(a2,b2,c2);Ug=(a2.flags&131072)!==0}else Ug=!1,I2&&(b2.flags&1048576)!==0&&ug(b2,ng,b2.index);switch(b2.lanes=0,b2.tag){case 2:var d2=b2.type;jj(a2,b2),a2=b2.pendingProps;var e2=Yf(b2,H2.current);Tg(b2,c2),e2=Xh(null,b2,d2,a2,e2,c2);var f2=bi();return b2.flags|=1,typeof e2=="object"&&e2!==null&&typeof e2.render=="function"&&e2.$$typeof===void 0?(b2.tag=1,b2.memoizedState=null,b2.updateQueue=null,Zf(d2)?(f2=!0,cg(b2)):f2=!1,b2.memoizedState=e2.state!==null&&e2.state!==void 0?e2.state:null,ah(b2),e2.updater=nh,b2.stateNode=e2,e2._reactInternals=b2,rh(b2,d2,a2,c2),b2=kj(null,b2,d2,!0,f2,c2)):(b2.tag=0,I2&&f2&&vg(b2),Yi(null,b2,e2,c2),b2=b2.child),b2;case 16:d2=b2.elementType;a:{switch(jj(a2,b2),a2=b2.pendingProps,e2=d2._init,d2=e2(d2._payload),b2.type=d2,e2=b2.tag=$k(d2),a2=Lg(d2,a2),e2){case 0:b2=dj(null,b2,d2,a2,c2);break a;case 1:b2=ij(null,b2,d2,a2,c2);break a;case 11:b2=Zi(null,b2,d2,a2,c2);break a;case 14:b2=aj(null,b2,d2,Lg(d2.type,a2),c2);break a}throw Error(p2(306,d2,""))}return b2;case 0:return d2=b2.type,e2=b2.pendingProps,e2=b2.elementType===d2?e2:Lg(d2,e2),dj(a2,b2,d2,e2,c2);case 1:return d2=b2.type,e2=b2.pendingProps,e2=b2.elementType===d2?e2:Lg(d2,e2),ij(a2,b2,d2,e2,c2);case 3:a:{if(lj(b2),a2===null)throw Error(p2(387));d2=b2.pendingProps,f2=b2.memoizedState,e2=f2.element,bh(a2,b2),gh(b2,d2,null,c2);var g2=b2.memoizedState;if(d2=g2.element,f2.isDehydrated)if(f2={element:d2,isDehydrated:!1,cache:g2.cache,pendingSuspenseBoundaries:g2.pendingSuspenseBoundaries,transitions:g2.transitions},b2.updateQueue.baseState=f2,b2.memoizedState=f2,b2.flags&256){e2=Ki(Error(p2(423)),b2),b2=mj(a2,b2,d2,c2,e2);break a}else if(d2!==e2){e2=Ki(Error(p2(424)),b2),b2=mj(a2,b2,d2,c2,e2);break a}else for(yg=Lf(b2.stateNode.containerInfo.firstChild),xg=b2,I2=!0,zg=null,c2=Ch(b2,null,d2,c2),b2.child=c2;c2;)c2.flags=c2.flags&-3|4096,c2=c2.sibling;else{if(Ig(),d2===e2){b2=$i(a2,b2,c2);break a}Yi(a2,b2,d2,c2)}b2=b2.child}return b2;case 5:return Kh(b2),a2===null&&Eg(b2),d2=b2.type,e2=b2.pendingProps,f2=a2!==null?a2.memoizedProps:null,g2=e2.children,Ef(d2,e2)?g2=null:f2!==null&&Ef(d2,f2)&&(b2.flags|=32),hj(a2,b2),Yi(a2,b2,g2,c2),b2.child;case 6:return a2===null&&Eg(b2),null;case 13:return pj(a2,b2,c2);case 4:return Ih(b2,b2.stateNode.containerInfo),d2=b2.pendingProps,a2===null?b2.child=Bh(b2,null,d2,c2):Yi(a2,b2,d2,c2),b2.child;case 11:return d2=b2.type,e2=b2.pendingProps,e2=b2.elementType===d2?e2:Lg(d2,e2),Zi(a2,b2,d2,e2,c2);case 7:return Yi(a2,b2,b2.pendingProps,c2),b2.child;case 8:return Yi(a2,b2,b2.pendingProps.children,c2),b2.child;case 12:return Yi(a2,b2,b2.pendingProps.children,c2),b2.child;case 10:a:{if(d2=b2.type._context,e2=b2.pendingProps,f2=b2.memoizedProps,g2=e2.value,G2(Mg,d2._currentValue),d2._currentValue=g2,f2!==null)if(He(f2.value,g2)){if(f2.children===e2.children&&!Wf.current){b2=$i(a2,b2,c2);break a}}else for(f2=b2.child,f2!==null&&(f2.return=b2);f2!==null;){var h2=f2.dependencies;if(h2!==null){g2=f2.child;for(var k2=h2.firstContext;k2!==null;){if(k2.context===d2){if(f2.tag===1){k2=ch(-1,c2&-c2),k2.tag=2;var l2=f2.updateQueue;if(l2!==null){l2=l2.shared;var m2=l2.pending;m2===null?k2.next=k2:(k2.next=m2.next,m2.next=k2),l2.pending=k2}}f2.lanes|=c2,k2=f2.alternate,k2!==null&&(k2.lanes|=c2),Sg(f2.return,c2,b2),h2.lanes|=c2;break}k2=k2.next}}else if(f2.tag===10)g2=f2.type===b2.type?null:f2.child;else if(f2.tag===18){if(g2=f2.return,g2===null)throw Error(p2(341));g2.lanes|=c2,h2=g2.alternate,h2!==null&&(h2.lanes|=c2),Sg(g2,c2,b2),g2=f2.sibling}else g2=f2.child;if(g2!==null)g2.return=f2;else for(g2=f2;g2!==null;){if(g2===b2){g2=null;break}if(f2=g2.sibling,f2!==null){f2.return=g2.return,g2=f2;break}g2=g2.return}f2=g2}Yi(a2,b2,e2.children,c2),b2=b2.child}return b2;case 9:return e2=b2.type,d2=b2.pendingProps.children,Tg(b2,c2),e2=Vg(e2),d2=d2(e2),b2.flags|=1,Yi(a2,b2,d2,c2),b2.child;case 14:return d2=b2.type,e2=Lg(d2,b2.pendingProps),e2=Lg(d2.type,e2),aj(a2,b2,d2,e2,c2);case 15:return cj(a2,b2,b2.type,b2.pendingProps,c2);case 17:return d2=b2.type,e2=b2.pendingProps,e2=b2.elementType===d2?e2:Lg(d2,e2),jj(a2,b2),b2.tag=1,Zf(d2)?(a2=!0,cg(b2)):a2=!1,Tg(b2,c2),ph(b2,d2,e2),rh(b2,d2,e2,c2),kj(null,b2,d2,!0,a2,c2);case 19:return yj(a2,b2,c2);case 22:return ej(a2,b2,c2)}throw Error(p2(156,b2.tag))},"Wk");function Gk(a2,b2){return ac(a2,b2)}__name(Gk,"Gk");function al(a2,b2,c2,d2){this.tag=a2,this.key=c2,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=b2,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=d2,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}__name(al,"al");function Bg(a2,b2,c2,d2){return new al(a2,b2,c2,d2)}__name(Bg,"Bg");function bj(a2){return a2=a2.prototype,!(!a2||!a2.isReactComponent)}__name(bj,"bj");function $k(a2){if(typeof a2=="function")return bj(a2)?1:0;if(a2!=null){if(a2=a2.$$typeof,a2===Da)return 11;if(a2===Ga)return 14}return 2}__name($k,"$k");function wh(a2,b2){var c2=a2.alternate;return c2===null?(c2=Bg(a2.tag,b2,a2.key,a2.mode),c2.elementType=a2.elementType,c2.type=a2.type,c2.stateNode=a2.stateNode,c2.alternate=a2,a2.alternate=c2):(c2.pendingProps=b2,c2.type=a2.type,c2.flags=0,c2.subtreeFlags=0,c2.deletions=null),c2.flags=a2.flags&14680064,c2.childLanes=a2.childLanes,c2.lanes=a2.lanes,c2.child=a2.child,c2.memoizedProps=a2.memoizedProps,c2.memoizedState=a2.memoizedState,c2.updateQueue=a2.updateQueue,b2=a2.dependencies,c2.dependencies=b2===null?null:{lanes:b2.lanes,firstContext:b2.firstContext},c2.sibling=a2.sibling,c2.index=a2.index,c2.ref=a2.ref,c2}__name(wh,"wh");function yh(a2,b2,c2,d2,e2,f2){var g2=2;if(d2=a2,typeof a2=="function")bj(a2)&&(g2=1);else if(typeof a2=="string")g2=5;else a:switch(a2){case ya:return Ah(c2.children,e2,f2,b2);case za:g2=8,e2|=8;break;case Aa:return a2=Bg(12,c2,b2,e2|2),a2.elementType=Aa,a2.lanes=f2,a2;case Ea:return a2=Bg(13,c2,b2,e2),a2.elementType=Ea,a2.lanes=f2,a2;case Fa:return a2=Bg(19,c2,b2,e2),a2.elementType=Fa,a2.lanes=f2,a2;case Ia:return qj(c2,e2,f2,b2);default:if(typeof a2=="object"&&a2!==null)switch(a2.$$typeof){case Ba:g2=10;break a;case Ca:g2=9;break a;case Da:g2=11;break a;case Ga:g2=14;break a;case Ha:g2=16,d2=null;break a}throw Error(p2(130,a2==null?a2:typeof a2,""))}return b2=Bg(g2,c2,b2,e2),b2.elementType=a2,b2.type=d2,b2.lanes=f2,b2}__name(yh,"yh");function Ah(a2,b2,c2,d2){return a2=Bg(7,a2,d2,b2),a2.lanes=c2,a2}__name(Ah,"Ah");function qj(a2,b2,c2,d2){return a2=Bg(22,a2,d2,b2),a2.elementType=Ia,a2.lanes=c2,a2.stateNode={isHidden:!1},a2}__name(qj,"qj");function xh(a2,b2,c2){return a2=Bg(6,a2,null,b2),a2.lanes=c2,a2}__name(xh,"xh");function zh(a2,b2,c2){return b2=Bg(4,a2.children!==null?a2.children:[],a2.key,b2),b2.lanes=c2,b2.stateNode={containerInfo:a2.containerInfo,pendingChildren:null,implementation:a2.implementation},b2}__name(zh,"zh");function bl(a2,b2,c2,d2,e2){this.tag=b2,this.containerInfo=a2,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=zc(0),this.expirationTimes=zc(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=zc(0),this.identifierPrefix=d2,this.onRecoverableError=e2,this.mutableSourceEagerHydrationData=null}__name(bl,"bl");function cl(a2,b2,c2,d2,e2,f2,g2,h2,k2){return a2=new bl(a2,b2,c2,h2,k2),b2===1?(b2=1,f2===!0&&(b2|=8)):b2=0,f2=Bg(3,null,null,b2),a2.current=f2,f2.stateNode=a2,f2.memoizedState={element:d2,isDehydrated:c2,cache:null,transitions:null,pendingSuspenseBoundaries:null},ah(f2),a2}__name(cl,"cl");function dl(a2,b2,c2){var d2=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:wa,key:d2==null?null:""+d2,children:a2,containerInfo:b2,implementation:c2}}__name(dl,"dl");function el(a2){if(!a2)return Vf;a2=a2._reactInternals;a:{if(Vb(a2)!==a2||a2.tag!==1)throw Error(p2(170));var b2=a2;do{switch(b2.tag){case 3:b2=b2.stateNode.context;break a;case 1:if(Zf(b2.type)){b2=b2.stateNode.__reactInternalMemoizedMergedChildContext;break a}}b2=b2.return}while(b2!==null);throw Error(p2(171))}if(a2.tag===1){var c2=a2.type;if(Zf(c2))return bg(a2,c2,b2)}return b2}__name(el,"el");function fl(a2,b2,c2,d2,e2,f2,g2,h2,k2){return a2=cl(c2,d2,!0,a2,e2,f2,g2,h2,k2),a2.context=el(null),c2=a2.current,d2=L2(),e2=lh(c2),f2=ch(d2,e2),f2.callback=b2??null,dh(c2,f2,e2),a2.current.lanes=e2,Ac(a2,e2,d2),Ek(a2,d2),a2}__name(fl,"fl");function gl(a2,b2,c2,d2){var e2=b2.current,f2=L2(),g2=lh(e2);return c2=el(c2),b2.context===null?b2.context=c2:b2.pendingContext=c2,b2=ch(f2,g2),b2.payload={element:a2},d2=d2===void 0?null:d2,d2!==null&&(b2.callback=d2),a2=dh(e2,b2,g2),a2!==null&&(mh(a2,e2,g2,f2),eh(a2,e2,g2)),g2}__name(gl,"gl");function hl(a2){if(a2=a2.current,!a2.child)return null;switch(a2.child.tag){case 5:return a2.child.stateNode;default:return a2.child.stateNode}}__name(hl,"hl");function il(a2,b2){if(a2=a2.memoizedState,a2!==null&&a2.dehydrated!==null){var c2=a2.retryLane;a2.retryLane=c2!==0&&c2<b2?c2:b2}}__name(il,"il");function jl(a2,b2){il(a2,b2),(a2=a2.alternate)&&il(a2,b2)}__name(jl,"jl");function kl(){return null}__name(kl,"kl");var ll=typeof reportError=="function"?reportError:function(a2){console.error(a2)};function ml(a2){this._internalRoot=a2}__name(ml,"ml"),nl.prototype.render=ml.prototype.render=function(a2){var b2=this._internalRoot;if(b2===null)throw Error(p2(409));gl(a2,b2,null,null)},nl.prototype.unmount=ml.prototype.unmount=function(){var a2=this._internalRoot;if(a2!==null){this._internalRoot=null;var b2=a2.containerInfo;Sk(function(){gl(null,a2,null,null)}),b2[uf]=null}};function nl(a2){this._internalRoot=a2}__name(nl,"nl"),nl.prototype.unstable_scheduleHydration=function(a2){if(a2){var b2=Hc();a2={blockedOn:null,target:a2,priority:b2};for(var c2=0;c2<Qc.length&&b2!==0&&b2<Qc[c2].priority;c2++);Qc.splice(c2,0,a2),c2===0&&Vc(a2)}};function ol(a2){return!(!a2||a2.nodeType!==1&&a2.nodeType!==9&&a2.nodeType!==11)}__name(ol,"ol");function pl(a2){return!(!a2||a2.nodeType!==1&&a2.nodeType!==9&&a2.nodeType!==11&&(a2.nodeType!==8||a2.nodeValue!==" react-mount-point-unstable "))}__name(pl,"pl");function ql(){}__name(ql,"ql");function rl(a2,b2,c2,d2,e2){if(e2){if(typeof d2=="function"){var f2=d2;d2=__name(function(){var a3=hl(g2);f2.call(a3)},"d")}var g2=fl(b2,d2,a2,0,null,!1,!1,"",ql);return a2._reactRootContainer=g2,a2[uf]=g2.current,sf(a2.nodeType===8?a2.parentNode:a2),Sk(),g2}for(;e2=a2.lastChild;)a2.removeChild(e2);if(typeof d2=="function"){var h2=d2;d2=__name(function(){var a3=hl(k2);h2.call(a3)},"d")}var k2=cl(a2,0,!1,null,null,!1,!1,"",ql);return a2._reactRootContainer=k2,a2[uf]=k2.current,sf(a2.nodeType===8?a2.parentNode:a2),Sk(function(){gl(b2,k2,c2,d2)}),k2}__name(rl,"rl");function sl(a2,b2,c2,d2,e2){var f2=c2._reactRootContainer;if(f2){var g2=f2;if(typeof e2=="function"){var h2=e2;e2=__name(function(){var a3=hl(g2);h2.call(a3)},"e")}gl(b2,g2,a2,e2)}else g2=rl(c2,b2,a2,e2,d2);return hl(g2)}__name(sl,"sl"),Ec=__name(function(a2){switch(a2.tag){case 3:var b2=a2.stateNode;if(b2.current.memoizedState.isDehydrated){var c2=tc(b2.pendingLanes);c2!==0&&(Cc(b2,c2|1),Ek(b2,B2()),(K2&6)===0&&(Hj=B2()+500,jg()))}break;case 13:Sk(function(){var b3=Zg(a2,1);if(b3!==null){var c3=L2();mh(b3,a2,1,c3)}}),jl(a2,1)}},"Ec"),Fc=__name(function(a2){if(a2.tag===13){var b2=Zg(a2,134217728);if(b2!==null){var c2=L2();mh(b2,a2,134217728,c2)}jl(a2,134217728)}},"Fc"),Gc=__name(function(a2){if(a2.tag===13){var b2=lh(a2),c2=Zg(a2,b2);if(c2!==null){var d2=L2();mh(c2,a2,b2,d2)}jl(a2,b2)}},"Gc"),Hc=__name(function(){return C2},"Hc"),Ic=__name(function(a2,b2){var c2=C2;try{return C2=a2,b2()}finally{C2=c2}},"Ic"),yb=__name(function(a2,b2,c2){switch(b2){case"input":if(bb(a2,c2),b2=c2.name,c2.type==="radio"&&b2!=null){for(c2=a2;c2.parentNode;)c2=c2.parentNode;for(c2=c2.querySelectorAll("input[name="+JSON.stringify(""+b2)+'][type="radio"]'),b2=0;b2<c2.length;b2++){var d2=c2[b2];if(d2!==a2&&d2.form===a2.form){var e2=Db(d2);if(!e2)throw Error(p2(90));Wa(d2),bb(d2,e2)}}}break;case"textarea":ib(a2,c2);break;case"select":b2=c2.value,b2!=null&&fb(a2,!!c2.multiple,b2,!1)}},"yb"),Gb=Rk,Hb=Sk;var tl={usingClientEntryPoint:!1,Events:[Cb,ue,Db,Eb,Fb,Rk]},ul={findFiberByHostInstance:Wc,bundleType:0,version:"18.2.0",rendererPackageName:"react-dom"},vl={bundleType:ul.bundleType,version:ul.version,rendererPackageName:ul.rendererPackageName,rendererConfig:ul.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:ua.ReactCurrentDispatcher,findHostInstanceByFiber:__name(function(a2){return a2=Zb(a2),a2===null?null:a2.stateNode},"findHostInstanceByFiber"),findFiberByHostInstance:ul.findFiberByHostInstance||kl,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.2.0-next-9e3b772b8-20220608"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var wl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!wl.isDisabled&&wl.supportsFiber)try{kc=wl.inject(vl),lc=wl}catch{}}return reactDom_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=tl,reactDom_production_min.createPortal=function(a2,b2){var c2=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!ol(b2))throw Error(p2(200));return dl(a2,b2,null,c2)},reactDom_production_min.createRoot=function(a2,b2){if(!ol(a2))throw Error(p2(299));var c2=!1,d2="",e2=ll;return b2!=null&&(b2.unstable_strictMode===!0&&(c2=!0),b2.identifierPrefix!==void 0&&(d2=b2.identifierPrefix),b2.onRecoverableError!==void 0&&(e2=b2.onRecoverableError)),b2=cl(a2,1,!1,null,null,c2,!1,d2,e2),a2[uf]=b2.current,sf(a2.nodeType===8?a2.parentNode:a2),new ml(b2)},reactDom_production_min.findDOMNode=function(a2){if(a2==null)return null;if(a2.nodeType===1)return a2;var b2=a2._reactInternals;if(b2===void 0)throw typeof a2.render=="function"?Error(p2(188)):(a2=Object.keys(a2).join(","),Error(p2(268,a2)));return a2=Zb(b2),a2=a2===null?null:a2.stateNode,a2},reactDom_production_min.flushSync=function(a2){return Sk(a2)},reactDom_production_min.hydrate=function(a2,b2,c2){if(!pl(b2))throw Error(p2(200));return sl(null,a2,b2,!0,c2)},reactDom_production_min.hydrateRoot=function(a2,b2,c2){if(!ol(a2))throw Error(p2(405));var d2=c2!=null&&c2.hydratedSources||null,e2=!1,f2="",g2=ll;if(c2!=null&&(c2.unstable_strictMode===!0&&(e2=!0),c2.identifierPrefix!==void 0&&(f2=c2.identifierPrefix),c2.onRecoverableError!==void 0&&(g2=c2.onRecoverableError)),b2=fl(b2,null,a2,1,c2??null,e2,!1,f2,g2),a2[uf]=b2.current,sf(a2),d2)for(a2=0;a2<d2.length;a2++)c2=d2[a2],e2=c2._getVersion,e2=e2(c2._source),b2.mutableSourceEagerHydrationData==null?b2.mutableSourceEagerHydrationData=[c2,e2]:b2.mutableSourceEagerHydrationData.push(c2,e2);return new nl(b2)},reactDom_production_min.render=function(a2,b2,c2){if(!pl(b2))throw Error(p2(200));return sl(null,a2,b2,!1,c2)},reactDom_production_min.unmountComponentAtNode=function(a2){if(!pl(a2))throw Error(p2(40));return a2._reactRootContainer?(Sk(function(){sl(null,null,a2,!1,function(){a2._reactRootContainer=null,a2[uf]=null})}),!0):!1},reactDom_production_min.unstable_batchedUpdates=Rk,reactDom_production_min.unstable_renderSubtreeIntoContainer=function(a2,b2,c2,d2){if(!pl(c2))throw Error(p2(200));if(a2==null||a2._reactInternals===void 0)throw Error(p2(38));return sl(a2,b2,c2,!1,d2)},reactDom_production_min.version="18.2.0-next-9e3b772b8-20220608",reactDom_production_min}__name(requireReactDom_production_min,"requireReactDom_production_min");var hasRequiredReactDom;function requireReactDom(){if(hasRequiredReactDom)return reactDom.exports;hasRequiredReactDom=1;function checkDCE2(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE2)}catch(err){console.error(err)}}return __name(checkDCE2,"checkDCE"),checkDCE2(),reactDom.exports=requireReactDom_production_min(),reactDom.exports}__name(requireReactDom,"requireReactDom");var hasRequiredClient;function requireClient(){if(hasRequiredClient)return client;hasRequiredClient=1;var m2=requireReactDom();return client.createRoot=m2.createRoot,client.hydrateRoot=m2.hydrateRoot,client}__name(requireClient,"requireClient"),requireClient();/*!
 * @pivanov/utils v0.0.2
 * (c) 2024-present Pavel Ivanov
 * Released under the MIT License.
 * https://github.com/pivanov/utils
 */const m$2=__name(e2=>new Promise(t2=>{setTimeout(t2,e2)}),"m$2"),S$1=__name((e2,t2)=>typeof t2=="bigint"?t2.toString():t2,"S$1"),L$1=__name(async(e2,t2,r2)=>{const n2=await caches.open(e2),o2=JSON.stringify(r2,S$1),s2=new Response(o2,{headers:{"Content-Type":"application/json"}});await n2.put(t2,s2)},"L$1"),$$2=__name(async(e2,t2)=>{const r2=await caches.open(e2),n2=await r2.match(t2);if(!n2)return null;const o2=await n2.text();return JSON.parse(o2)},"$$2"),M$2=__name(e2=>`${((e3,t2="🚀")=>{let r2=0;const n2=e3+t2;for(let e4=0;e4<n2.length;e4++)r2=(r2<<5)-r2+n2.charCodeAt(e4),r2|=0;return(r2>>>0).toString(16)})(e2)}::${e2}`,"M$2"),U$1=__name((e2,t2)=>{const r2=M$2(e2);window.dispatchEvent(new CustomEvent(r2,{detail:t2,bubbles:!0,cancelable:!1}))},"U$1"),N$2=__name((e2,t2)=>{if(typeof t2!="function")return()=>{};const r2=(e3=>t3=>{if(t3 instanceof CustomEvent)try{e3(t3.detail)}catch(e4){console.error("Event listener error:",e4)}})(t2),n2=M$2(e2);return window.addEventListener(n2,r2),()=>window.removeEventListener(n2,r2)},"N$2");reactExports.memo(t2=>{const{name:n2,uuid:o2}=t2,i2=reactExports.useRef(),c2=`widget-${n2}`;return reactExports.useEffect(()=>{i2.current&&(i2.current.uuid=o2)},[o2]),typeof o2=="string"&&o2.length?jsxRuntimeExports.jsx(c2,{ref:i2}):null},()=>!0);/**
 * @license bippy
 *
 * Copyright (c) Aiden Bai, Million Software, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var version="0.3.8",BIPPY_INSTRUMENTATION_STRING=`bippy-${version}`,objectDefineProperty=Object.defineProperty,objectHasOwnProperty=Object.prototype.hasOwnProperty,NO_OP=__name(()=>{},"NO_OP"),checkDCE=__name(fn2=>{try{Function.prototype.toString.call(fn2).indexOf("^_^")>-1&&setTimeout(()=>{throw new Error("React is running in production mode, but dead code elimination has not been applied. Read how to correctly configure React for production: https://reactjs.org/link/perf-use-production-build")})}catch{}},"checkDCE"),isRealReactDevtools=__name((rdtHook2=getRDTHook())=>"getFiberRoots"in rdtHook2,"isRealReactDevtools"),isReactRefreshOverride=!1,injectFnStr=void 0,isReactRefresh=__name((rdtHook2=getRDTHook())=>isReactRefreshOverride?!0:(typeof rdtHook2.inject=="function"&&(injectFnStr=rdtHook2.inject.toString()),!!(injectFnStr!=null&&injectFnStr.includes("(injected)"))),"isReactRefresh"),onActiveListeners=new Set,installRDTHook=__name(onActive=>{const renderers=new Map;let i2=0,rdtHook2={checkDCE,supportsFiber:!0,supportsFlight:!0,hasUnsupportedRendererAttached:!1,renderers,onCommitFiberRoot:NO_OP,onCommitFiberUnmount:NO_OP,onPostCommitFiberRoot:NO_OP,inject(renderer){const nextID=++i2;return renderers.set(nextID,renderer),rdtHook2._instrumentationIsActive||(rdtHook2._instrumentationIsActive=!0,onActiveListeners.forEach(listener=>listener())),nextID},_instrumentationSource:BIPPY_INSTRUMENTATION_STRING,_instrumentationIsActive:!1};try{objectDefineProperty(globalThis,"__REACT_DEVTOOLS_GLOBAL_HOOK__",{get(){return rdtHook2},set(newHook){if(newHook&&typeof newHook=="object"){const ourRenderers=rdtHook2.renderers;rdtHook2=newHook,ourRenderers.size>0&&(ourRenderers.forEach((renderer,id)=>{newHook.renderers.set(id,renderer)}),patchRDTHook(onActive))}},configurable:!0,enumerable:!0});const originalWindowHasOwnProperty=window.hasOwnProperty;let hasRanHack=!1;objectDefineProperty(window,"hasOwnProperty",{value:__name(function(){try{return!hasRanHack&&arguments[0]==="__REACT_DEVTOOLS_GLOBAL_HOOK__"?(globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__=void 0,hasRanHack=!0,-0):originalWindowHasOwnProperty.apply(this,arguments)}catch{return originalWindowHasOwnProperty.apply(this,arguments)}},"value"),configurable:!0,writable:!0})}catch{patchRDTHook(onActive)}return rdtHook2},"installRDTHook"),patchRDTHook=__name(onActive=>{onActive&&onActiveListeners.add(onActive);try{const rdtHook2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!rdtHook2)return;if(!rdtHook2._instrumentationSource){if(rdtHook2.checkDCE=checkDCE,rdtHook2.supportsFiber=!0,rdtHook2.supportsFlight=!0,rdtHook2.hasUnsupportedRendererAttached=!1,rdtHook2._instrumentationSource=BIPPY_INSTRUMENTATION_STRING,rdtHook2._instrumentationIsActive=!1,rdtHook2.renderers.size){rdtHook2._instrumentationIsActive=!0,onActiveListeners.forEach(listener=>listener());return}const prevInject=rdtHook2.inject;isReactRefresh(rdtHook2)&&!isRealReactDevtools()&&(isReactRefreshOverride=!0,rdtHook2.inject({scheduleRefresh(){}})&&(rdtHook2._instrumentationIsActive=!0)),rdtHook2.inject=renderer=>{const id=prevInject(renderer);return rdtHook2._instrumentationIsActive=!0,onActiveListeners.forEach(listener=>listener()),id}}(rdtHook2.renderers.size||rdtHook2._instrumentationIsActive||isReactRefresh())&&(onActive==null||onActive())}catch{}},"patchRDTHook"),hasRDTHook=__name(()=>objectHasOwnProperty.call(globalThis,"__REACT_DEVTOOLS_GLOBAL_HOOK__"),"hasRDTHook"),getRDTHook=__name(onActive=>hasRDTHook()?(patchRDTHook(onActive),globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__):installRDTHook(onActive),"getRDTHook"),isClientEnvironment=__name(()=>{var _a2,_b2;return!!(typeof window<"u"&&((_a2=window.document)!=null&&_a2.createElement||((_b2=window.navigator)==null?void 0:_b2.product)==="ReactNative"))},"isClientEnvironment"),safelyInstallRDTHook=__name(()=>{try{isClientEnvironment()&&getRDTHook()}catch{}},"safelyInstallRDTHook"),FunctionComponentTag=0,ClassComponentTag=1,HostRootTag=3,HostComponentTag=5,HostTextTag=6,FragmentTag=7,ContextConsumerTag=9,ForwardRefTag=11,SuspenseComponentTag=13,MemoComponentTag=14,SimpleMemoComponentTag=15,DehydratedSuspenseComponentTag=18,OffscreenComponentTag=22,LegacyHiddenComponentTag=23,HostHoistableTag=26,HostSingletonTag=27,CONCURRENT_MODE_NUMBER=60111,CONCURRENT_MODE_SYMBOL_STRING="Symbol(react.concurrent_mode)",DEPRECATED_ASYNC_MODE_SYMBOL_STRING="Symbol(react.async_mode)",PerformedWork=1,Placement=2,Hydrating=4096,Update=4,Cloned=8,ChildDeletion=16,ContentReset=32,Snapshot=1024,Visibility=8192,MutationMask=Placement|Update|ChildDeletion|ContentReset|Hydrating|Visibility|Snapshot,isHostFiber=__name(fiber=>{switch(fiber.tag){case HostComponentTag:case HostHoistableTag:case HostSingletonTag:return!0;default:return typeof fiber.type=="string"}},"isHostFiber"),isCompositeFiber=__name(fiber=>{switch(fiber.tag){case FunctionComponentTag:case ClassComponentTag:case SimpleMemoComponentTag:case MemoComponentTag:case ForwardRefTag:return!0;default:return!1}},"isCompositeFiber"),didFiberRender=__name(fiber=>{var _a2;const nextProps=fiber.memoizedProps,prevProps=((_a2=fiber.alternate)==null?void 0:_a2.memoizedProps)||{},flags=fiber.flags??fiber.effectTag??0;switch(fiber.tag){case ClassComponentTag:case FunctionComponentTag:case ContextConsumerTag:case ForwardRefTag:case MemoComponentTag:case SimpleMemoComponentTag:return(flags&PerformedWork)===PerformedWork;default:return fiber.alternate?prevProps!==nextProps||fiber.alternate.memoizedState!==fiber.memoizedState||fiber.alternate.ref!==fiber.ref:!0}},"didFiberRender"),didFiberCommit=__name(fiber=>(fiber.flags&(MutationMask|Cloned))!==0||(fiber.subtreeFlags&(MutationMask|Cloned))!==0,"didFiberCommit"),getMutatedHostFibers=__name(fiber=>{const mutations=[],stack=[fiber];for(;stack.length;){const node=stack.pop();node&&(isHostFiber(node)&&didFiberCommit(node)&&didFiberRender(node)&&mutations.push(node),node.child&&stack.push(node.child),node.sibling&&stack.push(node.sibling))}return mutations},"getMutatedHostFibers"),shouldFilterFiber=__name(fiber=>{switch(fiber.tag){case DehydratedSuspenseComponentTag:return!0;case HostTextTag:case FragmentTag:case LegacyHiddenComponentTag:case OffscreenComponentTag:return!0;case HostRootTag:return!1;default:{const symbolOrNumber=typeof fiber.type=="object"&&fiber.type!==null?fiber.type.$$typeof:fiber.type;switch(typeof symbolOrNumber=="symbol"?symbolOrNumber.toString():symbolOrNumber){case CONCURRENT_MODE_NUMBER:case CONCURRENT_MODE_SYMBOL_STRING:case DEPRECATED_ASYNC_MODE_SYMBOL_STRING:return!0;default:return!1}}}},"shouldFilterFiber"),getNearestHostFibers=__name(fiber=>{const hostFibers=[],stack=[];for(isHostFiber(fiber)?hostFibers.push(fiber):fiber.child&&stack.push(fiber.child);stack.length;){const currentNode=stack.pop();if(!currentNode)break;isHostFiber(currentNode)?hostFibers.push(currentNode):currentNode.child&&stack.push(currentNode.child),currentNode.sibling&&stack.push(currentNode.sibling)}return hostFibers},"getNearestHostFibers"),traverseFiber=__name((fiber,selector,ascending=!1)=>{if(!fiber)return null;if(selector(fiber)===!0)return fiber;let child=ascending?fiber.return:fiber.child;for(;child;){const match=traverseFiber(child,selector,ascending);if(match)return match;child=ascending?null:child.sibling}return null},"traverseFiber"),getTimings=__name(fiber=>{const totalTime=(fiber==null?void 0:fiber.actualDuration)??0;let selfTime=totalTime,child=(fiber==null?void 0:fiber.child)??null;for(;totalTime>0&&child!=null;)selfTime-=child.actualDuration??0,child=child.sibling;return{selfTime,totalTime}},"getTimings"),hasMemoCache=__name(fiber=>{var _a2;return!!((_a2=fiber.updateQueue)!=null&&_a2.memoCache)},"hasMemoCache"),getType=__name(type=>{const currentType=type;return typeof currentType=="function"?currentType:typeof currentType=="object"&&currentType?getType(currentType.type||currentType.render):null},"getType"),getDisplayName=__name(type=>{const currentType=type;if(typeof currentType=="string")return currentType;if(typeof currentType!="function"&&!(typeof currentType=="object"&&currentType))return null;const name=currentType.displayName||currentType.name||null;if(name)return name;const unwrappedType=getType(currentType);return unwrappedType&&(unwrappedType.displayName||unwrappedType.name)||null},"getDisplayName"),detectReactBuildType=__name(renderer=>{try{if(typeof renderer.version=="string"&&renderer.bundleType>0)return"development"}catch{}return"production"},"detectReactBuildType"),isInstrumentationActive=__name(()=>!!getRDTHook()._instrumentationIsActive||isRealReactDevtools()||isReactRefresh(),"isInstrumentationActive"),fiberId=0,fiberIdMap=new WeakMap,setFiberId=__name((fiber,id=fiberId++)=>{fiberIdMap.set(fiber,id)},"setFiberId"),getFiberId=__name(fiber=>{let id=fiberIdMap.get(fiber);return!id&&fiber.alternate&&(id=fiberIdMap.get(fiber.alternate)),id||(id=fiberId++,setFiberId(fiber,id)),id},"getFiberId"),mountFiberRecursively=__name((onRender,firstChild,traverseSiblings)=>{let fiber=firstChild;for(;fiber!=null;){if(fiberIdMap.has(fiber)||getFiberId(fiber),!shouldFilterFiber(fiber)&&didFiberRender(fiber)&&onRender(fiber,"mount"),fiber.tag===SuspenseComponentTag)if(fiber.memoizedState!==null){const primaryChildFragment=fiber.child,fallbackChildFragment=primaryChildFragment?primaryChildFragment.sibling:null;if(fallbackChildFragment){const fallbackChild=fallbackChildFragment.child;fallbackChild!==null&&mountFiberRecursively(onRender,fallbackChild,!1)}}else{let primaryChild=null;fiber.child!==null&&(primaryChild=fiber.child.child),primaryChild!==null&&mountFiberRecursively(onRender,primaryChild,!1)}else fiber.child!=null&&mountFiberRecursively(onRender,fiber.child,!0);fiber=traverseSiblings?fiber.sibling:null}},"mountFiberRecursively"),updateFiberRecursively=__name((onRender,nextFiber,prevFiber,parentFiber)=>{var _a2,_b2,_c2;if(fiberIdMap.has(nextFiber)||getFiberId(nextFiber),!prevFiber)return;fiberIdMap.has(prevFiber)||getFiberId(prevFiber);const isSuspense=nextFiber.tag===SuspenseComponentTag;!shouldFilterFiber(nextFiber)&&didFiberRender(nextFiber)&&onRender(nextFiber,"update");const prevDidTimeout=isSuspense&&prevFiber.memoizedState!==null,nextDidTimeOut=isSuspense&&nextFiber.memoizedState!==null;if(prevDidTimeout&&nextDidTimeOut){const nextFallbackChildSet=((_a2=nextFiber.child)==null?void 0:_a2.sibling)??null,prevFallbackChildSet=((_b2=prevFiber.child)==null?void 0:_b2.sibling)??null;nextFallbackChildSet!==null&&prevFallbackChildSet!==null&&updateFiberRecursively(onRender,nextFallbackChildSet,prevFallbackChildSet)}else if(prevDidTimeout&&!nextDidTimeOut){const nextPrimaryChildSet=nextFiber.child;nextPrimaryChildSet!==null&&mountFiberRecursively(onRender,nextPrimaryChildSet,!0)}else if(!prevDidTimeout&&nextDidTimeOut){unmountFiberChildrenRecursively(onRender,prevFiber);const nextFallbackChildSet=((_c2=nextFiber.child)==null?void 0:_c2.sibling)??null;nextFallbackChildSet!==null&&mountFiberRecursively(onRender,nextFallbackChildSet,!0)}else if(nextFiber.child!==prevFiber.child){let nextChild=nextFiber.child;for(;nextChild;){if(nextChild.alternate){const prevChild=nextChild.alternate;updateFiberRecursively(onRender,nextChild,prevChild)}else mountFiberRecursively(onRender,nextChild,!1);nextChild=nextChild.sibling}}},"updateFiberRecursively"),unmountFiber=__name((onRender,fiber)=>{(fiber.tag===HostRootTag||!shouldFilterFiber(fiber))&&onRender(fiber,"unmount")},"unmountFiber"),unmountFiberChildrenRecursively=__name((onRender,fiber)=>{const isTimedOutSuspense=fiber.tag===SuspenseComponentTag&&fiber.memoizedState!==null;let child=fiber.child;if(isTimedOutSuspense){const primaryChildFragment=fiber.child,fallbackChildFragment=(primaryChildFragment==null?void 0:primaryChildFragment.sibling)??null;child=(fallbackChildFragment==null?void 0:fallbackChildFragment.child)??null}for(;child!==null;)child.return!==null&&(unmountFiber(onRender,child),unmountFiberChildrenRecursively(onRender,child)),child=child.sibling},"unmountFiberChildrenRecursively"),commitId=0,rootInstanceMap=new WeakMap,traverseRenderedFibers=__name((root,onRender)=>{const fiber="current"in root?root.current:root;let rootInstance=rootInstanceMap.get(root);rootInstance||(rootInstance={prevFiber:null,id:commitId++},rootInstanceMap.set(root,rootInstance));const{prevFiber}=rootInstance;if(!fiber)unmountFiber(onRender,fiber);else if(prevFiber!==null){const wasMounted=prevFiber&&prevFiber.memoizedState!=null&&prevFiber.memoizedState.element!=null&&prevFiber.memoizedState.isDehydrated!==!0,isMounted=fiber.memoizedState!=null&&fiber.memoizedState.element!=null&&fiber.memoizedState.isDehydrated!==!0;!wasMounted&&isMounted?mountFiberRecursively(onRender,fiber,!1):wasMounted&&isMounted?updateFiberRecursively(onRender,fiber,fiber.alternate):wasMounted&&!isMounted&&unmountFiber(onRender,fiber)}else mountFiberRecursively(onRender,fiber,!0);rootInstance.prevFiber=fiber},"traverseRenderedFibers"),instrument=__name(options=>getRDTHook(()=>{var _a2;const rdtHook2=getRDTHook();(_a2=options.onActive)==null||_a2.call(options),rdtHook2._instrumentationSource=options.name??BIPPY_INSTRUMENTATION_STRING;const prevOnCommitFiberRoot=rdtHook2.onCommitFiberRoot;options.onCommitFiberRoot&&(rdtHook2.onCommitFiberRoot=(rendererID,root,priority)=>{var _a3;prevOnCommitFiberRoot&&prevOnCommitFiberRoot(rendererID,root,priority),(_a3=options.onCommitFiberRoot)==null||_a3.call(options,rendererID,root,priority)});const prevOnCommitFiberUnmount=rdtHook2.onCommitFiberUnmount;options.onCommitFiberUnmount&&(rdtHook2.onCommitFiberUnmount=(rendererID,root)=>{var _a3;prevOnCommitFiberUnmount&&prevOnCommitFiberUnmount(rendererID,root),(_a3=options.onCommitFiberUnmount)==null||_a3.call(options,rendererID,root)});const prevOnPostCommitFiberRoot=rdtHook2.onPostCommitFiberRoot;options.onPostCommitFiberRoot&&(rdtHook2.onPostCommitFiberRoot=(rendererID,root)=>{var _a3;prevOnPostCommitFiberRoot&&prevOnPostCommitFiberRoot(rendererID,root),(_a3=options.onPostCommitFiberRoot)==null||_a3.call(options,rendererID,root)})}),"instrument");/**
 * @license bippy
 *
 * Copyright (c) Aiden Bai, Million Software, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */safelyInstallRDTHook();var n$1,l$3,u$3,t$2,i$2,r$2,o$2,e$2,f$3,c$2,s$3,a$2,h$2,p$3={},v$3=[],y$2=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,d$3=Array.isArray;function w$2(n2,l2){for(var u2 in l2)n2[u2]=l2[u2];return n2}__name(w$2,"w$2");function _$3(n2){n2&&n2.parentNode&&n2.parentNode.removeChild(n2)}__name(_$3,"_$3");function g$2(l2,u2,t2){var i2,r2,o2,e2={};for(o2 in u2)o2=="key"?i2=u2[o2]:o2=="ref"?r2=u2[o2]:e2[o2]=u2[o2];if(arguments.length>2&&(e2.children=arguments.length>3?n$1.call(arguments,2):t2),typeof l2=="function"&&l2.defaultProps!=null)for(o2 in l2.defaultProps)e2[o2]===void 0&&(e2[o2]=l2.defaultProps[o2]);return m$1(l2,e2,i2,r2,null)}__name(g$2,"g$2");function m$1(n2,t2,i2,r2,o2){var e2={type:n2,props:t2,key:i2,ref:r2,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o2??++u$3,__i:-1,__u:0};return o2==null&&l$3.vnode!=null&&l$3.vnode(e2),e2}__name(m$1,"m$1");function k$1(n2){return n2.children}__name(k$1,"k$1");function x$1(n2,l2){this.props=n2,this.context=l2}__name(x$1,"x$1");function C$2(n2,l2){if(l2==null)return n2.__?C$2(n2.__,n2.__i+1):null;for(var u2;l2<n2.__k.length;l2++)if((u2=n2.__k[l2])!=null&&u2.__e!=null)return u2.__e;return typeof n2.type=="function"?C$2(n2):null}__name(C$2,"C$2");function S(n2){var l2,u2;if((n2=n2.__)!=null&&n2.__c!=null){for(n2.__e=n2.__c.base=null,l2=0;l2<n2.__k.length;l2++)if((u2=n2.__k[l2])!=null&&u2.__e!=null){n2.__e=n2.__c.base=u2.__e;break}return S(n2)}}__name(S,"S");function M$1(n2){(!n2.__d&&(n2.__d=!0)&&i$2.push(n2)&&!P$1.__r++||r$2!==l$3.debounceRendering)&&((r$2=l$3.debounceRendering)||o$2)(P$1)}__name(M$1,"M$1");function P$1(){var n2,u2,t2,r2,o2,f2,c2,s2;for(i$2.sort(e$2);n2=i$2.shift();)n2.__d&&(u2=i$2.length,r2=void 0,f2=(o2=(t2=n2).__v).__e,c2=[],s2=[],t2.__P&&((r2=w$2({},o2)).__v=o2.__v+1,l$3.vnode&&l$3.vnode(r2),j$1(t2.__P,r2,o2,t2.__n,t2.__P.namespaceURI,32&o2.__u?[f2]:null,c2,f2??C$2(o2),!!(32&o2.__u),s2),r2.__v=o2.__v,r2.__.__k[r2.__i]=r2,z$2(c2,r2,s2),r2.__e!=f2&&S(r2)),i$2.length>u2&&i$2.sort(e$2));P$1.__r=0}__name(P$1,"P$1");function $$1(n2,l2,u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,y2,d2,w2,_3,g2=t2&&t2.__k||v$3,m2=l2.length;for(f2=I$1(u2,l2,g2,f2),a2=0;a2<m2;a2++)(y2=u2.__k[a2])!=null&&(h2=y2.__i===-1?p$3:g2[y2.__i]||p$3,y2.__i=a2,_3=j$1(n2,y2,h2,i2,r2,o2,e2,f2,c2,s2),d2=y2.__e,y2.ref&&h2.ref!=y2.ref&&(h2.ref&&V$1(h2.ref,null,y2),s2.push(y2.ref,y2.__c||d2,y2)),w2==null&&d2!=null&&(w2=d2),4&y2.__u||h2.__k===y2.__k?f2=H$1(y2,f2,n2):typeof y2.type=="function"&&_3!==void 0?f2=_3:d2&&(f2=d2.nextSibling),y2.__u&=-7);return u2.__e=w2,f2}__name($$1,"$$1");function I$1(n2,l2,u2,t2){var i2,r2,o2,e2,f2,c2=l2.length,s2=u2.length,a2=s2,h2=0;for(n2.__k=[],i2=0;i2<c2;i2++)(r2=l2[i2])!=null&&typeof r2!="boolean"&&typeof r2!="function"?(e2=i2+h2,(r2=n2.__k[i2]=typeof r2=="string"||typeof r2=="number"||typeof r2=="bigint"||r2.constructor==String?m$1(null,r2,null,null,null):d$3(r2)?m$1(k$1,{children:r2},null,null,null):r2.constructor===void 0&&r2.__b>0?m$1(r2.type,r2.props,r2.key,r2.ref?r2.ref:null,r2.__v):r2).__=n2,r2.__b=n2.__b+1,o2=null,(f2=r2.__i=T$2(r2,u2,e2,a2))!==-1&&(a2--,(o2=u2[f2])&&(o2.__u|=2)),o2==null||o2.__v===null?(f2==-1&&h2--,typeof r2.type!="function"&&(r2.__u|=4)):f2!==e2&&(f2==e2-1?h2--:f2==e2+1?h2++:(f2>e2?h2--:h2++,r2.__u|=4))):r2=n2.__k[i2]=null;if(a2)for(i2=0;i2<s2;i2++)(o2=u2[i2])!=null&&(2&o2.__u)==0&&(o2.__e==t2&&(t2=C$2(o2)),q$2(o2,o2));return t2}__name(I$1,"I$1");function H$1(n2,l2,u2){var t2,i2;if(typeof n2.type=="function"){for(t2=n2.__k,i2=0;t2&&i2<t2.length;i2++)t2[i2]&&(t2[i2].__=n2,l2=H$1(t2[i2],l2,u2));return l2}n2.__e!=l2&&(l2&&n2.type&&!u2.contains(l2)&&(l2=C$2(n2)),u2.insertBefore(n2.__e,l2||null),l2=n2.__e);do l2=l2&&l2.nextSibling;while(l2!=null&&l2.nodeType===8);return l2}__name(H$1,"H$1");function L(n2,l2){return l2=l2||[],n2==null||typeof n2=="boolean"||(d$3(n2)?n2.some(function(n3){L(n3,l2)}):l2.push(n2)),l2}__name(L,"L");function T$2(n2,l2,u2,t2){var i2=n2.key,r2=n2.type,o2=u2-1,e2=u2+1,f2=l2[u2];if(f2===null||f2&&i2==f2.key&&r2===f2.type&&(2&f2.__u)==0)return u2;if((typeof r2!="function"||r2===k$1||i2)&&t2>(f2!=null&&(2&f2.__u)==0?1:0))for(;o2>=0||e2<l2.length;){if(o2>=0){if((f2=l2[o2])&&(2&f2.__u)==0&&i2==f2.key&&r2===f2.type)return o2;o2--}if(e2<l2.length){if((f2=l2[e2])&&(2&f2.__u)==0&&i2==f2.key&&r2===f2.type)return e2;e2++}}return-1}__name(T$2,"T$2");function A$2(n2,l2,u2){l2[0]==="-"?n2.setProperty(l2,u2??""):n2[l2]=u2==null?"":typeof u2!="number"||y$2.test(l2)?u2:u2+"px"}__name(A$2,"A$2");function F$1(n2,l2,u2,t2,i2){var r2;n:if(l2==="style")if(typeof u2=="string")n2.style.cssText=u2;else{if(typeof t2=="string"&&(n2.style.cssText=t2=""),t2)for(l2 in t2)u2&&l2 in u2||A$2(n2.style,l2,"");if(u2)for(l2 in u2)t2&&u2[l2]===t2[l2]||A$2(n2.style,l2,u2[l2])}else if(l2[0]==="o"&&l2[1]==="n")r2=l2!==(l2=l2.replace(f$3,"$1")),l2=l2.toLowerCase()in n2||l2==="onFocusOut"||l2==="onFocusIn"?l2.toLowerCase().slice(2):l2.slice(2),n2.l||(n2.l={}),n2.l[l2+r2]=u2,u2?t2?u2.u=t2.u:(u2.u=c$2,n2.addEventListener(l2,r2?a$2:s$3,r2)):n2.removeEventListener(l2,r2?a$2:s$3,r2);else{if(i2=="http://www.w3.org/2000/svg")l2=l2.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(l2!="width"&&l2!="height"&&l2!="href"&&l2!="list"&&l2!="form"&&l2!="tabIndex"&&l2!="download"&&l2!="rowSpan"&&l2!="colSpan"&&l2!="role"&&l2!="popover"&&l2 in n2)try{n2[l2]=u2??"";break n}catch{}typeof u2=="function"||(u2==null||u2===!1&&l2[4]!=="-"?n2.removeAttribute(l2):n2.setAttribute(l2,l2=="popover"&&u2==1?"":u2))}}__name(F$1,"F$1");function O$1(n2){return function(u2){if(this.l){var t2=this.l[u2.type+n2];if(u2.t==null)u2.t=c$2++;else if(u2.t<t2.u)return;return t2(l$3.event?l$3.event(u2):u2)}}}__name(O$1,"O$1");function j$1(n2,u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,p2,v2,y2,g2,m2,b2,C2,S2,M2,P2,I2,H2,L2,T2,A2,F2=u2.type;if(u2.constructor!==void 0)return null;128&t2.__u&&(c2=!!(32&t2.__u),o2=[f2=u2.__e=t2.__e]),(a2=l$3.__b)&&a2(u2);n:if(typeof F2=="function")try{if(b2=u2.props,C2="prototype"in F2&&F2.prototype.render,S2=(a2=F2.contextType)&&i2[a2.__c],M2=a2?S2?S2.props.value:a2.__:i2,t2.__c?m2=(h2=u2.__c=t2.__c).__=h2.__E:(C2?u2.__c=h2=new F2(b2,M2):(u2.__c=h2=new x$1(b2,M2),h2.constructor=F2,h2.render=B$2),S2&&S2.sub(h2),h2.props=b2,h2.state||(h2.state={}),h2.context=M2,h2.__n=i2,p2=h2.__d=!0,h2.__h=[],h2._sb=[]),C2&&h2.__s==null&&(h2.__s=h2.state),C2&&F2.getDerivedStateFromProps!=null&&(h2.__s==h2.state&&(h2.__s=w$2({},h2.__s)),w$2(h2.__s,F2.getDerivedStateFromProps(b2,h2.__s))),v2=h2.props,y2=h2.state,h2.__v=u2,p2)C2&&F2.getDerivedStateFromProps==null&&h2.componentWillMount!=null&&h2.componentWillMount(),C2&&h2.componentDidMount!=null&&h2.__h.push(h2.componentDidMount);else{if(C2&&F2.getDerivedStateFromProps==null&&b2!==v2&&h2.componentWillReceiveProps!=null&&h2.componentWillReceiveProps(b2,M2),!h2.__e&&(h2.shouldComponentUpdate!=null&&h2.shouldComponentUpdate(b2,h2.__s,M2)===!1||u2.__v===t2.__v)){for(u2.__v!==t2.__v&&(h2.props=b2,h2.state=h2.__s,h2.__d=!1),u2.__e=t2.__e,u2.__k=t2.__k,u2.__k.some(function(n3){n3&&(n3.__=u2)}),P2=0;P2<h2._sb.length;P2++)h2.__h.push(h2._sb[P2]);h2._sb=[],h2.__h.length&&e2.push(h2);break n}h2.componentWillUpdate!=null&&h2.componentWillUpdate(b2,h2.__s,M2),C2&&h2.componentDidUpdate!=null&&h2.__h.push(function(){h2.componentDidUpdate(v2,y2,g2)})}if(h2.context=M2,h2.props=b2,h2.__P=n2,h2.__e=!1,I2=l$3.__r,H2=0,C2){for(h2.state=h2.__s,h2.__d=!1,I2&&I2(u2),a2=h2.render(h2.props,h2.state,h2.context),L2=0;L2<h2._sb.length;L2++)h2.__h.push(h2._sb[L2]);h2._sb=[]}else do h2.__d=!1,I2&&I2(u2),a2=h2.render(h2.props,h2.state,h2.context),h2.state=h2.__s;while(h2.__d&&++H2<25);h2.state=h2.__s,h2.getChildContext!=null&&(i2=w$2(w$2({},i2),h2.getChildContext())),C2&&!p2&&h2.getSnapshotBeforeUpdate!=null&&(g2=h2.getSnapshotBeforeUpdate(v2,y2)),f2=$$1(n2,d$3(T2=a2!=null&&a2.type===k$1&&a2.key==null?a2.props.children:a2)?T2:[T2],u2,t2,i2,r2,o2,e2,f2,c2,s2),h2.base=u2.__e,u2.__u&=-161,h2.__h.length&&e2.push(h2),m2&&(h2.__E=h2.__=null)}catch(n3){if(u2.__v=null,c2||o2!=null)if(n3.then){for(u2.__u|=c2?160:128;f2&&f2.nodeType===8&&f2.nextSibling;)f2=f2.nextSibling;o2[o2.indexOf(f2)]=null,u2.__e=f2}else for(A2=o2.length;A2--;)_$3(o2[A2]);else u2.__e=t2.__e,u2.__k=t2.__k;l$3.__e(n3,u2,t2)}else o2==null&&u2.__v===t2.__v?(u2.__k=t2.__k,u2.__e=t2.__e):f2=u2.__e=N$1(t2.__e,u2,t2,i2,r2,o2,e2,c2,s2);return(a2=l$3.diffed)&&a2(u2),128&u2.__u?void 0:f2}__name(j$1,"j$1");function z$2(n2,u2,t2){for(var i2=0;i2<t2.length;i2++)V$1(t2[i2],t2[++i2],t2[++i2]);l$3.__c&&l$3.__c(u2,n2),n2.some(function(u3){try{n2=u3.__h,u3.__h=[],n2.some(function(n3){n3.call(u3)})}catch(n3){l$3.__e(n3,u3.__v)}})}__name(z$2,"z$2");function N$1(u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,v2,y2,w2,g2,m2,b2=i2.props,k2=t2.props,x2=t2.type;if(x2==="svg"?o2="http://www.w3.org/2000/svg":x2==="math"?o2="http://www.w3.org/1998/Math/MathML":o2||(o2="http://www.w3.org/1999/xhtml"),e2!=null){for(a2=0;a2<e2.length;a2++)if((w2=e2[a2])&&"setAttribute"in w2==!!x2&&(x2?w2.localName===x2:w2.nodeType===3)){u2=w2,e2[a2]=null;break}}if(u2==null){if(x2===null)return document.createTextNode(k2);u2=document.createElementNS(o2,x2,k2.is&&k2),c2&&(l$3.__m&&l$3.__m(t2,e2),c2=!1),e2=null}if(x2===null)b2===k2||c2&&u2.data===k2||(u2.data=k2);else{if(e2=e2&&n$1.call(u2.childNodes),b2=i2.props||p$3,!c2&&e2!=null)for(b2={},a2=0;a2<u2.attributes.length;a2++)b2[(w2=u2.attributes[a2]).name]=w2.value;for(a2 in b2)if(w2=b2[a2],a2!="children"){if(a2=="dangerouslySetInnerHTML")v2=w2;else if(!(a2 in k2)){if(a2=="value"&&"defaultValue"in k2||a2=="checked"&&"defaultChecked"in k2)continue;F$1(u2,a2,null,w2,o2)}}for(a2 in k2)w2=k2[a2],a2=="children"?y2=w2:a2=="dangerouslySetInnerHTML"?h2=w2:a2=="value"?g2=w2:a2=="checked"?m2=w2:c2&&typeof w2!="function"||b2[a2]===w2||F$1(u2,a2,w2,b2[a2],o2);if(h2)c2||v2&&(h2.__html===v2.__html||h2.__html===u2.innerHTML)||(u2.innerHTML=h2.__html),t2.__k=[];else if(v2&&(u2.innerHTML=""),$$1(u2,d$3(y2)?y2:[y2],t2,i2,r2,x2==="foreignObject"?"http://www.w3.org/1999/xhtml":o2,e2,f2,e2?e2[0]:i2.__k&&C$2(i2,0),c2,s2),e2!=null)for(a2=e2.length;a2--;)_$3(e2[a2]);c2||(a2="value",x2==="progress"&&g2==null?u2.removeAttribute("value"):g2!==void 0&&(g2!==u2[a2]||x2==="progress"&&!g2||x2==="option"&&g2!==b2[a2])&&F$1(u2,a2,g2,b2[a2],o2),a2="checked",m2!==void 0&&m2!==u2[a2]&&F$1(u2,a2,m2,b2[a2],o2))}return u2}__name(N$1,"N$1");function V$1(n2,u2,t2){try{if(typeof n2=="function"){var i2=typeof n2.__u=="function";i2&&n2.__u(),i2&&u2==null||(n2.__u=n2(u2))}else n2.current=u2}catch(n3){l$3.__e(n3,t2)}}__name(V$1,"V$1");function q$2(n2,u2,t2){var i2,r2;if(l$3.unmount&&l$3.unmount(n2),(i2=n2.ref)&&(i2.current&&i2.current!==n2.__e||V$1(i2,null,u2)),(i2=n2.__c)!=null){if(i2.componentWillUnmount)try{i2.componentWillUnmount()}catch(n3){l$3.__e(n3,u2)}i2.base=i2.__P=null}if(i2=n2.__k)for(r2=0;r2<i2.length;r2++)i2[r2]&&q$2(i2[r2],u2,t2||typeof n2.type!="function");t2||_$3(n2.__e),n2.__c=n2.__=n2.__e=void 0}__name(q$2,"q$2");function B$2(n2,l2,u2){return this.constructor(n2,u2)}__name(B$2,"B$2");function D$1(u2,t2,i2){var r2,o2,e2,f2;t2===document&&(t2=document.documentElement),l$3.__&&l$3.__(u2,t2),o2=(r2=!1)?null:t2.__k,e2=[],f2=[],j$1(t2,u2=t2.__k=g$2(k$1,null,[u2]),o2||p$3,p$3,t2.namespaceURI,o2?null:t2.firstChild?n$1.call(t2.childNodes):null,e2,o2?o2.__e:t2.firstChild,r2,f2),z$2(e2,u2,f2)}__name(D$1,"D$1");function J$1(n2,l2){var u2={__c:l2="__cC"+h$2++,__:n2,Consumer:__name(function(n3,l3){return n3.children(l3)},"Consumer"),Provider:__name(function(n3){var u3,t2;return this.getChildContext||(u3=new Set,(t2={})[l2]=this,this.getChildContext=function(){return t2},this.componentWillUnmount=function(){u3=null},this.shouldComponentUpdate=function(n4){this.props.value!==n4.value&&u3.forEach(function(n5){n5.__e=!0,M$1(n5)})},this.sub=function(n4){u3.add(n4);var l3=n4.componentWillUnmount;n4.componentWillUnmount=function(){u3&&u3.delete(n4),l3&&l3.call(n4)}}),n3.children},"Provider")};return u2.Provider.__=u2.Consumer.contextType=u2}__name(J$1,"J$1"),n$1=v$3.slice,l$3={__e:__name(function(n2,l2,u2,t2){for(var i2,r2,o2;l2=l2.__;)if((i2=l2.__c)&&!i2.__)try{if((r2=i2.constructor)&&r2.getDerivedStateFromError!=null&&(i2.setState(r2.getDerivedStateFromError(n2)),o2=i2.__d),i2.componentDidCatch!=null&&(i2.componentDidCatch(n2,t2||{}),o2=i2.__d),o2)return i2.__E=i2}catch(l3){n2=l3}throw n2},"__e")},u$3=0,t$2=__name(function(n2){return n2!=null&&n2.constructor==null},"t$2"),x$1.prototype.setState=function(n2,l2){var u2;u2=this.__s!=null&&this.__s!==this.state?this.__s:this.__s=w$2({},this.state),typeof n2=="function"&&(n2=n2(w$2({},u2),this.props)),n2&&w$2(u2,n2),n2!=null&&this.__v&&(l2&&this._sb.push(l2),M$1(this))},x$1.prototype.forceUpdate=function(n2){this.__v&&(this.__e=!0,n2&&this.__h.push(n2),M$1(this))},x$1.prototype.render=k$1,i$2=[],o$2=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,e$2=__name(function(n2,l2){return n2.__v.__b-l2.__v.__b},"e$2"),P$1.__r=0,f$3=/(PointerCapture)$|Capture$/i,c$2=0,s$3=O$1(!1),a$2=O$1(!0),h$2=0;var t$1,r$1,u$2,i$1,o$1=0,f$2=[],c$1=l$3,e$1=c$1.__b,a$1=c$1.__r,v$2=c$1.diffed,l$2=c$1.__c,m=c$1.unmount,s$2=c$1.__;function d$2(n2,t2){c$1.__h&&c$1.__h(r$1,n2,o$1||t2),o$1=0;var u2=r$1.__H||(r$1.__H={__:[],__h:[]});return n2>=u2.__.length&&u2.__.push({}),u2.__[n2]}__name(d$2,"d$2");function h$1(n2){return o$1=1,p$2(D,n2)}__name(h$1,"h$1");function p$2(n2,u2,i2){var o2=d$2(t$1++,2);if(o2.t=n2,!o2.__c&&(o2.__=[i2?i2(u2):D(void 0,u2),function(n3){var t2=o2.__N?o2.__N[0]:o2.__[0],r2=o2.t(t2,n3);t2!==r2&&(o2.__N=[r2,o2.__[1]],o2.__c.setState({}))}],o2.__c=r$1,!r$1.u)){var f2=__name(function(n3,t2,r2){if(!o2.__c.__H)return!0;var u3=o2.__c.__H.__.filter(function(n4){return!!n4.__c});if(u3.every(function(n4){return!n4.__N}))return!c2||c2.call(this,n3,t2,r2);var i3=o2.__c.props!==n3;return u3.forEach(function(n4){if(n4.__N){var t3=n4.__[0];n4.__=n4.__N,n4.__N=void 0,t3!==n4.__[0]&&(i3=!0)}}),c2&&c2.call(this,n3,t2,r2)||i3},"f");r$1.u=!0;var c2=r$1.shouldComponentUpdate,e2=r$1.componentWillUpdate;r$1.componentWillUpdate=function(n3,t2,r2){if(this.__e){var u3=c2;c2=void 0,f2(n3,t2,r2),c2=u3}e2&&e2.call(this,n3,t2,r2)},r$1.shouldComponentUpdate=f2}return o2.__N||o2.__}__name(p$2,"p$2");function y$1(n2,u2){var i2=d$2(t$1++,3);!c$1.__s&&C$1(i2.__H,u2)&&(i2.__=n2,i2.i=u2,r$1.__H.__h.push(i2))}__name(y$1,"y$1");function _$2(n2,u2){var i2=d$2(t$1++,4);!c$1.__s&&C$1(i2.__H,u2)&&(i2.__=n2,i2.i=u2,r$1.__h.push(i2))}__name(_$2,"_$2");function A$1(n2){return o$1=5,T$1(function(){return{current:n2}},[])}__name(A$1,"A$1");function T$1(n2,r2){var u2=d$2(t$1++,7);return C$1(u2.__H,r2)&&(u2.__=n2(),u2.__H=r2,u2.__h=n2),u2.__}__name(T$1,"T$1");function q$1(n2,t2){return o$1=8,T$1(function(){return n2},t2)}__name(q$1,"q$1");function x(n2){var u2=r$1.context[n2.__c],i2=d$2(t$1++,9);return i2.c=n2,u2?(i2.__==null&&(i2.__=!0,u2.sub(r$1)),u2.props.value):n2.__}__name(x,"x");function j(){for(var n2;n2=f$2.shift();)if(n2.__P&&n2.__H)try{n2.__H.__h.forEach(z$1),n2.__H.__h.forEach(B$1),n2.__H.__h=[]}catch(t2){n2.__H.__h=[],c$1.__e(t2,n2.__v)}}__name(j,"j"),c$1.__b=function(n2){r$1=null,e$1&&e$1(n2)},c$1.__=function(n2,t2){n2&&t2.__k&&t2.__k.__m&&(n2.__m=t2.__k.__m),s$2&&s$2(n2,t2)},c$1.__r=function(n2){a$1&&a$1(n2),t$1=0;var i2=(r$1=n2.__c).__H;i2&&(u$2===r$1?(i2.__h=[],r$1.__h=[],i2.__.forEach(function(n3){n3.__N&&(n3.__=n3.__N),n3.i=n3.__N=void 0})):(i2.__h.forEach(z$1),i2.__h.forEach(B$1),i2.__h=[],t$1=0)),u$2=r$1},c$1.diffed=function(n2){v$2&&v$2(n2);var t2=n2.__c;t2&&t2.__H&&(t2.__H.__h.length&&(f$2.push(t2)!==1&&i$1===c$1.requestAnimationFrame||((i$1=c$1.requestAnimationFrame)||w$1)(j)),t2.__H.__.forEach(function(n3){n3.i&&(n3.__H=n3.i),n3.i=void 0})),u$2=r$1=null},c$1.__c=function(n2,t2){t2.some(function(n3){try{n3.__h.forEach(z$1),n3.__h=n3.__h.filter(function(n4){return!n4.__||B$1(n4)})}catch(r2){t2.some(function(n4){n4.__h&&(n4.__h=[])}),t2=[],c$1.__e(r2,n3.__v)}}),l$2&&l$2(n2,t2)},c$1.unmount=function(n2){m&&m(n2);var t2,r2=n2.__c;r2&&r2.__H&&(r2.__H.__.forEach(function(n3){try{z$1(n3)}catch(n4){t2=n4}}),r2.__H=void 0,t2&&c$1.__e(t2,r2.__v))};var k=typeof requestAnimationFrame=="function";function w$1(n2){var t2,r2=__name(function(){clearTimeout(u2),k&&cancelAnimationFrame(t2),setTimeout(n2)},"r"),u2=setTimeout(r2,100);k&&(t2=requestAnimationFrame(r2))}__name(w$1,"w$1");function z$1(n2){var t2=r$1,u2=n2.__c;typeof u2=="function"&&(n2.__c=void 0,u2()),r$1=t2}__name(z$1,"z$1");function B$1(n2){var t2=r$1;n2.__c=n2.__(),r$1=t2}__name(B$1,"B$1");function C$1(n2,t2){return!n2||n2.length!==t2.length||t2.some(function(t3,r2){return t3!==n2[r2]})}__name(C$1,"C$1");function D(n2,t2){return typeof t2=="function"?t2(n2):t2}__name(D,"D");var i=Symbol.for("preact-signals");function t(){if(s$1>1)s$1--;else{for(var i2,t2=!1;h!==void 0;){var r2=h;for(h=void 0,f$1++;r2!==void 0;){var o2=r2.o;if(r2.o=void 0,r2.f&=-3,!(8&r2.f)&&c(r2))try{r2.c()}catch(r3){t2||(i2=r3,t2=!0)}r2=o2}}if(f$1=0,s$1--,t2)throw i2}}__name(t,"t");var o=void 0;function n(i2){var t2=o;o=void 0;try{return i2()}finally{o=t2}}__name(n,"n");var h=void 0,s$1=0,f$1=0,v$1=0;function e(i2){if(o!==void 0){var t2=i2.n;if(t2===void 0||t2.t!==o)return t2={i:0,S:i2,p:o.s,n:void 0,t:o,e:void 0,x:void 0,r:t2},o.s!==void 0&&(o.s.n=t2),o.s=t2,i2.n=t2,32&o.f&&i2.S(t2),t2;if(t2.i===-1)return t2.i=0,t2.n!==void 0&&(t2.n.p=t2.p,t2.p!==void 0&&(t2.p.n=t2.n),t2.p=o.s,t2.n=void 0,o.s.n=t2,o.s=t2),t2}}__name(e,"e");function u$1(i2){this.v=i2,this.i=0,this.n=void 0,this.t=void 0}__name(u$1,"u$1"),u$1.prototype.brand=i,u$1.prototype.h=function(){return!0},u$1.prototype.S=function(i2){this.t!==i2&&i2.e===void 0&&(i2.x=this.t,this.t!==void 0&&(this.t.e=i2),this.t=i2)},u$1.prototype.U=function(i2){if(this.t!==void 0){var t2=i2.e,r2=i2.x;t2!==void 0&&(t2.x=r2,i2.e=void 0),r2!==void 0&&(r2.e=t2,i2.x=void 0),i2===this.t&&(this.t=r2)}},u$1.prototype.subscribe=function(i2){var t2=this;return E$1(function(){var r2=t2.value,n2=o;o=void 0;try{i2(r2)}finally{o=n2}})},u$1.prototype.valueOf=function(){return this.value},u$1.prototype.toString=function(){return this.value+""},u$1.prototype.toJSON=function(){return this.value},u$1.prototype.peek=function(){var i2=o;o=void 0;try{return this.value}finally{o=i2}},Object.defineProperty(u$1.prototype,"value",{get:__name(function(){var i2=e(this);return i2!==void 0&&(i2.i=this.i),this.v},"get"),set:__name(function(i2){if(i2!==this.v){if(f$1>100)throw new Error("Cycle detected");this.v=i2,this.i++,v$1++,s$1++;try{for(var r2=this.t;r2!==void 0;r2=r2.x)r2.t.N()}finally{t()}}},"set")});function d$1(i2){return new u$1(i2)}__name(d$1,"d$1");function c(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n)if(t2.S.i!==t2.i||!t2.S.h()||t2.S.i!==t2.i)return!0;return!1}__name(c,"c");function a(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n){var r2=t2.S.n;if(r2!==void 0&&(t2.r=r2),t2.S.n=t2,t2.i=-1,t2.n===void 0){i2.s=t2;break}}}__name(a,"a");function l$1(i2){for(var t2=i2.s,r2=void 0;t2!==void 0;){var o2=t2.p;t2.i===-1?(t2.S.U(t2),o2!==void 0&&(o2.n=t2.n),t2.n!==void 0&&(t2.n.p=o2)):r2=t2,t2.S.n=t2.r,t2.r!==void 0&&(t2.r=void 0),t2=o2}i2.s=r2}__name(l$1,"l$1");function y(i2){u$1.call(this,void 0),this.x=i2,this.s=void 0,this.g=v$1-1,this.f=4}__name(y,"y"),(y.prototype=new u$1).h=function(){if(this.f&=-3,1&this.f)return!1;if((36&this.f)==32||(this.f&=-5,this.g===v$1))return!0;if(this.g=v$1,this.f|=1,this.i>0&&!c(this))return this.f&=-2,!0;var i2=o;try{a(this),o=this;var t2=this.x();(16&this.f||this.v!==t2||this.i===0)&&(this.v=t2,this.f&=-17,this.i++)}catch(i3){this.v=i3,this.f|=16,this.i++}return o=i2,l$1(this),this.f&=-2,!0},y.prototype.S=function(i2){if(this.t===void 0){this.f|=36;for(var t2=this.s;t2!==void 0;t2=t2.n)t2.S.S(t2)}u$1.prototype.S.call(this,i2)},y.prototype.U=function(i2){if(this.t!==void 0&&(u$1.prototype.U.call(this,i2),this.t===void 0)){this.f&=-33;for(var t2=this.s;t2!==void 0;t2=t2.n)t2.S.U(t2)}},y.prototype.N=function(){if(!(2&this.f)){this.f|=6;for(var i2=this.t;i2!==void 0;i2=i2.x)i2.t.N()}},Object.defineProperty(y.prototype,"value",{get:__name(function(){if(1&this.f)throw new Error("Cycle detected");var i2=e(this);if(this.h(),i2!==void 0&&(i2.i=this.i),16&this.f)throw this.v;return this.v},"get")});function w(i2){return new y(i2)}__name(w,"w");function _$1(i2){var r2=i2.u;if(i2.u=void 0,typeof r2=="function"){s$1++;var n2=o;o=void 0;try{r2()}catch(t2){throw i2.f&=-2,i2.f|=8,g$1(i2),t2}finally{o=n2,t()}}}__name(_$1,"_$1");function g$1(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n)t2.S.U(t2);i2.x=void 0,i2.s=void 0,_$1(i2)}__name(g$1,"g$1");function p$1(i2){if(o!==this)throw new Error("Out-of-order effect");l$1(this),o=i2,this.f&=-2,8&this.f&&g$1(this),t()}__name(p$1,"p$1");function b(i2){this.x=i2,this.u=void 0,this.s=void 0,this.o=void 0,this.f=32}__name(b,"b"),b.prototype.c=function(){var i2=this.S();try{if(8&this.f||this.x===void 0)return;var t2=this.x();typeof t2=="function"&&(this.u=t2)}finally{i2()}},b.prototype.S=function(){if(1&this.f)throw new Error("Cycle detected");this.f|=1,this.f&=-9,_$1(this),a(this),s$1++;var i2=o;return o=this,p$1.bind(this,i2)},b.prototype.N=function(){2&this.f||(this.f|=2,this.o=h,h=this)},b.prototype.d=function(){this.f|=8,1&this.f||g$1(this)};function E$1(i2){var t2=new b(i2);try{t2.c()}catch(i3){throw t2.d(),i3}return t2.d.bind(t2)}__name(E$1,"E$1");var v,s;function l(n2,i2){l$3[n2]=i2.bind(null,l$3[n2]||function(){})}__name(l,"l");function d(n2){s&&s(),s=n2&&n2.S()}__name(d,"d");function p(n2){var r2=this,f2=n2.data,o2=useSignal(f2);o2.value=f2;var e2=T$1(function(){for(var n3=r2.__v;n3=n3.__;)if(n3.__c){n3.__c.__$f|=4;break}return r2.__$u.c=function(){var n4,t2=r2.__$u.S(),f3=e2.value;t2(),t$2(f3)||((n4=r2.base)==null?void 0:n4.nodeType)!==3?(r2.__$f|=1,r2.setState({})):r2.base.data=f3},w(function(){var n4=o2.value.value;return n4===0?0:n4===!0?"":n4||""})},[]);return e2.value}__name(p,"p"),p.displayName="_st",Object.defineProperties(u$1.prototype,{constructor:{configurable:!0,value:void 0},type:{configurable:!0,value:p},props:{configurable:!0,get:__name(function(){return{data:this}},"get")},__b:{configurable:!0,value:1}}),l("__b",function(n2,r2){if(typeof r2.type=="string"){var i2,t2=r2.props;for(var f2 in t2)if(f2!=="children"){var o2=t2[f2];o2 instanceof u$1&&(i2||(r2.__np=i2={}),i2[f2]=o2,t2[f2]=o2.peek())}}n2(r2)}),l("__r",function(n2,r2){d();var i2,t2=r2.__c;t2&&(t2.__$f&=-2,(i2=t2.__$u)===void 0&&(t2.__$u=i2=function(n3){var r3;return E$1(function(){r3=this}),r3.c=function(){t2.__$f|=1,t2.setState({})},r3}())),v=t2,d(i2),n2(r2)}),l("__e",function(n2,r2,i2,t2){d(),v=void 0,n2(r2,i2,t2)}),l("diffed",function(n2,r2){d(),v=void 0;var i2;if(typeof r2.type=="string"&&(i2=r2.__e)){var t2=r2.__np,f2=r2.props;if(t2){var o2=i2.U;if(o2)for(var e2 in o2){var u2=o2[e2];u2!==void 0&&!(e2 in t2)&&(u2.d(),o2[e2]=void 0)}else i2.U=o2={};for(var a2 in t2){var c2=o2[a2],s2=t2[a2];c2===void 0?(c2=_2(i2,a2,s2,f2),o2[a2]=c2):c2.o(s2,f2)}}}n2(r2)});function _2(n2,r2,i2,t2){var f2=r2 in n2&&n2.ownerSVGElement===void 0,o2=d$1(i2);return{o:__name(function(n3,r3){o2.value=n3,t2=r3},"o"),d:E$1(function(){var i3=o2.value.value;t2[r2]!==i3&&(t2[r2]=i3,f2?n2[r2]=i3:i3?n2.setAttribute(r2,i3):n2.removeAttribute(r2))})}}__name(_2,"_"),l("unmount",function(n2,r2){if(typeof r2.type=="string"){var i2=r2.__e;if(i2){var t2=i2.U;if(t2){i2.U=void 0;for(var f2 in t2){var o2=t2[f2];o2&&o2.d()}}}}else{var e2=r2.__c;if(e2){var u2=e2.__$u;u2&&(e2.__$u=void 0,u2.d())}}n2(r2)}),l("__h",function(n2,r2,i2,t2){(t2<3||t2===9)&&(r2.__$f|=2),n2(r2,i2,t2)}),x$1.prototype.shouldComponentUpdate=function(n2,r2){var i2=this.__$u;if(!(i2&&i2.s!==void 0||4&this.__$f)||3&this.__$f)return!0;for(var t2 in r2)return!0;for(var f2 in n2)if(f2!=="__source"&&n2[f2]!==this.props[f2])return!0;for(var o2 in this.props)if(!(o2 in n2))return!0;return!1};function useSignal(n2){return T$1(function(){return d$1(n2)},[])}__name(useSignal,"useSignal");function useComputed(n2){var r2=A$1(n2);return r2.current=n2,v.__$f|=4,T$1(function(){return w(function(){return r2.current()})},[])}__name(useComputed,"useComputed");function useSignalEffect(n2){var r2=A$1(n2);r2.current=n2,y$1(function(){return E$1(function(){return r2.current()})},[])}__name(useSignalEffect,"useSignalEffect");function g(n2,t2){for(var e2 in n2)if(e2!=="__source"&&!(e2 in t2))return!0;for(var r2 in t2)if(r2!=="__source"&&n2[r2]!==t2[r2])return!0;return!1}__name(g,"g");function E(n2,t2){var e2=t2(),r2=h$1({t:{__:e2,u:t2}}),u2=r2[0].t,o2=r2[1];return _$2(function(){u2.__=e2,u2.u=t2,C(u2)&&o2({t:u2})},[n2,e2,t2]),y$1(function(){return C(u2)&&o2({t:u2}),n2(function(){C(u2)&&o2({t:u2})})},[n2]),e2}__name(E,"E");function C(n2){var t2,e2,r2=n2.u,u2=n2.__;try{var o2=r2();return!((t2=u2)===(e2=o2)&&(t2!==0||1/t2==1/e2)||t2!=t2&&e2!=e2)}catch{return!0}}__name(C,"C");function I(n2,t2){this.props=n2,this.context=t2}__name(I,"I");function N(n2,e2){function r2(n3){var t2=this.props.ref,r3=t2==n3.ref;return!r3&&t2&&(t2.call?t2(null):t2.current=null),e2?!e2(this.props,n3)||!r3:g(this.props,n3)}__name(r2,"r");function u2(e3){return this.shouldComponentUpdate=r2,g$2(n2,e3)}return __name(u2,"u"),u2.displayName="Memo("+(n2.displayName||n2.name)+")",u2.prototype.isReactComponent=!0,u2.__f=!0,u2}__name(N,"N"),(I.prototype=new x$1).isPureReactComponent=!0,I.prototype.shouldComponentUpdate=function(n2,t2){return g(this.props,n2)||g(this.state,t2)};var M=l$3.__b;l$3.__b=function(n2){n2.type&&n2.type.__f&&n2.ref&&(n2.props.ref=n2.ref,n2.ref=null),M&&M(n2)};var T=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.forward_ref")||3911;function A(n2){function t2(t3){if(!("ref"in t3))return n2(t3,null);var e2=t3.ref;delete t3.ref;var r2=n2(t3,e2);return t3.ref=e2,r2}return __name(t2,"t"),t2.$$typeof=T,t2.render=t2,t2.prototype.isReactComponent=t2.__f=!0,t2.displayName="ForwardRef("+(n2.displayName||n2.name)+")",t2}__name(A,"A");var O=l$3.__e;l$3.__e=function(n2,t2,e2,r2){if(n2.then){for(var u2,o2=t2;o2=o2.__;)if((u2=o2.__c)&&u2.__c)return t2.__e==null&&(t2.__e=e2.__e,t2.__k=e2.__k),u2.__c(n2,t2)}O(n2,t2,e2,r2)};var F=l$3.unmount;function U(n2,t2,e2){return n2&&(n2.__c&&n2.__c.__H&&(n2.__c.__H.__.forEach(function(n3){typeof n3.__c=="function"&&n3.__c()}),n2.__c.__H=null),(n2=function(n3,t3){for(var e3 in t3)n3[e3]=t3[e3];return n3}({},n2)).__c!=null&&(n2.__c.__P===e2&&(n2.__c.__P=t2),n2.__c=null),n2.__k=n2.__k&&n2.__k.map(function(n3){return U(n3,t2,e2)})),n2}__name(U,"U");function V(n2,t2,e2){return n2&&e2&&(n2.__v=null,n2.__k=n2.__k&&n2.__k.map(function(n3){return V(n3,t2,e2)}),n2.__c&&n2.__c.__P===t2&&(n2.__e&&e2.appendChild(n2.__e),n2.__c.__e=!0,n2.__c.__P=e2)),n2}__name(V,"V");function W(){this.__u=0,this.o=null,this.__b=null}__name(W,"W");function P(n2){var t2=n2.__.__c;return t2&&t2.__a&&t2.__a(n2)}__name(P,"P");function z(){this.i=null,this.l=null}__name(z,"z"),l$3.unmount=function(n2){var t2=n2.__c;t2&&t2.__R&&t2.__R(),t2&&32&n2.__u&&(n2.type=null),F&&F(n2)},(W.prototype=new x$1).__c=function(n2,t2){var e2=t2.__c,r2=this;r2.o==null&&(r2.o=[]),r2.o.push(e2);var u2=P(r2.__v),o2=!1,i2=__name(function(){o2||(o2=!0,e2.__R=null,u2?u2(c2):c2())},"i");e2.__R=i2;var c2=__name(function(){if(!--r2.__u){if(r2.state.__a){var n3=r2.state.__a;r2.__v.__k[0]=V(n3,n3.__c.__P,n3.__c.__O)}var t3;for(r2.setState({__a:r2.__b=null});t3=r2.o.pop();)t3.forceUpdate()}},"c");r2.__u++||32&t2.__u||r2.setState({__a:r2.__b=r2.__v.__k[0]}),n2.then(i2,i2)},W.prototype.componentWillUnmount=function(){this.o=[]},W.prototype.render=function(n2,e2){if(this.__b){if(this.__v.__k){var r2=document.createElement("div"),o2=this.__v.__k[0].__c;this.__v.__k[0]=U(this.__b,r2,o2.__O=o2.__P)}this.__b=null}var i2=e2.__a&&g$2(k$1,null,n2.fallback);return i2&&(i2.__u&=-33),[g$2(k$1,null,e2.__a?null:n2.children),i2]};var B=__name(function(n2,t2,e2){if(++e2[1]===e2[0]&&n2.l.delete(t2),n2.props.revealOrder&&(n2.props.revealOrder[0]!=="t"||!n2.l.size))for(e2=n2.i;e2;){for(;e2.length>3;)e2.pop()();if(e2[1]<e2[0])break;n2.i=e2=e2[2]}},"B");function H(n2){return this.getChildContext=function(){return n2.context},n2.children}__name(H,"H");function Z(n2){var e2=this,r2=n2.h;e2.componentWillUnmount=function(){D$1(null,e2.v),e2.v=null,e2.h=null},e2.h&&e2.h!==r2&&e2.componentWillUnmount(),e2.v||(e2.h=r2,e2.v={nodeType:1,parentNode:r2,childNodes:[],contains:__name(function(){return!0},"contains"),appendChild:__name(function(n3){this.childNodes.push(n3),e2.h.appendChild(n3)},"appendChild"),insertBefore:__name(function(n3,t2){this.childNodes.push(n3),e2.h.insertBefore(n3,t2)},"insertBefore"),removeChild:__name(function(n3){this.childNodes.splice(this.childNodes.indexOf(n3)>>>1,1),e2.h.removeChild(n3)},"removeChild")}),D$1(g$2(H,{context:e2.context},n2.__v),e2.v)}__name(Z,"Z");function Y(n2,e2){var r2=g$2(Z,{__v:n2,h:e2});return r2.containerInfo=e2,r2}__name(Y,"Y"),(z.prototype=new x$1).__a=function(n2){var t2=this,e2=P(t2.__v),r2=t2.l.get(n2);return r2[0]++,function(u2){var o2=__name(function(){t2.props.revealOrder?(r2.push(u2),B(t2,n2,r2)):u2()},"o");e2?e2(o2):o2()}},z.prototype.render=function(n2){this.i=null,this.l=new Map;var t2=L(n2.children);n2.revealOrder&&n2.revealOrder[0]==="b"&&t2.reverse();for(var e2=t2.length;e2--;)this.l.set(t2[e2],this.i=[1,0,this.i]);return n2.children},z.prototype.componentDidUpdate=z.prototype.componentDidMount=function(){var n2=this;this.l.forEach(function(t2,e2){B(n2,e2,t2)})};var $=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.element")||60103,q=/^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,G=/^on(Ani|Tra|Tou|BeforeInp|Compo)/,J=/[A-Z0-9]/g,K=typeof document<"u",Q=__name(function(n2){return(typeof Symbol<"u"&&typeof Symbol()=="symbol"?/fil|che|rad/:/fil|che|ra/).test(n2)},"Q");x$1.prototype.isReactComponent={},["componentWillMount","componentWillReceiveProps","componentWillUpdate"].forEach(function(t2){Object.defineProperty(x$1.prototype,t2,{configurable:!0,get:__name(function(){return this["UNSAFE_"+t2]},"get"),set:__name(function(n2){Object.defineProperty(this,t2,{configurable:!0,writable:!0,value:n2})},"set")})});var tn=l$3.event;function en(){}__name(en,"en");function rn(){return this.cancelBubble}__name(rn,"rn");function un(){return this.defaultPrevented}__name(un,"un"),l$3.event=function(n2){return tn&&(n2=tn(n2)),n2.persist=en,n2.isPropagationStopped=rn,n2.isDefaultPrevented=un,n2.nativeEvent=n2};var cn$1={enumerable:!1,configurable:!0,get:__name(function(){return this.class},"get")},fn=l$3.vnode;l$3.vnode=function(n2){typeof n2.type=="string"&&function(n3){var t2=n3.props,e2=n3.type,u2={},o2=e2.indexOf("-")===-1;for(var i2 in t2){var c2=t2[i2];if(!(i2==="value"&&"defaultValue"in t2&&c2==null||K&&i2==="children"&&e2==="noscript"||i2==="class"||i2==="className")){var f2=i2.toLowerCase();i2==="defaultValue"&&"value"in t2&&t2.value==null?i2="value":i2==="download"&&c2===!0?c2="":f2==="translate"&&c2==="no"?c2=!1:f2[0]==="o"&&f2[1]==="n"?f2==="ondoubleclick"?i2="ondblclick":f2!=="onchange"||e2!=="input"&&e2!=="textarea"||Q(t2.type)?f2==="onfocus"?i2="onfocusin":f2==="onblur"?i2="onfocusout":G.test(i2)&&(i2=f2):f2=i2="oninput":o2&&q.test(i2)?i2=i2.replace(J,"-$&").toLowerCase():c2===null&&(c2=void 0),f2==="oninput"&&u2[i2=f2]&&(i2="oninputCapture"),u2[i2]=c2}}e2=="select"&&u2.multiple&&Array.isArray(u2.value)&&(u2.value=L(t2.children).forEach(function(n4){n4.props.selected=u2.value.indexOf(n4.props.value)!=-1})),e2=="select"&&u2.defaultValue!=null&&(u2.value=L(t2.children).forEach(function(n4){n4.props.selected=u2.multiple?u2.defaultValue.indexOf(n4.props.value)!=-1:u2.defaultValue==n4.props.value})),t2.class&&!t2.className?(u2.class=t2.class,Object.defineProperty(u2,"className",cn$1)):(t2.className&&!t2.class||t2.class&&t2.className)&&(u2.class=u2.className=t2.className),n3.props=u2}(n2),n2.$$typeof=$,fn&&fn(n2)};var ln=l$3.__r;l$3.__r=function(n2){ln&&ln(n2),n2.__c};var an=l$3.diffed;l$3.diffed=function(n2){an&&an(n2);var t2=n2.props,e2=n2.__e;e2!=null&&n2.type==="textarea"&&"value"in t2&&t2.value!==e2.value&&(e2.value=t2.value==null?"":t2.value)};var f=0;function u(e2,t2,n2,o2,i2,u2){t2||(t2={});var a2,c2,l2=t2;"ref"in t2&&(a2=t2.ref,delete t2.ref);var p2={type:e2,props:l2,key:n2,ref:a2,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--f,__i:-1,__u:0,__source:i2,__self:u2};if(typeof e2=="function"&&(a2=e2.defaultProps))for(c2 in a2)l2[c2]===void 0&&(l2[c2]=a2[c2]);return l$3.vnode&&l$3.vnode(p2),p2}__name(u,"u");function descending(a2,b2){return b2-a2}__name(descending,"descending");function getComponentGroupNames(group){let result=group[0].name;const len=group.length,max=Math.min(4,len);for(let i2=1;i2<max;i2++)result+=`, ${group[i2].name}`;return result}__name(getComponentGroupNames,"getComponentGroupNames");function getComponentGroupTotalTime(group){let result=group[0].time;for(let i2=1,len=group.length;i2<len;i2++)result+=group[i2].time;return result}__name(getComponentGroupTotalTime,"getComponentGroupTotalTime");function componentGroupHasForget(group){for(let i2=0,len=group.length;i2<len;i2++)if(group[i2].forget)return!0;return!1}__name(componentGroupHasForget,"componentGroupHasForget");var getLabelText=__name(groupedAggregatedRenders=>{let labelText="";const componentsByCount=new Map;for(const aggregatedRender of groupedAggregatedRenders){const{forget,time,aggregatedCount,name}=aggregatedRender;componentsByCount.has(aggregatedCount)||componentsByCount.set(aggregatedCount,[]);const components=componentsByCount.get(aggregatedCount);components&&components.push({name,forget,time:time??0})}const sortedCounts=Array.from(componentsByCount.keys()).sort(descending),parts=[];let cumulativeTime=0;for(const count of sortedCounts){const componentGroup=componentsByCount.get(count);if(!componentGroup)continue;let text=getComponentGroupNames(componentGroup);const totalTime=getComponentGroupTotalTime(componentGroup),hasForget=componentGroupHasForget(componentGroup);cumulativeTime+=totalTime,componentGroup.length>4&&(text+="…"),count>1&&(text+=` × ${count}`),hasForget&&(text=`✨${text}`),parts.push(text)}return labelText=parts.join(", "),labelText.length?(labelText.length>40&&(labelText=`${labelText.slice(0,40)}…`),cumulativeTime>=.01&&(labelText+=` (${Number(cumulativeTime.toFixed(2))}ms)`),labelText):null},"getLabelText");function isEqual(a2,b2){return a2===b2||a2!==a2&&b2!==b2}__name(isEqual,"isEqual");var playNotificationSound=__name(audioContext=>{const oscillator=audioContext.createOscillator(),gainNode=audioContext.createGain();oscillator.connect(gainNode),gainNode.connect(audioContext.destination);const options={type:"sine",freq:[392,600],duration:.3,gain:.12},frequencies=options.freq,timePerNote=options.duration/frequencies.length;frequencies.forEach((freq,i2)=>{oscillator.frequency.setValueAtTime(freq,audioContext.currentTime+i2*timePerNote)}),oscillator.type=options.type,gainNode.gain.setValueAtTime(options.gain,audioContext.currentTime),gainNode.gain.setTargetAtTime(0,audioContext.currentTime+options.duration*.7,.05),oscillator.start(),oscillator.stop(audioContext.currentTime+options.duration)},"playNotificationSound"),batchGetBoundingRects=__name(elements=>new Promise(resolve=>{const results=new Map,observer=new IntersectionObserver(entries=>{for(const entry of entries){const element=entry.target,bounds=entry.boundingClientRect;results.set(element,bounds)}observer.disconnect(),resolve(results)});for(const element of elements)observer.observe(element)}),"batchGetBoundingRects"),RENDER_PHASE_STRING_TO_ENUM={mount:1,update:2,unmount:4},Icon=A(({size=15,name,fill="currentColor",stroke="currentColor",className,externalURL="",style},ref)=>{const width=Array.isArray(size)?size[0]:size,height=Array.isArray(size)?size[1]||size[0]:size,path=`${externalURL}#${name}`;return u("svg",{ref,width:`${width}px`,height:`${height}px`,fill,stroke,className,style:{...style,minWidth:`${width}px`,maxWidth:`${width}px`,minHeight:`${height}px`,maxHeight:`${height}px`},children:[u("title",{children:name}),u("use",{href:path})]})}),StickySection=N(({children})=>{const refScrollableElement=A$1(null),refScrollAtTop=A$1(!1),[isSticky,setIsSticky]=h$1(!1),refRafId=A$1(0),calculateStickyTop=q$1((removeSticky=!1)=>{var _a2;const stickyElements=Array.from(((_a2=refScrollableElement.current)==null?void 0:_a2.children)||[]);if(!stickyElements.length)return;let cumulativeHeight=0;for(const element of stickyElements){const sticky=element;sticky.dataset.sticky&&(removeSticky?sticky.style.removeProperty("top"):sticky.style.setProperty("top",`${cumulativeHeight}px`),cumulativeHeight+=sticky.offsetHeight)}},[]),refSticky=q$1(node=>{var _a2;if(!node){requestAnimationFrame(()=>{calculateStickyTop()});return}refScrollableElement.current=node.parentElement,node.dataset.sticky="true";const handleClick=__name(()=>{var _a3;node.dataset.disableScroll||(_a3=refScrollableElement.current)==null||_a3.scrollTo({top:Number(node.style.top)??0,behavior:"smooth"})},"handleClick");node.onclick=handleClick,calculateStickyTop();const handleScroll=__name(()=>{cancelAnimationFrame(refRafId.current),refRafId.current=requestAnimationFrame(()=>{if(!node||!refScrollableElement.current)return;const refRect=node.getBoundingClientRect(),containerRect=refScrollableElement.current.getBoundingClientRect(),stickyOffset=Number.parseInt(getComputedStyle(node).top);refScrollAtTop.current=refScrollableElement.current.scrollTop>0;const stickyActive=refScrollAtTop.current&&refRect.top<=containerRect.top+stickyOffset;stickyActive!==isSticky&&setIsSticky(stickyActive),calculateStickyTop()})},"handleScroll");(_a2=refScrollableElement.current)==null||_a2.addEventListener("scroll",handleScroll,{passive:!0})},[isSticky,calculateStickyTop]);return children({refSticky,isSticky,calculateStickyTop})}),SAFE_AREA=24,MIN_SIZE={width:550,height:350,initialHeight:400},MIN_CONTAINER_WIDTH=240,LOCALSTORAGE_KEY="react-scan-widget-settings-v2",IS_CLIENT=typeof window<"u";function r(e2){var t2,f2,n2="";if(typeof e2=="string"||typeof e2=="number")n2+=e2;else if(typeof e2=="object")if(Array.isArray(e2)){var o2=e2.length;for(t2=0;t2<o2;t2++)e2[t2]&&(f2=r(e2[t2]))&&(n2&&(n2+=" "),n2+=f2)}else for(f2 in e2)e2[f2]&&(n2&&(n2+=" "),n2+=f2);return n2}__name(r,"r");function clsx(){for(var e2,t2,f2=0,n2="",o2=arguments.length;f2<o2;f2++)(e2=arguments[f2])&&(t2=r(e2))&&(n2&&(n2+=" "),n2+=t2);return n2}__name(clsx,"clsx");var CLASS_PART_SEPARATOR="-",createClassGroupUtils=__name(config=>{const classMap=createClassMap(config),{conflictingClassGroups,conflictingClassGroupModifiers}=config;return{getClassGroupId:__name(className=>{const classParts=className.split(CLASS_PART_SEPARATOR);return classParts[0]===""&&classParts.length!==1&&classParts.shift(),getGroupRecursive(classParts,classMap)||getGroupIdForArbitraryProperty(className)},"getClassGroupId"),getConflictingClassGroupIds:__name((classGroupId,hasPostfixModifier)=>{const conflicts=conflictingClassGroups[classGroupId]||[];return hasPostfixModifier&&conflictingClassGroupModifiers[classGroupId]?[...conflicts,...conflictingClassGroupModifiers[classGroupId]]:conflicts},"getConflictingClassGroupIds")}},"createClassGroupUtils"),getGroupRecursive=__name((classParts,classPartObject)=>{var _a2;if(classParts.length===0)return classPartObject.classGroupId;const currentClassPart=classParts[0],nextClassPartObject=classPartObject.nextPart.get(currentClassPart),classGroupFromNextClassPart=nextClassPartObject?getGroupRecursive(classParts.slice(1),nextClassPartObject):void 0;if(classGroupFromNextClassPart)return classGroupFromNextClassPart;if(classPartObject.validators.length===0)return;const classRest=classParts.join(CLASS_PART_SEPARATOR);return(_a2=classPartObject.validators.find(({validator})=>validator(classRest)))==null?void 0:_a2.classGroupId},"getGroupRecursive"),arbitraryPropertyRegex=/^\[(.+)\]$/,getGroupIdForArbitraryProperty=__name(className=>{if(arbitraryPropertyRegex.test(className)){const arbitraryPropertyClassName=arbitraryPropertyRegex.exec(className)[1],property=arbitraryPropertyClassName==null?void 0:arbitraryPropertyClassName.substring(0,arbitraryPropertyClassName.indexOf(":"));if(property)return"arbitrary.."+property}},"getGroupIdForArbitraryProperty"),createClassMap=__name(config=>{const{theme,prefix}=config,classMap={nextPart:new Map,validators:[]};return getPrefixedClassGroupEntries(Object.entries(config.classGroups),prefix).forEach(([classGroupId,classGroup])=>{processClassesRecursively(classGroup,classMap,classGroupId,theme)}),classMap},"createClassMap"),processClassesRecursively=__name((classGroup,classPartObject,classGroupId,theme)=>{classGroup.forEach(classDefinition=>{if(typeof classDefinition=="string"){const classPartObjectToEdit=classDefinition===""?classPartObject:getPart(classPartObject,classDefinition);classPartObjectToEdit.classGroupId=classGroupId;return}if(typeof classDefinition=="function"){if(isThemeGetter(classDefinition)){processClassesRecursively(classDefinition(theme),classPartObject,classGroupId,theme);return}classPartObject.validators.push({validator:classDefinition,classGroupId});return}Object.entries(classDefinition).forEach(([key,classGroup2])=>{processClassesRecursively(classGroup2,getPart(classPartObject,key),classGroupId,theme)})})},"processClassesRecursively"),getPart=__name((classPartObject,path)=>{let currentClassPartObject=classPartObject;return path.split(CLASS_PART_SEPARATOR).forEach(pathPart=>{currentClassPartObject.nextPart.has(pathPart)||currentClassPartObject.nextPart.set(pathPart,{nextPart:new Map,validators:[]}),currentClassPartObject=currentClassPartObject.nextPart.get(pathPart)}),currentClassPartObject},"getPart"),isThemeGetter=__name(func=>func.isThemeGetter,"isThemeGetter"),getPrefixedClassGroupEntries=__name((classGroupEntries,prefix)=>prefix?classGroupEntries.map(([classGroupId,classGroup])=>{const prefixedClassGroup=classGroup.map(classDefinition=>typeof classDefinition=="string"?prefix+classDefinition:typeof classDefinition=="object"?Object.fromEntries(Object.entries(classDefinition).map(([key,value])=>[prefix+key,value])):classDefinition);return[classGroupId,prefixedClassGroup]}):classGroupEntries,"getPrefixedClassGroupEntries"),createLruCache=__name(maxCacheSize=>{if(maxCacheSize<1)return{get:__name(()=>{},"get"),set:__name(()=>{},"set")};let cacheSize=0,cache2=new Map,previousCache=new Map;const update=__name((key,value)=>{cache2.set(key,value),cacheSize++,cacheSize>maxCacheSize&&(cacheSize=0,previousCache=cache2,cache2=new Map)},"update");return{get(key){let value=cache2.get(key);if(value!==void 0)return value;if((value=previousCache.get(key))!==void 0)return update(key,value),value},set(key,value){cache2.has(key)?cache2.set(key,value):update(key,value)}}},"createLruCache"),IMPORTANT_MODIFIER="!",createParseClassName=__name(config=>{const{separator,experimentalParseClassName}=config,isSeparatorSingleCharacter=separator.length===1,firstSeparatorCharacter=separator[0],separatorLength=separator.length,parseClassName=__name(className=>{const modifiers=[];let bracketDepth=0,modifierStart=0,postfixModifierPosition;for(let index=0;index<className.length;index++){let currentCharacter=className[index];if(bracketDepth===0){if(currentCharacter===firstSeparatorCharacter&&(isSeparatorSingleCharacter||className.slice(index,index+separatorLength)===separator)){modifiers.push(className.slice(modifierStart,index)),modifierStart=index+separatorLength;continue}if(currentCharacter==="/"){postfixModifierPosition=index;continue}}currentCharacter==="["?bracketDepth++:currentCharacter==="]"&&bracketDepth--}const baseClassNameWithImportantModifier=modifiers.length===0?className:className.substring(modifierStart),hasImportantModifier=baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER),baseClassName=hasImportantModifier?baseClassNameWithImportantModifier.substring(1):baseClassNameWithImportantModifier,maybePostfixModifierPosition=postfixModifierPosition&&postfixModifierPosition>modifierStart?postfixModifierPosition-modifierStart:void 0;return{modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition}},"parseClassName");return experimentalParseClassName?className=>experimentalParseClassName({className,parseClassName}):parseClassName},"createParseClassName"),sortModifiers=__name(modifiers=>{if(modifiers.length<=1)return modifiers;const sortedModifiers=[];let unsortedModifiers=[];return modifiers.forEach(modifier=>{modifier[0]==="["?(sortedModifiers.push(...unsortedModifiers.sort(),modifier),unsortedModifiers=[]):unsortedModifiers.push(modifier)}),sortedModifiers.push(...unsortedModifiers.sort()),sortedModifiers},"sortModifiers"),createConfigUtils=__name(config=>({cache:createLruCache(config.cacheSize),parseClassName:createParseClassName(config),...createClassGroupUtils(config)}),"createConfigUtils"),SPLIT_CLASSES_REGEX=/\s+/,mergeClassList=__name((classList,configUtils)=>{const{parseClassName,getClassGroupId,getConflictingClassGroupIds}=configUtils,classGroupsInConflict=[],classNames=classList.trim().split(SPLIT_CLASSES_REGEX);let result="";for(let index=classNames.length-1;index>=0;index-=1){const originalClassName=classNames[index],{modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition}=parseClassName(originalClassName);let hasPostfixModifier=!!maybePostfixModifierPosition,classGroupId=getClassGroupId(hasPostfixModifier?baseClassName.substring(0,maybePostfixModifierPosition):baseClassName);if(!classGroupId){if(!hasPostfixModifier){result=originalClassName+(result.length>0?" "+result:result);continue}if(classGroupId=getClassGroupId(baseClassName),!classGroupId){result=originalClassName+(result.length>0?" "+result:result);continue}hasPostfixModifier=!1}const variantModifier=sortModifiers(modifiers).join(":"),modifierId=hasImportantModifier?variantModifier+IMPORTANT_MODIFIER:variantModifier,classId=modifierId+classGroupId;if(classGroupsInConflict.includes(classId))continue;classGroupsInConflict.push(classId);const conflictGroups=getConflictingClassGroupIds(classGroupId,hasPostfixModifier);for(let i2=0;i2<conflictGroups.length;++i2){const group=conflictGroups[i2];classGroupsInConflict.push(modifierId+group)}result=originalClassName+(result.length>0?" "+result:result)}return result},"mergeClassList");function twJoin(){let index=0,argument,resolvedValue,string="";for(;index<arguments.length;)(argument=arguments[index++])&&(resolvedValue=toValue(argument))&&(string&&(string+=" "),string+=resolvedValue);return string}__name(twJoin,"twJoin");var toValue=__name(mix=>{if(typeof mix=="string")return mix;let resolvedValue,string="";for(let k2=0;k2<mix.length;k2++)mix[k2]&&(resolvedValue=toValue(mix[k2]))&&(string&&(string+=" "),string+=resolvedValue);return string},"toValue");function createTailwindMerge(createConfigFirst,...createConfigRest){let configUtils,cacheGet,cacheSet,functionToCall=initTailwindMerge;function initTailwindMerge(classList){const config=createConfigRest.reduce((previousConfig,createConfigCurrent)=>createConfigCurrent(previousConfig),createConfigFirst());return configUtils=createConfigUtils(config),cacheGet=configUtils.cache.get,cacheSet=configUtils.cache.set,functionToCall=tailwindMerge,tailwindMerge(classList)}__name(initTailwindMerge,"initTailwindMerge");function tailwindMerge(classList){const cachedResult=cacheGet(classList);if(cachedResult)return cachedResult;const result=mergeClassList(classList,configUtils);return cacheSet(classList,result),result}return __name(tailwindMerge,"tailwindMerge"),__name(function(){return functionToCall(twJoin.apply(null,arguments))},"callTailwindMerge")}__name(createTailwindMerge,"createTailwindMerge");var fromTheme=__name(key=>{const themeGetter=__name(theme=>theme[key]||[],"themeGetter");return themeGetter.isThemeGetter=!0,themeGetter},"fromTheme"),arbitraryValueRegex=/^\[(?:([a-z-]+):)?(.+)\]$/i,fractionRegex=/^\d+\/\d+$/,stringLengths=new Set(["px","full","screen"]),tshirtUnitRegex=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,lengthUnitRegex=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,colorFunctionRegex=/^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,shadowRegex=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,imageRegex=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,isLength=__name(value=>isNumber(value)||stringLengths.has(value)||fractionRegex.test(value),"isLength"),isArbitraryLength=__name(value=>getIsArbitraryValue(value,"length",isLengthOnly),"isArbitraryLength"),isNumber=__name(value=>!!value&&!Number.isNaN(Number(value)),"isNumber"),isArbitraryNumber=__name(value=>getIsArbitraryValue(value,"number",isNumber),"isArbitraryNumber"),isInteger=__name(value=>!!value&&Number.isInteger(Number(value)),"isInteger"),isPercent=__name(value=>value.endsWith("%")&&isNumber(value.slice(0,-1)),"isPercent"),isArbitraryValue=__name(value=>arbitraryValueRegex.test(value),"isArbitraryValue"),isTshirtSize=__name(value=>tshirtUnitRegex.test(value),"isTshirtSize"),sizeLabels=new Set(["length","size","percentage"]),isArbitrarySize=__name(value=>getIsArbitraryValue(value,sizeLabels,isNever),"isArbitrarySize"),isArbitraryPosition=__name(value=>getIsArbitraryValue(value,"position",isNever),"isArbitraryPosition"),imageLabels=new Set(["image","url"]),isArbitraryImage=__name(value=>getIsArbitraryValue(value,imageLabels,isImage),"isArbitraryImage"),isArbitraryShadow=__name(value=>getIsArbitraryValue(value,"",isShadow),"isArbitraryShadow"),isAny=__name(()=>!0,"isAny"),getIsArbitraryValue=__name((value,label,testValue)=>{const result=arbitraryValueRegex.exec(value);return result?result[1]?typeof label=="string"?result[1]===label:label.has(result[1]):testValue(result[2]):!1},"getIsArbitraryValue"),isLengthOnly=__name(value=>lengthUnitRegex.test(value)&&!colorFunctionRegex.test(value),"isLengthOnly"),isNever=__name(()=>!1,"isNever"),isShadow=__name(value=>shadowRegex.test(value),"isShadow"),isImage=__name(value=>imageRegex.test(value),"isImage"),getDefaultConfig=__name(()=>{const colors=fromTheme("colors"),spacing=fromTheme("spacing"),blur=fromTheme("blur"),brightness=fromTheme("brightness"),borderColor=fromTheme("borderColor"),borderRadius=fromTheme("borderRadius"),borderSpacing=fromTheme("borderSpacing"),borderWidth=fromTheme("borderWidth"),contrast=fromTheme("contrast"),grayscale=fromTheme("grayscale"),hueRotate=fromTheme("hueRotate"),invert=fromTheme("invert"),gap=fromTheme("gap"),gradientColorStops=fromTheme("gradientColorStops"),gradientColorStopPositions=fromTheme("gradientColorStopPositions"),inset=fromTheme("inset"),margin=fromTheme("margin"),opacity=fromTheme("opacity"),padding=fromTheme("padding"),saturate=fromTheme("saturate"),scale=fromTheme("scale"),sepia=fromTheme("sepia"),skew=fromTheme("skew"),space=fromTheme("space"),translate=fromTheme("translate"),getOverscroll=__name(()=>["auto","contain","none"],"getOverscroll"),getOverflow=__name(()=>["auto","hidden","clip","visible","scroll"],"getOverflow"),getSpacingWithAutoAndArbitrary=__name(()=>["auto",isArbitraryValue,spacing],"getSpacingWithAutoAndArbitrary"),getSpacingWithArbitrary=__name(()=>[isArbitraryValue,spacing],"getSpacingWithArbitrary"),getLengthWithEmptyAndArbitrary=__name(()=>["",isLength,isArbitraryLength],"getLengthWithEmptyAndArbitrary"),getNumberWithAutoAndArbitrary=__name(()=>["auto",isNumber,isArbitraryValue],"getNumberWithAutoAndArbitrary"),getPositions=__name(()=>["bottom","center","left","left-bottom","left-top","right","right-bottom","right-top","top"],"getPositions"),getLineStyles=__name(()=>["solid","dashed","dotted","double","none"],"getLineStyles"),getBlendModes=__name(()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],"getBlendModes"),getAlign=__name(()=>["start","end","center","between","around","evenly","stretch"],"getAlign"),getZeroAndEmpty=__name(()=>["","0",isArbitraryValue],"getZeroAndEmpty"),getBreaks=__name(()=>["auto","avoid","all","avoid-page","page","left","right","column"],"getBreaks"),getNumberAndArbitrary=__name(()=>[isNumber,isArbitraryValue],"getNumberAndArbitrary");return{cacheSize:500,separator:":",theme:{colors:[isAny],spacing:[isLength,isArbitraryLength],blur:["none","",isTshirtSize,isArbitraryValue],brightness:getNumberAndArbitrary(),borderColor:[colors],borderRadius:["none","","full",isTshirtSize,isArbitraryValue],borderSpacing:getSpacingWithArbitrary(),borderWidth:getLengthWithEmptyAndArbitrary(),contrast:getNumberAndArbitrary(),grayscale:getZeroAndEmpty(),hueRotate:getNumberAndArbitrary(),invert:getZeroAndEmpty(),gap:getSpacingWithArbitrary(),gradientColorStops:[colors],gradientColorStopPositions:[isPercent,isArbitraryLength],inset:getSpacingWithAutoAndArbitrary(),margin:getSpacingWithAutoAndArbitrary(),opacity:getNumberAndArbitrary(),padding:getSpacingWithArbitrary(),saturate:getNumberAndArbitrary(),scale:getNumberAndArbitrary(),sepia:getZeroAndEmpty(),skew:getNumberAndArbitrary(),space:getSpacingWithArbitrary(),translate:getSpacingWithArbitrary()},classGroups:{aspect:[{aspect:["auto","square","video",isArbitraryValue]}],container:["container"],columns:[{columns:[isTshirtSize]}],"break-after":[{"break-after":getBreaks()}],"break-before":[{"break-before":getBreaks()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:[...getPositions(),isArbitraryValue]}],overflow:[{overflow:getOverflow()}],"overflow-x":[{"overflow-x":getOverflow()}],"overflow-y":[{"overflow-y":getOverflow()}],overscroll:[{overscroll:getOverscroll()}],"overscroll-x":[{"overscroll-x":getOverscroll()}],"overscroll-y":[{"overscroll-y":getOverscroll()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:[inset]}],"inset-x":[{"inset-x":[inset]}],"inset-y":[{"inset-y":[inset]}],start:[{start:[inset]}],end:[{end:[inset]}],top:[{top:[inset]}],right:[{right:[inset]}],bottom:[{bottom:[inset]}],left:[{left:[inset]}],visibility:["visible","invisible","collapse"],z:[{z:["auto",isInteger,isArbitraryValue]}],basis:[{basis:getSpacingWithAutoAndArbitrary()}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["wrap","wrap-reverse","nowrap"]}],flex:[{flex:["1","auto","initial","none",isArbitraryValue]}],grow:[{grow:getZeroAndEmpty()}],shrink:[{shrink:getZeroAndEmpty()}],order:[{order:["first","last","none",isInteger,isArbitraryValue]}],"grid-cols":[{"grid-cols":[isAny]}],"col-start-end":[{col:["auto",{span:["full",isInteger,isArbitraryValue]},isArbitraryValue]}],"col-start":[{"col-start":getNumberWithAutoAndArbitrary()}],"col-end":[{"col-end":getNumberWithAutoAndArbitrary()}],"grid-rows":[{"grid-rows":[isAny]}],"row-start-end":[{row:["auto",{span:[isInteger,isArbitraryValue]},isArbitraryValue]}],"row-start":[{"row-start":getNumberWithAutoAndArbitrary()}],"row-end":[{"row-end":getNumberWithAutoAndArbitrary()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":["auto","min","max","fr",isArbitraryValue]}],"auto-rows":[{"auto-rows":["auto","min","max","fr",isArbitraryValue]}],gap:[{gap:[gap]}],"gap-x":[{"gap-x":[gap]}],"gap-y":[{"gap-y":[gap]}],"justify-content":[{justify:["normal",...getAlign()]}],"justify-items":[{"justify-items":["start","end","center","stretch"]}],"justify-self":[{"justify-self":["auto","start","end","center","stretch"]}],"align-content":[{content:["normal",...getAlign(),"baseline"]}],"align-items":[{items:["start","end","center","baseline","stretch"]}],"align-self":[{self:["auto","start","end","center","stretch","baseline"]}],"place-content":[{"place-content":[...getAlign(),"baseline"]}],"place-items":[{"place-items":["start","end","center","baseline","stretch"]}],"place-self":[{"place-self":["auto","start","end","center","stretch"]}],p:[{p:[padding]}],px:[{px:[padding]}],py:[{py:[padding]}],ps:[{ps:[padding]}],pe:[{pe:[padding]}],pt:[{pt:[padding]}],pr:[{pr:[padding]}],pb:[{pb:[padding]}],pl:[{pl:[padding]}],m:[{m:[margin]}],mx:[{mx:[margin]}],my:[{my:[margin]}],ms:[{ms:[margin]}],me:[{me:[margin]}],mt:[{mt:[margin]}],mr:[{mr:[margin]}],mb:[{mb:[margin]}],ml:[{ml:[margin]}],"space-x":[{"space-x":[space]}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":[space]}],"space-y-reverse":["space-y-reverse"],w:[{w:["auto","min","max","fit","svw","lvw","dvw",isArbitraryValue,spacing]}],"min-w":[{"min-w":[isArbitraryValue,spacing,"min","max","fit"]}],"max-w":[{"max-w":[isArbitraryValue,spacing,"none","full","min","max","fit","prose",{screen:[isTshirtSize]},isTshirtSize]}],h:[{h:[isArbitraryValue,spacing,"auto","min","max","fit","svh","lvh","dvh"]}],"min-h":[{"min-h":[isArbitraryValue,spacing,"min","max","fit","svh","lvh","dvh"]}],"max-h":[{"max-h":[isArbitraryValue,spacing,"min","max","fit","svh","lvh","dvh"]}],size:[{size:[isArbitraryValue,spacing,"auto","min","max","fit"]}],"font-size":[{text:["base",isTshirtSize,isArbitraryLength]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:["thin","extralight","light","normal","medium","semibold","bold","extrabold","black",isArbitraryNumber]}],"font-family":[{font:[isAny]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:["tighter","tight","normal","wide","wider","widest",isArbitraryValue]}],"line-clamp":[{"line-clamp":["none",isNumber,isArbitraryNumber]}],leading:[{leading:["none","tight","snug","normal","relaxed","loose",isLength,isArbitraryValue]}],"list-image":[{"list-image":["none",isArbitraryValue]}],"list-style-type":[{list:["none","disc","decimal",isArbitraryValue]}],"list-style-position":[{list:["inside","outside"]}],"placeholder-color":[{placeholder:[colors]}],"placeholder-opacity":[{"placeholder-opacity":[opacity]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"text-color":[{text:[colors]}],"text-opacity":[{"text-opacity":[opacity]}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...getLineStyles(),"wavy"]}],"text-decoration-thickness":[{decoration:["auto","from-font",isLength,isArbitraryLength]}],"underline-offset":[{"underline-offset":["auto",isLength,isArbitraryValue]}],"text-decoration-color":[{decoration:[colors]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:getSpacingWithArbitrary()}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",isArbitraryValue]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",isArbitraryValue]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-opacity":[{"bg-opacity":[opacity]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:[...getPositions(),isArbitraryPosition]}],"bg-repeat":[{bg:["no-repeat",{repeat:["","x","y","round","space"]}]}],"bg-size":[{bg:["auto","cover","contain",isArbitrarySize]}],"bg-image":[{bg:["none",{"gradient-to":["t","tr","r","br","b","bl","l","tl"]},isArbitraryImage]}],"bg-color":[{bg:[colors]}],"gradient-from-pos":[{from:[gradientColorStopPositions]}],"gradient-via-pos":[{via:[gradientColorStopPositions]}],"gradient-to-pos":[{to:[gradientColorStopPositions]}],"gradient-from":[{from:[gradientColorStops]}],"gradient-via":[{via:[gradientColorStops]}],"gradient-to":[{to:[gradientColorStops]}],rounded:[{rounded:[borderRadius]}],"rounded-s":[{"rounded-s":[borderRadius]}],"rounded-e":[{"rounded-e":[borderRadius]}],"rounded-t":[{"rounded-t":[borderRadius]}],"rounded-r":[{"rounded-r":[borderRadius]}],"rounded-b":[{"rounded-b":[borderRadius]}],"rounded-l":[{"rounded-l":[borderRadius]}],"rounded-ss":[{"rounded-ss":[borderRadius]}],"rounded-se":[{"rounded-se":[borderRadius]}],"rounded-ee":[{"rounded-ee":[borderRadius]}],"rounded-es":[{"rounded-es":[borderRadius]}],"rounded-tl":[{"rounded-tl":[borderRadius]}],"rounded-tr":[{"rounded-tr":[borderRadius]}],"rounded-br":[{"rounded-br":[borderRadius]}],"rounded-bl":[{"rounded-bl":[borderRadius]}],"border-w":[{border:[borderWidth]}],"border-w-x":[{"border-x":[borderWidth]}],"border-w-y":[{"border-y":[borderWidth]}],"border-w-s":[{"border-s":[borderWidth]}],"border-w-e":[{"border-e":[borderWidth]}],"border-w-t":[{"border-t":[borderWidth]}],"border-w-r":[{"border-r":[borderWidth]}],"border-w-b":[{"border-b":[borderWidth]}],"border-w-l":[{"border-l":[borderWidth]}],"border-opacity":[{"border-opacity":[opacity]}],"border-style":[{border:[...getLineStyles(),"hidden"]}],"divide-x":[{"divide-x":[borderWidth]}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":[borderWidth]}],"divide-y-reverse":["divide-y-reverse"],"divide-opacity":[{"divide-opacity":[opacity]}],"divide-style":[{divide:getLineStyles()}],"border-color":[{border:[borderColor]}],"border-color-x":[{"border-x":[borderColor]}],"border-color-y":[{"border-y":[borderColor]}],"border-color-s":[{"border-s":[borderColor]}],"border-color-e":[{"border-e":[borderColor]}],"border-color-t":[{"border-t":[borderColor]}],"border-color-r":[{"border-r":[borderColor]}],"border-color-b":[{"border-b":[borderColor]}],"border-color-l":[{"border-l":[borderColor]}],"divide-color":[{divide:[borderColor]}],"outline-style":[{outline:["",...getLineStyles()]}],"outline-offset":[{"outline-offset":[isLength,isArbitraryValue]}],"outline-w":[{outline:[isLength,isArbitraryLength]}],"outline-color":[{outline:[colors]}],"ring-w":[{ring:getLengthWithEmptyAndArbitrary()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:[colors]}],"ring-opacity":[{"ring-opacity":[opacity]}],"ring-offset-w":[{"ring-offset":[isLength,isArbitraryLength]}],"ring-offset-color":[{"ring-offset":[colors]}],shadow:[{shadow:["","inner","none",isTshirtSize,isArbitraryShadow]}],"shadow-color":[{shadow:[isAny]}],opacity:[{opacity:[opacity]}],"mix-blend":[{"mix-blend":[...getBlendModes(),"plus-lighter","plus-darker"]}],"bg-blend":[{"bg-blend":getBlendModes()}],filter:[{filter:["","none"]}],blur:[{blur:[blur]}],brightness:[{brightness:[brightness]}],contrast:[{contrast:[contrast]}],"drop-shadow":[{"drop-shadow":["","none",isTshirtSize,isArbitraryValue]}],grayscale:[{grayscale:[grayscale]}],"hue-rotate":[{"hue-rotate":[hueRotate]}],invert:[{invert:[invert]}],saturate:[{saturate:[saturate]}],sepia:[{sepia:[sepia]}],"backdrop-filter":[{"backdrop-filter":["","none"]}],"backdrop-blur":[{"backdrop-blur":[blur]}],"backdrop-brightness":[{"backdrop-brightness":[brightness]}],"backdrop-contrast":[{"backdrop-contrast":[contrast]}],"backdrop-grayscale":[{"backdrop-grayscale":[grayscale]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[hueRotate]}],"backdrop-invert":[{"backdrop-invert":[invert]}],"backdrop-opacity":[{"backdrop-opacity":[opacity]}],"backdrop-saturate":[{"backdrop-saturate":[saturate]}],"backdrop-sepia":[{"backdrop-sepia":[sepia]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":[borderSpacing]}],"border-spacing-x":[{"border-spacing-x":[borderSpacing]}],"border-spacing-y":[{"border-spacing-y":[borderSpacing]}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["none","all","","colors","opacity","shadow","transform",isArbitraryValue]}],duration:[{duration:getNumberAndArbitrary()}],ease:[{ease:["linear","in","out","in-out",isArbitraryValue]}],delay:[{delay:getNumberAndArbitrary()}],animate:[{animate:["none","spin","ping","pulse","bounce",isArbitraryValue]}],transform:[{transform:["","gpu","none"]}],scale:[{scale:[scale]}],"scale-x":[{"scale-x":[scale]}],"scale-y":[{"scale-y":[scale]}],rotate:[{rotate:[isInteger,isArbitraryValue]}],"translate-x":[{"translate-x":[translate]}],"translate-y":[{"translate-y":[translate]}],"skew-x":[{"skew-x":[skew]}],"skew-y":[{"skew-y":[skew]}],"transform-origin":[{origin:["center","top","top-right","right","bottom-right","bottom","bottom-left","left","top-left",isArbitraryValue]}],accent:[{accent:["auto",colors]}],appearance:[{appearance:["none","auto"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",isArbitraryValue]}],"caret-color":[{caret:[colors]}],"pointer-events":[{"pointer-events":["none","auto"]}],resize:[{resize:["none","y","x",""]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scroll-m":[{"scroll-m":getSpacingWithArbitrary()}],"scroll-mx":[{"scroll-mx":getSpacingWithArbitrary()}],"scroll-my":[{"scroll-my":getSpacingWithArbitrary()}],"scroll-ms":[{"scroll-ms":getSpacingWithArbitrary()}],"scroll-me":[{"scroll-me":getSpacingWithArbitrary()}],"scroll-mt":[{"scroll-mt":getSpacingWithArbitrary()}],"scroll-mr":[{"scroll-mr":getSpacingWithArbitrary()}],"scroll-mb":[{"scroll-mb":getSpacingWithArbitrary()}],"scroll-ml":[{"scroll-ml":getSpacingWithArbitrary()}],"scroll-p":[{"scroll-p":getSpacingWithArbitrary()}],"scroll-px":[{"scroll-px":getSpacingWithArbitrary()}],"scroll-py":[{"scroll-py":getSpacingWithArbitrary()}],"scroll-ps":[{"scroll-ps":getSpacingWithArbitrary()}],"scroll-pe":[{"scroll-pe":getSpacingWithArbitrary()}],"scroll-pt":[{"scroll-pt":getSpacingWithArbitrary()}],"scroll-pr":[{"scroll-pr":getSpacingWithArbitrary()}],"scroll-pb":[{"scroll-pb":getSpacingWithArbitrary()}],"scroll-pl":[{"scroll-pl":getSpacingWithArbitrary()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",isArbitraryValue]}],fill:[{fill:[colors,"none"]}],"stroke-w":[{stroke:[isLength,isArbitraryLength,isArbitraryNumber]}],stroke:[{stroke:[colors,"none"]}],sr:["sr-only","not-sr-only"],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-s","border-w-e","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-s","border-color-e","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]}}},"getDefaultConfig"),twMerge=createTailwindMerge(getDefaultConfig),cn=__name((...inputs)=>twMerge(clsx(inputs)),"cn");typeof navigator<"u"&&navigator.userAgent.includes("Firefox");var throttle=__name((callback,delay)=>{let lastCall=0;return e2=>{const now=Date.now();if(now-lastCall>=delay)return lastCall=now,callback(e2)}},"throttle"),tryOrElse=__name((fn2,defaultValue)=>{try{return fn2()}catch{return defaultValue}},"tryOrElse"),readLocalStorage$1=__name(storageKey=>{if(!IS_CLIENT)return null;try{const stored=localStorage.getItem(storageKey);return stored?JSON.parse(stored):null}catch{return null}},"readLocalStorage$1"),saveLocalStorage$1=__name((storageKey,state)=>{if(IS_CLIENT)try{window.localStorage.setItem(storageKey,JSON.stringify(state))}catch{}},"saveLocalStorage$1"),removeLocalStorage=__name(storageKey=>{if(IS_CLIENT)try{window.localStorage.removeItem(storageKey)}catch{}},"removeLocalStorage"),LazyComponentTag=24,ProfilerTag=12,getExtendedDisplayName=__name(fiber=>{if(!fiber)return{name:"Unknown",wrappers:[],wrapperTypes:[]};const{tag,type,elementType}=fiber;let name=getDisplayName(type);const wrappers=[],wrapperTypes=[];if(hasMemoCache(fiber)||tag===SimpleMemoComponentTag||tag===MemoComponentTag||(type==null?void 0:type.$$typeof)===Symbol.for("react.memo")||(elementType==null?void 0:elementType.$$typeof)===Symbol.for("react.memo")){const compiler=hasMemoCache(fiber);wrapperTypes.push({type:"memo",title:compiler?"This component has been auto-memoized by the React Compiler.":"Memoized component that skips re-renders if props are the same",compiler})}if(tag===LazyComponentTag&&wrapperTypes.push({type:"lazy",title:"Lazily loaded component that supports code splitting"}),tag===SuspenseComponentTag&&wrapperTypes.push({type:"suspense",title:"Component that can suspend while content is loading"}),tag===ProfilerTag&&wrapperTypes.push({type:"profiler",title:"Component that measures rendering performance"}),typeof name=="string"){const wrapperRegex=/^(\w+)\((.*)\)$/;let currentName=name;for(;wrapperRegex.test(currentName);){const match=currentName.match(wrapperRegex);if(match!=null&&match[1]&&(match!=null&&match[2]))wrappers.unshift(match[1]),currentName=match[2];else break}name=currentName}return{name:name||"Unknown",wrappers,wrapperTypes}},"getExtendedDisplayName"),signalIsSettingsOpen=d$1(!1),signalRefWidget=d$1(null),defaultWidgetConfig={corner:"bottom-right",dimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:{x:SAFE_AREA,y:SAFE_AREA}},lastDimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:{x:SAFE_AREA,y:SAFE_AREA}},componentsTree:{width:MIN_CONTAINER_WIDTH}},getInitialWidgetConfig=__name(()=>{const stored=readLocalStorage$1(LOCALSTORAGE_KEY);return stored?{corner:stored.corner??defaultWidgetConfig.corner,dimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:stored.dimensions.position??defaultWidgetConfig.dimensions.position},lastDimensions:stored.dimensions??defaultWidgetConfig.dimensions,componentsTree:stored.componentsTree??defaultWidgetConfig.componentsTree}:(saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:defaultWidgetConfig.corner,dimensions:defaultWidgetConfig.dimensions,lastDimensions:defaultWidgetConfig.lastDimensions,componentsTree:defaultWidgetConfig.componentsTree}),defaultWidgetConfig)},"getInitialWidgetConfig"),signalWidget=d$1(getInitialWidgetConfig()),updateDimensions=__name(()=>{if(!IS_CLIENT)return;const{dimensions}=signalWidget.value,{width,height,position}=dimensions;signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:width>=window.innerWidth-SAFE_AREA*2,isFullHeight:height>=window.innerHeight-SAFE_AREA*2,width,height,position}}},"updateDimensions"),signalWidgetViews=d$1({view:"none"});function CONSTANT_UPDATE(){return!1}__name(CONSTANT_UPDATE,"CONSTANT_UPDATE");function constant(Component3){function Memoed(props){return this.shouldComponentUpdate=CONSTANT_UPDATE,g$2(Component3,props)}return __name(Memoed,"Memoed"),Memoed.displayName=`Memo(${Component3.displayName||Component3.name})`,Memoed.prototype.isReactComponent=!0,Memoed._forwarded=!0,Memoed}__name(constant,"constant");var useVirtualList=__name(options=>{const{count,getScrollElement,estimateSize,overscan=5}=options,[scrollTop,setScrollTop]=h$1(0),[containerHeight,setContainerHeight]=h$1(0),refResizeObserver=A$1(),refScrollElement=A$1(null),refRafId=A$1(null),itemHeight=estimateSize(),updateContainer=q$1(entries=>{var _a2;if(!refScrollElement.current)return;const height=((_a2=entries==null?void 0:entries[0])==null?void 0:_a2.contentRect.height)??refScrollElement.current.getBoundingClientRect().height;setContainerHeight(height)},[]),debouncedUpdateContainer=q$1(()=>{refRafId.current!==null&&cancelAnimationFrame(refRafId.current),refRafId.current=requestAnimationFrame(()=>{updateContainer(),refRafId.current=null})},[updateContainer]);y$1(()=>{const element=getScrollElement();if(!element)return;refScrollElement.current=element;const handleScroll=__name(()=>{refScrollElement.current&&setScrollTop(refScrollElement.current.scrollTop)},"handleScroll");updateContainer(),refResizeObserver.current||(refResizeObserver.current=new ResizeObserver(()=>{debouncedUpdateContainer()})),refResizeObserver.current.observe(element),element.addEventListener("scroll",handleScroll,{passive:!0});const mutationObserver=new MutationObserver(debouncedUpdateContainer);return mutationObserver.observe(element,{attributes:!0,childList:!0,subtree:!0}),()=>{element.removeEventListener("scroll",handleScroll),refResizeObserver.current&&refResizeObserver.current.disconnect(),mutationObserver.disconnect(),refRafId.current!==null&&cancelAnimationFrame(refRafId.current)}},[getScrollElement,updateContainer,debouncedUpdateContainer]);const visibleRange=T$1(()=>{const start2=Math.floor(scrollTop/itemHeight),visibleCount=Math.ceil(containerHeight/itemHeight);return{start:Math.max(0,start2-overscan),end:Math.min(count,start2+visibleCount+overscan)}},[scrollTop,itemHeight,containerHeight,count,overscan]);return{virtualItems:T$1(()=>{const virtualItems=[];for(let index=visibleRange.start;index<visibleRange.end;index++)virtualItems.push({key:index,index,start:index*itemHeight});return virtualItems},[visibleRange,itemHeight]),totalSize:count*itemHeight,scrollTop,containerHeight}},"useVirtualList");readLocalStorage$1("react-scann-pinned");var getFiberPath=__name(fiber=>{const pathSegments=[];let currentFiber=fiber;for(;currentFiber;){const elementType=currentFiber.elementType,name=typeof elementType=="function"?elementType.displayName||elementType.name:typeof elementType=="string"?elementType:"Unknown",index=currentFiber.index!==void 0?`[${currentFiber.index}]`:"";pathSegments.unshift(`${name}${index}`),currentFiber=currentFiber.return??null}return pathSegments.join("::")},"getFiberPath"),fadeOutTimers=new WeakMap,trackElementPosition=__name((element,callback)=>{const handleScroll=callback.bind(null,element);return document.addEventListener("scroll",handleScroll,{passive:!0,capture:!0}),()=>{document.removeEventListener("scroll",handleScroll,{capture:!0})}},"trackElementPosition"),flashManager={activeFlashes:new Map,create(container){const existingOverlay=container.querySelector(".react-scan-flash-overlay"),overlay=existingOverlay instanceof HTMLElement?existingOverlay:(()=>{const newOverlay=document.createElement("div");newOverlay.className="react-scan-flash-overlay",container.appendChild(newOverlay);const scrollCleanup=trackElementPosition(container,()=>{container.querySelector(".react-scan-flash-overlay")&&this.create(container)});return this.activeFlashes.set(container,{element:container,overlay:newOverlay,scrollCleanup}),newOverlay})(),existingTimer=fadeOutTimers.get(overlay);existingTimer&&(clearTimeout(existingTimer),fadeOutTimers.delete(overlay)),requestAnimationFrame(()=>{overlay.style.transition="none",overlay.style.opacity="0.9";const timerId=setTimeout(()=>{overlay.style.transition="opacity 150ms ease-out",overlay.style.opacity="0";const cleanupTimer=setTimeout(()=>{overlay.parentNode&&overlay.parentNode.removeChild(overlay);const entry=this.activeFlashes.get(container);entry!=null&&entry.scrollCleanup&&entry.scrollCleanup(),this.activeFlashes.delete(container),fadeOutTimers.delete(overlay)},150);fadeOutTimers.set(overlay,cleanupTimer)},300);fadeOutTimers.set(overlay,timerId)})},cleanup(container){const entry=this.activeFlashes.get(container);if(entry){const existingTimer=fadeOutTimers.get(entry.overlay);existingTimer&&(clearTimeout(existingTimer),fadeOutTimers.delete(entry.overlay)),entry.overlay.parentNode&&entry.overlay.parentNode.removeChild(entry.overlay),entry.scrollCleanup&&entry.scrollCleanup(),this.activeFlashes.delete(container)}},cleanupAll(){for(const[,entry]of this.activeFlashes)this.cleanup(entry.element)}},TIMELINE_MAX_UPDATES=1e3,timelineStateDefault={updates:[],currentFiber:null,totalUpdates:0,windowOffset:0,currentIndex:0,isViewingHistory:!1,latestFiber:null,isVisible:!1,playbackSpeed:1},timelineState=d$1(timelineStateDefault),inspectorUpdateSignal=d$1(0),pendingUpdates=[],batchTimeout=null,batchUpdates=__name(()=>{if(pendingUpdates.length===0)return;const batchedUpdates=[...pendingUpdates],{updates,totalUpdates,currentIndex,isViewingHistory}=timelineState.value,newUpdates=[...updates];let newTotalUpdates=totalUpdates;for(const{update}of batchedUpdates)newUpdates.length>=TIMELINE_MAX_UPDATES&&newUpdates.shift(),newUpdates.push(update),newTotalUpdates++;const newWindowOffset=Math.max(0,newTotalUpdates-TIMELINE_MAX_UPDATES);let newCurrentIndex;isViewingHistory?currentIndex===totalUpdates-1?newCurrentIndex=newUpdates.length-1:currentIndex===0?newCurrentIndex=0:newWindowOffset===0?newCurrentIndex=currentIndex:newCurrentIndex=currentIndex-1:newCurrentIndex=newUpdates.length-1;const lastUpdate=batchedUpdates[batchedUpdates.length-1];timelineState.value={...timelineState.value,latestFiber:lastUpdate.fiber,updates:newUpdates,totalUpdates:newTotalUpdates,windowOffset:newWindowOffset,currentIndex:newCurrentIndex,isViewingHistory},pendingUpdates=pendingUpdates.slice(batchedUpdates.length)},"batchUpdates"),timelineActions={showTimeline:__name(()=>{timelineState.value={...timelineState.value,isVisible:!0}},"showTimeline"),hideTimeline:__name(()=>{timelineState.value={...timelineState.value,isVisible:!1,currentIndex:timelineState.value.updates.length-1}},"hideTimeline"),updateFrame:__name((index,isViewingHistory)=>{timelineState.value={...timelineState.value,currentIndex:index,isViewingHistory}},"updateFrame"),updatePlaybackSpeed:__name(speed=>{timelineState.value={...timelineState.value,playbackSpeed:speed}},"updatePlaybackSpeed"),addUpdate:__name((update,latestFiber)=>{if(pendingUpdates.push({update,fiber:latestFiber}),!batchTimeout){const processBatch=__name(()=>{batchUpdates(),batchTimeout=null,pendingUpdates.length>0&&(batchTimeout=setTimeout(processBatch,96))},"processBatch");batchTimeout=setTimeout(processBatch,96)}},"addUpdate"),reset:__name(()=>{batchTimeout&&(clearTimeout(batchTimeout),batchTimeout=null),pendingUpdates=[],timelineState.value=timelineStateDefault},"reset")},searchState=d$1({query:"",matches:[],currentMatchIndex:-1}),signalSkipTreeUpdate=d$1(!1),flattenTree=__name((nodes,depth=0,parentPath=null)=>nodes.reduce((acc,node,index)=>{var _a2,_b2;const nodePath=node.element?getFiberPath(node.fiber):`${parentPath}-${index}`,renderData=(_a2=node.fiber)!=null&&_a2.type?renderDataMap.get(node.fiber.type):void 0,flatNode={...node,depth,nodeId:nodePath,parentId:parentPath,fiber:node.fiber,renderData};return acc.push(flatNode),(_b2=node.children)!=null&&_b2.length&&acc.push(...flattenTree(node.children,depth+1,nodePath)),acc},[]),"flattenTree"),getMaxDepth=__name(nodes=>nodes.reduce((max,node)=>Math.max(max,node.depth),0),"getMaxDepth"),calculateIndentSize=__name((containerWidth,maxDepth)=>{if(maxDepth<=0)return 24;const availableSpace=Math.max(0,containerWidth-MIN_CONTAINER_WIDTH);if(availableSpace<24)return 0;const baseIndent=Math.min(availableSpace*.3,maxDepth*24)/maxDepth;return Math.max(0,Math.min(24,baseIndent))},"calculateIndentSize"),VALID_TYPES=["memo","forwardRef","lazy","suspense"],parseTypeSearch=__name(query=>{const typeMatch=query.match(/\[(.*?)\]/);if(!typeMatch)return null;const typeSearches=[],parts=typeMatch[1].split(",");for(const part of parts){const trimmed=part.trim().toLowerCase();trimmed&&typeSearches.push(trimmed)}return typeSearches},"parseTypeSearch"),isValidTypeSearch=__name(typeSearches=>{if(typeSearches.length===0)return!1;for(const search of typeSearches){let isValid=!1;for(const validType of VALID_TYPES)if(validType.toLowerCase().includes(search)){isValid=!0;break}if(!isValid)return!1}return!0},"isValidTypeSearch"),matchesTypeSearch=__name((typeSearches,wrapperTypes)=>{if(typeSearches.length===0)return!0;if(!wrapperTypes.length)return!1;for(const search of typeSearches){let foundMatch=!1;for(const wrapper of wrapperTypes)if(wrapper.type.toLowerCase().includes(search)){foundMatch=!0;break}if(!foundMatch)return!1}return!0},"matchesTypeSearch"),useNodeHighlighting=__name((node,searchValue)=>T$1(()=>{const{query,matches}=searchValue,isMatch=matches.some(match=>match.nodeId===node.nodeId),typeSearches=parseTypeSearch(query)||[],searchQuery=query?query.replace(/\[.*?\]/,"").trim():"";if(!query||!isMatch)return{highlightedText:u("span",{className:"truncate",children:node.label}),typeHighlight:!1};let matchesType=!0;if(typeSearches.length>0)if(!node.fiber)matchesType=!1;else{const{wrapperTypes}=getExtendedDisplayName(node.fiber);matchesType=matchesTypeSearch(typeSearches,wrapperTypes)}let textContent=u("span",{className:"truncate",children:node.label});if(searchQuery)try{if(searchQuery.startsWith("/")&&searchQuery.endsWith("/")){const pattern=searchQuery.slice(1,-1),regex=new RegExp(`(${pattern})`,"i"),parts=node.label.split(regex);textContent=u("span",{className:"tree-node-search-highlight",children:parts.map((part,index)=>regex.test(part)?u("span",{className:cn("regex",{start:regex.test(part)&&index===0,middle:regex.test(part)&&index%2===1,end:regex.test(part)&&index===parts.length-1,"!ml-0":index===1}),children:part},`${node.nodeId}-${part}`):part)})}else{const lowerLabel=node.label.toLowerCase(),lowerQuery=searchQuery.toLowerCase(),index=lowerLabel.indexOf(lowerQuery);index>=0&&(textContent=u("span",{className:"tree-node-search-highlight",children:[node.label.slice(0,index),u("span",{className:"single",children:node.label.slice(index,index+searchQuery.length)}),node.label.slice(index+searchQuery.length)]}))}}catch{}return{highlightedText:textContent,typeHighlight:matchesType&&typeSearches.length>0}},[node.label,node.nodeId,node.fiber,searchValue]),"useNodeHighlighting"),formatTime=__name(time=>time>0?time<.1-Number.EPSILON?"< 0.1":time<1e3?Number(time.toFixed(1)).toString():`${(time/1e3).toFixed(1)}k`:"0","formatTime"),TreeNodeItem=__name(({node,nodeIndex,hasChildren,isCollapsed,handleTreeNodeClick,handleTreeNodeToggle,searchValue})=>{var _a2,_b2;const refRenderCount=A$1(null),refPrevRenderCount=A$1(((_a2=node.renderData)==null?void 0:_a2.renderCount)??0),{highlightedText,typeHighlight}=useNodeHighlighting(node,searchValue);y$1(()=>{var _a3;const currentRenderCount=(_a3=node.renderData)==null?void 0:_a3.renderCount,element=refRenderCount.current;!element||!refPrevRenderCount.current||!currentRenderCount||refPrevRenderCount.current===currentRenderCount||(element.classList.remove("count-flash"),element.offsetWidth,element.classList.add("count-flash"),refPrevRenderCount.current=currentRenderCount)},[(_b2=node.renderData)==null?void 0:_b2.renderCount]);const renderTimeInfo=T$1(()=>{if(!node.renderData)return null;const{selfTime,totalTime,renderCount}=node.renderData;return renderCount?u("span",{className:cn("flex items-center gap-x-0.5 ml-1.5","text-[10px] text-neutral-400"),children:u("span",{ref:refRenderCount,title:`Self time: ${formatTime(selfTime)}ms
Total time: ${formatTime(totalTime)}ms`,className:"count-badge",children:["×",renderCount]})}):null},[node.renderData]),componentTypes=T$1(()=>{if(!node.fiber)return null;const{wrapperTypes}=getExtendedDisplayName(node.fiber),firstWrapperType=wrapperTypes[0];return u("span",{className:cn("flex items-center gap-x-1","text-[10px] text-neutral-400 tracking-wide","overflow-hidden"),children:[firstWrapperType&&u(k$1,{children:[u("span",{title:firstWrapperType==null?void 0:firstWrapperType.title,className:cn("rounded py-[1px] px-1","bg-neutral-700 text-neutral-300","truncate",firstWrapperType.type==="memo"&&"bg-[#8e61e3] text-white",typeHighlight&&"bg-yellow-300 text-black"),children:firstWrapperType.type},firstWrapperType.type),firstWrapperType.compiler&&u("span",{className:"text-yellow-300 ml-1",children:"✨"})]}),wrapperTypes.length>1&&`×${wrapperTypes.length}`,renderTimeInfo]})},[node.fiber,typeHighlight,renderTimeInfo]);return u("button",{type:"button",title:node.title,"data-index":nodeIndex,className:cn("flex items-center gap-x-1","pl-1 pr-2","w-full h-7","text-left","rounded","cursor-pointer select-none"),onClick:handleTreeNodeClick,children:[u("button",{type:"button","data-index":nodeIndex,onClick:handleTreeNodeToggle,className:cn("w-6 h-6 flex items-center justify-center","text-left"),children:hasChildren&&u(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-transform",!isCollapsed&&"rotate-90")})}),highlightedText,componentTypes]})},"TreeNodeItem"),ComponentsTree=__name(()=>{const refContainer=A$1(null),refMainContainer=A$1(null),refSearchInputContainer=A$1(null),refSearchInput=A$1(null),refSelectedElement=A$1(null),refMaxTreeDepth=A$1(0),refIsHovering=A$1(!1),refIsResizing=A$1(!1),refResizeHandle=A$1(null),[flattenedNodes,setFlattenedNodes]=h$1([]),[collapsedNodes,setCollapsedNodes]=h$1(new Set),[selectedIndex,setSelectedIndex]=h$1(void 0),[searchValue,setSearchValue]=h$1(searchState.value),visibleNodes=T$1(()=>{const visible=[],nodes=flattenedNodes,nodeMap=new Map(nodes.map(node=>[node.nodeId,node]));for(const node of nodes){let isVisible=!0,currentNode=node;for(;currentNode.parentId;){const parent=nodeMap.get(currentNode.parentId);if(!parent)break;if(collapsedNodes.has(parent.nodeId)){isVisible=!1;break}currentNode=parent}isVisible&&visible.push(node)}return visible},[collapsedNodes,flattenedNodes]),ITEM_HEIGHT=28,{virtualItems,totalSize}=useVirtualList({count:visibleNodes.length,getScrollElement:__name(()=>refContainer.current,"getScrollElement"),estimateSize:__name(()=>ITEM_HEIGHT,"estimateSize"),overscan:5}),handleElementClick=q$1(element=>{var _a2;refIsHovering.current=!0,(_a2=refSearchInput.current)==null||_a2.blur(),signalSkipTreeUpdate.value=!0;const{parentCompositeFiber}=getCompositeComponentFromElement(element);if(!parentCompositeFiber)return;Store.inspectState.value={kind:"focused",focusedDomElement:element,fiber:parentCompositeFiber};const nodeIndex=visibleNodes.findIndex(node=>node.element===element);if(nodeIndex!==-1){setSelectedIndex(nodeIndex);const itemTop=nodeIndex*ITEM_HEIGHT,container=refContainer.current;if(container){const containerHeight=container.clientHeight,scrollTop=container.scrollTop;(itemTop<scrollTop||itemTop+ITEM_HEIGHT>scrollTop+containerHeight)&&container.scrollTo({top:Math.max(0,itemTop-containerHeight/2),behavior:"instant"})}}},[visibleNodes]),handleTreeNodeClick=q$1(e2=>{const target=e2.currentTarget,index=Number(target.dataset.index);if(Number.isNaN(index))return;const element=visibleNodes[index].element;element&&handleElementClick(element)},[visibleNodes,handleElementClick]),handleToggle=q$1(nodeId=>{setCollapsedNodes(prev=>{const next=new Set(prev);return next.has(nodeId)?next.delete(nodeId):next.add(nodeId),next})},[]),handleTreeNodeToggle=q$1(e2=>{e2.stopPropagation();const target=e2.target,index=Number(target.dataset.index);if(Number.isNaN(index))return;const nodeId=visibleNodes[index].nodeId;handleToggle(nodeId)},[visibleNodes,handleToggle]),handleOnChangeSearch=q$1(query=>{var _a2,_b2,_c2,_d2,_e2;(_a2=refSearchInputContainer.current)==null||_a2.classList.remove("!border-red-500");const matches=[];if(!query){searchState.value={query,matches,currentMatchIndex:-1};return}if(query.includes("[")&&!query.includes("]")&&query.length>query.indexOf("[")+1){(_b2=refSearchInputContainer.current)==null||_b2.classList.add("!border-red-500");return}const typeSearches=parseTypeSearch(query)||[];if(query.includes("[")&&!isValidTypeSearch(typeSearches)){(_c2=refSearchInputContainer.current)==null||_c2.classList.add("!border-red-500");return}const searchQuery=query.replace(/\[.*?\]/,"").trim(),isRegex=/^\/.*\/$/.test(searchQuery);let matchesLabel=__name(_label=>!1,"matchesLabel");if(searchQuery.startsWith("/")&&!isRegex&&searchQuery.length>1){(_d2=refSearchInputContainer.current)==null||_d2.classList.add("!border-red-500");return}if(isRegex)try{const pattern=searchQuery.slice(1,-1),regex=new RegExp(pattern,"i");matchesLabel=__name(label=>regex.test(label),"matchesLabel")}catch{(_e2=refSearchInputContainer.current)==null||_e2.classList.add("!border-red-500");return}else if(searchQuery){const lowerQuery=searchQuery.toLowerCase();matchesLabel=__name(label=>label.toLowerCase().includes(lowerQuery),"matchesLabel")}for(const node of flattenedNodes){let matchesSearch=!0;if(searchQuery&&(matchesSearch=matchesLabel(node.label)),matchesSearch&&typeSearches.length>0)if(!node.fiber)matchesSearch=!1;else{const{wrapperTypes}=getExtendedDisplayName(node.fiber);matchesSearch=matchesTypeSearch(typeSearches,wrapperTypes)}matchesSearch&&matches.push(node)}if(searchState.value={query,matches,currentMatchIndex:matches.length>0?0:-1},matches.length>0){const firstMatch=matches[0],nodeIndex=visibleNodes.findIndex(node=>node.nodeId===firstMatch.nodeId);if(nodeIndex!==-1){const itemTop=nodeIndex*ITEM_HEIGHT,container=refContainer.current;if(container){const containerHeight=container.clientHeight;container.scrollTo({top:Math.max(0,itemTop-containerHeight/2),behavior:"instant"})}}}},[flattenedNodes,visibleNodes]),handleInputChange=q$1(e2=>{const target=e2.currentTarget;target&&handleOnChangeSearch(target.value)},[handleOnChangeSearch]),navigateSearch=q$1(direction=>{const{matches,currentMatchIndex}=searchState.value;if(matches.length===0)return;const newIndex=direction==="next"?(currentMatchIndex+1)%matches.length:(currentMatchIndex-1+matches.length)%matches.length;searchState.value={...searchState.value,currentMatchIndex:newIndex};const currentMatch=matches[newIndex],nodeIndex=visibleNodes.findIndex(node=>node.nodeId===currentMatch.nodeId);if(nodeIndex!==-1){setSelectedIndex(nodeIndex);const itemTop=nodeIndex*ITEM_HEIGHT,container=refContainer.current;if(container){const containerHeight=container.clientHeight;container.scrollTo({top:Math.max(0,itemTop-containerHeight/2),behavior:"instant"})}}},[visibleNodes]),updateContainerWidths=q$1(width=>{if(refMainContainer.current&&(refMainContainer.current.style.width=`${width}px`),refContainer.current){refContainer.current.style.width=`${width}px`;const indentSize=calculateIndentSize(width,refMaxTreeDepth.current);refContainer.current.style.setProperty("--indentation-size",`${indentSize}px`)}},[]),updateResizeDirection=q$1(width=>{if(!refResizeHandle.current)return;const parentWidth=signalWidget.value.dimensions.width,maxWidth=Math.floor(parentWidth-MIN_SIZE.width/2);refResizeHandle.current.classList.remove("cursor-ew-resize","cursor-w-resize","cursor-e-resize"),width<=MIN_CONTAINER_WIDTH?refResizeHandle.current.classList.add("cursor-w-resize"):width>=maxWidth?refResizeHandle.current.classList.add("cursor-e-resize"):refResizeHandle.current.classList.add("cursor-ew-resize")},[]),handleResize=q$1(e2=>{if(e2.preventDefault(),e2.stopPropagation(),!refContainer.current)return;refContainer.current.style.setProperty("pointer-events","none"),refIsResizing.current=!0;const startX=e2.clientX,startWidth=refContainer.current.offsetWidth,parentWidth=signalWidget.value.dimensions.width,maxWidth=Math.floor(parentWidth-MIN_SIZE.width/2);updateResizeDirection(startWidth);const handlePointerMove=__name(e22=>{const delta=startX-e22.clientX,newWidth=startWidth+delta;updateResizeDirection(newWidth);const clampedWidth=Math.min(maxWidth,Math.max(MIN_CONTAINER_WIDTH,newWidth));updateContainerWidths(clampedWidth)},"handlePointerMove"),handlePointerUp=__name(()=>{refContainer.current&&(refContainer.current.style.removeProperty("pointer-events"),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerUp),signalWidget.value={...signalWidget.value,componentsTree:{...signalWidget.value.componentsTree,width:refContainer.current.offsetWidth}},saveLocalStorage$1(LOCALSTORAGE_KEY,signalWidget.value),refIsResizing.current=!1)},"handlePointerUp");document.addEventListener("pointermove",handlePointerMove),document.addEventListener("pointerup",handlePointerUp)},[updateContainerWidths,updateResizeDirection]);y$1(()=>{if(!refContainer.current)return;const currentWidth=refContainer.current.offsetWidth;return updateResizeDirection(currentWidth),signalWidget.subscribe(()=>{refContainer.current&&updateResizeDirection(refContainer.current.offsetWidth)})},[updateResizeDirection]);const onPointerLeave=q$1(()=>{refIsHovering.current=!1},[]);return y$1(()=>{let isInitialTreeBuild=!0;const buildTreeFromElements=__name(elements=>{const nodeMap=new Map,rootNodes=[];for(const{element,name,fiber}of elements){if(!element)continue;let title=name;const{name:componentName,wrappers}=getExtendedDisplayName(fiber);componentName&&(wrappers.length>0?title=`${wrappers.join("(")}(${componentName})${")".repeat(wrappers.length)}`:title=componentName),nodeMap.set(element,{label:componentName||name,title,children:[],element,fiber})}for(const{element,depth}of elements){if(!element)continue;const node=nodeMap.get(element);if(node)if(depth===0)rootNodes.push(node);else{let parent=element.parentElement;for(;parent;){const parentNode=nodeMap.get(parent);if(parentNode){parentNode.children=parentNode.children||[],parentNode.children.push(node);break}parent=parent.parentElement}}}return rootNodes},"buildTreeFromElements"),updateTree=__name(()=>{const element=refSelectedElement.current;if(!element)return;const inspectableElements=getInspectableElements(),tree=buildTreeFromElements(inspectableElements);if(tree.length>0){const flattened=flattenTree(tree),newMaxDepth=getMaxDepth(flattened);if(refMaxTreeDepth.current=newMaxDepth,updateContainerWidths(signalWidget.value.componentsTree.width),setFlattenedNodes(flattened),isInitialTreeBuild){isInitialTreeBuild=!1;const focusedIndex=flattened.findIndex(node=>node.element===element);if(focusedIndex!==-1){const itemTop=focusedIndex*ITEM_HEIGHT,container=refContainer.current;container&&setTimeout(()=>{container.scrollTo({top:itemTop,behavior:"instant"})},96)}}}},"updateTree"),unsubscribeStore=Store.inspectState.subscribe(state=>{if(state.kind==="focused"){if(signalSkipTreeUpdate.value)return;handleOnChangeSearch(""),refSelectedElement.current=state.focusedDomElement,updateTree()}});let rafId=0;const unsubscribeUpdates=inspectorUpdateSignal.subscribe(()=>{if(Store.inspectState.value.kind==="focused"){if(cancelAnimationFrame(rafId),refIsResizing.current)return;rafId=requestAnimationFrame(()=>{signalSkipTreeUpdate.value=!1,updateTree()})}});return()=>{unsubscribeStore(),unsubscribeUpdates(),searchState.value={query:"",matches:[],currentMatchIndex:-1}}},[]),y$1(()=>{const handleKeyDown=__name(e2=>{if(refIsHovering.current&&selectedIndex)switch(e2.key){case"ArrowUp":{if(e2.preventDefault(),e2.stopPropagation(),selectedIndex>0){const currentNode=visibleNodes[selectedIndex-1];currentNode!=null&&currentNode.element&&handleElementClick(currentNode.element)}return}case"ArrowDown":{if(e2.preventDefault(),e2.stopPropagation(),selectedIndex<visibleNodes.length-1){const currentNode=visibleNodes[selectedIndex+1];currentNode!=null&&currentNode.element&&handleElementClick(currentNode.element)}return}case"ArrowLeft":{e2.preventDefault(),e2.stopPropagation();const currentNode=visibleNodes[selectedIndex];currentNode!=null&&currentNode.nodeId&&handleToggle(currentNode.nodeId);return}case"ArrowRight":{e2.preventDefault(),e2.stopPropagation();const currentNode=visibleNodes[selectedIndex];currentNode!=null&&currentNode.nodeId&&handleToggle(currentNode.nodeId);return}}},"handleKeyDown");return document.addEventListener("keydown",handleKeyDown),()=>{document.removeEventListener("keydown",handleKeyDown)}},[selectedIndex,visibleNodes,handleElementClick,handleToggle]),y$1(()=>searchState.subscribe(setSearchValue),[]),y$1(()=>signalWidget.subscribe(state=>{var _a2;(_a2=refMainContainer.current)==null||_a2.style.setProperty("transition","width 0.1s"),updateContainerWidths(state.componentsTree.width),setTimeout(()=>{var _a3;(_a3=refMainContainer.current)==null||_a3.style.removeProperty("transition")},500)}),[]),u("div",{className:"react-scan-components-tree flex",children:[u("div",{ref:refResizeHandle,onPointerDown:handleResize,className:"relative resize-v-line",children:u("span",{children:u(Icon,{name:"icon-ellipsis",size:18})})}),u("div",{ref:refMainContainer,className:"flex flex-col h-full",children:[u("div",{className:"p-2 border-b border-[#1e1e1e]",children:u("div",{ref:refSearchInputContainer,title:`Search components by:

• Name (e.g., "Button") — Case insensitive, matches any part

• Regular Expression (e.g., "/^Button/") — Use forward slashes

• Wrapper Type (e.g., "[memo,forwardRef]"):
   - Available types: memo, forwardRef, lazy, suspense
   - Matches any part of type name (e.g., "mo" matches "memo")
   - Use commas for multiple types

• Combined Search:
   - Mix name/regex with type: "button [for]"
   - Will match components satisfying both conditions

• Navigation:
   - Enter → Next match
   - Shift + Enter → Previous match
   - Cmd/Ctrl + Enter → Select and focus match
`,className:cn("relative","flex items-center gap-x-1 px-2","rounded","border border-transparent","focus-within:border-[#454545]","bg-[#1e1e1e] text-neutral-300","transition-colors","whitespace-nowrap","overflow-hidden"),children:[u(Icon,{name:"icon-search",size:12,className:" text-neutral-500"}),u("div",{className:"relative flex-1 h-7 overflow-hidden",children:u("input",{ref:refSearchInput,type:"text",value:searchState.value.query,onClick:__name(e2=>{e2.stopPropagation(),e2.currentTarget.focus()},"onClick"),onPointerDown:__name(e2=>{e2.stopPropagation()},"onPointerDown"),onKeyDown:__name(e2=>{e2.key==="Escape"&&e2.currentTarget.blur(),searchState.value.matches.length&&(e2.key==="Enter"&&e2.shiftKey?navigateSearch("prev"):e2.key==="Enter"&&(e2.metaKey||e2.ctrlKey?(e2.preventDefault(),e2.stopPropagation(),handleElementClick(searchState.value.matches[searchState.value.currentMatchIndex].element),e2.currentTarget.focus()):navigateSearch("next")))},"onKeyDown"),onChange:handleInputChange,className:"absolute inset-y-0 inset-x-1",placeholder:"Component name, /regex/, or [type]"})}),searchState.value.query?u(k$1,{children:[u("span",{className:"flex items-center gap-x-0.5 text-xs text-neutral-500",children:[searchState.value.currentMatchIndex+1,"|",searchState.value.matches.length]}),!!searchState.value.matches.length&&u(k$1,{children:[u("button",{type:"button",onClick:__name(e2=>{e2.stopPropagation(),navigateSearch("prev")},"onClick"),className:"button rounded w-4 h-4 flex items-center justify-center text-neutral-400 hover:text-neutral-300",children:u(Icon,{name:"icon-chevron-right",className:"-rotate-90",size:12})}),u("button",{type:"button",onClick:__name(e2=>{e2.stopPropagation(),navigateSearch("next")},"onClick"),className:"button rounded w-4 h-4 flex items-center justify-center text-neutral-400 hover:text-neutral-300",children:u(Icon,{name:"icon-chevron-right",className:"rotate-90",size:12})})]}),u("button",{type:"button",onClick:__name(e2=>{e2.stopPropagation(),handleOnChangeSearch("")},"onClick"),className:"button rounded w-4 h-4 flex items-center justify-center text-neutral-400 hover:text-neutral-300",children:u(Icon,{name:"icon-close",size:12})})]}):!!flattenedNodes.length&&u("span",{className:"text-xs text-neutral-500",children:flattenedNodes.length})]})}),u("div",{className:"flex-1 overflow-hidden",children:u("div",{ref:refContainer,onPointerLeave,className:"tree h-full overflow-auto will-change-transform",children:u("div",{className:"relative w-full",style:{height:totalSize},children:virtualItems.map(virtualItem=>{var _a2;const node=visibleNodes[virtualItem.index];if(!node)return null;const isSelected=Store.inspectState.value.kind==="focused"&&node.element===Store.inspectState.value.focusedDomElement,isKeyboardSelected=virtualItem.index===selectedIndex;return u("div",{className:cn("absolute left-0 w-full overflow-hidden","text-neutral-400 hover:text-neutral-300","bg-transparent hover:bg-[#5f3f9a]/20",(isSelected||isKeyboardSelected)&&"text-neutral-300 bg-[#5f3f9a]/40 hover:bg-[#5f3f9a]/40"),style:{top:virtualItem.start,height:ITEM_HEIGHT},children:u("div",{className:"w-full h-full",style:{paddingLeft:`calc(${node.depth} * var(--indentation-size))`},children:u(TreeNodeItem,{node,nodeIndex:virtualItem.index,hasChildren:!!((_a2=node.children)!=null&&_a2.length),isCollapsed:collapsedNodes.has(node.nodeId),handleTreeNodeClick,handleTreeNodeToggle,searchValue})})},node.nodeId)})})})})]})]})},"ComponentsTree"),CopyToClipboard=N(({text,children,onCopy,className,iconSize=14})=>{const[isCopied,setIsCopied]=h$1(!1);y$1(()=>{if(isCopied){const timeout2=setTimeout(()=>setIsCopied(!1),600);return()=>{clearTimeout(timeout2)}}},[isCopied]);const copyToClipboard=q$1(e2=>{e2.preventDefault(),e2.stopPropagation(),navigator.clipboard.writeText(text).then(()=>{setIsCopied(!0),onCopy==null||onCopy(!0,text)},()=>{onCopy==null||onCopy(!1,text)})},[text,onCopy]),ClipboardIcon=u("button",{onClick:copyToClipboard,type:"button",className:cn("z-10","flex items-center justify-center","hover:text-dev-pink-400","transition-colors duration-200 ease-in-out","cursor-pointer",`size-[${iconSize}px]`,className),children:u(Icon,{name:`icon-${isCopied?"check":"copy"}`,size:[iconSize],className:cn(isCopied&&"text-green-500")})});return children?children({ClipboardIcon,onClick:copyToClipboard}):ClipboardIcon}),assignRef=__name((ref,value)=>{typeof ref=="function"?ref(value):ref!==null&&(ref.current=value)},"assignRef"),mergeRefs=__name((...refs)=>node=>{for(const ref of refs)ref&&assignRef(ref,node)},"mergeRefs"),useMergedRefs=__name((...refs)=>q$1(mergeRefs(...refs),[...refs]),"useMergedRefs"),EditableValue=__name(({value,onSave,onCancel})=>{const refInput=A$1(null),[editValue,setEditValue]=h$1("");y$1(()=>{let initialValue="";try{value instanceof Date?initialValue=value.toISOString().slice(0,16):value instanceof Map||value instanceof Set||value instanceof RegExp||value instanceof Error||value instanceof ArrayBuffer||ArrayBuffer.isView(value)||typeof value=="object"&&value!==null?initialValue=formatValue(value):initialValue=formatInitialValue(value)}catch{initialValue=String(value)}const sanitizedValue=sanitizeString(initialValue);setEditValue(sanitizedValue),requestAnimationFrame(()=>{refInput.current&&(refInput.current.focus(),typeof value=="string"?refInput.current.setSelectionRange(1,sanitizedValue.length-1):refInput.current.select())})},[value]);const handleChange=q$1(e2=>{const target=e2.target;target&&setEditValue(target.value)},[]),handleKeyDown=__name(e2=>{if(e2.key==="Enter"){e2.preventDefault();try{let newValue;if(value instanceof Date){const date=new Date(editValue);if(Number.isNaN(date.getTime()))throw new Error("Invalid date");newValue=date}else newValue=detectValueType(editValue).value;onSave(newValue)}catch{onCancel()}}else e2.key==="Escape"&&(e2.preventDefault(),e2.stopPropagation(),e2.stopImmediatePropagation(),onCancel())},"handleKeyDown");return u("input",{ref:refInput,type:value instanceof Date?"datetime-local":"text",className:"react-scan-input flex-1",value:editValue,onChange:handleChange,onKeyDown:handleKeyDown,onBlur:onCancel,step:value instanceof Date?1:void 0})},"EditableValue"),PropertyElement=__name(({name,value,section,level,parentPath,objectPathMap=new WeakMap,changedKeys=new Set,allowEditing=!0})=>{const{updates,currentIndex}=timelineState.value,currentUpdate=updates[currentIndex],fiberInfo=currentUpdate==null?void 0:currentUpdate.fiberInfo,refElement=A$1(null),currentPath=getPath(fiberInfo.displayName,section,parentPath??"",name),[isExpanded,setIsExpanded]=h$1(globalInspectorState.expandedPaths.has(currentPath)),[isEditing,setIsEditing]=h$1(!1),prevValue=globalInspectorState.lastRendered.get(currentPath),isChanged=!isEqual(prevValue,value);y$1(()=>{if(name==="children"||section==="context")return;const isFirstRender=!globalInspectorState.lastRendered.has(currentPath),shouldFlash=isChanged&&refElement.current&&!isFirstRender;globalInspectorState.lastRendered.set(currentPath,value),shouldFlash&&refElement.current&&level===0&&flashManager.create(refElement.current)},[value,isChanged,currentPath,level,name,section]);const handleToggleExpand=q$1(()=>{setIsExpanded(prevState=>{const newIsExpanded=!prevState;return newIsExpanded?globalInspectorState.expandedPaths.add(currentPath):globalInspectorState.expandedPaths.delete(currentPath),newIsExpanded})},[currentPath]),valuePreview=T$1(()=>typeof value=="object"&&value!==null&&"displayValue"in value?String(value.displayValue):formatValue(value),[value]),clipboardText=T$1(()=>{if(typeof value=="object"&&value!==null){if("value"in value)return String(formatForClipboard(value.value));if("displayValue"in value)return String(value.displayValue)}return String(formatForClipboard(value))},[value]),isExpandableValue=T$1(()=>{if(!value||typeof value!="object")return!1;if("type"in value){const metadata2=value;switch(metadata2.type){case"array":case"Map":case"Set":return(metadata2.size??metadata2.length??0)>0;case"object":return(metadata2.size??0)>0;case"ArrayBuffer":case"DataView":return(metadata2.byteLength??0)>0;case"circular":case"promise":case"function":case"error":return!1;default:return"entries"in metadata2||"items"in metadata2}}return isExpandable(value)},[value]),{overrideProps,overrideHookState}=getOverrideMethods(),canEdit=T$1(()=>allowEditing?section==="props"?!!overrideProps&&name!=="children":section==="state"?!!overrideHookState:!1:!1,[section,overrideProps,overrideHookState,allowEditing,name]),handleEdit=q$1(()=>{canEdit&&setIsEditing(!0)},[canEdit]),handleSave=__name((section2,name2,value2)=>{const{updates:updates2,currentIndex:currentIndex2,latestFiber}=timelineState.value,currentUpdate2=updates2[currentIndex2];if(!latestFiber)return;const{overrideProps:overrideProps2,overrideHookState:overrideHookState2}=getOverrideMethods();!overrideProps2||!overrideHookState2||(section2==="props"?tryOrElse(()=>{const currentProps=latestFiber.memoizedProps||{};let currentValue,path;parentPath?(path=parentPath.split(".").filter(part=>part!=="props"&&part!==getDisplayName(latestFiber.type)),path.push(name2),currentValue=path.reduce((obj,key)=>obj&&typeof obj=="object"?obj[key]:{},currentProps)):(path=[name2],currentValue=currentProps[name2]),isEqual(currentValue,value2)||(overrideProps2(latestFiber,path,value2),latestFiber.alternate&&overrideProps2(latestFiber.alternate,path,value2))},null):section2==="state"&&tryOrElse(()=>{var _a2;if(parentPath){const fullPathParts=parentPath.split("."),stateIndex=fullPathParts.indexOf("state");if(stateIndex===-1)return;const statePath=fullPathParts.slice(stateIndex+1),baseStateKey=statePath[0],namedStateIndex=currentUpdate2.stateNames.indexOf(baseStateKey),hookId=namedStateIndex!==-1?namedStateIndex.toString():"0",currentState=currentUpdate2.state.current;if(!currentState||!currentState.find(item=>item.name===Number(baseStateKey)))return;const updatedState=updateNestedValue((_a2=currentState.find(item=>item.name===Number(baseStateKey)))==null?void 0:_a2.value,statePath.slice(1).concat(name2),value2);overrideHookState2(latestFiber,hookId,[],updatedState)}else{const namedStateIndex=currentUpdate2.stateNames.indexOf(name2),hookId=namedStateIndex!==-1?namedStateIndex.toString():name2;overrideHookState2(latestFiber,hookId,[],value2)}},null),setIsEditing(!1))},"handleSave"),checkCircularInValue=T$1(()=>!value||typeof value!="object"||isPromise(value)?!1:"type"in value&&value.type==="circular",[value]),renderNestedProperties=q$1(obj=>{if(!obj||typeof obj!="object")return null;if("type"in obj){const metadata2=obj;if("entries"in metadata2&&metadata2.entries){const entries2=Object.entries(metadata2.entries);return entries2.length===0?null:u("div",{className:"react-scan-nested",children:entries2.map(([key,val])=>u(PropertyElement,{name:key,value:val,section,level:level+1,parentPath:currentPath,objectPathMap,changedKeys,allowEditing},`${currentPath}-entry-${key}`))})}return"items"in metadata2&&Array.isArray(metadata2.items)?metadata2.items.length===0?null:u("div",{className:"react-scan-nested",children:metadata2.items.map((item,i2)=>{const itemKey=`${currentPath}-item-${item.type}-${i2}`;return u(PropertyElement,{name:`${i2}`,value:item,section,level:level+1,parentPath:currentPath,objectPathMap,changedKeys,allowEditing},itemKey)})}):null}let entries;if(obj instanceof ArrayBuffer){const view=new Uint8Array(obj);entries=Array.from(view).map((v2,i2)=>[i2,v2])}else if(obj instanceof DataView){const view=new Uint8Array(obj.buffer,obj.byteOffset,obj.byteLength);entries=Array.from(view).map((v2,i2)=>[i2,v2])}else if(ArrayBuffer.isView(obj))if(obj instanceof BigInt64Array||obj instanceof BigUint64Array)entries=Array.from({length:obj.length},(_3,i2)=>[i2,obj[i2]]);else{const typedArray=obj;entries=Array.from(typedArray).map((v2,i2)=>[i2,v2])}else obj instanceof Map?entries=Array.from(obj.entries()).map(([k2,v2])=>[String(k2),v2]):obj instanceof Set?entries=Array.from(obj).map((v2,i2)=>[i2,v2]):Array.isArray(obj)?entries=obj.map((value2,index)=>[`${index}`,value2]):entries=Object.entries(obj);if(entries.length===0)return null;const canEditChildren=!(obj instanceof DataView||obj instanceof ArrayBuffer||ArrayBuffer.isView(obj));return u("div",{className:"react-scan-nested",children:entries.map(([key,val])=>{const itemKey=`${currentPath}-${typeof key=="number"?`item-${key}`:key}`;return u(PropertyElement,{name:String(key),value:val,section,level:level+1,parentPath:currentPath,objectPathMap,changedKeys,allowEditing:canEditChildren},itemKey)})})},[section,level,currentPath,objectPathMap,changedKeys,allowEditing]);return checkCircularInValue?u("div",{className:"react-scan-property",children:u("div",{className:"react-scan-property-content",children:u("div",{className:"react-scan-preview-line",children:[u("div",{className:"react-scan-key",children:[name,":"]}),u("span",{className:"text-yellow-500",children:"[Circular Reference]"})]})})}):u("div",{ref:refElement,className:"react-scan-property",children:u("div",{className:"react-scan-property-content",children:[isExpandableValue&&u("button",{type:"button",onClick:handleToggleExpand,className:"react-scan-arrow",children:u(Icon,{name:"icon-chevron-right",size:12,className:cn(isExpanded&&"rotate-90")})}),u("div",{className:cn("group","react-scan-preview-line",isChanged&&"react-scan-highlight"),children:[u("div",{className:"react-scan-key",children:[name,":"]}),isEditing&&isEditableValue(value,parentPath)?u(EditableValue,{value,onSave:__name(newValue=>handleSave(section,name,newValue),"onSave"),onCancel:__name(()=>setIsEditing(!1),"onCancel")}):u("button",{type:"button",className:"truncate",onClick:handleEdit,children:valuePreview}),u(CopyToClipboard,{text:clipboardText,className:"opacity-0 transition-opacity group-hover:opacity-100",children:__name(({ClipboardIcon})=>u(k$1,{children:ClipboardIcon}),"children")})]}),u("div",{className:cn("react-scan-expandable",isExpanded&&"react-scan-expanded"),children:isExpandableValue&&isExpanded&&u("div",{className:"react-scan-nested",children:renderNestedProperties(value)})})]})})},"PropertyElement"),PropertySection=__name(({refSticky,isSticky,section})=>{const refStickyElement=A$1(null),{updates,currentIndex}=timelineState.value,[isExpanded,setIsExpanded]=h$1(!0),refs=useMergedRefs(refStickyElement,refSticky),pathMap=T$1(()=>new WeakMap,[]),{currentData,changedKeys}=T$1(()=>{const data=updates[currentIndex]??{props:{current:{},changes:new Set},state:{current:{},changes:new Set},context:{current:{},changes:new Set}};switch(section){case"props":return{currentData:data.props.current,changedKeys:data.props.changes};case"state":return{currentData:data.state.current,changedKeys:data.state.changes};case"context":return{currentData:data.context.current,changedKeys:data.context.changes};default:return{currentData:{},changedKeys:new Set}}},[section,currentIndex,updates]),toggleExpanded=q$1(()=>{setIsExpanded(state=>isSticky&&isExpanded?state:!state)},[isExpanded,isSticky]);if(!currentData||(Array.isArray(currentData)?currentData.length===0:Object.keys(currentData).length===0))return null;const propertyCount=Array.isArray(currentData)?currentData.length:Object.keys(currentData).length;return u(k$1,{children:[u("button",{ref:refs,type:"button",onClick:toggleExpanded,"data-sticky":!0,className:"react-section-header",children:[u("div",{className:"w-4 h-4 flex items-center justify-center",children:u(Icon,{name:"icon-chevron-right",size:12,className:cn(isExpanded&&"rotate-90",isSticky&&isExpanded&&"rotate-0")})}),u("span",{className:"capitalize",children:[section," ",!isExpanded&&propertyCount>0&&`(${propertyCount})`]})]}),u("div",{className:"react-scan-section",children:u("div",{className:cn("react-scan-expandable",isExpanded&&"react-scan-expanded"),children:u("div",{className:"overflow-hidden",children:Array.isArray(currentData)?currentData.map(({name,value})=>u(PropertyElement,{name,value,section,level:0,objectPathMap:pathMap,changedKeys},name)):Object.entries(currentData).map(([key,value])=>u(PropertyElement,{name:key,value,section,level:0,objectPathMap:pathMap,changedKeys},key))})})})]})},"PropertySection"),ArrayHeader=__name(({length,expanded,onToggle,isNegative})=>u("div",{className:"flex items-center gap-1",children:[u("button",{type:"button",onClick:onToggle,className:"flex items-center p-0 opacity-50",children:u(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-[color,transform]",isNegative?"text-[#f87171]":"text-[#4ade80]",expanded&&"rotate-90")})}),u("span",{children:["Array(",length,")"]})]}),"ArrayHeader"),TreeNode=__name(({value,path,isNegative})=>{const[isExpanded,setIsExpanded]=h$1(!1);if(!(value!==null&&typeof value=="object"&&!(value instanceof Date)))return u("div",{className:"flex items-center gap-1",children:[u("span",{className:"text-gray-500",children:[path,":"]}),u("span",{className:"truncate",children:formatValuePreview(value)})]});const entries=Object.entries(value);return u("div",{className:"flex flex-col",children:[u("div",{className:"flex items-center gap-1",children:[u("button",{type:"button",onClick:__name(()=>setIsExpanded(!isExpanded),"onClick"),className:"flex items-center p-0 opacity-50",children:u(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-[color,transform]",isNegative?"text-[#f87171]":"text-[#4ade80]",isExpanded&&"rotate-90")})}),u("span",{className:"text-gray-500",children:[path,":"]}),!isExpanded&&u("span",{className:"truncate",children:value instanceof Date?formatValuePreview(value):`{${Object.keys(value).join(", ")}}`})]}),isExpanded&&u("div",{className:"pl-5 border-l border-[#333] mt-0.5 ml-1 flex flex-col gap-0.5",children:entries.map(([key,val])=>u(TreeNode,{value:val,path:key,isNegative},key))})]})},"TreeNode"),DiffValueView=__name(({value,expanded,onToggle,isNegative})=>{const{value:safeValue,error}=safeGetValue(value);return error?u("span",{className:"text-gray-500 font-italic",children:error}):safeValue!==null&&typeof safeValue=="object"&&!(safeValue instanceof Promise)?Array.isArray(safeValue)?u("div",{className:"flex flex-col gap-1 relative",children:[u(ArrayHeader,{length:safeValue.length,expanded,onToggle,isNegative}),expanded&&u("div",{className:"pl-2 border-l border-[#333] mt-0.5 ml-1 flex flex-col gap-0.5",children:safeValue.map((item,index)=>u(TreeNode,{value:item,path:index.toString(),isNegative},index.toString()))}),u(CopyToClipboard,{text:formatForClipboard(safeValue),className:"absolute top-0.5 right-0.5 opacity-0 transition-opacity group-hover:opacity-100 self-end",children:__name(({ClipboardIcon})=>u(k$1,{children:ClipboardIcon}),"children")})]}):u("div",{className:"flex items-start gap-1 relative",children:[u("button",{type:"button",onClick:onToggle,className:cn("flex items-center","p-0 mt-0.5 mr-1","opacity-50"),children:u(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-[color,transform]",isNegative?"text-[#f87171]":"text-[#4ade80]",expanded&&"rotate-90")})}),u("div",{className:"flex-1",children:expanded?u("div",{className:"pl-2 border-l border-[#333] mt-0.5 ml-1 flex flex-col gap-0.5",children:Object.entries(safeValue).map(([key,val])=>u(TreeNode,{value:val,path:key,isNegative},key))}):u("span",{children:formatValuePreview(safeValue)})}),u(CopyToClipboard,{text:formatForClipboard(safeValue),className:"absolute top-0.5 right-0.5 opacity-0 transition-opacity group-hover:opacity-100 self-end",children:__name(({ClipboardIcon})=>u(k$1,{children:ClipboardIcon}),"children")})]}):u("span",{children:formatValuePreview(safeValue)})},"DiffValueView"),Slider=__name(({value,min,max,onChange,className,totalUpdates=max+1})=>{const refThumb=A$1(null),refLastValue=A$1(value),updateThumbPosition=q$1(value2=>{if(!refThumb.current)return;const range=Math.max(1,max-min),valueOffset=value2-min,percentage=min===max?0:Math.min(100,Math.round(valueOffset/range*100));refThumb.current.style.setProperty("left",`${percentage}%`)},[min,max]);y$1(()=>{updateThumbPosition(value)},[min,max,value]);const handleChange=q$1(e2=>{const target=e2.target,newValue=Number.parseInt(target.value,10);newValue>=totalUpdates||refLastValue.current!==newValue&&(refLastValue.current=newValue,updateThumbPosition(newValue),onChange(e2))},[onChange,updateThumbPosition,totalUpdates]);return u("div",{onPointerDown:__name(e2=>{e2.stopPropagation()},"onPointerDown"),className:cn("react-scan-slider relative","flex-1",className),children:[u("input",{type:"range",value,min,max,onChange:handleChange,className:cn("react-scan-slider","flex-1","h-1.5","bg-gray-200","rounded-lg","appearance-none","cursor-pointer",className)}),u("div",{className:cn("absolute inset-0 right-2","pointer-events-none"),children:u("span",{ref:refThumb})})]})},"Slider"),Timeline=N(({refSticky})=>{const refPlayInterval=A$1(null),{currentIndex,isVisible,totalUpdates,updates}=timelineState.value,sliderValues=T$1(()=>calculateSliderValues(totalUpdates,currentIndex),[totalUpdates,currentIndex]),handleSliderChange=__name(async e2=>{const target=e2.target,value=Number.parseInt(target.value,10),newIndex=Math.min(updates.length-1,Math.max(0,value));let isViewingHistory=!1;newIndex>0&&newIndex<updates.length-1&&(isViewingHistory=!0),timelineActions.updateFrame(newIndex,isViewingHistory)},"handleSliderChange");y$1(()=>()=>{refPlayInterval.current&&clearInterval(refPlayInterval.current)},[]);const handleShowTimeline=q$1(()=>{isVisible||timelineActions.showTimeline()},[isVisible]),handleHideTimeline=q$1(e2=>{e2.preventDefault(),e2.stopPropagation(),refPlayInterval.current&&(clearInterval(refPlayInterval.current),refPlayInterval.current=null),timelineActions.hideTimeline()},[]);return!isInstrumentationActive()||totalUpdates<=1?null:u("button",{ref:refSticky,type:"button",onClick:handleShowTimeline,className:"react-section-header","data-disable-scroll":"true",children:[u("button",{type:"button",onClick:isVisible?handleHideTimeline:void 0,title:isVisible?"Hide Re-renders History":"View Re-renders History",className:"w-4 h-4 flex items-center justify-center",children:u(Icon,{name:"icon-gallery-horizontal-end",size:12})}),isVisible?u(k$1,{children:[u("div",{className:"text-xs text-gray-500",children:sliderValues.leftValue}),u(Slider,{min:sliderValues.min,max:sliderValues.max,value:sliderValues.value,onChange:handleSliderChange,className:"flex-1",totalUpdates:sliderValues.rightValue+1}),u("div",{className:"text-xs text-gray-500",children:sliderValues.rightValue})]}):"View Re-renders History"]})}),safeGetValue2=__name(value=>{var _a2;if(value==null)return{value};if(typeof value=="function")return{value};if(typeof value!="object")return{value};if(isPromise(value))return{value:"Promise"};try{const proto=Object.getPrototypeOf(value);return proto===Promise.prototype||((_a2=proto==null?void 0:proto.constructor)==null?void 0:_a2.name)==="Promise"?{value:"Promise"}:{value}}catch{return{value:null,error:"Error accessing value"}}},"safeGetValue2"),WhatChangedSection=N(()=>{const showTimeline=useSignal(!1),shouldShowChanges=useSignal(!0);return useSignalEffect(()=>{const state=timelineState.value,{currentIndex,updates}=state;if(currentIndex===0){shouldShowChanges.value=!1;return}updates.length>0&&(n(()=>{showTimeline.value||(showTimeline.value=!0)}),shouldShowChanges.value=!0)}),useComputed(()=>u(k$1,{children:[showTimeline.value&&u(StickySection,{children:__name(props=>u(Timeline,{...props}),"children")}),u(StickySection,{children:__name(props=>u(WhatChanged,{...props,shouldShowChanges:shouldShowChanges.value}),"children")})]}))}),WhatChanged=N(({isSticky,refSticky,calculateStickyTop,shouldShowChanges})=>{const[isExpanded,setIsExpanded]=h$1(!0);return u(k$1,{children:[u(WhatsChangedHeader,{refSticky,isSticky,calculateStickyTop,isExpanded,shouldShowChanges,setIsExpanded}),u("div",{className:cn("react-scan-expandable",isExpanded&&"react-scan-expanded"),children:u("div",{className:"overflow-hidden",children:shouldShowChanges&&u("div",{className:cn("relative","flex flex-col gap-y-2","pl-9 pr-2",'before:content-[""] before:absolute before:inset-x-0 before:bottom-0 before:h-[1px] before:bg-[#333]'),children:[u(Section,{title:"Props",isExpanded}),u(Section,{title:"State",isExpanded}),u(Section,{title:"Context",isExpanded})]})})})]})}),renderStateName=__name((key,componentName)=>{if(Number.isNaN(Number(key)))return key;const n2=Number.parseInt(key);return u("span",{className:"truncate",children:[u("span",{className:"text-white",children:[n2,__name(num=>{const lastDigit=num%10,lastTwoDigits=num%100;if(lastTwoDigits>=11&&lastTwoDigits<=13)return"th";switch(lastDigit){case 1:return"st";case 2:return"nd";case 3:return"rd";default:return"th"}},"getOrdinalSuffix")(n2)," hook"," "]}),u("span",{style:{color:"#666"},children:["called in ",u("i",{className:"text-[#A855F7] truncate",children:componentName})]})]})},"renderStateName"),WhatsChangedHeader=N(({refSticky,isSticky,calculateStickyTop,isExpanded,shouldShowChanges,setIsExpanded})=>{const refProps=A$1(null),refState=A$1(null),refContext=A$1(null),refStats=A$1({isPropsChanged:!1,isStateChanged:!1,isContextChanged:!1});y$1(()=>{const flash=throttle(()=>{var _a2,_b2,_c2;const flashElements=[];((_a2=refProps.current)==null?void 0:_a2.dataset.flash)==="true"&&flashElements.push(refProps.current),((_b2=refState.current)==null?void 0:_b2.dataset.flash)==="true"&&flashElements.push(refState.current),((_c2=refContext.current)==null?void 0:_c2.dataset.flash)==="true"&&flashElements.push(refContext.current);for(const element of flashElements)element.classList.remove("count-flash-white"),element.offsetWidth,element.classList.add("count-flash-white")},400);return timelineState.subscribe(state=>{var _a2,_b2,_c2,_d2,_e2,_f2;if(!refProps.current||!refState.current||!refContext.current)return;const{currentIndex,updates}=state,currentUpdate=updates[currentIndex];!currentUpdate||currentIndex===0||(flash(),refStats.current={isPropsChanged:(((_b2=(_a2=currentUpdate.props)==null?void 0:_a2.changes)==null?void 0:_b2.size)??0)>0,isStateChanged:(((_d2=(_c2=currentUpdate.state)==null?void 0:_c2.changes)==null?void 0:_d2.size)??0)>0,isContextChanged:(((_f2=(_e2=currentUpdate.context)==null?void 0:_e2.changes)==null?void 0:_f2.size)??0)>0},refProps.current.dataset.flash!=="true"&&(refProps.current.dataset.flash=refStats.current.isPropsChanged.toString()),refState.current.dataset.flash!=="true"&&(refState.current.dataset.flash=refStats.current.isStateChanged.toString()),refContext.current.dataset.flash!=="true"&&(refContext.current.dataset.flash=refStats.current.isContextChanged.toString()))})},[]);const toggleExpanded=q$1(()=>{setIsExpanded(state=>isSticky&&isExpanded?state:!state)},[setIsExpanded,isExpanded,isSticky]),onTransitionStart=q$1(e2=>{e2.propertyName==="max-height"&&calculateStickyTop(!0)},[calculateStickyTop]),onTransitionEnd=q$1(e2=>{e2.propertyName==="max-height"&&calculateStickyTop(!1)},[calculateStickyTop]);return u("button",{ref:refSticky,type:"button",onClick:toggleExpanded,onTransitionStart,onTransitionEnd,className:cn("react-section-header","overflow-hidden","max-h-0","transition-[max-height]",shouldShowChanges&&"max-h-8"),children:u("div",{className:cn("flex-1 react-scan-expandable",shouldShowChanges&&"react-scan-expanded"),children:u("div",{className:"overflow-hidden",children:u("div",{className:"flex items-center whitespace-nowrap",children:[u("div",{className:"flex items-center gap-x-2",children:[u("div",{className:"w-4 h-4 flex items-center justify-center",children:u(Icon,{name:"icon-chevron-right",size:12,className:cn(isExpanded&&"rotate-90",isSticky&&isExpanded&&"rotate-0")})}),"What changed?"]}),u("div",{className:cn("ml-auto","change-scope","opacity-0","transition-opacity duration-300 delay-150",isExpanded?"opacity-0":"opacity-100"),children:[u("div",{ref:refProps,children:"props"}),u("div",{ref:refState,children:"state"}),u("div",{ref:refContext,children:"context"})]})]})})})})}),Section=N(({title,isExpanded})=>{const refFiberInfo=A$1(null),refLastUpdated=A$1(new Set),refChangesValues=A$1(new Map),refLatestChanges=A$1([]),[changes,setChanges]=h$1([]),[expandedFns,setExpandedFns]=h$1(new Set),[expandedEntries,setExpandedEntries]=h$1(new Set);y$1(()=>timelineState.subscribe(state=>{var _a2,_b2,_c2;const{currentIndex,updates}=state,currentUpdate=currentIndex>=0?updates[currentIndex]:null,prevUpdate=currentIndex>0?updates[currentIndex-1]:null,currentData=currentUpdate==null?void 0:currentUpdate[title.toLowerCase()],prevData=prevUpdate==null?void 0:prevUpdate[title.toLowerCase()];if(!currentData)return;refFiberInfo.current=currentUpdate==null?void 0:currentUpdate.fiberInfo,refLastUpdated.current.clear();const changesMap=new Map(refLatestChanges.current.map(c2=>[c2.name,c2]));for(const{name,value}of currentData.current){const currentCount=((_a2=currentData.changesCounts)==null?void 0:_a2.get(name))??0,prevCount=((_b2=prevData==null?void 0:prevData.changesCounts)==null?void 0:_b2.get(name))??0,count=Math.max(currentCount,prevCount),prevValue=(_c2=prevData==null?void 0:prevData.current.find(p2=>p2.name===name))==null?void 0:_c2.value,hasValueChange=!isEqual(value,prevValue);if(count>0||hasValueChange){const{value:safePrevValue,error:prevError}=safeGetValue2(prevValue),{value:safeCurrValue,error:currError}=safeGetValue2(value),diff=getObjectDiff(safePrevValue,safeCurrValue);refChangesValues.current.set(name,{name,prevValue,currValue:value,prevError,currError,diff,isFunction:typeof value=="function"});const change={name,value,prevValue,count},existingChange=changesMap.get(name);(!existingChange||existingChange.count!==count||!isEqual(existingChange.value,value))&&refLastUpdated.current.add(name),changesMap.set(name,change)}}refLatestChanges.current=Array.from(changesMap.values()),setChanges(refLatestChanges.current)}),[title]);const handleExpandEntry=q$1(entryKey=>{setExpandedEntries(prev=>{const next=new Set(prev);return next.has(String(entryKey))?next.delete(String(entryKey)):next.add(String(entryKey)),next})},[]),memoizedRenderStateName=q$1(name=>refFiberInfo.current?renderStateName(name,refFiberInfo.current.displayName):name,[]);return changes.length===0?null:u("div",{className:"pb-2",children:[u("div",{className:"text-xs text-[#888] mb-1.5",children:title}),u("div",{className:"flex flex-col gap-2",children:changes.map(change=>{const isEntryExpanded=expandedEntries.has(String(change.name)),values=refChangesValues.current.get(change.name);return values?u("div",{children:[u("button",{type:"button",onClick:__name(()=>handleExpandEntry(String(change.name)),"onClick"),className:cn("relative","flex items-center gap-2","w-full p-0 cursor-pointer text-white text-xs"),children:u("div",{className:"flex items-center gap-1.5 flex-1 truncate",children:[u(Icon,{name:"icon-chevron-right",size:12,className:cn("text-[#666] transition-transform duration-200 ease-[cubic-bezier(0.25,0.1,0.25,1)]",isEntryExpanded&&"rotate-90")}),u("div",{className:"overflow-hidden whitespace-nowrap break-words text-left font-medium flex items-center gap-x-1.5",children:[memoizedRenderStateName(String(change.name)),u(CountBadge,{forceFlash:isExpanded&&refLastUpdated.current.has(change.name),count:change.count,isFunction:values.isFunction,showWarning:values.diff.changes.length===0})]})]})}),u("div",{className:cn("react-scan-expandable",isEntryExpanded&&"react-scan-expanded"),children:u("div",{className:"overflow-hidden",children:u("div",{className:"mt-1 pl-3 text-xs font-mono border-l-1 border-[#333]",children:u("div",{className:"flex flex-col gap-0.5",children:values.prevError||values.currError?u(AccessError,{currError:values.currError,prevError:values.prevError}):values.diff.changes.length>0?u(DiffChange,{title,change,diff:values.diff,expandedFns,renderName:memoizedRenderStateName,setExpandedFns}):u(ReferenceOnlyChange,{currValue:values.currValue,entryKey:change.name,expandedFns,prevValue:values.prevValue,setExpandedFns})})})})})]},change.name):null})})]})}),AccessError=__name(({prevError,currError})=>u(k$1,{children:[prevError&&u("div",{className:"text-[#f87171] bg-[#2a1515] pr-1.5 py-[3px] rounded italic",children:prevError}),currError&&u("div",{className:"text-[#4ade80] bg-[#1a2a1a] pr-1.5 py-[3px] rounded italic mt-0.5",children:currError})]}),"AccessError"),DiffChange=__name(({diff,title,renderName,change,expandedFns,setExpandedFns})=>diff.changes.map((diffChange,i2)=>{const{value:prevDiffValue,error:prevDiffError}=safeGetValue2(diffChange.prevValue),{value:currDiffValue,error:currDiffError}=safeGetValue2(diffChange.currentValue),isFunction=typeof prevDiffValue=="function"||typeof currDiffValue=="function";let path;return title==="Props"&&(path=diffChange.path.length>0?`${renderName(String(change.name))}.${formatPath(diffChange.path)}`:void 0),title==="State"&&diffChange.path.length>0&&(path=`state.${formatPath(diffChange.path)}`),path||(path=formatPath(diffChange.path)),u("div",{className:cn("flex flex-col gap-y-1",i2<diff.changes.length-1&&"mb-4"),children:[path&&u("div",{className:"text-[#666] text-[10px]",children:path}),u("button",{type:"button",className:cn("group","flex items-start","py-[3px] px-1.5","text-left text-[#f87171] bg-[#2a1515]","rounded","overflow-hidden break-all",isFunction&&"cursor-pointer"),onClick:isFunction?()=>{const fnKey=`${formatPath(diffChange.path)}-prev`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(fnKey)?next.delete(fnKey):next.add(fnKey),next})}:void 0,children:[u("span",{className:"w-3 flex items-center justify-center opacity-50",children:"-"}),u("span",{className:"flex-1 whitespace-nowrap font-mono",children:prevDiffError?u("span",{className:"italic text-[#f87171]",children:prevDiffError}):isFunction?u("div",{className:"flex gap-1 items-start flex-col",children:[u("div",{className:"flex gap-1 items-start w-full",children:[u("span",{className:"flex-1 max-h-40",children:formatFunctionPreview(prevDiffValue,expandedFns.has(`${formatPath(diffChange.path)}-prev`))}),typeof prevDiffValue=="function"&&u(CopyToClipboard,{text:prevDiffValue.toString(),className:"opacity-0 transition-opacity group-hover:opacity-100",children:__name(({ClipboardIcon})=>u(k$1,{children:ClipboardIcon}),"children")})]}),(prevDiffValue==null?void 0:prevDiffValue.toString())===(currDiffValue==null?void 0:currDiffValue.toString())&&u("div",{className:"text-[10px] text-[#666] italic",children:"Function reference changed"})]}):u(DiffValueView,{value:prevDiffValue,expanded:expandedFns.has(`${formatPath(diffChange.path)}-prev`),onToggle:__name(()=>{const key=`${formatPath(diffChange.path)}-prev`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!0})})]}),u("button",{type:"button",className:cn("group","flex items-start","py-[3px] px-1.5","text-left text-[#4ade80] bg-[#1a2a1a]","rounded","overflow-hidden break-all",isFunction&&"cursor-pointer"),onClick:isFunction?()=>{const fnKey=`${formatPath(diffChange.path)}-current`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(fnKey)?next.delete(fnKey):next.add(fnKey),next})}:void 0,children:[u("span",{className:"w-3 flex items-center justify-center opacity-50",children:"+"}),u("span",{className:"flex-1 whitespace-pre-wrap font-mono",children:currDiffError?u("span",{className:"italic text-[#4ade80]",children:currDiffError}):isFunction?u("div",{className:"flex gap-1 items-start flex-col",children:[u("div",{className:"flex gap-1 items-start w-full",children:[u("span",{className:"flex-1",children:formatFunctionPreview(currDiffValue,expandedFns.has(`${formatPath(diffChange.path)}-current`))}),typeof currDiffValue=="function"&&u(CopyToClipboard,{text:currDiffValue.toString(),className:"opacity-0 transition-opacity group-hover:opacity-100",children:__name(({ClipboardIcon})=>u(k$1,{children:ClipboardIcon}),"children")})]}),(prevDiffValue==null?void 0:prevDiffValue.toString())===(currDiffValue==null?void 0:currDiffValue.toString())&&u("div",{className:"text-[10px] text-[#666] italic",children:"Function reference changed"})]}):u(DiffValueView,{value:currDiffValue,expanded:expandedFns.has(`${formatPath(diffChange.path)}-current`),onToggle:__name(()=>{const key=`${formatPath(diffChange.path)}-current`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!1})})]})]},`${path}-${change.name}-${i2}`)}),"DiffChange"),ReferenceOnlyChange=__name(({prevValue,currValue,entryKey,expandedFns,setExpandedFns})=>u(k$1,{children:[u("div",{className:"group flex gap-0.5 items-start text-[#f87171] bg-[#2a1515] py-[3px] px-1.5 rounded",children:[u("span",{className:"w-3 flex items-center justify-center opacity-50",children:"-"}),u("span",{className:"flex-1 overflow-hidden whitespace-pre-wrap font-mono",children:u(DiffValueView,{value:prevValue,expanded:expandedFns.has(`${String(entryKey)}-prev`),onToggle:__name(()=>{const key=`${String(entryKey)}-prev`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!0})})]}),u("div",{className:"group flex gap-0.5 items-start text-[#4ade80] bg-[#1a2a1a] py-[3px] px-1.5 rounded mt-0.5",children:[u("span",{className:"w-3 flex items-center justify-center opacity-50",children:"+"}),u("span",{className:"flex-1 overflow-hidden whitespace-pre-wrap font-mono",children:u(DiffValueView,{value:currValue,expanded:expandedFns.has(`${String(entryKey)}-current`),onToggle:__name(()=>{const key=`${String(entryKey)}-current`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!1})})]}),typeof currValue=="object"&&currValue!==null&&u("div",{className:"text-[#666] text-[10px] italic mt-1",children:"Reference changed but objects are the same"})]}),"ReferenceOnlyChange"),CountBadge=__name(({count,forceFlash,isFunction,showWarning})=>{const refIsFirstRender=A$1(!0),refBadge=A$1(null),refPrevCount=A$1(count);return y$1(()=>{const element=refBadge.current;!element||refPrevCount.current===count||(element.classList.remove("count-flash"),element.offsetWidth,element.classList.add("count-flash"),refPrevCount.current=count)},[count]),y$1(()=>{if(refIsFirstRender.current){refIsFirstRender.current=!1;return}if(forceFlash){let timer2=setTimeout(()=>{var _a2;(_a2=refBadge.current)==null||_a2.classList.add("count-flash-white"),timer2=setTimeout(()=>{var _a3;(_a3=refBadge.current)==null||_a3.classList.remove("count-flash-white")},300)},500);return()=>{clearTimeout(timer2)}}},[forceFlash]),u("div",{ref:refBadge,className:"count-badge",children:[showWarning&&u(Icon,{name:"icon-triangle-alert",className:"text-yellow-500 mb-px",size:14}),isFunction&&u(Icon,{name:"icon-function",className:"text-[#A855F7] mb-px",size:14}),"x",count]})},"CountBadge"),globalInspectorState={lastRendered:new Map,expandedPaths:new Set,cleanup:__name(()=>{globalInspectorState.lastRendered.clear(),globalInspectorState.expandedPaths.clear(),flashManager.cleanupAll(),resetTracking(),timelineActions.reset()},"cleanup")},InspectorErrorBoundary=(_a=class extends x$1{constructor(){super(...arguments),this.state={hasError:!1,error:null},this.handleReset=()=>{this.setState({hasError:!1,error:null}),globalInspectorState.cleanup()}}static getDerivedStateFromError(e2){return{hasError:!0,error:e2}}render(){var _a2;return this.state.hasError?u("div",{className:"p-4 bg-red-950/50 h-screen backdrop-blur-sm",children:[u("div",{className:"flex items-center gap-2 mb-3 text-red-400 font-medium",children:[u(Icon,{name:"icon-flame",className:"text-red-500",size:16}),"Something went wrong in the inspector"]}),u("div",{className:"p-3 bg-black/40 rounded font-mono text-xs text-red-300 mb-4 break-words",children:((_a2=this.state.error)==null?void 0:_a2.message)||JSON.stringify(this.state.error)}),u("button",{type:"button",onClick:this.handleReset,className:"px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-md text-sm font-medium transition-colors flex items-center justify-center gap-2",children:"Reset Inspector"})]}):this.props.children}},__name(_a,"InspectorErrorBoundary"),_a),inspectorContainerClassName=w(()=>cn("react-scan-inspector","flex-1","opacity-0","overflow-y-auto overflow-x-hidden","transition-opacity delay-0","pointer-events-none",!signalIsSettingsOpen.value&&"opacity-100 delay-300 pointer-events-auto")),Inspector=constant(()=>{const refLastInspectedFiber=A$1(null),processUpdate=__name(fiber=>{if(!fiber)return;refLastInspectedFiber.current=fiber;const{data:inspectorData,shouldUpdate}=collectInspectorData(fiber);if(shouldUpdate){const update={timestamp:Date.now(),fiberInfo:extractMinimalFiberInfo(fiber),props:inspectorData.fiberProps,state:inspectorData.fiberState,context:inspectorData.fiberContext,stateNames:getStateNames(fiber)};timelineActions.addUpdate(update,fiber)}},"processUpdate");return useSignalEffect(()=>{const state=Store.inspectState.value;n(()=>{var _a2;if(state.kind!=="focused"||!state.focusedDomElement){refLastInspectedFiber.current=null,globalInspectorState.cleanup();return}state.kind==="focused"&&(signalIsSettingsOpen.value=!1);const{parentCompositeFiber}=getCompositeFiberFromElement(state.focusedDomElement,state.fiber);if(!parentCompositeFiber){Store.inspectState.value={kind:"inspect-off"},signalWidgetViews.value={view:"none"};return}((_a2=refLastInspectedFiber.current)==null?void 0:_a2.type)!==parentCompositeFiber.type&&(refLastInspectedFiber.current=parentCompositeFiber,globalInspectorState.cleanup(),processUpdate(parentCompositeFiber))})}),useSignalEffect(()=>{inspectorUpdateSignal.value,n(()=>{const inspectState=Store.inspectState.value;if(inspectState.kind!=="focused"||!inspectState.focusedDomElement){refLastInspectedFiber.current=null,globalInspectorState.cleanup();return}const{parentCompositeFiber}=getCompositeFiberFromElement(inspectState.focusedDomElement,inspectState.fiber);if(!parentCompositeFiber){Store.inspectState.value={kind:"inspect-off"},signalWidgetViews.value={view:"none"};return}processUpdate(parentCompositeFiber),inspectState.focusedDomElement.isConnected||(refLastInspectedFiber.current=null,globalInspectorState.cleanup(),Store.inspectState.value={kind:"inspecting",hoveredDomElement:null})})}),y$1(()=>()=>{globalInspectorState.cleanup()},[]),u(InspectorErrorBoundary,{children:u("div",{className:inspectorContainerClassName,children:[u(WhatChangedSection,{}),u(StickySection,{children:__name(props=>u(PropertySection,{section:"props",...props}),"children")}),u(StickySection,{children:__name(props=>u(PropertySection,{section:"state",...props}),"children")}),u(StickySection,{children:__name(props=>u(PropertySection,{section:"context",...props}),"children")})]})})}),ViewInspector=constant(()=>Store.inspectState.value.kind!=="focused"?null:u(InspectorErrorBoundary,{children:[u(Inspector,{}),u(ComponentsTree,{})]})),getFiberFromElement=__name(element=>{var _a2,_b2,_c2;if("__REACT_DEVTOOLS_GLOBAL_HOOK__"in window){const hook=window.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!(hook!=null&&hook.renderers))return null;for(const[,renderer]of Array.from(hook.renderers))try{const fiber=(_a2=renderer.findFiberByHostInstance)==null?void 0:_a2.call(renderer,element);if(fiber)return fiber}catch{}}if("_reactRootContainer"in element){const rootContainer2=element._reactRootContainer;return((_c2=(_b2=rootContainer2==null?void 0:rootContainer2._internalRoot)==null?void 0:_b2.current)==null?void 0:_c2.child)??null}for(const key in element)if(key.startsWith("__reactInternalInstance$")||key.startsWith("__reactFiber"))return element[key];return null},"getFiberFromElement"),getFirstStateNode=__name(fiber=>{let current=fiber;for(;current;){if(current.stateNode instanceof Element)return current.stateNode;if(!current.child)break;current=current.child}for(;current;){if(current.stateNode instanceof Element)return current.stateNode;if(!current.return)break;current=current.return}return null},"getFirstStateNode"),getNearestFiberFromElement=__name(element=>{if(!element)return null;try{const fiber=getFiberFromElement(element);if(!fiber)return null;const res=getParentCompositeFiber(fiber);return res?res[0]:null}catch{return null}},"getNearestFiberFromElement"),getParentCompositeFiber=__name(fiber=>{let current=fiber,prevHost=null;for(;current;){if(isCompositeFiber(current))return[current,prevHost];isHostFiber(current)&&!prevHost&&(prevHost=current),current=current.return}return null},"getParentCompositeFiber"),isFiberInTree=__name((fiber,root)=>!!traverseFiber(root,searchFiber=>searchFiber===fiber),"isFiberInTree"),getAssociatedFiberRect=__name(async element=>{const associatedFiber=getNearestFiberFromElement(element);if(!associatedFiber)return null;const stateNode=getFirstStateNode(associatedFiber);if(!stateNode)return null;const rect=(await batchGetBoundingRects([stateNode])).get(stateNode);return rect||null},"getAssociatedFiberRect"),getCompositeComponentFromElement=__name(element=>{const associatedFiber=getNearestFiberFromElement(element);if(!associatedFiber)return{};if(!getFirstStateNode(associatedFiber))return{};const parentCompositeFiberInfo=getParentCompositeFiber(associatedFiber);if(!parentCompositeFiberInfo)return{};const[parentCompositeFiber]=parentCompositeFiberInfo;return{parentCompositeFiber}},"getCompositeComponentFromElement"),getCompositeFiberFromElement=__name((element,knownFiber)=>{var _a2,_b2;if(!element.isConnected)return{};let fiber=knownFiber??getNearestFiberFromElement(element);if(!fiber)return{};let curr=fiber,rootFiber=null,currentRootFiber=null;for(;curr;){if(!curr.stateNode){curr=curr.return;continue}if((_a2=ReactScanInternals.instrumentation)!=null&&_a2.fiberRoots.has(curr.stateNode)){rootFiber=curr,currentRootFiber=curr.stateNode.current;break}curr=curr.return}if(!rootFiber||!currentRootFiber)return{};if(fiber=isFiberInTree(fiber,currentRootFiber)?fiber:fiber.alternate??fiber,!fiber)return{};if(!getFirstStateNode(fiber))return{};const parentCompositeFiber=(_b2=getParentCompositeFiber(fiber))==null?void 0:_b2[0];return parentCompositeFiber?{parentCompositeFiber:isFiberInTree(parentCompositeFiber,currentRootFiber)?parentCompositeFiber:parentCompositeFiber.alternate??parentCompositeFiber}:{}},"getCompositeFiberFromElement"),getChangedPropsDetailed=__name(fiber=>{var _a2;const currentProps=fiber.memoizedProps??{},previousProps=((_a2=fiber.alternate)==null?void 0:_a2.memoizedProps)??{},changes=[];for(const key in currentProps){if(key==="children")continue;const currentValue=currentProps[key],prevValue=previousProps[key];isEqual(currentValue,prevValue)||changes.push({name:key,value:currentValue,prevValue,type:1})}return changes},"getChangedPropsDetailed"),isRecord=__name(value=>value!==null&&typeof value=="object","isRecord"),getOverrideMethods=__name(()=>{let overrideProps=null,overrideHookState=null,overrideContext=null;if("__REACT_DEVTOOLS_GLOBAL_HOOK__"in window){const hook=window.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!(hook!=null&&hook.renderers))return{overrideProps:null,overrideHookState:null,overrideContext:null};for(const[,renderer]of Array.from(hook.renderers))try{const devToolsRenderer=renderer;if(overrideHookState){const prevOverrideHookState=overrideHookState;overrideHookState=__name((fiber,id,path,value)=>{var _a2;let current=fiber.memoizedState;for(let i2=0;i2<Number(id)&&(current!=null&&current.next);i2++)current=current.next;if(current!=null&&current.queue){const queue=current.queue;if(isRecord(queue)&&"dispatch"in queue){const dispatch=queue.dispatch;dispatch(value);return}}prevOverrideHookState(fiber,id,path,value),(_a2=devToolsRenderer.overrideHookState)==null||_a2.call(devToolsRenderer,fiber,id,path,value)},"overrideHookState")}else devToolsRenderer.overrideHookState&&(overrideHookState=devToolsRenderer.overrideHookState);if(overrideProps){const prevOverrideProps=overrideProps;overrideProps=__name((fiber,path,value)=>{var _a2;prevOverrideProps(fiber,path,value),(_a2=devToolsRenderer.overrideProps)==null||_a2.call(devToolsRenderer,fiber,path,value)},"overrideProps")}else devToolsRenderer.overrideProps&&(overrideProps=devToolsRenderer.overrideProps);overrideContext=__name((fiber,contextType,value)=>{let current=fiber;for(;current;){const type=current.type;if(type===contextType||(type==null?void 0:type.Provider)===contextType){overrideProps&&(overrideProps(current,["value"],value),current.alternate&&overrideProps(current.alternate,["value"],value));break}current=current.return}},"overrideContext")}catch{}}return{overrideProps,overrideHookState,overrideContext}},"getOverrideMethods"),nonVisualTags=new Set(["HTML","HEAD","META","TITLE","BASE","SCRIPT","SCRIPT","STYLE","LINK","NOSCRIPT","SOURCE","TRACK","EMBED","OBJECT","PARAM","TEMPLATE","PORTAL","SLOT","AREA","XML","DOCTYPE","COMMENT"]),findComponentDOMNode=__name((fiber,excludeNonVisualTags=!0)=>{if(fiber.stateNode&&"nodeType"in fiber.stateNode){const element=fiber.stateNode;return excludeNonVisualTags&&element.tagName&&nonVisualTags.has(element.tagName.toLowerCase())?null:element}let child=fiber.child;for(;child;){const result=findComponentDOMNode(child,excludeNonVisualTags);if(result)return result;child=child.sibling}return null},"findComponentDOMNode"),getInspectableElements=__name((root=document.body)=>{const result=[],findInspectableFiber=__name(element=>{if(!element)return null;const{parentCompositeFiber}=getCompositeComponentFromElement(element);return parentCompositeFiber&&findComponentDOMNode(parentCompositeFiber)===element?element:null},"findInspectableFiber"),traverse=__name((element,depth=0)=>{const inspectable=findInspectableFiber(element);if(inspectable){const{parentCompositeFiber}=getCompositeComponentFromElement(inspectable);if(!parentCompositeFiber)return;result.push({element:inspectable,depth,name:getDisplayName(parentCompositeFiber.type)??"Unknown",fiber:parentCompositeFiber})}for(const child of Array.from(element.children))traverse(child,inspectable?depth+1:depth)},"traverse");return traverse(root),result},"getInspectableElements"),isExpandable=__name(value=>value===null||typeof value!="object"||isPromise(value)?!1:value instanceof ArrayBuffer||value instanceof DataView||ArrayBuffer.isView(value)?!0:value instanceof Map||value instanceof Set?value.size>0:Array.isArray(value)?value.length>0:Object.keys(value).length>0,"isExpandable"),isEditableValue=__name((value,parentPath)=>{if(value==null)return!0;if(isPromise(value)||typeof value=="function")return!1;if(parentPath){const parts=parentPath.split(".");let currentPath="";for(const part of parts){currentPath=currentPath?`${currentPath}.${part}`:part;const obj=globalInspectorState.lastRendered.get(currentPath);if(obj instanceof DataView||obj instanceof ArrayBuffer||ArrayBuffer.isView(obj))return!1}}switch(value.constructor){case Date:case RegExp:case Error:return!0;default:switch(typeof value){case"string":case"number":case"boolean":case"bigint":return!0;default:return!1}}},"isEditableValue"),getPath=__name((componentName,section,parentPath,key)=>parentPath?`${componentName}.${parentPath}.${key}`:section==="context"&&!key.startsWith("context.")?`${componentName}.${section}.context.${key}`:`${componentName}.${section}.${key}`,"getPath"),sanitizeString=__name(value=>value.replace(/[<>]/g,"").replace(/javascript:/gi,"").replace(/data:/gi,"").replace(/on\w+=/gi,"").slice(0,5e4),"sanitizeString"),formatValue=__name(value=>ensureRecord(value).displayValue,"formatValue"),formatForClipboard=__name(value=>{try{if(value===null)return"null";if(value===void 0)return"undefined";if(isPromise(value))return"Promise";if(typeof value=="function"){const fnStr=value.toString();try{return fnStr.replace(/\s+/g," ").replace(/{\s+/g,`{
  `).replace(/;\s+/g,`;
  `).replace(/}\s*$/g,`
}`).replace(/\(\s+/g,"(").replace(/\s+\)/g,")").replace(/,\s+/g,", ")}catch{return fnStr}}switch(!0){case value instanceof Date:return value.toISOString();case value instanceof RegExp:return value.toString();case value instanceof Error:return`${value.name}: ${value.message}`;case value instanceof Map:return JSON.stringify(Array.from(value.entries()),null,2);case value instanceof Set:return JSON.stringify(Array.from(value),null,2);case value instanceof DataView:return JSON.stringify(Array.from(new Uint8Array(value.buffer)),null,2);case value instanceof ArrayBuffer:return JSON.stringify(Array.from(new Uint8Array(value)),null,2);case(ArrayBuffer.isView(value)&&"length"in value):return JSON.stringify(Array.from(value),null,2);case Array.isArray(value):return JSON.stringify(value,null,2);case typeof value=="object":return JSON.stringify(value,null,2);default:return String(value)}}catch{return String(value)}},"formatForClipboard"),detectValueType=__name(value=>{const trimmed=value.trim();switch(trimmed){case"undefined":return{type:"undefined",value:void 0};case"null":return{type:"null",value:null};case"true":return{type:"boolean",value:!0};case"false":return{type:"boolean",value:!1}}return/^".*"$/.test(trimmed)?{type:"string",value:trimmed.slice(1,-1)}:/^-?\d+(?:\.\d+)?$/.test(trimmed)?{type:"number",value:Number(trimmed)}:{type:"string",value:`"${trimmed}"`}},"detectValueType"),formatInitialValue=__name(value=>value===void 0?"undefined":value===null?"null":typeof value=="string"?`"${value}"`:String(value),"formatInitialValue"),updateNestedValue=__name((obj,path,value)=>{try{if(path.length===0)return value;const[key,...rest]=path;if(Array.isArray(obj)&&obj.every(item=>"name"in item&&"value"in item)){const index=obj.findIndex(item=>item.name===key);if(index===-1)return obj;const newArray=[...obj];return rest.length===0?newArray[index]={...newArray[index],value}:newArray[index]={...newArray[index],value:updateNestedValue(newArray[index].value,rest,value)},newArray}if(obj instanceof Map){const newMap=new Map(obj);if(rest.length===0)newMap.set(key,value);else{const currentValue=newMap.get(key);newMap.set(key,updateNestedValue(currentValue,rest,value))}return newMap}if(Array.isArray(obj)){const index=Number.parseInt(key,10),newArray=[...obj];return rest.length===0?newArray[index]=value:newArray[index]=updateNestedValue(obj[index],rest,value),newArray}return obj&&typeof obj=="object"?rest.length===0?{...obj,[key]:value}:{...obj,[key]:updateNestedValue(obj[key],rest,value)}:value}catch{return obj}},"updateNestedValue"),areFunctionsEqual=__name((prev,current)=>{try{return typeof prev!="function"||typeof current!="function"?!1:prev.toString()===current.toString()}catch{return!1}},"areFunctionsEqual"),getObjectDiff=__name((prev,current,path=[],seen=new WeakSet)=>{if(prev===current)return{type:"primitive",changes:[],hasDeepChanges:!1};if(typeof prev=="function"&&typeof current=="function"){const isSameFunction=areFunctionsEqual(prev,current);return{type:"primitive",changes:[{path,prevValue:prev,currentValue:current,sameFunction:isSameFunction}],hasDeepChanges:!isSameFunction}}if(prev===null||current===null||prev===void 0||current===void 0||typeof prev!="object"||typeof current!="object")return{type:"primitive",changes:[{path,prevValue:prev,currentValue:current}],hasDeepChanges:!0};if(seen.has(prev)||seen.has(current))return{type:"object",changes:[{path,prevValue:"[Circular]",currentValue:"[Circular]"}],hasDeepChanges:!1};seen.add(prev),seen.add(current);const prevObj=prev,currentObj=current,allKeys=new Set([...Object.keys(prevObj),...Object.keys(currentObj)]),changes=[];let hasDeepChanges=!1;for(const key of allKeys){const prevValue=prevObj[key],currentValue=currentObj[key];if(prevValue!==currentValue)if(typeof prevValue=="object"&&typeof currentValue=="object"&&prevValue!==null&&currentValue!==null){const nestedDiff=getObjectDiff(prevValue,currentValue,[...path,key],seen);changes.push(...nestedDiff.changes),nestedDiff.hasDeepChanges&&(hasDeepChanges=!0)}else changes.push({path:[...path,key],prevValue,currentValue}),hasDeepChanges=!0}return{type:"object",changes,hasDeepChanges}},"getObjectDiff"),formatPath=__name(path=>path.length===0?"":path.reduce((acc,segment,i2)=>/^\d+$/.test(segment)?`${acc}[${segment}]`:i2===0?segment:`${acc}.${segment}`,""),"formatPath");function hackyJsFormatter(code){const normalizedCode=code.replace(/\s+/g," ").trim(),rawTokens=[];let current="";for(let i2=0;i2<normalizedCode.length;i2++){const c2=normalizedCode[i2];if(c2==="="&&normalizedCode[i2+1]===">"){current.trim()&&rawTokens.push(current.trim()),rawTokens.push("=>"),current="",i2++;continue}/[(){}[\];,<>:\?!]/.test(c2)?(current.trim()&&rawTokens.push(current.trim()),rawTokens.push(c2),current=""):/\s/.test(c2)?(current.trim()&&rawTokens.push(current.trim()),current=""):current+=c2}current.trim()&&rawTokens.push(current.trim());const merged=[];for(let i2=0;i2<rawTokens.length;i2++){const t2=rawTokens[i2],n2=rawTokens[i2+1];t2==="("&&n2===")"||t2==="["&&n2==="]"||t2==="{"&&n2==="}"||t2==="<"&&n2===">"?(merged.push(t2+n2),i2++):merged.push(t2)}const arrowParamSet=new Set,genericSet=new Set;function findMatchingPair(openTok,closeTok,startIndex){let depth=0;for(let j2=startIndex;j2<merged.length;j2++){const token=merged[j2];if(token===openTok)depth++;else if(token===closeTok&&(depth--,depth===0))return j2}return-1}__name(findMatchingPair,"findMatchingPair");for(let i2=0;i2<merged.length;i2++)if(merged[i2]==="("){const closeIndex=findMatchingPair("(",")",i2);if(closeIndex!==-1&&merged[closeIndex+1]==="=>")for(let k2=i2;k2<=closeIndex;k2++)arrowParamSet.add(k2)}for(let i2=1;i2<merged.length;i2++){const prev=merged[i2-1],t2=merged[i2];if(/^[a-zA-Z0-9_$]+$/.test(prev)&&t2==="<"){const closeIndex=findMatchingPair("<",">",i2);if(closeIndex!==-1)for(let k2=i2;k2<=closeIndex;k2++)genericSet.add(k2)}}let indentLevel=0;const indentStr="  ",lines=[];let line="";function pushLine(){line.trim()&&lines.push(line.replace(/\s+$/,"")),line=""}__name(pushLine,"pushLine");function newLine(){pushLine(),line=indentStr.repeat(indentLevel)}__name(newLine,"newLine");const stack=[];function stackTop(){return stack.length?stack[stack.length-1]:null}__name(stackTop,"stackTop");function placeToken(tok,noSpaceBefore=!1){line.trim()?noSpaceBefore||/^[),;:\].}>]$/.test(tok)?line+=tok:line+=` ${tok}`:line+=tok}__name(placeToken,"placeToken");for(let i2=0;i2<merged.length;i2++){const tok=merged[i2],next=merged[i2+1]||"";if(["(","{","[","<"].includes(tok)){if(placeToken(tok),stack.push(tok),tok==="{")indentLevel++,newLine();else if((tok==="("||tok==="["||tok==="<")&&!(arrowParamSet.has(i2)&&tok==="("||genericSet.has(i2)&&tok==="<")){const directClose={"(":")","[":"]","<":">"}[tok];next!==directClose&&next!=="()"&&next!=="[]"&&next!=="<>"&&(indentLevel++,newLine())}}else if([")","}","]",">"].includes(tok)){const opening=stackTop();tok===")"&&opening==="("||tok==="]"&&opening==="["||tok===">"&&opening==="<"?!(arrowParamSet.has(i2)&&tok===")")&&!(genericSet.has(i2)&&tok===">")&&(indentLevel=Math.max(indentLevel-1,0),newLine()):tok==="}"&&opening==="{"&&(indentLevel=Math.max(indentLevel-1,0),newLine()),stack.pop(),placeToken(tok),tok==="}"&&newLine()}else if(/^\(\)|\[\]|\{\}|\<\>$/.test(tok))placeToken(tok);else if(tok==="=>")placeToken(tok);else if(tok===";")placeToken(tok,!0),newLine();else if(tok===","){placeToken(tok,!0);const top=stackTop();!(arrowParamSet.has(i2)&&top==="(")&&!(genericSet.has(i2)&&top==="<")&&top&&["{","[","(","<"].includes(top)&&newLine()}else placeToken(tok)}return pushLine(),lines.join(`
`).replace(/\n\s*\n+/g,`
`).trim()}__name(hackyJsFormatter,"hackyJsFormatter");var formatFunctionPreview=__name((fn2,expanded=!1)=>{try{const fnStr=fn2.toString(),match=fnStr.match(/(?:function\s*)?(?:\(([^)]*)\)|([^=>\s]+))\s*=>?/);if(!match)return"ƒ";const cleanParams=(match[1]||match[2]||"").replace(/\s+/g,"");return expanded?hackyJsFormatter(fnStr):`ƒ (${cleanParams}) => ...`}catch{return"ƒ"}},"formatFunctionPreview"),formatValuePreview=__name(value=>{if(value===null)return"null";if(value===void 0)return"undefined";if(typeof value=="string")return`"${value.length>150?`${value.slice(0,20)}...`:value}"`;if(typeof value=="number"||typeof value=="boolean")return String(value);if(typeof value=="function")return formatFunctionPreview(value);if(Array.isArray(value))return`Array(${value.length})`;if(value instanceof Map)return`Map(${value.size})`;if(value instanceof Set)return`Set(${value.size})`;if(value instanceof Date)return value.toISOString();if(value instanceof RegExp)return value.toString();if(value instanceof Error)return`${value.name}: ${value.message}`;if(typeof value=="object"){const keys=Object.keys(value);return`{${keys.length>2?`${keys.slice(0,2).join(", ")}, ...`:keys.join(", ")}}`}return String(value)},"formatValuePreview"),safeGetValue=__name(value=>{var _a2;if(value==null)return{value};if(typeof value=="function")return{value};if(typeof value!="object")return{value};if(value instanceof Promise)return{value:"Promise"};try{const proto=Object.getPrototypeOf(value);return proto===Promise.prototype||((_a2=proto==null?void 0:proto.constructor)==null?void 0:_a2.name)==="Promise"?{value:"Promise"}:{value}}catch{return{value:null,error:"Error accessing value"}}},"safeGetValue"),calculateSliderValues=__name((totalUpdates,currentIndex)=>totalUpdates<=TIMELINE_MAX_UPDATES?{leftValue:0,min:0,max:totalUpdates-1,value:currentIndex,rightValue:totalUpdates-1}:{leftValue:totalUpdates-TIMELINE_MAX_UPDATES,min:0,max:TIMELINE_MAX_UPDATES-1,value:currentIndex,rightValue:totalUpdates-1},"calculateSliderValues"),isPromise=__name(value=>!!value&&(value instanceof Promise||typeof value=="object"&&"then"in value),"isPromise"),ensureRecord=__name((value,maxDepth=2,seen=new WeakSet)=>{if(isPromise(value))return{type:"promise",displayValue:"Promise"};if(value===null)return{type:"null",displayValue:"null"};if(value===void 0)return{type:"undefined",displayValue:"undefined"};switch(typeof value){case"object":{if(seen.has(value))return{type:"circular",displayValue:"[Circular Reference]"};if(!value)return{type:"null",displayValue:"null"};seen.add(value);try{const result={};if(value instanceof Element)return result.type="Element",result.tagName=value.tagName.toLowerCase(),result.displayValue=value.tagName.toLowerCase(),result;if(value instanceof Map){if(result.type="Map",result.size=value.size,result.displayValue=`Map(${value.size})`,maxDepth>0){const entries={};let index=0;for(const[key,val]of value.entries()){if(index>=50)break;try{entries[String(key)]=ensureRecord(val,maxDepth-1,seen)}catch{entries[String(index)]={type:"error",displayValue:"Error accessing Map entry"}}index++}result.entries=entries}return result}if(value instanceof Set){if(result.type="Set",result.size=value.size,result.displayValue=`Set(${value.size})`,maxDepth>0){const items=[];let count=0;for(const item of value){if(count>=50)break;items.push(ensureRecord(item,maxDepth-1,seen)),count++}result.items=items}return result}if(value instanceof Date)return result.type="Date",result.value=value.toISOString(),result.displayValue=value.toLocaleString(),result;if(value instanceof RegExp)return result.type="RegExp",result.value=value.toString(),result.displayValue=value.toString(),result;if(value instanceof Error)return result.type="Error",result.name=value.name,result.message=value.message,result.displayValue=`${value.name}: ${value.message}`,result;if(value instanceof ArrayBuffer)return result.type="ArrayBuffer",result.byteLength=value.byteLength,result.displayValue=`ArrayBuffer(${value.byteLength})`,result;if(value instanceof DataView)return result.type="DataView",result.byteLength=value.byteLength,result.displayValue=`DataView(${value.byteLength})`,result;if(ArrayBuffer.isView(value)){const typedArray=value;return result.type=typedArray.constructor.name,result.length=typedArray.length,result.byteLength=typedArray.buffer.byteLength,result.displayValue=`${typedArray.constructor.name}(${typedArray.length})`,result}if(Array.isArray(value))return result.type="array",result.length=value.length,result.displayValue=`Array(${value.length})`,maxDepth>0&&(result.items=value.slice(0,50).map(item=>ensureRecord(item,maxDepth-1,seen))),result;const keys=Object.keys(value);if(result.type="object",result.size=keys.length,result.displayValue=keys.length<=5?`{${keys.join(", ")}}`:`{${keys.slice(0,5).join(", ")}, ...${keys.length-5}}`,maxDepth>0){const entries={};for(const key of keys.slice(0,50))try{entries[key]=ensureRecord(value[key],maxDepth-1,seen)}catch{entries[key]={type:"error",displayValue:"Error accessing property"}}result.entries=entries}return result}finally{seen.delete(value)}}case"string":return{type:"string",value,displayValue:`"${value}"`};case"function":return{type:"function",displayValue:"ƒ()",name:value.name||"anonymous"};default:return{type:typeof value,value,displayValue:String(value)}}},"ensureRecord"),extractMinimalFiberInfo=__name(fiber=>{const timings=getTimings(fiber);return{displayName:getDisplayName(fiber)||"Unknown",type:fiber.type,key:fiber.key,id:fiber.index,selfTime:(timings==null?void 0:timings.selfTime)??null,totalTime:(timings==null?void 0:timings.totalTime)??null}},"extractMinimalFiberInfo"),propsTracker=new Map,stateTracker=new Map,contextTracker=new Map,lastComponentType=null,STATE_NAME_REGEX=/\[(?<name>\w+),\s*set\w+\]/g,getStateNames=__name(fiber=>{var _a2,_b2;const componentSource=((_b2=(_a2=fiber.type)==null?void 0:_a2.toString)==null?void 0:_b2.call(_a2))||"";return componentSource?Array.from(componentSource.matchAll(STATE_NAME_REGEX),m2=>{var _a3;return((_a3=m2.groups)==null?void 0:_a3.name)??""}):[]},"getStateNames"),resetTracking=__name(()=>{propsTracker.clear(),stateTracker.clear(),contextTracker.clear(),lastComponentType=null},"resetTracking"),isInitialComponentUpdate=__name(fiber=>{const isNewComponent=fiber.type!==lastComponentType;return lastComponentType=fiber.type,isNewComponent},"isInitialComponentUpdate"),trackChange=__name((tracker,key,currentValue,previousValue)=>{const existing=tracker.get(key),isInitialValue=tracker===propsTracker||tracker===contextTracker,hasChanged=!isEqual(currentValue,previousValue);if(!existing)return tracker.set(key,{count:hasChanged&&isInitialValue?1:0,currentValue,previousValue,lastUpdated:Date.now()}),{hasChanged,count:hasChanged&&isInitialValue?1:isInitialValue?0:1};if(!isEqual(existing.currentValue,currentValue)){const newCount=existing.count+1;return tracker.set(key,{count:newCount,currentValue,previousValue:existing.currentValue,lastUpdated:Date.now()}),{hasChanged:!0,count:newCount}}return{hasChanged:!1,count:existing.count}},"trackChange"),getStateFromFiber=__name(fiber=>{if(!fiber)return{};if(fiber.tag===FunctionComponentTag||fiber.tag===ForwardRefTag||fiber.tag===SimpleMemoComponentTag||fiber.tag===MemoComponentTag){let memoizedState=fiber.memoizedState;const state={};let index=0;for(;memoizedState;)memoizedState.queue&&memoizedState.memoizedState!==void 0&&(state[index]=memoizedState.memoizedState),memoizedState=memoizedState.next,index++;return state}return fiber.tag===ClassComponentTag?fiber.memoizedState||{}:{}},"getStateFromFiber"),collectPropsChanges=__name(fiber=>{var _a2;const currentProps=fiber.memoizedProps||{},prevProps=((_a2=fiber.alternate)==null?void 0:_a2.memoizedProps)||{},current={},prev={},allProps=Object.keys(currentProps);for(const key of allProps)key in currentProps&&(current[key]=currentProps[key],prev[key]=prevProps[key]);const changes=getChangedPropsDetailed(fiber).map(change=>({name:change.name,value:change.value,prevValue:change.prevValue}));return{current,prev,changes}},"collectPropsChanges"),collectStateChanges=__name(fiber=>{const current=getStateFromFiber(fiber),prev=fiber.alternate?getStateFromFiber(fiber.alternate):{},changes=[];for(const[index,value]of Object.entries(current)){const stateKey=fiber.tag===ClassComponentTag?index:Number(index);fiber.alternate&&!isEqual(prev[index],value)&&changes.push({name:stateKey,value,prevValue:prev[index]})}return{current,prev,changes}},"collectStateChanges"),collectContextChanges=__name(fiber=>{const currentContexts=getAllFiberContexts(fiber),prevContexts=fiber.alternate?getAllFiberContexts(fiber.alternate):new Map,current={},prev={},changes=[],seenContexts=new Set;for(const[contextType,ctx2]of currentContexts){const name=ctx2.displayName,contextKey=contextType;if(seenContexts.has(contextKey))continue;seenContexts.add(contextKey),current[name]=ctx2.value;const prevCtx=prevContexts.get(contextType);prevCtx&&(prev[name]=prevCtx.value,isEqual(prevCtx.value,ctx2.value)||changes.push({name,value:ctx2.value,prevValue:prevCtx.value,contextType}))}return{current,prev,changes}},"collectContextChanges"),collectInspectorData=__name(fiber=>{const emptySection=__name(()=>({current:[],changes:new Set,changesCounts:new Map}),"emptySection");if(!fiber)return{data:{fiberProps:emptySection(),fiberState:emptySection(),fiberContext:emptySection()},shouldUpdate:!1};let hasNewChanges=!1;const isInitialUpdate=isInitialComponentUpdate(fiber),propsData=emptySection();if(fiber.memoizedProps){const{current,changes}=collectPropsChanges(fiber);for(const[key,value]of Object.entries(current))propsData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes){const{hasChanged,count}=trackChange(propsTracker,change.name,change.value,change.prevValue);hasChanged&&(hasNewChanges=!0,propsData.changes.add(change.name),propsData.changesCounts.set(change.name,count))}}const stateData=emptySection(),{current:stateCurrent,changes:stateChanges}=collectStateChanges(fiber);for(const[index,value]of Object.entries(stateCurrent)){const stateKey=fiber.tag===ClassComponentTag?index:Number(index);stateData.current.push({name:stateKey,value})}for(const change of stateChanges){const{hasChanged,count}=trackChange(stateTracker,change.name,change.value,change.prevValue);hasChanged&&(hasNewChanges=!0,stateData.changes.add(change.name),stateData.changesCounts.set(change.name,count))}const contextData=emptySection(),{current:contextCurrent,changes:contextChanges}=collectContextChanges(fiber);for(const[name,value]of Object.entries(contextCurrent))contextData.current.push({name,value});if(!isInitialUpdate)for(const change of contextChanges){const{hasChanged,count}=trackChange(contextTracker,change.name,change.value,change.prevValue);hasChanged&&(hasNewChanges=!0,contextData.changes.add(change.name),contextData.changesCounts.set(change.name,count))}return!hasNewChanges&&!isInitialUpdate&&(propsData.changes.clear(),stateData.changes.clear(),contextData.changes.clear()),{data:{fiberProps:propsData,fiberState:stateData,fiberContext:contextData},shouldUpdate:hasNewChanges||isInitialUpdate}},"collectInspectorData"),fiberContextsCache=new WeakMap,getAllFiberContexts=__name(fiber=>{var _a2;if(!fiber)return new Map;const cachedContexts=fiberContextsCache.get(fiber);if(cachedContexts)return cachedContexts;const contexts=new Map;let currentFiber=fiber;for(;currentFiber;){const dependencies=currentFiber.dependencies;if(dependencies!=null&&dependencies.firstContext){let contextItem=dependencies.firstContext;for(;contextItem;){const memoizedValue=contextItem.memoizedValue,displayName=(_a2=contextItem.context)==null?void 0:_a2.displayName;if(contexts.has(memoizedValue)||contexts.set(contextItem.context,{value:memoizedValue,displayName:displayName??"UnnamedContext",contextType:null}),contextItem===contextItem.next)break;contextItem=contextItem.next}}currentFiber=currentFiber.return}return fiberContextsCache.set(fiber,contexts),contexts},"getAllFiberContexts"),collectInspectorDataWithoutCounts=__name(fiber=>{const emptySection=__name(()=>({current:[],changes:new Set,changesCounts:new Map}),"emptySection");if(!fiber)return{fiberProps:emptySection(),fiberState:emptySection(),fiberContext:emptySection()};const propsData=emptySection();if(fiber.memoizedProps){const{current:current2,changes:changes2}=collectPropsChanges(fiber);for(const[key,value]of Object.entries(current2))propsData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes2)propsData.changes.add(change.name),propsData.changesCounts.set(change.name,1)}const stateData=emptySection();if(fiber.memoizedState){const{current:current2,changes:changes2}=collectStateChanges(fiber);for(const[key,value]of Object.entries(current2))stateData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes2)stateData.changes.add(change.name),stateData.changesCounts.set(change.name,1)}const contextData=emptySection(),{current,changes}=collectContextChanges(fiber);for(const[key,value]of Object.entries(current))contextData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes)contextData.changes.add(change.name),contextData.changesCounts.set(change.name,1);return{fiberProps:propsData,fiberState:stateData,fiberContext:contextData}},"collectInspectorDataWithoutCounts"),fps=0,lastTime=performance.now(),frameCount=0,initedFps=!1,updateFPS=__name(()=>{frameCount++;const now=performance.now();now-lastTime>=1e3&&(fps=frameCount,frameCount=0,lastTime=now),requestAnimationFrame(updateFPS)},"updateFPS"),getFPS=__name(()=>(initedFps||(initedFps=!0,updateFPS(),fps=60),fps),"getFPS"),instrumentationInstances=new Map,inited=!1,getAllInstances=__name(()=>Array.from(instrumentationInstances.values()),"getAllInstances"),RENDER_DEBOUNCE_MS=16,renderDataMap=new WeakMap,trackRender=__name((type,fiberSelfTime,fiberTotalTime,hasChanges,hasDomMutations)=>{const currentTimestamp=Date.now(),existingData=renderDataMap.get(type);if((hasChanges||hasDomMutations)&&(!existingData||currentTimestamp-(existingData.lastRenderTimestamp||0)>RENDER_DEBOUNCE_MS)){const renderData=existingData||{selfTime:0,totalTime:0,renderCount:0,lastRenderTimestamp:currentTimestamp};renderData.renderCount=(renderData.renderCount||0)+1,renderData.selfTime=fiberSelfTime||0,renderData.totalTime=fiberTotalTime||0,renderData.lastRenderTimestamp=currentTimestamp,renderDataMap.set(type,{...renderData})}},"trackRender"),createInstrumentation=__name((instanceKey,config)=>{const instrumentation={isPaused:d$1(!ReactScanInternals.options.value.enabled),fiberRoots:new WeakSet};return instrumentationInstances.set(instanceKey,{key:instanceKey,config,instrumentation}),inited||(inited=!0,instrument({name:"react-scan",onActive:config.onActive,onCommitFiberRoot(_rendererID,root){instrumentation.fiberRoots.add(root);const allInstances=getAllInstances();for(const instance of allInstances)instance.config.onCommitStart();traverseRenderedFibers(root.current,(fiber,phase)=>{const type=getType(fiber.type);if(!type)return null;const allInstances2=getAllInstances(),validInstancesIndicies=[];for(let i2=0,len=allInstances2.length;i2<len;i2++)allInstances2[i2].config.isValidFiber(fiber)&&validInstancesIndicies.push(i2);if(!validInstancesIndicies.length)return null;const changes=[];if(allInstances2.some(instance=>instance.config.trackChanges)){const changesProps=collectPropsChanges(fiber).changes,changesState=collectStateChanges(fiber).changes,changesContext=collectContextChanges(fiber).changes;changes.push.apply(null,changesProps.map(change=>({type:1,name:change.name,value:change.value})));for(const change of changesState)fiber.tag===ClassComponentTag?changes.push({type:3,name:change.name.toString(),value:change.value}):changes.push({type:2,name:change.name.toString(),value:change.value});changes.push.apply(null,changesContext.map(change=>({type:4,name:change.name,value:change.value,contextType:Number(change.contextType)})))}const{selfTime:fiberSelfTime,totalTime:fiberTotalTime}=getTimings(fiber),fps2=getFPS(),render2={phase:RENDER_PHASE_STRING_TO_ENUM[phase],componentName:getDisplayName(type),count:1,changes,time:fiberSelfTime,forget:hasMemoCache(fiber),unnecessary:null,didCommit:didFiberCommit(fiber),fps:fps2},hasChanges=changes.length>0,hasDomMutations=getMutatedHostFibers(fiber).length>0;phase==="update"&&trackRender(type,fiberSelfTime,fiberTotalTime,hasChanges,hasDomMutations);for(let i2=0,len=validInstancesIndicies.length;i2<len;i2++){const index=validInstancesIndicies[i2];allInstances2[index].config.onRender(fiber,[render2])}});for(const instance of allInstances)instance.config.onCommitFinish()},onPostCommitFiberRoot(){const allInstances=getAllInstances();for(const instance of allInstances)instance.config.onPostCommitFiberRoot()}})),instrumentation},"createInstrumentation"),log=__name(renders=>{const logMap=new Map;for(let i2=0,len=renders.length;i2<len;i2++){const render2=renders[i2];if(!render2.componentName)continue;const changeLog=logMap.get(render2.componentName)??[],labelText=getLabelText([{aggregatedCount:1,computedKey:null,name:render2.componentName,frame:null,...render2,changes:{type:render2.changes.reduce((set,change)=>set|change.type,0),unstable:render2.changes.some(change=>change.unstable)},phase:render2.phase,computedCurrent:null}]);if(!labelText)continue;let prevChangedProps=null,nextChangedProps=null;if(render2.changes)for(let i22=0,len2=render2.changes.length;i22<len2;i22++){const{name,prevValue,nextValue,unstable,type}=render2.changes[i22];type===1?(prevChangedProps??(prevChangedProps={}),nextChangedProps??(nextChangedProps={}),prevChangedProps[`${unstable?"⚠️":""}${name} (prev)`]=prevValue,nextChangedProps[`${unstable?"⚠️":""}${name} (next)`]=nextValue):changeLog.push({prev:prevValue,next:nextValue,type:type===4?"context":"state",unstable:unstable??!1})}prevChangedProps&&nextChangedProps&&changeLog.push({prev:prevChangedProps,next:nextChangedProps,type:"props",unstable:!1}),logMap.set(labelText,changeLog)}for(const[name,changeLog]of Array.from(logMap.entries())){console.group(`%c${name}`,"background: hsla(0,0%,70%,.3); border-radius:3px; padding: 0 2px;");for(const{type,prev,next,unstable}of changeLog)console.log(`${type}:`,unstable?"⚠️":"",prev,"!==",next);console.groupEnd()}},"log"),logIntro=__name(()=>{if(window.hideIntro){window.hideIntro=void 0;return}console.log("%c[·] %cReact Scan","font-weight:bold;color:#7a68e8;font-size:20px;","font-weight:bold;font-size:14px;"),console.log("Try React Scan Monitoring to target performance issues in production: https://react-scan.com/monitoring")},"logIntro"),OUTLINE_ARRAY_SIZE=7,MONO_FONT="Menlo,Consolas,Monaco,Liberation Mono,Lucida Console,monospace",INTERPOLATION_SPEED=.1,lerp=__name((start2,end)=>Math.floor(start2+(end-start2)*INTERPOLATION_SPEED),"lerp"),MAX_PARTS_LENGTH=4,MAX_LABEL_LENGTH=40,TOTAL_FRAMES=45,PRIMARY_COLOR="115,97,230";function sortEntry(prev,next){return next[0]-prev[0]}__name(sortEntry,"sortEntry");function getSortedEntries(countByNames){return[...countByNames.entries()].sort(sortEntry)}__name(getSortedEntries,"getSortedEntries");function getLabelTextPart([count,names]){let part=`${names.slice(0,MAX_PARTS_LENGTH).join(", ")} ×${count}`;return part.length>MAX_LABEL_LENGTH&&(part=`${part.slice(0,MAX_LABEL_LENGTH)}…`),part}__name(getLabelTextPart,"getLabelTextPart");var getLabelText2=__name(outlines=>{const nameByCount=new Map;for(const{name,count}of outlines)nameByCount.set(name,(nameByCount.get(name)||0)+count);const countByNames=new Map;for(const[name,count]of nameByCount){const names=countByNames.get(count);names?names.push(name):countByNames.set(count,[name])}const partsEntries=getSortedEntries(countByNames);let labelText=getLabelTextPart(partsEntries[0]);for(let i2=1,len=partsEntries.length;i2<len;i2++)labelText+=", "+getLabelTextPart(partsEntries[i2]);return labelText.length>MAX_LABEL_LENGTH?`${labelText.slice(0,MAX_LABEL_LENGTH)}…`:labelText},"getLabelText2"),getAreaFromOutlines=__name(outlines=>{let area=0;for(const outline of outlines)area+=outline.width*outline.height;return area},"getAreaFromOutlines"),updateOutlines=__name((activeOutlines2,outlines)=>{for(const{id,name,count,x:x2,y:y2,width,height,didCommit}of outlines){const outline={id,name,count,x:x2,y:y2,width,height,frame:0,targetX:x2,targetY:y2,targetWidth:width,targetHeight:height,didCommit},key=String(outline.id),existingOutline=activeOutlines2.get(key);existingOutline?(existingOutline.count++,existingOutline.frame=0,existingOutline.targetX=x2,existingOutline.targetY=y2,existingOutline.targetWidth=width,existingOutline.targetHeight=height,existingOutline.didCommit=didCommit):activeOutlines2.set(key,outline)}},"updateOutlines"),updateScroll=__name((activeOutlines2,deltaX,deltaY)=>{for(const outline of activeOutlines2.values()){const newX=outline.x-deltaX,newY=outline.y-deltaY;outline.targetX=newX,outline.targetY=newY}},"updateScroll"),initCanvas=__name((canvas2,dpr2)=>{const ctx2=canvas2.getContext("2d",{alpha:!0});return ctx2&&ctx2.scale(dpr2,dpr2),ctx2},"initCanvas"),drawCanvas=__name((ctx2,canvas2,dpr2,activeOutlines2)=>{ctx2.clearRect(0,0,canvas2.width/dpr2,canvas2.height/dpr2);const groupedOutlinesMap=new Map,rectMap=new Map;for(const outline of activeOutlines2.values()){const{x:x2,y:y2,width,height,targetX,targetY,targetWidth,targetHeight,frame}=outline;targetX!==x2&&(outline.x=lerp(x2,targetX)),targetY!==y2&&(outline.y=lerp(y2,targetY)),targetWidth!==width&&(outline.width=lerp(width,targetWidth)),targetHeight!==height&&(outline.height=lerp(height,targetHeight));const labelKey=`${targetX??x2},${targetY??y2}`,rectKey=`${labelKey},${targetWidth??width},${targetHeight??height}`,outlines=groupedOutlinesMap.get(labelKey);outlines?outlines.push(outline):groupedOutlinesMap.set(labelKey,[outline]);const alpha=1-frame/TOTAL_FRAMES;outline.frame++;const rect=rectMap.get(rectKey)||{x:x2,y:y2,width,height,alpha};alpha>rect.alpha&&(rect.alpha=alpha),rectMap.set(rectKey,rect)}for(const{x:x2,y:y2,width,height,alpha}of rectMap.values())ctx2.strokeStyle=`rgba(${PRIMARY_COLOR},${alpha})`,ctx2.lineWidth=1,ctx2.beginPath(),ctx2.rect(x2,y2,width,height),ctx2.stroke(),ctx2.fillStyle=`rgba(${PRIMARY_COLOR},${alpha*.1})`,ctx2.fill();ctx2.font=`11px ${MONO_FONT}`;const labelMap=new Map;ctx2.textRendering="optimizeSpeed";for(const outlines of groupedOutlinesMap.values()){const first=outlines[0],{x:x2,y:y2,frame}=first,alpha=1-frame/TOTAL_FRAMES,text=getLabelText2(outlines),{width}=ctx2.measureText(text);if(labelMap.set(`${x2},${y2},${width},${text}`,{text,width,height:11,alpha,x:x2,y:y2,outlines}),frame>TOTAL_FRAMES)for(const outline of outlines)activeOutlines2.delete(String(outline.id))}const sortedLabels=Array.from(labelMap.entries()).sort(([_3,a2],[__,b2])=>getAreaFromOutlines(b2.outlines)-getAreaFromOutlines(a2.outlines));for(const[labelKey,label]of sortedLabels)if(labelMap.has(labelKey))for(const[otherKey,otherLabel]of labelMap.entries()){if(labelKey===otherKey)continue;const{x:x2,y:y2,width,height}=label,{x:otherX,y:otherY,width:otherWidth,height:otherHeight}=otherLabel;x2+width>otherX&&otherX+otherWidth>x2&&y2+height>otherY&&otherY+otherHeight>y2&&(label.text=getLabelText2(label.outlines.concat(otherLabel.outlines)),label.width=ctx2.measureText(label.text).width,labelMap.delete(otherKey))}for(const label of labelMap.values()){const{x:x2,y:y2,alpha,width,height,text}=label;let labelY=y2-height-4;labelY<0&&(labelY=0),ctx2.fillStyle=`rgba(${PRIMARY_COLOR},${alpha})`,ctx2.fillRect(x2,labelY,width+4,height+4),ctx2.fillStyle=`rgba(255,255,255,${alpha})`,ctx2.fillText(text,x2+2,labelY+height)}return activeOutlines2.size>0},"drawCanvas"),workerCode='"use strict";(()=>{var D="Menlo,Consolas,Monaco,Liberation Mono,Lucida Console,monospace";var M=(t,i)=>Math.floor(t+(i-t)*.1);var _="115,97,230";function F(t,i){return i[0]-t[0]}function I(t){return[...t.entries()].sort(F)}function $([t,i]){let o=`${i.slice(0,4).join(", ")} \\xD7${t}`;return o.length>40&&(o=`${o.slice(0,40)}\\u2026`),o}var S=t=>{let i=new Map;for(let{name:e,count:u}of t)i.set(e,(i.get(e)||0)+u);let o=new Map;for(let[e,u]of i){let A=o.get(u);A?A.push(e):o.set(u,[e])}let h=I(o),s=$(h[0]);for(let e=1,u=h.length;e<u;e++)s+=", "+$(h[e]);return s.length>40?`${s.slice(0,40)}\\u2026`:s},X=t=>{let i=0;for(let o of t)i+=o.width*o.height;return i};var N=(t,i)=>{let o=t.getContext("2d",{alpha:!0});return o&&o.scale(i,i),o},Y=(t,i,o,h)=>{t.clearRect(0,0,i.width/o,i.height/o);let s=new Map,e=new Map;for(let n of h.values()){let{x:r,y:c,width:a,height:g,targetX:l,targetY:d,targetWidth:f,targetHeight:p,frame:O}=n;l!==r&&(n.x=M(r,l)),d!==c&&(n.y=M(c,d)),f!==a&&(n.width=M(a,f)),p!==g&&(n.height=M(g,p));let w=`${l??r},${d??c}`,y=`${w},${f??a},${p??g}`,v=s.get(w);v?v.push(n):s.set(w,[n]);let E=1-O/45;n.frame++;let x=e.get(y)||{x:r,y:c,width:a,height:g,alpha:E};E>x.alpha&&(x.alpha=E),e.set(y,x)}for(let{x:n,y:r,width:c,height:a,alpha:g}of e.values())t.strokeStyle=`rgba(${_},${g})`,t.lineWidth=1,t.beginPath(),t.rect(n,r,c,a),t.stroke(),t.fillStyle=`rgba(${_},${g*.1})`,t.fill();t.font=`11px ${D}`;let u=new Map;t.textRendering="optimizeSpeed";for(let n of s.values()){let r=n[0],{x:c,y:a,frame:g}=r,l=1-g/45,d=S(n),{width:f}=t.measureText(d),p=11;u.set(`${c},${a},${f},${d}`,{text:d,width:f,height:p,alpha:l,x:c,y:a,outlines:n});let O=a-p-4;if(O<0&&(O=0),g>45)for(let w of n)h.delete(String(w.id))}let A=Array.from(u.entries()).sort(([n,r],[c,a])=>X(a.outlines)-X(r.outlines));for(let[n,r]of A)if(u.has(n))for(let[c,a]of u.entries()){if(n===c)continue;let{x:g,y:l,width:d,height:f}=r,{x:p,y:O,width:w,height:y}=a;g+d>p&&p+w>g&&l+f>O&&O+y>l&&(r.text=S(r.outlines.concat(a.outlines)),r.width=t.measureText(r.text).width,u.delete(c))}for(let n of u.values()){let{x:r,y:c,alpha:a,width:g,height:l,text:d}=n,f=c-l-4;f<0&&(f=0),t.fillStyle=`rgba(${_},${a})`,t.fillRect(r,f,g+4,l+4),t.fillStyle=`rgba(255,255,255,${a})`,t.fillText(d,r+2,f+l)}return h.size>0};var m=null,L=null,b=1,T=new Map,C=null,R=()=>{if(!L||!m)return;Y(L,m,b,T)?C=requestAnimationFrame(R):C=null};self.onmessage=t=>{let{type:i}=t.data;if(i==="init"&&(m=t.data.canvas,b=t.data.dpr,m&&(m.width=t.data.width,m.height=t.data.height,L=N(m,b))),!(!m||!L)){if(i==="resize"){b=t.data.dpr,m.width=t.data.width*b,m.height=t.data.height*b,L.resetTransform(),L.scale(b,b),R();return}if(i==="draw-outlines"){let{data:o,names:h}=t.data,s=new Float32Array(o);for(let e=0;e<s.length;e+=7){let u=s[e+2],A=s[e+3],n=s[e+4],r=s[e+5],c=s[e+6],a={id:s[e],name:h[e/7],count:s[e+1],x:u,y:A,width:n,height:r,frame:0,targetX:u,targetY:A,targetWidth:n,targetHeight:r,didCommit:c},g=String(a.id),l=T.get(g);l?(l.count++,l.frame=0,l.targetX=u,l.targetY=A,l.targetWidth=n,l.targetHeight=r,l.didCommit=c):T.set(g,a)}C||(C=requestAnimationFrame(R));return}if(i==="scroll"){let{deltaX:o,deltaY:h}=t.data;for(let s of T.values()){let e=s.x-o,u=s.y-h;s.targetX=e,s.targetY=u}}}};})();\n',worker=null,canvas=null,ctx=null,dpr=1,animationFrameId=null,activeOutlines=new Map,blueprintMap=new Map,blueprintMapKeys=new Set,outlineFiber=__name(fiber=>{if(!isCompositeFiber(fiber))return;const name=typeof fiber.type=="string"?fiber.type:getDisplayName(fiber);if(!name)return;const blueprint=blueprintMap.get(fiber),nearestFibers=getNearestHostFibers(fiber),didCommit=didFiberCommit(fiber);blueprint?blueprint.count++:(blueprintMap.set(fiber,{name,count:1,elements:nearestFibers.map(fiber2=>fiber2.stateNode),didCommit:didCommit?1:0}),blueprintMapKeys.add(fiber))},"outlineFiber"),mergeRects=__name(rects=>{const firstRect=rects[0];if(rects.length===1)return firstRect;let minX,minY,maxX,maxY;for(let i2=0,len=rects.length;i2<len;i2++){const rect=rects[i2];minX=minX==null?rect.x:Math.min(minX,rect.x),minY=minY==null?rect.y:Math.min(minY,rect.y),maxX=maxX==null?rect.x+rect.width:Math.max(maxX,rect.x+rect.width),maxY=maxY==null?rect.y+rect.height:Math.max(maxY,rect.y+rect.height)}return minX==null||minY==null||maxX==null||maxY==null?rects[0]:new DOMRect(minX,minY,maxX-minX,maxY-minY)},"mergeRects");function onIntersect(entries,observer){const newEntries=[];for(const entry of entries){const element=entry.target;this.seenElements.has(element)||(this.seenElements.add(element),newEntries.push(entry))}newEntries.length>0&&this.resolveNext&&(this.resolveNext(newEntries),this.resolveNext=null),this.seenElements.size===this.uniqueElements.size&&(observer.disconnect(),this.done=!0,this.resolveNext&&this.resolveNext([]))}__name(onIntersect,"onIntersect");var getBatchedRectMap=__name(async function*(elements){const state={uniqueElements:new Set(elements),seenElements:new Set,resolveNext:null,done:!1},observer=new IntersectionObserver(onIntersect.bind(state));for(const element of state.uniqueElements)observer.observe(element);for(;!state.done;){const entries=await new Promise(resolve=>{state.resolveNext=resolve});entries.length>0&&(yield entries)}},"getBatchedRectMap"),SupportedArrayBuffer=typeof SharedArrayBuffer<"u"?SharedArrayBuffer:ArrayBuffer,flushOutlines=__name(async()=>{const elements=[];for(const fiber of blueprintMapKeys){const blueprint=blueprintMap.get(fiber);if(blueprint)for(let i2=0;i2<blueprint.elements.length;i2++)blueprint.elements[i2]instanceof Element&&elements.push(blueprint.elements[i2])}const rectsMap=new Map;for await(const entries of getBatchedRectMap(elements)){for(const entry of entries){const element=entry.target,rect=entry.intersectionRect;entry.isIntersecting&&rect.width&&rect.height&&rectsMap.set(element,rect)}const blueprints=[],blueprintRects=[],blueprintIds=[];for(const fiber of blueprintMapKeys){const blueprint=blueprintMap.get(fiber);if(!blueprint)continue;const rects=[];for(let i2=0;i2<blueprint.elements.length;i2++){const element=blueprint.elements[i2],rect=rectsMap.get(element);rect&&rects.push(rect)}rects.length&&(blueprints.push(blueprint),blueprintRects.push(mergeRects(rects)),blueprintIds.push(getFiberId(fiber)))}if(blueprints.length>0){const arrayBuffer=new SupportedArrayBuffer(blueprints.length*OUTLINE_ARRAY_SIZE*4),sharedView=new Float32Array(arrayBuffer),blueprintNames=new Array(blueprints.length);let outlineData;for(let i2=0,len=blueprints.length;i2<len;i2++){const blueprint=blueprints[i2],id=blueprintIds[i2],{x:x2,y:y2,width,height}=blueprintRects[i2],{count,name,didCommit}=blueprint;if(worker){const scaledIndex=i2*OUTLINE_ARRAY_SIZE;sharedView[scaledIndex]=id,sharedView[scaledIndex+1]=count,sharedView[scaledIndex+2]=x2,sharedView[scaledIndex+3]=y2,sharedView[scaledIndex+4]=width,sharedView[scaledIndex+5]=height,sharedView[scaledIndex+6]=didCommit,blueprintNames[i2]=name}else outlineData||(outlineData=new Array(blueprints.length)),outlineData[i2]={id,name,count,x:x2,y:y2,width,height,didCommit}}worker?worker.postMessage({type:"draw-outlines",data:arrayBuffer,names:blueprintNames}):canvas&&ctx&&outlineData&&(updateOutlines(activeOutlines,outlineData),animationFrameId||(animationFrameId=requestAnimationFrame(draw)))}}for(const fiber of blueprintMapKeys)blueprintMap.delete(fiber),blueprintMapKeys.delete(fiber)},"flushOutlines"),draw=__name(()=>{if(!ctx||!canvas)return;drawCanvas(ctx,canvas,dpr,activeOutlines)?animationFrameId=requestAnimationFrame(draw):animationFrameId=null},"draw"),IS_OFFSCREEN_CANVAS_WORKER_SUPPORTED=typeof OffscreenCanvas<"u"&&typeof Worker<"u",getDpr=__name(()=>Math.min(window.devicePixelRatio||1,2),"getDpr"),getCanvasEl=__name(()=>{cleanup();const host=document.createElement("div");host.setAttribute("data-react-scan","true");const shadowRoot2=host.attachShadow({mode:"open"}),canvasEl=document.createElement("canvas");if(canvasEl.style.position="fixed",canvasEl.style.top="0",canvasEl.style.left="0",canvasEl.style.pointerEvents="none",canvasEl.style.zIndex="2147483646",canvasEl.setAttribute("aria-hidden","true"),shadowRoot2.appendChild(canvasEl),!canvasEl)return null;dpr=getDpr(),canvas=canvasEl;const{innerWidth,innerHeight}=window;canvasEl.style.width=`${innerWidth}px`,canvasEl.style.height=`${innerHeight}px`;const width=innerWidth*dpr,height=innerHeight*dpr;canvasEl.width=width,canvasEl.height=height;const useExtensionWorker=readLocalStorage$1("use-extension-worker");if(removeLocalStorage("use-extension-worker"),IS_OFFSCREEN_CANVAS_WORKER_SUPPORTED&&!useExtensionWorker)try{worker=new Worker(URL.createObjectURL(new Blob([workerCode],{type:"application/javascript"})));const offscreenCanvas=canvasEl.transferControlToOffscreen();worker==null||worker.postMessage({type:"init",canvas:offscreenCanvas,width:canvasEl.width,height:canvasEl.height,dpr},[offscreenCanvas])}catch(e2){console.warn("Failed to initialize OffscreenCanvas worker:",e2)}worker||(ctx=initCanvas(canvasEl,dpr));let isResizeScheduled=!1;window.addEventListener("resize",()=>{isResizeScheduled||(isResizeScheduled=!0,setTimeout(()=>{const width2=window.innerWidth,height2=window.innerHeight;dpr=getDpr(),canvasEl.style.width=`${width2}px`,canvasEl.style.height=`${height2}px`,worker?worker.postMessage({type:"resize",width:width2,height:height2,dpr}):(canvasEl.width=width2*dpr,canvasEl.height=height2*dpr,ctx&&(ctx.resetTransform(),ctx.scale(dpr,dpr)),draw()),isResizeScheduled=!1}))});let prevScrollX=window.scrollX,prevScrollY=window.scrollY,isScrollScheduled=!1;return window.addEventListener("scroll",()=>{isScrollScheduled||(isScrollScheduled=!0,setTimeout(()=>{const{scrollX,scrollY}=window,deltaX=scrollX-prevScrollX,deltaY=scrollY-prevScrollY;prevScrollX=scrollX,prevScrollY=scrollY,worker?worker.postMessage({type:"scroll",deltaX,deltaY}):requestAnimationFrame(updateScroll.bind(null,activeOutlines,deltaX,deltaY)),isScrollScheduled=!1},16*2))}),setInterval(()=>{blueprintMapKeys.size&&requestAnimationFrame(flushOutlines)},16*2),shadowRoot2.appendChild(canvasEl),host},"getCanvasEl"),hasStopped=__name(()=>globalThis.__REACT_SCAN_STOP__,"hasStopped"),cleanup=__name(()=>{const host=document.querySelector("[data-react-scan]");host&&host.remove()},"cleanup"),reportInterval,startReportInterval=__name(()=>{clearInterval(reportInterval),reportInterval=setInterval(()=>{},50)},"startReportInterval"),isValidFiber=__name(fiber=>!ignoredProps.has(fiber.memoizedProps),"isValidFiber"),initReactScanInstrumentation=__name(setupToolbar=>{if(hasStopped())return;let schedule,mounted=!1;const scheduleSetup=__name(()=>{mounted||(schedule&&cancelAnimationFrame(schedule),schedule=requestAnimationFrame(()=>{mounted=!0;const host=getCanvasEl();host&&document.documentElement.appendChild(host),setupToolbar()}))},"scheduleSetup"),instrumentation=createInstrumentation("react-scan-devtools-0.1.0",{onCommitStart:__name(()=>{var _a2,_b2;(_b2=(_a2=ReactScanInternals.options.value).onCommitStart)==null||_b2.call(_a2)},"onCommitStart"),onActive:__name(()=>{hasStopped()||(scheduleSetup(),globalThis.__REACT_SCAN__={ReactScanInternals},startReportInterval(),logIntro())},"onActive"),onError:__name(()=>{},"onError"),isValidFiber,onRender:__name((fiber,renders)=>{var _a2,_b2,_c2,_d2;isCompositeFiber(fiber)&&((_a2=Store.interactionListeningForRenders)==null||_a2.call(Store,fiber,renders));const isOverlayPaused=(_b2=ReactScanInternals.instrumentation)==null?void 0:_b2.isPaused.value,isInspectorInactive=Store.inspectState.value.kind==="inspect-off"||Store.inspectState.value.kind==="uninitialized";isOverlayPaused&&isInspectorInactive||(isOverlayPaused||outlineFiber(fiber),ReactScanInternals.options.value.log&&log(renders),Store.inspectState.value.kind==="focused"&&(inspectorUpdateSignal.value=Date.now()),(_d2=(_c2=ReactScanInternals.options.value).onRender)==null||_d2.call(_c2,fiber,renders))},"onRender"),onCommitFinish:__name(()=>{var _a2,_b2;scheduleSetup(),(_b2=(_a2=ReactScanInternals.options.value).onCommitFinish)==null||_b2.call(_a2)},"onCommitFinish"),onPostCommitFiberRoot(){scheduleSetup()},trackChanges:!1});ReactScanInternals.instrumentation=instrumentation},"initReactScanInstrumentation"),styles_default=`*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}/*
! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com
*//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e5e7eb; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #9ca3af; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
.\\!container {
  width: 100% !important;
}
.container {
  width: 100%;
}
@media (min-width: 640px) {

  .\\!container {
    max-width: 640px !important;
  }

  .container {
    max-width: 640px;
  }
}
@media (min-width: 768px) {

  .\\!container {
    max-width: 768px !important;
  }

  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {

  .\\!container {
    max-width: 1024px !important;
  }

  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {

  .\\!container {
    max-width: 1280px !important;
  }

  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {

  .\\!container {
    max-width: 1536px !important;
  }

  .container {
    max-width: 1536px;
  }
}
.pointer-events-none {
  pointer-events: none;
}
.pointer-events-auto {
  pointer-events: auto;
}
.visible {
  visibility: visible;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.inset-0 {
  inset: 0px;
}
.inset-x-1 {
  left: 4px;
  right: 4px;
}
.inset-y-0 {
  top: 0px;
  bottom: 0px;
}
.-right-1 {
  right: -4px;
}
.-right-2\\.5 {
  right: -10px;
}
.-top-1 {
  top: -4px;
}
.-top-2\\.5 {
  top: -10px;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-4 {
  bottom: 16px;
}
.left-0 {
  left: 0px;
}
.left-2 {
  left: 8px;
}
.left-3 {
  left: 12px;
}
.right-0 {
  right: 0px;
}
.right-0\\.5 {
  right: 2px;
}
.right-2 {
  right: 8px;
}
.right-4 {
  right: 16px;
}
.top-0 {
  top: 0px;
}
.top-0\\.5 {
  top: 2px;
}
.top-1\\/2 {
  top: 50%;
}
.top-2 {
  top: 8px;
}
.z-10 {
  z-index: 10;
}
.z-100 {
  z-index: 100;
}
.z-50 {
  z-index: 50;
}
.z-\\[124124124124\\] {
  z-index: 124124124124;
}
.z-\\[214748365\\] {
  z-index: 214748365;
}
.z-\\[214748367\\] {
  z-index: 214748367;
}
.m-\\[2px\\] {
  margin: 2px;
}
.mx-0\\.5 {
  margin-left: 2px;
  margin-right: 2px;
}
.\\!ml-0 {
  margin-left: 0px !important;
}
.mb-1\\.5 {
  margin-bottom: 6px;
}
.mb-2 {
  margin-bottom: 8px;
}
.mb-3 {
  margin-bottom: 12px;
}
.mb-4 {
  margin-bottom: 16px;
}
.mb-px {
  margin-bottom: 1px;
}
.ml-1 {
  margin-left: 4px;
}
.ml-1\\.5 {
  margin-left: 6px;
}
.ml-auto {
  margin-left: auto;
}
.mr-0\\.5 {
  margin-right: 2px;
}
.mr-1 {
  margin-right: 4px;
}
.mr-1\\.5 {
  margin-right: 6px;
}
.mr-16 {
  margin-right: 64px;
}
.mr-auto {
  margin-right: auto;
}
.mt-0\\.5 {
  margin-top: 2px;
}
.mt-1 {
  margin-top: 4px;
}
.mt-4 {
  margin-top: 16px;
}
.block {
  display: block;
}
.inline {
  display: inline;
}
.flex {
  display: flex;
}
.table {
  display: table;
}
.hidden {
  display: none;
}
.aspect-square {
  aspect-ratio: 1 / 1;
}
.h-1 {
  height: 4px;
}
.h-1\\.5 {
  height: 6px;
}
.h-10 {
  height: 40px;
}
.h-12 {
  height: 48px;
}
.h-4 {
  height: 16px;
}
.h-4\\/5 {
  height: 80%;
}
.h-6 {
  height: 24px;
}
.h-7 {
  height: 28px;
}
.h-8 {
  height: 32px;
}
.h-\\[150px\\] {
  height: 150px;
}
.h-\\[235px\\] {
  height: 235px;
}
.h-\\[28px\\] {
  height: 28px;
}
.h-\\[48px\\] {
  height: 48px;
}
.h-\\[50px\\] {
  height: 50px;
}
.h-\\[calc\\(100\\%-150px\\)\\] {
  height: calc(100% - 150px);
}
.h-\\[calc\\(100\\%-200px\\)\\] {
  height: calc(100% - 200px);
}
.h-\\[calc\\(100\\%-25px\\)\\] {
  height: calc(100% - 25px);
}
.h-\\[calc\\(100\\%-40px\\)\\] {
  height: calc(100% - 40px);
}
.h-\\[calc\\(100\\%-48px\\)\\] {
  height: calc(100% - 48px);
}
.h-fit {
  height: -moz-fit-content;
  height: fit-content;
}
.h-full {
  height: 100%;
}
.h-screen {
  height: 100vh;
}
.max-h-0 {
  max-height: 0px;
}
.max-h-40 {
  max-height: 160px;
}
.max-h-8 {
  max-height: 32px;
}
.max-h-9 {
  max-height: 36px;
}
.min-h-9 {
  min-height: 36px;
}
.min-h-\\[48px\\] {
  min-height: 48px;
}
.min-h-fit {
  min-height: -moz-fit-content;
  min-height: fit-content;
}
.w-1 {
  width: 4px;
}
.w-1\\/2 {
  width: 50%;
}
.w-1\\/3 {
  width: 33.333333%;
}
.w-2\\/4 {
  width: 50%;
}
.w-3 {
  width: 12px;
}
.w-4 {
  width: 16px;
}
.w-4\\/5 {
  width: 80%;
}
.w-6 {
  width: 24px;
}
.w-80 {
  width: 320px;
}
.w-\\[5\\%\\] {
  width: 5%;
}
.w-\\[72px\\] {
  width: 72px;
}
.w-\\[90\\%\\] {
  width: 90%;
}
.w-\\[calc\\(100\\%-200px\\)\\] {
  width: calc(100% - 200px);
}
.w-fit {
  width: -moz-fit-content;
  width: fit-content;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.w-screen {
  width: 100vw;
}
.min-w-\\[200px\\] {
  min-width: 200px;
}
.min-w-fit {
  min-width: -moz-fit-content;
  min-width: fit-content;
}
.max-w-md {
  max-width: 448px;
}
.flex-1 {
  flex: 1 1 0%;
}
.grow {
  flex-grow: 1;
}
.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-\\[200\\%\\] {
  --tw-translate-y: -200%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.translate-y-0 {
  --tw-translate-y: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.translate-y-1 {
  --tw-translate-y: 4px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-rotate-90 {
  --tw-rotate: -90deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.rotate-0 {
  --tw-rotate: 0deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.rotate-90 {
  --tw-rotate: 90deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-110 {
  --tw-scale-x: 1.1;
  --tw-scale-y: 1.1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes fadeIn {

  0% {
    opacity: 0;
  }

  100% {
    opacity: 1;
  }
}
.animate-fade-in {
  animation: fadeIn ease-in forwards;
}
.cursor-e-resize {
  cursor: e-resize;
}
.cursor-ew-resize {
  cursor: ew-resize;
}
.cursor-move {
  cursor: move;
}
.cursor-nesw-resize {
  cursor: nesw-resize;
}
.cursor-ns-resize {
  cursor: ns-resize;
}
.cursor-nwse-resize {
  cursor: nwse-resize;
}
.cursor-pointer {
  cursor: pointer;
}
.cursor-w-resize {
  cursor: w-resize;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize {
  resize: both;
}
.appearance-none {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
}
.flex-col {
  flex-direction: column;
}
.items-start {
  align-items: flex-start;
}
.items-end {
  align-items: flex-end;
}
.items-center {
  align-items: center;
}
.items-stretch {
  align-items: stretch;
}
.justify-start {
  justify-content: flex-start;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.gap-0\\.5 {
  gap: 2px;
}
.gap-1 {
  gap: 4px;
}
.gap-1\\.5 {
  gap: 6px;
}
.gap-2 {
  gap: 8px;
}
.gap-4 {
  gap: 16px;
}
.gap-x-0\\.5 {
  -moz-column-gap: 2px;
       column-gap: 2px;
}
.gap-x-1 {
  -moz-column-gap: 4px;
       column-gap: 4px;
}
.gap-x-1\\.5 {
  -moz-column-gap: 6px;
       column-gap: 6px;
}
.gap-x-2 {
  -moz-column-gap: 8px;
       column-gap: 8px;
}
.gap-x-3 {
  -moz-column-gap: 12px;
       column-gap: 12px;
}
.gap-x-4 {
  -moz-column-gap: 16px;
       column-gap: 16px;
}
.gap-y-0\\.5 {
  row-gap: 2px;
}
.gap-y-1 {
  row-gap: 4px;
}
.gap-y-2 {
  row-gap: 8px;
}
.gap-y-4 {
  row-gap: 16px;
}
.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(6px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(6px * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.divide-zinc-800 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(39 39 42 / var(--tw-divide-opacity, 1));
}
.place-self-center {
  place-self: center;
}
.self-end {
  align-self: flex-end;
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.\\!overflow-visible {
  overflow: visible !important;
}
.overflow-x-auto {
  overflow-x: auto;
}
.overflow-y-auto {
  overflow-y: auto;
}
.overflow-x-hidden {
  overflow-x: hidden;
}
.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.text-wrap {
  text-wrap: wrap;
}
.break-words {
  overflow-wrap: break-word;
}
.break-all {
  word-break: break-all;
}
.rounded {
  border-radius: 4px;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 8px;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-sm {
  border-radius: 2px;
}
.rounded-l-sm {
  border-top-left-radius: 2px;
  border-bottom-left-radius: 2px;
}
.rounded-r-sm {
  border-top-right-radius: 2px;
  border-bottom-right-radius: 2px;
}
.rounded-t-lg {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}
.rounded-t-sm {
  border-top-left-radius: 2px;
  border-top-right-radius: 2px;
}
.border {
  border-width: 1px;
}
.border-4 {
  border-width: 4px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-l {
  border-left-width: 1px;
}
.border-l-0 {
  border-left-width: 0px;
}
.border-l-1 {
  border-left-width: 1px;
}
.border-r {
  border-right-width: 1px;
}
.border-t {
  border-top-width: 1px;
}
.\\!border-red-500 {
  --tw-border-opacity: 1 !important;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1)) !important;
}
.border-\\[\\#1e1e1e\\] {
  --tw-border-opacity: 1;
  border-color: rgb(30 30 30 / var(--tw-border-opacity, 1));
}
.border-\\[\\#222\\] {
  --tw-border-opacity: 1;
  border-color: rgb(34 34 34 / var(--tw-border-opacity, 1));
}
.border-\\[\\#27272A\\] {
  --tw-border-opacity: 1;
  border-color: rgb(39 39 42 / var(--tw-border-opacity, 1));
}
.border-\\[\\#333\\] {
  --tw-border-opacity: 1;
  border-color: rgb(51 51 51 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.border-zinc-800 {
  --tw-border-opacity: 1;
  border-color: rgb(39 39 42 / var(--tw-border-opacity, 1));
}
.bg-\\[\\#0A0A0A\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#141414\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(20 20 20 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#18181B\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#18181B\\]\\/50 {
  background-color: rgb(24 24 27 / 0.5);
}
.bg-\\[\\#1D3A66\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(29 58 102 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#1a2a1a\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(26 42 26 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#1e1e1e\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(30 30 30 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#214379d4\\] {
  background-color: #214379d4;
}
.bg-\\[\\#27272A\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(39 39 42 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#2a1515\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(42 21 21 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#412162\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(65 33 98 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#44444a\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(68 68 74 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#4b4b4b\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(75 75 75 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#5f3f9a\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(95 63 154 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#5f3f9a\\]\\/40 {
  background-color: rgb(95 63 154 / 0.4);
}
.bg-\\[\\#6a369e\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(106 54 158 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#7521c8\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(117 33 200 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#8e61e3\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(142 97 227 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#EFD81A\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(239 216 26 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#b77116\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(183 113 22 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#b94040\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(185 64 64 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#d36cff\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(211 108 255 / var(--tw-bg-opacity, 1));
}
.bg-\\[\\#efd81a6b\\] {
  background-color: #efd81a6b;
}
.bg-black {
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
}
.bg-black\\/40 {
  background-color: rgb(0 0 0 / 0.4);
}
.bg-gray-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(229 231 235 / var(--tw-bg-opacity, 1));
}
.bg-green-500\\/50 {
  background-color: rgb(34 197 94 / 0.5);
}
.bg-green-500\\/60 {
  background-color: rgb(34 197 94 / 0.6);
}
.bg-neutral-700 {
  --tw-bg-opacity: 1;
  background-color: rgb(64 64 64 / var(--tw-bg-opacity, 1));
}
.bg-purple-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(168 85 247 / var(--tw-bg-opacity, 1));
}
.bg-purple-500\\/90 {
  background-color: rgb(168 85 247 / 0.9);
}
.bg-purple-800 {
  --tw-bg-opacity: 1;
  background-color: rgb(107 33 168 / var(--tw-bg-opacity, 1));
}
.bg-red-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 68 68 / var(--tw-bg-opacity, 1));
}
.bg-red-500\\/90 {
  background-color: rgb(239 68 68 / 0.9);
}
.bg-red-950\\/50 {
  background-color: rgb(69 10 10 / 0.5);
}
.bg-transparent {
  background-color: transparent;
}
.bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));
}
.bg-yellow-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(253 224 71 / var(--tw-bg-opacity, 1));
}
.bg-zinc-800 {
  --tw-bg-opacity: 1;
  background-color: rgb(39 39 42 / var(--tw-bg-opacity, 1));
}
.bg-zinc-900\\/30 {
  background-color: rgb(24 24 27 / 0.3);
}
.bg-zinc-900\\/50 {
  background-color: rgb(24 24 27 / 0.5);
}
.p-0 {
  padding: 0px;
}
.p-1 {
  padding: 4px;
}
.p-2 {
  padding: 8px;
}
.p-3 {
  padding: 12px;
}
.p-4 {
  padding: 16px;
}
.p-5 {
  padding: 20px;
}
.p-6 {
  padding: 24px;
}
.px-1 {
  padding-left: 4px;
  padding-right: 4px;
}
.px-1\\.5 {
  padding-left: 6px;
  padding-right: 6px;
}
.px-2 {
  padding-left: 8px;
  padding-right: 8px;
}
.px-2\\.5 {
  padding-left: 10px;
  padding-right: 10px;
}
.px-3 {
  padding-left: 12px;
  padding-right: 12px;
}
.px-4 {
  padding-left: 16px;
  padding-right: 16px;
}
.py-0\\.5 {
  padding-top: 2px;
  padding-bottom: 2px;
}
.py-1 {
  padding-top: 4px;
  padding-bottom: 4px;
}
.py-1\\.5 {
  padding-top: 6px;
  padding-bottom: 6px;
}
.py-2 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.py-3 {
  padding-top: 12px;
  padding-bottom: 12px;
}
.py-4 {
  padding-top: 16px;
  padding-bottom: 16px;
}
.py-\\[1px\\] {
  padding-top: 1px;
  padding-bottom: 1px;
}
.py-\\[3px\\] {
  padding-top: 3px;
  padding-bottom: 3px;
}
.py-\\[5px\\] {
  padding-top: 5px;
  padding-bottom: 5px;
}
.pb-2 {
  padding-bottom: 8px;
}
.pl-1 {
  padding-left: 4px;
}
.pl-2 {
  padding-left: 8px;
}
.pl-2\\.5 {
  padding-left: 10px;
}
.pl-3 {
  padding-left: 12px;
}
.pl-5 {
  padding-left: 20px;
}
.pl-6 {
  padding-left: 24px;
}
.pl-9 {
  padding-left: 36px;
}
.pr-1 {
  padding-right: 4px;
}
.pr-1\\.5 {
  padding-right: 6px;
}
.pr-2 {
  padding-right: 8px;
}
.pr-2\\.5 {
  padding-right: 10px;
}
.pt-0 {
  padding-top: 0px;
}
.pt-2 {
  padding-top: 8px;
}
.pt-5 {
  padding-top: 20px;
}
.text-left {
  text-align: left;
}
.font-mono {
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
}
.text-\\[10px\\] {
  font-size: 10px;
}
.text-\\[11px\\] {
  font-size: 11px;
}
.text-\\[13px\\] {
  font-size: 13px;
}
.text-\\[14px\\] {
  font-size: 14px;
}
.text-\\[17px\\] {
  font-size: 17px;
}
.text-\\[8px\\] {
  font-size: 8px;
}
.text-sm {
  font-size: 14px;
  line-height: 20px;
}
.text-xs {
  font-size: 12px;
  line-height: 16px;
}
.font-bold {
  font-weight: 700;
}
.font-medium {
  font-weight: 500;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.capitalize {
  text-transform: capitalize;
}
.italic {
  font-style: italic;
}
.leading-6 {
  line-height: 24px;
}
.leading-none {
  line-height: 1;
}
.tracking-wide {
  letter-spacing: 0.025em;
}
.text-\\[\\#4ade80\\] {
  --tw-text-opacity: 1;
  color: rgb(74 222 128 / var(--tw-text-opacity, 1));
}
.text-\\[\\#5a5a5a\\] {
  --tw-text-opacity: 1;
  color: rgb(90 90 90 / var(--tw-text-opacity, 1));
}
.text-\\[\\#65656D\\] {
  --tw-text-opacity: 1;
  color: rgb(101 101 109 / var(--tw-text-opacity, 1));
}
.text-\\[\\#666\\] {
  --tw-text-opacity: 1;
  color: rgb(102 102 102 / var(--tw-text-opacity, 1));
}
.text-\\[\\#6E6E77\\] {
  --tw-text-opacity: 1;
  color: rgb(110 110 119 / var(--tw-text-opacity, 1));
}
.text-\\[\\#6F6F78\\] {
  --tw-text-opacity: 1;
  color: rgb(111 111 120 / var(--tw-text-opacity, 1));
}
.text-\\[\\#7346a0\\] {
  --tw-text-opacity: 1;
  color: rgb(115 70 160 / var(--tw-text-opacity, 1));
}
.text-\\[\\#888\\] {
  --tw-text-opacity: 1;
  color: rgb(136 136 136 / var(--tw-text-opacity, 1));
}
.text-\\[\\#8E61E3\\] {
  --tw-text-opacity: 1;
  color: rgb(142 97 227 / var(--tw-text-opacity, 1));
}
.text-\\[\\#999\\] {
  --tw-text-opacity: 1;
  color: rgb(153 153 153 / var(--tw-text-opacity, 1));
}
.text-\\[\\#A1A1AA\\] {
  --tw-text-opacity: 1;
  color: rgb(161 161 170 / var(--tw-text-opacity, 1));
}
.text-\\[\\#A855F7\\] {
  --tw-text-opacity: 1;
  color: rgb(168 85 247 / var(--tw-text-opacity, 1));
}
.text-\\[\\#E4E4E7\\] {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}
.text-\\[\\#d36cff\\] {
  --tw-text-opacity: 1;
  color: rgb(211 108 255 / var(--tw-text-opacity, 1));
}
.text-\\[\\#f87171\\] {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}
.text-black {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}
.text-gray-100 {
  --tw-text-opacity: 1;
  color: rgb(243 244 246 / var(--tw-text-opacity, 1));
}
.text-gray-300 {
  --tw-text-opacity: 1;
  color: rgb(209 213 219 / var(--tw-text-opacity, 1));
}
.text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity, 1));
}
.text-gray-500 {
  --tw-text-opacity: 1;
  color: rgb(107 114 128 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-neutral-300 {
  --tw-text-opacity: 1;
  color: rgb(212 212 212 / var(--tw-text-opacity, 1));
}
.text-neutral-400 {
  --tw-text-opacity: 1;
  color: rgb(163 163 163 / var(--tw-text-opacity, 1));
}
.text-neutral-500 {
  --tw-text-opacity: 1;
  color: rgb(115 115 115 / var(--tw-text-opacity, 1));
}
.text-purple-400 {
  --tw-text-opacity: 1;
  color: rgb(192 132 252 / var(--tw-text-opacity, 1));
}
.text-red-300 {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}
.text-red-400 {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-white\\/30 {
  color: rgb(255 255 255 / 0.3);
}
.text-yellow-300 {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}
.text-yellow-500 {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
.text-zinc-200 {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}
.text-zinc-400 {
  --tw-text-opacity: 1;
  color: rgb(161 161 170 / var(--tw-text-opacity, 1));
}
.text-zinc-500 {
  --tw-text-opacity: 1;
  color: rgb(113 113 122 / var(--tw-text-opacity, 1));
}
.text-zinc-600 {
  --tw-text-opacity: 1;
  color: rgb(82 82 91 / var(--tw-text-opacity, 1));
}
.opacity-0 {
  opacity: 0;
}
.opacity-100 {
  opacity: 1;
}
.opacity-50 {
  opacity: 0.5;
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline {
  outline-style: solid;
}
.ring-1 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-white\\/\\[0\\.08\\] {
  --tw-ring-color: rgb(255 255 255 / 0.08);
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.\\!filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow) !important;
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur-sm {
  --tw-backdrop-blur: blur(4px);
  -webkit-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-\\[border-radius\\] {
  transition-property: border-radius;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-\\[color\\2c transform\\] {
  transition-property: color,transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-\\[max-height\\] {
  transition-property: max-height;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-\\[opacity\\] {
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-none {
  transition-property: none;
}
.transition-opacity {
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.delay-0 {
  transition-delay: 0s;
}
.delay-150 {
  transition-delay: 150ms;
}
.delay-300 {
  transition-delay: 300ms;
}
.\\!duration-0 {
  transition-duration: 0s !important;
}
.duration-0 {
  transition-duration: 0s;
}
.duration-200 {
  transition-duration: 200ms;
}
.duration-300 {
  transition-duration: 300ms;
}
.ease-\\[cubic-bezier\\(0\\.23\\2c 1\\2c 0\\.32\\2c 1\\)\\] {
  transition-timing-function: cubic-bezier(0.23,1,0.32,1);
}
.ease-\\[cubic-bezier\\(0\\.25\\2c 0\\.1\\2c 0\\.25\\2c 1\\)\\] {
  transition-timing-function: cubic-bezier(0.25,0.1,0.25,1);
}
.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.will-change-transform {
  will-change: transform;
}
.animation-duration-300 {
  animation-duration: .3s;
}
.animation-delay-300 {
  animation-delay: .3s;
}
.\\[touch-action\\:none\\] {
  touch-action: none;
}

* {
  outline: none !important;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  backface-visibility: hidden;

  /* WebKit (Chrome, Safari, Edge) specific scrollbar styles */
  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  &::-webkit-scrollbar-track {
    border-radius: 10px;
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.3);
  }

  &::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, .4);
  }

  &::-webkit-scrollbar-corner {
    background: transparent;
  }
}

@-moz-document url-prefix() {
  * {
    scrollbar-width: thin;
    scrollbar-color: rgba(255, 255, 255, 0.4) transparent;
    scrollbar-width: 6px;
  }
}


button:hover {
  background-image: none;
}


button {
  outline: 2px solid transparent;
  outline-offset: 2px;
  border-style: none;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
  transition-timing-function: linear;
  cursor: pointer;
}

input {
  border-style: none;
  background-color: transparent;
  background-image: none;
  outline: 2px solid transparent;
  outline-offset: 2px;
}

input::-moz-placeholder {
  font-size: 12px;
  line-height: 16px;
  font-style: italic;
  --tw-text-opacity: 1;
  color: rgb(115 115 115 / var(--tw-text-opacity, 1));
}

input::placeholder {
  font-size: 12px;
  line-height: 16px;
  font-style: italic;
  --tw-text-opacity: 1;
  color: rgb(115 115 115 / var(--tw-text-opacity, 1));
}

input:-moz-placeholder-shown {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

input:placeholder-shown {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

svg {
  height: auto;
  width: auto;
  pointer-events: none;
}

/*
  Using CSS content with data attributes is more performant than:
  1. React re-renders with JSX text content
  2. Direct DOM manipulation methods:
     - element.textContent (creates/updates text nodes, triggers repaint)
     - element.innerText (triggers reflow by computing styles & layout)
     - element.innerHTML (heavy parsing, triggers reflow, security risks)
  3. Multiple data attributes with complex CSS concatenation

  This approach:
  - Avoids React reconciliation
  - Uses browser's native CSS engine (optimized content updates)
  - Minimizes main thread work
  - Reduces DOM operations
  - Avoids forced reflows (layout recalculation)
  - Only triggers necessary repaints
  - Keeps pseudo-element updates in render layer
*/
.with-data-text {
  overflow: hidden;
  &::before {
    content: attr(data-text);
  }
  &::before {
    display: block;
  }
  &::before {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

#react-scan-toolbar {
  position: fixed;
  left: 0px;
  top: 0px;
  display: flex;
  flex-direction: column;
  border-radius: 8px;
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
  font-size: 13px;
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
  cursor: move;
  opacity: 0;
  z-index: 2147483678;
}

@keyframes fadeIn {

  0% {
    opacity: 0;
  }

  100% {
    opacity: 1;
  }
}

#react-scan-toolbar {
  animation: fadeIn ease-in forwards;
  animation-duration: .3s;
  animation-delay: .3s;
  --tw-shadow: 0 4px 12px rgba(0,0,0,0.2);
  --tw-shadow-colored: 0 4px 12px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
  place-self: start;
}

.button {
  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }

  &:active {
    background: rgba(255, 255, 255, 0.15);
  }
}

.resize-line-wrapper {
  position: absolute;
  overflow: hidden;
}

.resize-line {
  position: absolute;
  inset: 0px;
  overflow: hidden;
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;

  svg {
    position: absolute;
  }

  svg {
    top: 50%;
  }

  svg {
    left: 50%;
  }

  svg {
    --tw-translate-x: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  svg {
    --tw-translate-y: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}

.resize-right,
.resize-left {
  top: 0px;
  bottom: 0px;
  width: 24px;
  cursor: ew-resize;

  .resize-line-wrapper {
    top: 0px;
    bottom: 0px;
  }

  .resize-line-wrapper {
    width: 50%;
  }

  &:hover {
    .resize-line {
      --tw-translate-x: 0px;
      transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
    }
  }
}
.resize-right {
  right: 0px;
  --tw-translate-x: 50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));

  .resize-line-wrapper {
    right: 0px;
  }
  .resize-line {
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
  }
  .resize-line {
    --tw-translate-x: -100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}

.resize-left {
  left: 0px;
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));

  .resize-line-wrapper {
    left: 0px;
  }
  .resize-line {
    border-top-left-radius: 8px;
    border-bottom-left-radius: 8px;
  }
  .resize-line {
    --tw-translate-x: 100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}

.resize-top,
.resize-bottom {
  left: 0px;
  right: 0px;
  height: 24px;
  cursor: ns-resize;

  .resize-line-wrapper {
    left: 0px;
    right: 0px;
  }

  .resize-line-wrapper {
    height: 50%;
  }

  &:hover {
    .resize-line {
      --tw-translate-y: 0px;
      transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
    }
  }
}
.resize-top {
  top: 0px;
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));

  .resize-line-wrapper {
    top: 0px;
  }
  .resize-line {
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
  }
  .resize-line {
    --tw-translate-y: 100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}

.resize-bottom {
  bottom: 0px;
  --tw-translate-y: 50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));

  .resize-line-wrapper {
    bottom: 0px;
  }
  .resize-line {
    border-bottom-right-radius: 8px;
    border-bottom-left-radius: 8px;
  }
  .resize-line {
    --tw-translate-y: -100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}

.react-scan-header {
  display: flex;
  align-items: center;
  -moz-column-gap: 8px;
       column-gap: 8px;
  padding-left: 12px;
  padding-right: 8px;
  min-height: 36px;
  border-bottom-width: 1px;
  --tw-border-opacity: 1;
  border-color: rgb(34 34 34 / var(--tw-border-opacity, 1));
  overflow: hidden;
  white-space: nowrap;
}

.react-scan-replay-button,
.react-scan-close-button {
  display: flex;
  align-items: center;
  padding: 4px;
  min-width: -moz-fit-content;
  min-width: fit-content;
  border-radius: 4px;
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 300ms;
}

.react-scan-replay-button {
  position: relative;
  overflow: hidden;
  background-color: rgb(168 85 247 / 0.5) !important;

  &:hover {
    background-color: rgb(168 85 247 / 0.25);
  }

  &.disabled {
    opacity: 0.5;
  }

  &.disabled {
    pointer-events: none;
  }

  &:before {
    content: '';
  }

  &:before {
    position: absolute;
  }

  &:before {
    inset: 0px;
  }

  &:before {
    --tw-translate-x: -100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  &:before {
    animation: shimmer 2s infinite;
    background: linear-gradient(to right,
      transparent,
      rgba(142, 97, 227, 0.3),
      transparent);
  }
}

.react-scan-close-button {
  background-color: rgb(255 255 255 / 0.1);

  &:hover {
    background-color: rgb(255 255 255 / 0.15);
  }
}

@keyframes shimmer {
  100% {
    --tw-translate-x: 100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}

.react-section-header {
  position: sticky;
  z-index: 100;
  display: flex;
  align-items: center;
  -moz-column-gap: 8px;
       column-gap: 8px;
  padding-left: 12px;
  padding-right: 12px;
  height: 28px;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  --tw-text-opacity: 1;
  color: rgb(136 136 136 / var(--tw-text-opacity, 1));
  border-bottom-width: 1px;
  --tw-border-opacity: 1;
  border-color: rgb(34 34 34 / var(--tw-border-opacity, 1));
  --tw-bg-opacity: 1;
  background-color: rgb(10 10 10 / var(--tw-bg-opacity, 1));
}

.react-scan-section {
  display: flex;
  flex-direction: column;
  padding-left: 8px;
  padding-right: 8px;
  --tw-text-opacity: 1;
  color: rgb(136 136 136 / var(--tw-text-opacity, 1));
}

.react-scan-section::before {
  --tw-text-opacity: 1;
  color: rgb(107 114 128 / var(--tw-text-opacity, 1));
  --tw-content: attr(data-section);
  content: var(--tw-content);
}

.react-scan-section {
  font-size: 12px;
  line-height: 16px;

  > .react-scan-property {
    margin-left: -14px;
  }
}

.react-scan-property {
  position: relative;
  display: flex;
  flex-direction: column;
  padding-left: 32px;
  border-left-width: 1px;
  border-color: transparent;
  overflow: hidden;
}

.react-scan-property-content {
  display: flex;
  flex: 1 1 0%;
  flex-direction: column;
  min-height: 28px;
  max-width: 100%;
  overflow: hidden;
}

.react-scan-string {
  color: #9ecbff;
}

.react-scan-number {
  color: #79c7ff;
}

.react-scan-boolean {
  color: #56b6c2;
}

.react-scan-key {
  width: -moz-fit-content;
  width: fit-content;
  max-width: 240px;
  white-space: nowrap;
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}

.react-scan-input {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
}

@keyframes blink {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

.react-scan-arrow {
  position: absolute;
  top: 0px;
  left: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  height: 28px;
  width: 24px;
  --tw-translate-x: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  z-index: 10;

  > svg {
    transition-property: transform;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }
}

.react-scan-expandable {
  display: grid;
  grid-template-rows: 0fr;
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 75ms;

  &.react-scan-expanded {
    grid-template-rows: 1fr;
  }

  &.react-scan-expanded {
    transition-duration: 100ms;
  }
}

.react-scan-nested {
  position: relative;
  overflow: hidden;

  &:before {
    content: '';
  }

  &:before {
    position: absolute;
  }

  &:before {
    top: 0px;
  }

  &:before {
    left: 0px;
  }

  &:before {
    height: 100%;
  }

  &:before {
    width: 1px;
  }

  &:before {
    background-color: rgb(107 114 128 / 0.3);
  }
}

.react-scan-settings {
  position: absolute;
  inset: 0px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-left: 16px;
  padding-right: 16px;
  --tw-text-opacity: 1;
  color: rgb(136 136 136 / var(--tw-text-opacity, 1));

  >div {
    display: flex;
  }

  >div {
    align-items: center;
  }

  >div {
    justify-content: space-between;
  }

  >div {
    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }

  >div {
    transition-duration: 300ms;
  }
}

.react-scan-preview-line {
  position: relative;
  display: flex;
  min-height: 28px;
  align-items: center;
  -moz-column-gap: 8px;
       column-gap: 8px;
}

.react-scan-flash-overlay {
  position: absolute;
  inset: 0px;
  opacity: 0;
  z-index: 50;
  pointer-events: none;
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
  mix-blend-mode: multiply;
  background-color: rgb(168 85 247 / 0.9);
}

.react-scan-toggle {
  position: relative;
  display: inline-flex;
  height: 24px;
  width: 40px;

  input {
    position: absolute;
  }

  input {
    inset: 0px;
  }

  input {
    z-index: 20;
  }

  input {
    opacity: 0;
  }

  input {
    cursor: pointer;
  }

  input {
    height: 100%;
  }

  input {
    width: 100%;
  }

  input:checked {
    +div {
      --tw-bg-opacity: 1;
      background-color: rgb(95 63 154 / var(--tw-bg-opacity, 1));
    }
    +div {

      &::before {
        --tw-translate-x: 100%;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
      }

      &::before {
        left: auto;
      }

      &::before {
        --tw-border-opacity: 1;
        border-color: rgb(95 63 154 / var(--tw-border-opacity, 1));
      }
    }
  }

  >div {
    position: absolute;
  }

  >div {
    inset: 4px;
  }

  >div {
    --tw-bg-opacity: 1;
    background-color: rgb(64 64 64 / var(--tw-bg-opacity, 1));
  }

  >div {
    border-radius: 9999px;
  }

  >div {
    pointer-events: none;
  }

  >div {
    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }

  >div {
    transition-duration: 300ms;
  }

  >div {

    &:before {
      --tw-content: '';
      content: var(--tw-content);
    }

    &:before {
      position: absolute;
    }

    &:before {
      top: 50%;
    }

    &:before {
      left: 0px;
    }

    &:before {
      --tw-translate-y: -50%;
      transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
    }

    &:before {
      height: 16px;
    }

    &:before {
      width: 16px;
    }

    &:before {
      --tw-bg-opacity: 1;
      background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));
    }

    &:before {
      border-width: 2px;
    }

    &:before {
      --tw-border-opacity: 1;
      border-color: rgb(64 64 64 / var(--tw-border-opacity, 1));
    }

    &:before {
      border-radius: 9999px;
    }

    &:before {
      --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
      --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
      box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
    }

    &:before {
      transition-property: all;
      transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
      transition-duration: 150ms;
    }

    &:before {
      transition-duration: 300ms;
    }
  }
}

.react-scan-flash-active {
  opacity: 0.4;
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 300ms;
}

.react-scan-inspector-overlay {
  display: flex;
  flex-direction: column;
  opacity: 0;
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 300ms;

  &.fade-out {
    opacity: 0;
  }

  &.fade-in {
    opacity: 1;
  }
}

.react-scan-what-changed {
  ul {
    list-style-type: disc;
  }
  ul {
    padding-left: 16px;
  }

  li {
    white-space: nowrap;
  }

  li {
    > div {
      display: flex;
    }
    > div {
      align-items: center;
    }
    > div {
      justify-content: space-between;
    }
    > div {
      -moz-column-gap: 8px;
           column-gap: 8px;
    }
  }
}

.count-badge {
  display: flex;
  align-items: center;
  -moz-column-gap: 8px;
       column-gap: 8px;
  padding-left: 6px;
  padding-right: 6px;
  padding-top: 2px;
  padding-bottom: 2px;
  border-radius: 4px;
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  --tw-numeric-spacing: tabular-nums;
  font-variant-numeric: var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction);
  --tw-text-opacity: 1;
  color: rgb(168 85 247 / var(--tw-text-opacity, 1));
  background-color: rgb(168 85 247 / 0.1);
  transform-origin: center;
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-delay: 150ms;
  transition-duration: 300ms;
}

@keyframes countFlash {

  0% {
    background-color: rgba(168, 85, 247, 0.3);
    transform: scale(1.05);
  }

  100% {
    background-color: rgba(168, 85, 247, 0.1);
    transform: scale(1);
  }
}

.count-flash {
  animation: countFlash .3s ease-out forwards;
}

@keyframes countFlashShake {

  0% {
    transform: translateX(0);
  }

  25% {
    transform: translateX(-5px);
  }

  50% {
    transform: translateX(5px) scale(1.1);
  }

  75% {
    transform: translateX(-5px);
  }

  100% {
    transform: translateX(0);
  }
}

.count-flash-white {
  animation: countFlashShake .3s ease-out forwards;
  transition-delay: 500ms !important;
}

.change-scope {
  display: flex;
  align-items: center;
  -moz-column-gap: 4px;
       column-gap: 4px;
  --tw-text-opacity: 1;
  color: rgb(102 102 102 / var(--tw-text-opacity, 1));
  font-size: 12px;
  line-height: 16px;
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;

  > div {
    padding-left: 6px;
    padding-right: 6px;
  }

  > div {
    padding-top: 2px;
    padding-bottom: 2px;
  }

  > div {
    transform-origin: center;
  }

  > div {
    border-radius: 4px;
  }

  > div {
    font-size: 12px;
    line-height: 16px;
  }

  > div {
    font-weight: 500;
  }

  > div {
    --tw-numeric-spacing: tabular-nums;
    font-variant-numeric: var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction);
  }

  > div {
    transform-origin: center;
  }

  > div {
    transition-property: all;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }

  > div {
    transition-delay: 150ms;
  }

  > div {
    transition-duration: 300ms;
  }

  > div {

    &[data-flash="true"] {
      background-color: rgb(168 85 247 / 0.1);
    }

    &[data-flash="true"] {
      --tw-text-opacity: 1;
      color: rgb(168 85 247 / var(--tw-text-opacity, 1));
    }
  }
}

.react-scan-slider {
  position: relative;
  min-height: 24px;

  > input {
    position: absolute;
  }

  > input {
    inset: 0px;
  }

  > input {
    opacity: 0;
  }

  &:before {
    --tw-content: '';
    content: var(--tw-content);
  }

  &:before {
    position: absolute;
  }

  &:before {
    left: 0px;
    right: 0px;
  }

  &:before {
    top: 50%;
  }

  &:before {
    --tw-translate-y: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  &:before {
    height: 6px;
  }

  &:before {
    background-color: rgb(142 97 227 / 0.4);
  }

  &:before {
    border-radius: 8px;
  }

  &:before {
    pointer-events: none;
  }

  &:after {
    --tw-content: '';
    content: var(--tw-content);
  }

  &:after {
    position: absolute;
  }

  &:after {
    left: 0px;
    right: 0px;
  }

  &:after {
    top: -8px;
    bottom: -8px;
  }

  &:after {
    z-index: -10;
  }

  span {
    position: absolute;
  }

  span {
    left: 0px;
  }

  span {
    top: 50%;
  }

  span {
    --tw-translate-y: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  span {
    height: 10px;
  }

  span {
    width: 10px;
  }

  span {
    border-radius: 8px;
  }

  span {
    --tw-bg-opacity: 1;
    background-color: rgb(142 97 227 / var(--tw-bg-opacity, 1));
  }

  span {
    pointer-events: none;
  }

  span {
    transition-property: transform;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }

  span {
    transition-duration: 75ms;
  }
}

.resize-v-line {
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 4px;
  max-width: 4px;
  height: 100%;
  width: 100%;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;

  &:hover,
  &:active {
    > span {
      --tw-bg-opacity: 1;
      background-color: rgb(34 34 34 / var(--tw-bg-opacity, 1));
    }

    svg {
      opacity: 1;
    }
  }

  &::before {
    --tw-content: "";
    content: var(--tw-content);
  }

  &::before {
    position: absolute;
  }

  &::before {
    inset: 0px;
  }

  &::before {
    left: 50%;
  }

  &::before {
    --tw-translate-x: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  &::before {
    width: 1px;
  }

  &::before {
    --tw-bg-opacity: 1;
    background-color: rgb(34 34 34 / var(--tw-bg-opacity, 1));
  }

  &::before {
    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }

  > span {
    position: absolute;
  }

  > span {
    left: 50%;
  }

  > span {
    top: 50%;
  }

  > span {
    --tw-translate-x: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  > span {
    --tw-translate-y: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  > span {
    height: 18px;
  }

  > span {
    width: 6px;
  }

  > span {
    border-radius: 4px;
  }

  > span {
    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }

  svg {
    position: absolute;
  }

  svg {
    left: 50%;
  }

  svg {
    top: 50%;
  }

  svg {
    --tw-translate-x: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  svg {
    --tw-translate-y: -50%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  svg {
    --tw-rotate: 90deg;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  svg {
    --tw-text-opacity: 1;
    color: rgb(163 163 163 / var(--tw-text-opacity, 1));
  }

  svg {
    opacity: 0;
  }

  svg {
    transition-property: opacity;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }

  svg {
    z-index: 50;
  }
}


.tree-node-search-highlight {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

  span {
    padding-top: 1px;
    padding-bottom: 1px;
  }

  span {
    border-radius: 2px;
  }

  span {
    --tw-bg-opacity: 1;
    background-color: rgb(253 224 71 / var(--tw-bg-opacity, 1));
  }

  span {
    font-weight: 500;
  }

  span {
    --tw-text-opacity: 1;
    color: rgb(0 0 0 / var(--tw-text-opacity, 1));
  }

  .single {
    margin-right: 1px;
  }

  .single {
    padding-left: 2px;
    padding-right: 2px;
  }

  .regex {
    padding-left: 2px;
    padding-right: 2px;
  }

  .start {
    margin-left: 1px;
  }

  .start {
    border-top-left-radius: 2px;
    border-bottom-left-radius: 2px;
  }

  .end {
    margin-right: 1px;
  }

  .end {
    border-top-right-radius: 2px;
    border-bottom-right-radius: 2px;
  }

  .middle {
    margin-left: 1px;
    margin-right: 1px;
  }

  .middle {
    border-radius: 2px;
  }
}

.react-scan-toolbar-notification {
  position: absolute;
  left: 0px;
  right: 0px;
  display: flex;
  align-items: center;
  -moz-column-gap: 8px;
       column-gap: 8px;
  padding: 4px;
  padding-left: 8px;
  font-size: 10px;
  --tw-text-opacity: 1;
  color: rgb(212 212 212 / var(--tw-text-opacity, 1));
  background-color: rgb(0 0 0 / 0.9);
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;

  &:before {
    --tw-content: '';
    content: var(--tw-content);
  }

  &:before {
    position: absolute;
  }

  &:before {
    left: 0px;
    right: 0px;
  }

  &:before {
    --tw-bg-opacity: 1;
    background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  }

  &:before {
    height: 8px;
  }

  &.position-top {
    top: 100%;
  }

  &.position-top {
    --tw-translate-y: -100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  &.position-top {
    border-bottom-right-radius: 8px;
    border-bottom-left-radius: 8px;
  }

  &.position-top {

    &::before {
      top: 0px;
    }

    &::before {
      --tw-translate-y: -100%;
      transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
    }
  }

  &.position-bottom {
    bottom: 100%;
  }

  &.position-bottom {
    --tw-translate-y: 100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }

  &.position-bottom {
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
  }

  &.position-bottom {

    &::before {
      bottom: 0px;
    }

    &::before {
      --tw-translate-y: 100%;
      transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
    }

  }

  &.is-open {
    --tw-translate-y: 0px;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}


.react-scan-header-item {
  position: absolute;
  inset: 0px;
  --tw-translate-y: -200%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 300ms;

  &.is-visible {
    --tw-translate-y: 0px;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
}

.react-scan-components-tree:has(.resize-v-line:hover, .resize-v-line:active) .tree {
  overflow: hidden;
}

.before\\:absolute::before {
  content: var(--tw-content);
  position: absolute;
}

.before\\:inset-x-0::before {
  content: var(--tw-content);
  left: 0px;
  right: 0px;
}

.before\\:bottom-0::before {
  content: var(--tw-content);
  bottom: 0px;
}

.before\\:h-\\[1px\\]::before {
  content: var(--tw-content);
  height: 1px;
}

.before\\:bg-\\[\\#333\\]::before {
  content: var(--tw-content);
  --tw-bg-opacity: 1;
  background-color: rgb(51 51 51 / var(--tw-bg-opacity, 1));
}

.before\\:content-\\[\\"\\"\\]::before {
  --tw-content: "";
  content: var(--tw-content);
}

.after\\:absolute::after {
  content: var(--tw-content);
  position: absolute;
}

.after\\:inset-0::after {
  content: var(--tw-content);
  inset: 0px;
}

.after\\:left-1\\/2::after {
  content: var(--tw-content);
  left: 50%;
}

.after\\:top-\\[100\\%\\]::after {
  content: var(--tw-content);
  top: 100%;
}

.after\\:h-\\[6px\\]::after {
  content: var(--tw-content);
  height: 6px;
}

.after\\:w-\\[10px\\]::after {
  content: var(--tw-content);
  width: 10px;
}

.after\\:-translate-x-1\\/2::after {
  content: var(--tw-content);
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

@keyframes fadeOut {

  0% {
    content: var(--tw-content);
    opacity: 1;
  }

  100% {
    content: var(--tw-content);
    opacity: 0;
  }
}

.after\\:animate-\\[fadeOut_1s_ease-out_forwards\\]::after {
  content: var(--tw-content);
  animation: fadeOut 1s ease-out forwards;
}

.after\\:border-l-\\[5px\\]::after {
  content: var(--tw-content);
  border-left-width: 5px;
}

.after\\:border-r-\\[5px\\]::after {
  content: var(--tw-content);
  border-right-width: 5px;
}

.after\\:border-t-\\[6px\\]::after {
  content: var(--tw-content);
  border-top-width: 6px;
}

.after\\:border-l-transparent::after {
  content: var(--tw-content);
  border-left-color: transparent;
}

.after\\:border-r-transparent::after {
  content: var(--tw-content);
  border-right-color: transparent;
}

.after\\:border-t-white::after {
  content: var(--tw-content);
  --tw-border-opacity: 1;
  border-top-color: rgb(255 255 255 / var(--tw-border-opacity, 1));
}

.after\\:bg-purple-500\\/30::after {
  content: var(--tw-content);
  background-color: rgb(168 85 247 / 0.3);
}

.after\\:content-\\[\\"\\"\\]::after {
  --tw-content: "";
  content: var(--tw-content);
}

.focus-within\\:border-\\[\\#454545\\]:focus-within {
  --tw-border-opacity: 1;
  border-color: rgb(69 69 69 / var(--tw-border-opacity, 1));
}

.hover\\:bg-\\[\\#0f0f0f\\]:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(15 15 15 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-\\[\\#18181B\\]:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-\\[\\#34343b\\]:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(52 52 59 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-\\[\\#5f3f9a\\]\\/20:hover {
  background-color: rgb(95 63 154 / 0.2);
}

.hover\\:bg-\\[\\#5f3f9a\\]\\/40:hover {
  background-color: rgb(95 63 154 / 0.4);
}

.hover\\:bg-red-600:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-zinc-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-zinc-800\\/50:hover {
  background-color: rgb(39 39 42 / 0.5);
}

.hover\\:text-neutral-300:hover {
  --tw-text-opacity: 1;
  color: rgb(212 212 212 / var(--tw-text-opacity, 1));
}

.hover\\:text-white:hover {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}

.group:hover .group-hover\\:bg-\\[\\#21437982\\] {
  background-color: #21437982;
}

.group:hover .group-hover\\:bg-\\[\\#5b2d89\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(91 45 137 / var(--tw-bg-opacity, 1));
}

.group:hover .group-hover\\:bg-\\[\\#6a6a6a\\] {
  --tw-bg-opacity: 1;
  background-color: rgb(106 106 106 / var(--tw-bg-opacity, 1));
}

.group:hover .group-hover\\:bg-\\[\\#efda1a2f\\] {
  background-color: #efda1a2f;
}

.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}

.peer\\/bottom:hover ~ .peer-hover\\/bottom\\:rounded-b-none {
  border-bottom-right-radius: 0px;
  border-bottom-left-radius: 0px;
}

.peer\\/left:hover ~ .peer-hover\\/left\\:rounded-l-none {
  border-top-left-radius: 0px;
  border-bottom-left-radius: 0px;
}

.peer\\/right:hover ~ .peer-hover\\/right\\:rounded-r-none {
  border-top-right-radius: 0px;
  border-bottom-right-radius: 0px;
}

.peer\\/top:hover ~ .peer-hover\\/top\\:rounded-t-none {
  border-top-left-radius: 0px;
  border-top-right-radius: 0px;
}
`,useDelayedValue=__name((value,onDelay,offDelay=onDelay)=>{const[delayedValue,setDelayedValue]=h$1(value);return y$1(()=>{if(value===delayedValue)return;const timeout2=setTimeout(()=>setDelayedValue(value),value?onDelay:offDelay);return()=>clearTimeout(timeout2)},[value,onDelay,offDelay]),delayedValue},"useDelayedValue"),headerInspectClassName=w(()=>cn("absolute inset-0 flex items-center gap-x-2","translate-y-0","transition-transform duration-300",signalIsSettingsOpen.value&&"-translate-y-[200%]")),HeaderInspect=__name(()=>{const refReRenders=A$1(null),refTiming=A$1(null),[currentFiber,setCurrentFiber]=h$1(null);useSignalEffect(()=>{const state=Store.inspectState.value;state.kind==="focused"&&setCurrentFiber(state.fiber)}),useSignalEffect(()=>{const state=timelineState.value;n(()=>{var _a2,_b2;if(Store.inspectState.value.kind!=="focused"||!refReRenders.current||!refTiming.current)return;const{totalUpdates,currentIndex,updates,isVisible,windowOffset}=state,reRenders=Math.max(0,totalUpdates-1),headerText=isVisible?`#${windowOffset+currentIndex} Re-render`:reRenders>0?`×${reRenders}`:"";let formattedTime;if(reRenders>0&&currentIndex>=0&&currentIndex<updates.length){const time=(_b2=(_a2=updates[currentIndex])==null?void 0:_a2.fiberInfo)==null?void 0:_b2.selfTime;formattedTime=time>0?time<.1-Number.EPSILON?"< 0.1ms":`${Number(time.toFixed(1))}ms`:void 0}refReRenders.current.dataset.text=headerText?` • ${headerText}`:"",refTiming.current.dataset.text=formattedTime?` • ${formattedTime}`:""})});const componentName=T$1(()=>{if(!currentFiber)return null;const{name,wrappers,wrapperTypes}=getExtendedDisplayName(currentFiber),title=wrappers.length?`${wrappers.join("(")}(${name})${")".repeat(wrappers.length)}`:name??"",firstWrapperType=wrapperTypes[0];return u("span",{title,className:"flex items-center gap-x-1",children:[name??"Unknown",u("span",{title:firstWrapperType==null?void 0:firstWrapperType.title,className:"flex items-center gap-x-1 text-[10px] text-purple-400",children:!!firstWrapperType&&u(k$1,{children:[u("span",{className:cn("rounded py-[1px] px-1","truncate",firstWrapperType.compiler&&"bg-purple-800 text-neutral-400",!firstWrapperType.compiler&&"bg-neutral-700 text-neutral-300",firstWrapperType.type==="memo"&&"bg-[#5f3f9a] text-white"),children:firstWrapperType.type},firstWrapperType.type),firstWrapperType.compiler&&u("span",{className:"text-yellow-300",children:"✨"})]})}),wrapperTypes.length>1&&u("span",{className:"text-[10px] text-neutral-400",children:["×",wrapperTypes.length-1]})]})},[currentFiber]);return u("div",{className:headerInspectClassName,children:[componentName,u("div",{className:"flex items-center gap-x-2 mr-auto text-xs text-[#888]",children:[u("span",{ref:refReRenders,className:"with-data-text cursor-pointer !overflow-visible",title:"Click to toggle between rerenders and total renders"}),u("span",{ref:refTiming,className:"with-data-text !overflow-visible"})]})]})},"HeaderInspect"),Header=__name(()=>{const isInitialView=useDelayedValue(Store.inspectState.value.kind==="focused",150,0),handleClose=__name(()=>{signalWidgetViews.value={view:"none"},Store.inspectState.value={kind:"inspect-off"}},"handleClose");if(signalWidgetViews.value.view!=="notifications")return u("div",{className:"react-scan-header",children:[u("div",{className:"relative flex-1 h-full",children:u("div",{className:cn("react-scan-header-item is-visible",!isInitialView&&"!duration-0"),children:u(HeaderInspect,{})})}),u("button",{type:"button",title:"Close",className:"react-scan-close-button",onClick:handleClose,children:u(Icon,{name:"icon-close"})})]})},"Header"),Toggle=__name(({className,...props})=>u("div",{className:cn("react-scan-toggle",className),children:[u("input",{type:"checkbox",...props}),u("div",{})]}),"Toggle"),FpsMeterInner=__name(({fps:fps2})=>{const getColor=__name(fps3=>fps3<30?"#EF4444":fps3<50?"#F59E0B":"rgb(214,132,245)","getColor");return u("div",{className:cn("flex items-center gap-x-1 px-2 w-full","h-6","rounded-md","font-mono leading-none","bg-[#141414]","ring-1 ring-white/[0.08]"),children:[u("div",{style:{color:getColor(fps2)},className:"text-sm font-semibold tracking-wide transition-colors ease-in-out w-full flex justify-center items-center",children:fps2}),u("span",{className:"text-white/30 text-[11px] font-medium tracking-wide ml-auto min-w-fit",children:"FPS"})]})},"FpsMeterInner"),FPSMeter=__name(()=>{const[fps2,setFps]=h$1(null);return y$1(()=>{const intervalId=setInterval(()=>{setFps(getFPS())},200);return()=>clearInterval(intervalId)},[]),u("div",{className:cn("flex items-center justify-end gap-x-2 px-1 ml-1 w-[72px]","whitespace-nowrap text-sm text-white"),children:fps2===null?u(k$1,{children:"️"}):u(FpsMeterInner,{fps:fps2})})},"FPSMeter"),getComponentName=__name(path=>{const filteredPath=path.filter(item=>item.length>2);return filteredPath.length===0?path.at(-1)??"Unknown":filteredPath.at(-1)},"getComponentName"),getTotalTime=__name(timing=>{switch(timing.kind){case"interaction":{const{renderTime,otherJSTime,framePreparation,frameConstruction,frameDraw}=timing;return renderTime+otherJSTime+framePreparation+frameConstruction+(frameDraw??0)}case"dropped-frames":return timing.otherTime+timing.renderTime}},"getTotalTime"),isRenderMemoizable=__name(gropedFiberRender=>gropedFiberRender.changes.context.length===0&&gropedFiberRender.changes.props.length===0&&gropedFiberRender.changes.state.length===0,"isRenderMemoizable"),getEventSeverity=__name(event=>{const totalTime=getTotalTime(event.timing);switch(event.kind){case"interaction":return totalTime<200?"low":totalTime<500?"needs-improvement":"high";case"dropped-frames":return totalTime<50?"low":totalTime<100?"needs-improvement":"high"}},"getEventSeverity"),useNotificationsContext=__name(()=>x(NotificationStateContext),"useNotificationsContext"),NotificationStateContext=J$1(null),ChevronRight=__name(({size=24,className})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className:cn(["lucide lucide-chevron-right",className]),children:u("path",{d:"m9 18 6-6-6-6"})}),"ChevronRight"),Notification=__name(({className="",size=24,events=[]})=>{const hasHighSeverity=events.includes(!0),totalSevere=events.filter(e2=>e2).length,displayCount=totalSevere>99?">99":totalSevere,badgeSize=hasHighSeverity?Math.max(size*.6,14):Math.max(size*.4,6);return u("div",{className:"relative",children:[u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className:`lucide lucide-bell ${className}`,children:[u("path",{d:"M10.268 21a2 2 0 0 0 3.464 0"}),u("path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"})]}),events.length>0&&totalSevere>0&&u("div",{className:cn(["absolute",hasHighSeverity?"-top-2.5 -right-2.5":"-top-1 -right-1","rounded-full","flex items-center justify-center","text-[8px] font-medium text-white","aspect-square",hasHighSeverity?"bg-red-500/90":"bg-purple-500/90"]),style:{width:`${badgeSize}px`,height:`${badgeSize}px`,padding:hasHighSeverity?"0.5px":"0"},children:hasHighSeverity&&displayCount})]})},"Notification"),CloseIcon=__name(({className="",size=24})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u("path",{d:"M18 6 6 18"}),u("path",{d:"m6 6 12 12"})]}),"CloseIcon"),VolumeOnIcon=__name(({className="",size=24})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u("path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"}),u("path",{d:"M16 9a5 5 0 0 1 0 6"}),u("path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728"})]}),"VolumeOnIcon"),VolumeOffIcon=__name(({className="",size=24})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u("path",{d:"M16 9a5 5 0 0 1 .95 2.293"}),u("path",{d:"M19.364 5.636a9 9 0 0 1 1.889 9.96"}),u("path",{d:"m2 2 20 20"}),u("path",{d:"m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11"}),u("path",{d:"M9.828 4.172A.686.686 0 0 1 11 4.657v.686"})]}),"VolumeOffIcon"),ArrowLeft=__name(({size=24,className})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className:cn(["lucide lucide-arrow-left",className]),children:[u("path",{d:"m12 19-7-7 7-7"}),u("path",{d:"M19 12H5"})]}),"ArrowLeft"),PointerIcon=__name(({className="",size=24})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u("path",{d:"M14 4.1 12 6"}),u("path",{d:"m5.1 8-2.9-.8"}),u("path",{d:"m6 12-1.9 2"}),u("path",{d:"M7.2 2.2 8 5.1"}),u("path",{d:"M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z"})]}),"PointerIcon"),KeyboardIcon=__name(({className="",size=24})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u("path",{d:"M10 8h.01"}),u("path",{d:"M12 12h.01"}),u("path",{d:"M14 8h.01"}),u("path",{d:"M16 12h.01"}),u("path",{d:"M18 8h.01"}),u("path",{d:"M6 8h.01"}),u("path",{d:"M7 16h10"}),u("path",{d:"M8 12h.01"}),u("rect",{width:"20",height:"16",x:"2",y:"4",rx:"2"})]}),"KeyboardIcon"),ClearIcon=__name(({className="",size=24})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,style:{transform:"rotate(180deg)"},children:[u("circle",{cx:"12",cy:"12",r:"10"}),u("path",{d:"m4.9 4.9 14.2 14.2"})]}),"ClearIcon"),TrendingDownIcon=__name(({className="",size=24})=>u("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className,children:[u("polyline",{points:"22 17 13.5 8.5 8.5 13.5 2 7"}),u("polyline",{points:"16 17 22 17 22 11"})]}),"TrendingDownIcon"),not_globally_unique_generateId=__name(()=>IS_CLIENT?(window.reactScanIdCounter===void 0&&(window.reactScanIdCounter=0),`${++window.reactScanIdCounter}`):"0","not_globally_unique_generateId"),iife=__name(fn2=>fn2(),"iife"),BoundedArray=(_b=class extends Array{constructor(capacity=25){super(),this.capacity=capacity}push(...items){const result=super.push(...items);for(;this.length>this.capacity;)this.shift();return result}static fromArray(array,capacity){const arr=new _b(capacity);return arr.push(...array),arr}},__name(_b,"_BoundedArray"),_b),Store2=(_c=class{constructor(initialValue){this.subscribers=new Set,this.currentValue=initialValue}subscribe(subscriber){return this.subscribers.add(subscriber),subscriber(this.currentValue),()=>{this.subscribers.delete(subscriber)}}setState(data){this.currentValue=data,this.subscribers.forEach(subscriber=>subscriber(data))}getCurrentState(){return this.currentValue}},__name(_c,"Store2"),_c),MAX_INTERACTION_BATCH=150,interactionStore=new Store2(new BoundedArray(MAX_INTERACTION_BATCH)),MAX_CHANNEL_SIZE=50,PerformanceEntryChannels=(_d=class{constructor(){this.channels={}}publish(item,to,createIfNoChannel=!0){const existingChannel=this.channels[to];if(!existingChannel){if(!createIfNoChannel)return;this.channels[to]={callbacks:new BoundedArray(MAX_CHANNEL_SIZE),state:new BoundedArray(MAX_CHANNEL_SIZE)},this.channels[to].state.push(item);return}existingChannel.state.push(item),existingChannel.callbacks.forEach(cb=>cb(item))}getAvailableChannels(){return BoundedArray.fromArray(Object.keys(this.channels),MAX_CHANNEL_SIZE)}subscribe(to,cb,dropFirst=!1){const defer=__name(()=>(dropFirst||this.channels[to].state.forEach(item=>{cb(item)}),()=>{const filtered=this.channels[to].callbacks.filter(subscribed=>subscribed!==cb);this.channels[to].callbacks=BoundedArray.fromArray(filtered,MAX_CHANNEL_SIZE)}),"defer"),existing=this.channels[to];return existing?(existing.callbacks.push(cb),defer()):(this.channels[to]={callbacks:new BoundedArray(MAX_CHANNEL_SIZE),state:new BoundedArray(MAX_CHANNEL_SIZE)},this.channels[to].callbacks.push(cb),defer())}updateChannelState(channel,updater,createIfNoChannel=!0){const existingChannel=this.channels[channel];if(!existingChannel){if(!createIfNoChannel)return;const state=new BoundedArray(MAX_CHANNEL_SIZE),newChannel={callbacks:new BoundedArray(MAX_CHANNEL_SIZE),state};this.channels[channel]=newChannel,newChannel.state=updater(state);return}existingChannel.state=updater(existingChannel.state)}getChannelState(channel){return this.channels[channel].state??new BoundedArray(MAX_CHANNEL_SIZE)}},__name(_d,"PerformanceEntryChannels"),_d),performanceEntryChannels=new PerformanceEntryChannels,DEFAULT_FILTERS={skipProviders:!0,skipHocs:!0,skipContainers:!0,skipMinified:!0,skipUtilities:!0,skipBoundaries:!0},FILTER_PATTERNS={providers:[/Provider$/,/^Provider$/,/^Context$/],hocs:[/^with[A-Z]/,/^forward(?:Ref)?$/i,/^Forward(?:Ref)?\(/],containers:[/^(?:App)?Container$/,/^Root$/,/^ReactDev/],utilities:[/^Fragment$/,/^Suspense$/,/^ErrorBoundary$/,/^Portal$/,/^Consumer$/,/^Layout$/,/^Router/,/^Hydration/],boundaries:[/^Boundary$/,/Boundary$/,/^Provider$/,/Provider$/]},shouldIncludeInPath=__name((name,filters=DEFAULT_FILTERS)=>{const patternsToCheck=[];return filters.skipProviders&&patternsToCheck.push(...FILTER_PATTERNS.providers),filters.skipHocs&&patternsToCheck.push(...FILTER_PATTERNS.hocs),filters.skipContainers&&patternsToCheck.push(...FILTER_PATTERNS.containers),filters.skipUtilities&&patternsToCheck.push(...FILTER_PATTERNS.utilities),filters.skipBoundaries&&patternsToCheck.push(...FILTER_PATTERNS.boundaries),!patternsToCheck.some(pattern=>pattern.test(name))},"shouldIncludeInPath"),minifiedPatterns=[/^[a-z]$/,/^[a-z][0-9]$/,/^_+$/,/^[A-Za-z][_$]$/,/^[a-z]{1,2}$/],isMinified=__name(name=>{var _a2;for(let i2=0;i2<minifiedPatterns.length;i2++)if(minifiedPatterns[i2].test(name))return!0;const hasNoVowels=!/[aeiou]/i.test(name),hasMostlyNumbers=(((_a2=name.match(/\d/g))==null?void 0:_a2.length)??0)>name.length/2,isSingleWordLowerCase=/^[a-z]+$/.test(name),hasRandomLookingChars=/[$_]{2,}/.test(name);return Number(hasNoVowels)+Number(hasMostlyNumbers)+Number(isSingleWordLowerCase)+Number(hasRandomLookingChars)>=2},"isMinified"),getInteractionPath=__name((initialFiber,filters=DEFAULT_FILTERS)=>{if(!initialFiber)return[];if(!getDisplayName(initialFiber.type))return[];const stack=new Array;let fiber=initialFiber;for(;fiber.return;){const name=getCleanComponentName(fiber.type);name&&!isMinified(name)&&shouldIncludeInPath(name,filters)&&name.toLowerCase()!==name&&stack.push(name),fiber=fiber.return}const fullPath=new Array(stack.length);for(let i2=0;i2<stack.length;i2++)fullPath[i2]=stack[stack.length-i2-1];return fullPath},"getInteractionPath"),getCleanComponentName=__name(component=>{const name=getDisplayName(component);return name?name.replace(/^(?:Memo|Forward(?:Ref)?|With.*?)\((?<inner>.*?)\)$/,"$<inner>"):""},"getCleanComponentName"),getFirstNameFromAncestor=__name((fiber,accept=()=>!0)=>{let curr=fiber;for(;curr;){const currName=getDisplayName(curr.type);if(currName&&accept(currName))return currName;curr=curr.return}return null},"getFirstNameFromAncestor"),unsubscribeTrackVisibilityChange,lastVisibilityHiddenAt="never-hidden",trackVisibilityChange=__name(()=>{unsubscribeTrackVisibilityChange==null||unsubscribeTrackVisibilityChange();const onVisibilityChange=__name(()=>{document.hidden&&(lastVisibilityHiddenAt=Date.now())},"onVisibilityChange");document.addEventListener("visibilitychange",onVisibilityChange),unsubscribeTrackVisibilityChange=__name(()=>{document.removeEventListener("visibilitychange",onVisibilityChange)},"unsubscribeTrackVisibilityChange")},"trackVisibilityChange"),getInteractionType=__name(eventName=>["pointerup","click"].includes(eventName)?"pointer":(eventName.includes("key"),["keydown","keyup"].includes(eventName)?"keyboard":null),"getInteractionType"),onEntryAnimationId=null,setupPerformanceListener=__name(onEntry=>{trackVisibilityChange();const interactionMap=new Map,interactionTargetMap=new Map,processInteractionEntry=__name(entry=>{if(!entry.interactionId)return;if(entry.interactionId&&entry.target&&!interactionTargetMap.has(entry.interactionId)&&interactionTargetMap.set(entry.interactionId,entry.target),entry.target){let current=entry.target;for(;current;){if(current.id==="react-scan-toolbar-root"||current.id==="react-scan-root")return;current=current.parentElement}}const existingInteraction=interactionMap.get(entry.interactionId);if(existingInteraction)entry.duration>existingInteraction.latency?(existingInteraction.entries=[entry],existingInteraction.latency=entry.duration):entry.duration===existingInteraction.latency&&entry.startTime===existingInteraction.entries[0].startTime&&existingInteraction.entries.push(entry);else{const interactionType=getInteractionType(entry.name);if(!interactionType)return;const interaction={id:entry.interactionId,latency:entry.duration,entries:[entry],target:entry.target,type:interactionType,startTime:entry.startTime,endTime:Date.now(),processingStart:entry.processingStart,processingEnd:entry.processingEnd,duration:entry.duration,inputDelay:entry.processingStart-entry.startTime,processingDuration:entry.processingEnd-entry.processingStart,presentationDelay:entry.duration-(entry.processingEnd-entry.startTime),timestamp:Date.now(),timeSinceTabInactive:lastVisibilityHiddenAt==="never-hidden"?"never-hidden":Date.now()-lastVisibilityHiddenAt,visibilityState:document.visibilityState,timeOrigin:performance.timeOrigin,referrer:document.referrer};interactionMap.set(interaction.id,interaction),onEntryAnimationId||(onEntryAnimationId=requestAnimationFrame(()=>{requestAnimationFrame(()=>{onEntry(interactionMap.get(interaction.id)),onEntryAnimationId=null})}))}},"processInteractionEntry"),po=new PerformanceObserver(list=>{const entries=list.getEntries();for(let i2=0,len=entries.length;i2<len;i2++){const entry=entries[i2];processInteractionEntry(entry)}});try{po.observe({type:"event",buffered:!0,durationThreshold:16}),po.observe({type:"first-input",buffered:!0})}catch{}return()=>po.disconnect()},"setupPerformanceListener"),setupPerformancePublisher=__name(()=>setupPerformanceListener(entry=>{performanceEntryChannels.publish({kind:"entry-received",entry},"recording")}),"setupPerformancePublisher"),MAX_INTERACTION_TASKS=25,tasks=new BoundedArray(MAX_INTERACTION_TASKS),getAssociatedDetailedTimingInteraction=__name((entry,activeTasks)=>{let closestTask=null;for(const task of activeTasks){if(task.type!==entry.type)continue;if(closestTask===null){closestTask=task;continue}const getAbsoluteDiff=__name((task2,entry2)=>Math.abs(task2.startDateTime)-(entry2.startTime+entry2.timeOrigin),"getAbsoluteDiff");getAbsoluteDiff(task,entry)<getAbsoluteDiff(closestTask,entry)&&(closestTask=task)}return closestTask},"getAssociatedDetailedTimingInteraction"),listenForPerformanceEntryInteractions=__name(onComplete=>performanceEntryChannels.subscribe("recording",event=>{const associatedDetailedInteraction=event.kind==="auto-complete-race"?tasks.find(task=>task.interactionUUID===event.interactionUUID):getAssociatedDetailedTimingInteraction(event.entry,tasks);if(!associatedDetailedInteraction)return;const completedInteraction=associatedDetailedInteraction.completeInteraction(event);onComplete(completedInteraction)}),"listenForPerformanceEntryInteractions"),trackDetailedTiming=__name(({onMicroTask,onRAF,onTimeout,abort})=>{queueMicrotask(()=>{(abort==null?void 0:abort())!==!0&&onMicroTask()&&requestAnimationFrame(()=>{(abort==null?void 0:abort())!==!0&&onRAF()&&setTimeout(()=>{(abort==null?void 0:abort())!==!0&&onTimeout()},0)})})},"trackDetailedTiming"),getTargetInteractionDetails=__name(target=>{const associatedFiber=getFiberFromElement(target);if(!associatedFiber)return;let componentName=associatedFiber?getDisplayName(associatedFiber==null?void 0:associatedFiber.type):"N/A";return componentName||(componentName=getFirstNameFromAncestor(associatedFiber,name=>name.length>2)??"N/A"),componentName?{componentPath:getInteractionPath(associatedFiber),childrenTree:{},componentName}:void 0},"getTargetInteractionDetails"),setupDetailedPointerTimingListener=__name((kind,options)=>{let instrumentationIdInControl=null;const getEvent=__name(info=>{switch(kind){case"pointer":return info.phase==="start"?"pointerup":info.target instanceof HTMLInputElement||info.target instanceof HTMLSelectElement?"change":"click";case"keyboard":return info.phase==="start"?"keydown":"change"}},"getEvent"),lastInteractionRef={current:{kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind}},onInteractionStart=__name(e2=>{var _a2,_b2;if(e2.composedPath().some(el=>el instanceof Element&&el.id==="react-scan-toolbar-root")||(Date.now()-lastInteractionRef.current.stageStart>2e3&&(lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind}),lastInteractionRef.current.kind!=="uninitialized-stage"))return;const pointerUpStart=performance.now();(_a2=options==null?void 0:options.onStart)==null||_a2.call(options,lastInteractionRef.current.interactionUUID);const details=getTargetInteractionDetails(e2.target);if(!details){(_b2=options==null?void 0:options.onError)==null||_b2.call(options,lastInteractionRef.current.interactionUUID);return}const fiberRenders={},stopListeningForRenders=listenForRenders(fiberRenders);lastInteractionRef.current={...lastInteractionRef.current,interactionType:kind,blockingTimeStart:Date.now(),childrenTree:details.childrenTree,componentName:details.componentName,componentPath:details.componentPath,fiberRenders,kind:"interaction-start",interactionStartDetail:pointerUpStart,stopListeningForRenders};const event=getEvent({phase:"end",target:e2.target});document.addEventListener(event,onLastJS,{once:!0}),requestAnimationFrame(()=>{document.removeEventListener(event,onLastJS)})},"onInteractionStart");document.addEventListener(getEvent({phase:"start"}),onInteractionStart,{capture:!0});const onLastJS=__name((e2,instrumentationId,abort)=>{var _a2;if(lastInteractionRef.current.kind!=="interaction-start"&&instrumentationId===instrumentationIdInControl){if(kind==="pointer"&&e2.target instanceof HTMLSelectElement){lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind};return}(_a2=options==null?void 0:options.onError)==null||_a2.call(options,lastInteractionRef.current.interactionUUID),lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind};return}instrumentationIdInControl=instrumentationId,trackDetailedTiming({abort,onMicroTask:__name(()=>lastInteractionRef.current.kind==="uninitialized-stage"?!1:(lastInteractionRef.current={...lastInteractionRef.current,kind:"js-end-stage",jsEndDetail:performance.now()},!0),"onMicroTask"),onRAF:__name(()=>{var _a3;return lastInteractionRef.current.kind!=="js-end-stage"&&lastInteractionRef.current.kind!=="raf-stage"?((_a3=options==null?void 0:options.onError)==null||_a3.call(options,lastInteractionRef.current.interactionUUID),lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind},!1):(lastInteractionRef.current={...lastInteractionRef.current,kind:"raf-stage",rafStart:performance.now()},!0)},"onRAF"),onTimeout:__name(()=>{var _a3;if(lastInteractionRef.current.kind!=="raf-stage"){(_a3=options==null?void 0:options.onError)==null||_a3.call(options,lastInteractionRef.current.interactionUUID),lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind};return}const now=Date.now(),timeoutStage=Object.freeze({...lastInteractionRef.current,kind:"timeout-stage",blockingTimeEnd:now,commitEnd:performance.now()});lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:now,interactionType:kind};let completed=!1;const completeInteraction=__name(event=>{var _a4;completed=!0;const latency=event.kind==="auto-complete-race"?event.detailedTiming.commitEnd-event.detailedTiming.interactionStartDetail:event.entry.latency,finalInteraction={detailedTiming:timeoutStage,latency,completedAt:Date.now(),flushNeeded:!0};(_a4=options==null?void 0:options.onComplete)==null||_a4.call(options,timeoutStage.interactionUUID,finalInteraction,event);const newTasks=tasks.filter(task2=>task2.interactionUUID!==timeoutStage.interactionUUID);return tasks=BoundedArray.fromArray(newTasks,MAX_INTERACTION_TASKS),finalInteraction},"completeInteraction"),task={completeInteraction,endDateTime:Date.now(),startDateTime:timeoutStage.blockingTimeStart,type:kind,interactionUUID:timeoutStage.interactionUUID};if(tasks.push(task),isPerformanceEventAvailable())setTimeout(()=>{if(completed)return;completeInteraction({kind:"auto-complete-race",detailedTiming:timeoutStage,interactionUUID:timeoutStage.interactionUUID});const newTasks=tasks.filter(task2=>task2.interactionUUID!==timeoutStage.interactionUUID);tasks=BoundedArray.fromArray(newTasks,MAX_INTERACTION_TASKS)},1e3);else{const newTasks=tasks.filter(task2=>task2.interactionUUID!==timeoutStage.interactionUUID);tasks=BoundedArray.fromArray(newTasks,MAX_INTERACTION_TASKS),completeInteraction({kind:"auto-complete-race",detailedTiming:timeoutStage,interactionUUID:timeoutStage.interactionUUID})}},"onTimeout")})},"onLastJS"),onKeyPress=__name(e2=>{const id=not_globally_unique_generateId();onLastJS(e2,id,()=>id!==instrumentationIdInControl)},"onKeyPress");return kind==="keyboard"&&document.addEventListener("keypress",onKeyPress),()=>{document.removeEventListener(getEvent({phase:"start"}),onInteractionStart,{capture:!0}),document.removeEventListener("keypress",onKeyPress)}},"setupDetailedPointerTimingListener"),getHostFromFiber=__name(fiber=>{var _a2;return(_a2=traverseFiber(fiber,node=>{if(isHostFiber(node))return!0}))==null?void 0:_a2.stateNode},"getHostFromFiber"),isPerformanceEventAvailable=__name(()=>"PerformanceEventTiming"in globalThis,"isPerformanceEventAvailable"),listenForRenders=__name(fiberRenders=>{const listener=__name(fiber=>{var _a2,_b2,_c2,_d2,_e2;const displayName=getDisplayName(fiber.type);if(!displayName)return;const existing=fiberRenders[displayName];if(!existing){const parents=new Set,parentCompositeName=getDisplayName(getParentCompositeFiber(fiber));parentCompositeName&&parents.add(parentCompositeName);const{selfTime:selfTime2,totalTime:totalTime2}=getTimings(fiber),newChanges2=collectInspectorDataWithoutCounts(fiber),emptySection2={current:[],changes:new Set,changesCounts:new Map},changes={fiberProps:newChanges2.fiberProps||emptySection2,fiberState:newChanges2.fiberState||emptySection2,fiberContext:newChanges2.fiberContext||emptySection2};fiberRenders[displayName]={renderCount:1,parents,selfTime:selfTime2,totalTime:totalTime2,nodeInfo:[{element:getHostFromFiber(fiber),name:getDisplayName(fiber.type)??"Unknown",selfTime:getTimings(fiber).selfTime}],changes};return}const parentType=(_b2=(_a2=getParentCompositeFiber(fiber))==null?void 0:_a2[0])==null?void 0:_b2.type;if(parentType){const parentCompositeName=getDisplayName(parentType);parentCompositeName&&existing.parents.add(parentCompositeName)}const{selfTime,totalTime}=getTimings(fiber),newChanges=collectInspectorDataWithoutCounts(fiber);if(!newChanges)return;const emptySection={current:[],changes:new Set,changesCounts:new Map};existing.changes={fiberProps:mergeSectionData(((_c2=existing.changes)==null?void 0:_c2.fiberProps)||emptySection,newChanges.fiberProps||emptySection),fiberState:mergeSectionData(((_d2=existing.changes)==null?void 0:_d2.fiberState)||emptySection,newChanges.fiberState||emptySection),fiberContext:mergeSectionData(((_e2=existing.changes)==null?void 0:_e2.fiberContext)||emptySection,newChanges.fiberContext||emptySection)},existing.renderCount+=1,existing.selfTime+=selfTime,existing.totalTime+=totalTime,existing.nodeInfo.push({element:getHostFromFiber(fiber),name:getDisplayName(fiber.type)??"Unknown",selfTime:getTimings(fiber).selfTime})},"listener");return Store.interactionListeningForRenders=listener,()=>{Store.interactionListeningForRenders===listener&&(Store.interactionListeningForRenders=null)}},"listenForRenders"),mergeSectionData=__name((existing,newData)=>{const mergedSection={current:[...existing.current],changes:new Set,changesCounts:new Map};for(const value of newData.current)mergedSection.current.some(item=>item.name===value.name)||mergedSection.current.push(value);for(const change of newData.changes)if(typeof change=="string"||typeof change=="number"){mergedSection.changes.add(change);const existingCount=existing.changesCounts.get(change)||0,newCount=newData.changesCounts.get(change)||0;mergedSection.changesCounts.set(change,existingCount+newCount)}return mergedSection},"mergeSectionData"),createStoreImpl=__name(createState=>{let state;const listeners=new Set,setState=__name((partial,replace)=>{const nextState=typeof partial=="function"?partial(state):partial;if(!Object.is(nextState,state)){const previousState=state;state=replace??(typeof nextState!="object"||nextState===null)?nextState:Object.assign({},state,nextState),listeners.forEach(listener=>listener(state,previousState))}},"setState"),getState=__name(()=>state,"getState"),api={setState,getState,getInitialState:__name(()=>initialState,"getInitialState"),subscribe:__name((selectorOrListener,listener)=>{let selector,actualListener;listener?(selector=selectorOrListener,actualListener=listener):actualListener=selectorOrListener;let currentSlice=selector?selector(state):void 0;const wrappedListener=__name((newState,previousState)=>{if(selector){const nextSlice=selector(newState),prevSlice=selector(previousState);Object.is(currentSlice,nextSlice)||(currentSlice=nextSlice,actualListener(nextSlice,prevSlice))}else actualListener(newState,previousState)},"wrappedListener");return listeners.add(wrappedListener),()=>listeners.delete(wrappedListener)},"subscribe")},initialState=state=createState(setState,getState,api);return api},"createStoreImpl"),createStore=__name(createState=>createStoreImpl,"createStore"),accumulatedFiberRendersOverTask=null;createStore()(set=>({state:{events:[]},actions:{addEvent:__name(event=>{set(store=>({state:{events:[...store.state.events,event]}}))},"addEvent"),clear:__name(()=>{set({state:{events:[]}})},"clear")}}));var toolbarEventStore=createStore()((set,get)=>{const listeners=new Set;return{state:{events:[]},actions:{addEvent:__name(event=>{listeners.forEach(listener=>listener(event));const events=[...get().state.events,event],applyOverlapCheckToLongRenderEvent=__name((longRenderEvent,onOverlap)=>{const overlapsWith=events.find(event2=>{if(event2.kind!=="long-render"&&event2.id!==longRenderEvent.id&&(longRenderEvent.data.startAt<=event2.data.startAt&&longRenderEvent.data.endAt<=event2.data.endAt&&longRenderEvent.data.endAt>=event2.data.startAt||event2.data.startAt<=longRenderEvent.data.startAt&&event2.data.endAt>=longRenderEvent.data.startAt||longRenderEvent.data.startAt<=event2.data.startAt&&longRenderEvent.data.endAt>=event2.data.endAt))return!0});overlapsWith&&onOverlap(overlapsWith)},"applyOverlapCheckToLongRenderEvent"),toRemove=new Set;events.forEach(event2=>{event2.kind!=="interaction"&&applyOverlapCheckToLongRenderEvent(event2,()=>{toRemove.add(event2.id)})});const withRemovedEvents=events.filter(event2=>!toRemove.has(event2.id));set(()=>({state:{events:withRemovedEvents}}))},"addEvent"),addListener:__name(listener=>(listeners.add(listener),()=>{listeners.delete(listener)}),"addListener"),clear:__name(()=>{set({state:{events:[]}})},"clear")}}}),useToolbarEventLog=__name(()=>E(toolbarEventStore.subscribe,toolbarEventStore.getState),"useToolbarEventLog"),taskDirtyAt=null,taskDirtyOrigin=null,startDirtyTaskTracking=__name(()=>{const onVisibilityChange=__name(()=>{taskDirtyAt=performance.now(),taskDirtyOrigin=performance.timeOrigin},"onVisibilityChange");return document.addEventListener("visibilitychange",onVisibilityChange),()=>{document.removeEventListener("visibilitychange",onVisibilityChange)}},"startDirtyTaskTracking"),framesDrawnInTheLastSecond=[];function startLongPipelineTracking(){let rafHandle,timeoutHandle;function measure(){let unSub=null;accumulatedFiberRendersOverTask=null,accumulatedFiberRendersOverTask={},unSub=listenForRenders(accumulatedFiberRendersOverTask);const startOrigin=performance.timeOrigin,startTime=performance.now();return rafHandle=requestAnimationFrame(()=>{timeoutHandle=setTimeout(()=>{const endNow=performance.now(),duration=endNow-startTime,endOrigin=performance.timeOrigin;framesDrawnInTheLastSecond.push(endNow+endOrigin);const framesInTheLastSecond=framesDrawnInTheLastSecond.filter(frameAt=>endNow+endOrigin-frameAt<=1e3),fps2=framesInTheLastSecond.length;framesDrawnInTheLastSecond=framesInTheLastSecond;const taskConsideredDirty=taskDirtyAt!==null&&taskDirtyOrigin!==null?endNow+endOrigin-(taskDirtyOrigin+taskDirtyAt)<100:null;if(duration>100&&!taskConsideredDirty){const endAt=endOrigin+endNow,startAt=startTime+startOrigin;toolbarEventStore.getState().actions.addEvent({kind:"long-render",id:not_globally_unique_generateId(),data:{endAt,startAt,meta:{fiberRenders:accumulatedFiberRendersOverTask,latency:duration,fps:fps2}}})}taskDirtyAt=null,taskDirtyOrigin=null,unSub==null||unSub(),measure()},0)}),unSub}__name(measure,"measure");const measureUnSub=measure();return()=>{measureUnSub(),cancelAnimationFrame(rafHandle),clearTimeout(timeoutHandle)}}__name(startLongPipelineTracking,"startLongPipelineTracking");var startTimingTracking=__name(()=>{const unSubPerformance=setupPerformancePublisher(),unSubDirtyTaskTracking=startDirtyTaskTracking(),unSubLongPipelineTracking=startLongPipelineTracking(),onComplete=__name(async(_3,finalInteraction,event)=>{toolbarEventStore.getState().actions.addEvent({kind:"interaction",id:not_globally_unique_generateId(),data:{startAt:finalInteraction.detailedTiming.blockingTimeStart,endAt:performance.now()+performance.timeOrigin,meta:{...finalInteraction,kind:event.kind}}});const existingCompletedInteractions=performanceEntryChannels.getChannelState("recording");finalInteraction.detailedTiming.stopListeningForRenders(),existingCompletedInteractions.length&&performanceEntryChannels.updateChannelState("recording",()=>new BoundedArray(MAX_CHANNEL_SIZE))},"onComplete"),unSubDetailedPointerTiming=setupDetailedPointerTimingListener("pointer",{onComplete}),unSubDetailedKeyboardTiming=setupDetailedPointerTimingListener("keyboard",{onComplete}),unSubInteractions=listenForPerformanceEntryInteractions(completedInteraction=>{interactionStore.setState(BoundedArray.fromArray(interactionStore.getCurrentState().concat(completedInteraction),MAX_INTERACTION_BATCH))});return()=>{unSubDirtyTaskTracking(),unSubLongPipelineTracking(),unSubPerformance(),unSubDetailedPointerTiming(),unSubInteractions(),unSubDetailedKeyboardTiming()}},"startTimingTracking"),Popover=__name(({children,triggerContent,wrapperProps})=>{const[popoverState,setPopoverState]=h$1("closed"),[elBoundingRect,setElBoundingRect]=h$1(null),[viewportSize,setViewportSize]=h$1({width:window.innerWidth,height:window.innerHeight}),triggerRef=A$1(null),popoverRef=A$1(null),portalEl=x(ToolbarElementContext),isHoveredRef=A$1(!1);y$1(()=>{const handleResize=__name(()=>{setViewportSize({width:window.innerWidth,height:window.innerHeight}),updateRect()},"handleResize");return window.addEventListener("resize",handleResize),()=>window.removeEventListener("resize",handleResize)},[]);const updateRect=__name(()=>{if(triggerRef.current&&portalEl){const triggerRect=triggerRef.current.getBoundingClientRect(),portalRect=portalEl.getBoundingClientRect(),centerX=triggerRect.left+triggerRect.width/2,centerY=triggerRect.top,rect=new DOMRect(centerX-portalRect.left,centerY-portalRect.top,triggerRect.width,triggerRect.height);setElBoundingRect(rect)}},"updateRect");y$1(()=>{updateRect()},[triggerRef.current]),y$1(()=>{if(popoverState==="opening"){const timer2=setTimeout(()=>setPopoverState("open"),120);return()=>clearTimeout(timer2)}else if(popoverState==="closing"){const timer2=setTimeout(()=>setPopoverState("closed"),120);return()=>clearTimeout(timer2)}},[popoverState]),y$1(()=>{const interval=setInterval(()=>{!isHoveredRef.current&&popoverState!=="closed"&&setPopoverState("closing")},1e3);return()=>clearInterval(interval)},[popoverState]);const handleMouseEnter=__name(()=>{isHoveredRef.current=!0,updateRect(),setPopoverState("opening")},"handleMouseEnter"),handleMouseLeave=__name(()=>{isHoveredRef.current=!1,updateRect(),setPopoverState("closing")},"handleMouseLeave"),getPopoverPosition=__name(()=>{var _a2;if(!elBoundingRect||!portalEl)return{top:0,left:0};const portalRect=portalEl.getBoundingClientRect(),popoverWidth=175,popoverHeight=((_a2=popoverRef.current)==null?void 0:_a2.offsetHeight)||40,safeArea=5,viewportX=elBoundingRect.x+portalRect.left,viewportY=elBoundingRect.y+portalRect.top;let left=viewportX,top=viewportY-4;return left-popoverWidth/2<safeArea?left=safeArea+popoverWidth/2:left+popoverWidth/2>viewportSize.width-safeArea&&(left=viewportSize.width-safeArea-popoverWidth/2),top-popoverHeight<safeArea&&(top=viewportY+elBoundingRect.height+4),{top:top-portalRect.top,left:left-portalRect.left}},"getPopoverPosition");return u(k$1,{children:[portalEl&&elBoundingRect&&popoverState!=="closed"&&Y(u("div",{ref:popoverRef,className:cn(["absolute z-100 bg-white text-black rounded-lg px-3 py-2 shadow-lg","transform transition-all duration-120 ease-[cubic-bezier(0.23,1,0.32,1)]",'after:content-[""] after:absolute after:top-[100%]',"after:left-1/2 after:-translate-x-1/2","after:w-[10px] after:h-[6px]","after:border-l-[5px] after:border-l-transparent","after:border-r-[5px] after:border-r-transparent","after:border-t-[6px] after:border-t-white","pointer-events-none",popoverState==="opening"||popoverState==="closing"?"opacity-0 translate-y-1":"opacity-100 translate-y-0"]),style:{top:getPopoverPosition().top+"px",left:getPopoverPosition().left+"px",transform:"translate(-50%, -100%)",minWidth:"175px"},children}),portalEl),u("div",{ref:triggerRef,onMouseEnter:handleMouseEnter,onMouseLeave:handleMouseLeave,...wrapperProps,children:triggerContent})]})},"Popover"),NotificationTabs=__name(({selectedEvent:_3})=>{const{notificationState,setNotificationState,setRoute}=useNotificationsContext();return u("div",{className:cn(["flex w-full justify-between items-center px-3 py-2 text-xs"]),children:[u("div",{className:cn(["bg-[#18181B] flex items-center gap-x-1 p-1 rounded-sm"]),children:[u("button",{onClick:__name(()=>{setRoute({route:"render-visualization",routeMessage:null})},"onClick"),className:cn(["w-1/2 flex items-center justify-center whitespace-nowrap py-[5px] px-1 gap-x-1",notificationState.route==="render-visualization"||notificationState.route==="render-explanation"?"text-white bg-[#7521c8] rounded-sm":"text-[#6E6E77] bg-[#18181B] rounded-sm"]),children:"Ranked"}),u("button",{onClick:__name(()=>{setRoute({route:"other-visualization",routeMessage:null})},"onClick"),className:cn(["w-1/2 flex items-center justify-center whitespace-nowrap py-[5px] px-1 gap-x-1",notificationState.route==="other-visualization"?"text-white bg-[#7521c8] rounded-sm":"text-[#6E6E77] bg-[#18181B] rounded-sm"]),children:"Overview"}),u("button",{onClick:__name(()=>{setRoute({route:"optimize",routeMessage:null})},"onClick"),className:cn(["w-1/2 flex items-center justify-center whitespace-nowrap py-[5px] px-1 gap-x-1",notificationState.route==="optimize"?"text-white bg-[#7521c8] rounded-sm":"text-[#6E6E77] bg-[#18181B] rounded-sm"]),children:u("span",{children:"Prompts"})})]}),u(Popover,{triggerContent:u("button",{onClick:__name(()=>{setNotificationState(prev=>{prev.audioNotificationsOptions.enabled&&prev.audioNotificationsOptions.audioContext.state!=="closed"&&prev.audioNotificationsOptions.audioContext.close();const prevEnabledState=prev.audioNotificationsOptions.enabled;localStorage.setItem("react-scan-notifications-audio",String(!prevEnabledState));const audioContext=new AudioContext;return prev.audioNotificationsOptions.enabled||playNotificationSound(audioContext),prevEnabledState&&audioContext.close(),{...prev,audioNotificationsOptions:prevEnabledState?{audioContext:null,enabled:!1}:{audioContext,enabled:!0}}})},"onClick"),className:"ml-auto",children:u("div",{className:cn(["flex gap-x-2 justify-center items-center text-[#6E6E77]"]),children:[u("span",{children:"Alerts"}),notificationState.audioNotificationsOptions.enabled?u(VolumeOnIcon,{size:16,className:"text-[#6E6E77]"}):u(VolumeOffIcon,{size:16,className:"text-[#6E6E77]"})]})}),children:u(k$1,{children:"Play a chime when a slowdown is recorded"})})]})},"NotificationTabs"),formatReactData=__name(groupedFiberRenders=>{let text="";return groupedFiberRenders.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).slice(0,30).filter(fiber=>fiber.totalTime>5).forEach(fiberRender=>{let localText="";localText+="Component Name:",localText+=fiberRender.name,localText+=`
`,localText+=`Rendered: ${fiberRender.count} times
`,localText+=`Sum of self times for ${fiberRender.name} is ${fiberRender.totalTime.toFixed(0)}ms
`,fiberRender.changes.props.length>0&&(localText+=`Changed props for all ${fiberRender.name} instances ("name:count" pairs)
`,fiberRender.changes.props.forEach(change=>{localText+=`${change.name}:${change.count}x
`})),fiberRender.changes.state.length>0&&(localText+=`Changed state for all ${fiberRender.name} instances ("hook index:count" pairs)
`,fiberRender.changes.state.forEach(change=>{localText+=`${change.index}:${change.count}x
`})),fiberRender.changes.context.length>0&&(localText+=`Changed context for all ${fiberRender.name} instances ("context display name (if exists):count" pairs)
`,fiberRender.changes.context.forEach(change=>{localText+=`${change.name}:${change.count}x
`})),text+=localText,text+=`
`}),text},"formatReactData"),generateInteractionDataPrompt=__name(({renderTime,eHandlerTimeExcludingRenders,toRafTime,commitTime,framePresentTime,formattedReactData})=>`I will provide you with a set of high level, and low level performance data about an interaction in a React App:
### High level
- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run javascript event handlers (EXCLUDING REACT RENDERS): ${eHandlerTimeExcludingRenders.toFixed(0)}ms
- how long it took from the last event handler time, to the last request animation frame: ${toRafTime.toFixed(0)}ms
	- things like prepaint, style recalculations, layerization, async web API's like observers may occur during this time
- how long it took from the last request animation frame to when the dom was committed: ${commitTime.toFixed(0)}ms
	- during this period you will see paint, commit, potential style recalcs, and other misc browser activity. Frequently high times here imply css that makes the browser do a lot of work, or mutating expensive dom properties during the event handler stage. This can be many things, but it narrows the problem scope significantly when this is high
${framePresentTime&&`- how long it took from dom commit for the frame to be presented: ${framePresentTime.toFixed(0)}ms. This is when information about how to paint the next frame is sent to the compositor threads, and when the GPU does work. If this is high, look for issues that may be a bottleneck for operations occurring during this time`}

### Low level
We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.
${formattedReactData}`,"generateInteractionDataPrompt"),generateInteractionOptimizationPrompt=__name(({interactionType,name,componentPath,time,renderTime,eHandlerTimeExcludingRenders,toRafTime,commitTime,framePresentTime,formattedReactData})=>`You will attempt to implement a performance improvement to a user interaction in a React app. You will be provided with data about the interaction, and the slow down.

Your should split your goals into 2 parts:
- identifying the problem
- fixing the problem
	- it is okay to implement a fix even if you aren't 100% sure the fix solves the performance problem. When you aren't sure, you should tell the user to try repeating the interaction, and feeding the "Formatted Data" in the React Scan notifications optimize tab. This allows you to start a debugging flow with the user, where you attempt a fix, and observe the result. The user may make a mistake when they pass you the formatted data, so must make sure, given the data passed to you, that the associated data ties to the same interaction you were trying to debug.


Make sure to check if the user has the react compiler enabled (project dependent, configured through build tool), so you don't unnecessarily memoize components. If it is, you do not need to worry about memoizing user components

One challenge you may face is the performance problem lies in a node_module, not in user code. If you are confident the problem originates because of a node_module, there are multiple strategies, which are context dependent:
- you can try to work around the problem, knowing which module is slow
- you can determine if its possible to resolve the problem in the node_module by modifying non node_module code
- you can monkey patch the node_module to experiment and see if it's really the problem (you can modify a functions properties to hijack the call for example)
- you can determine if it's feasible to replace whatever node_module is causing the problem with a performant option (this is an extreme)

The interaction was a ${interactionType} on the component named ${name}. This component has the following ancestors ${componentPath}. This is the path from the component, to the root. This should be enough information to figure out where this component is in the user's code base

This path is the component that was clicked, so it should tell you roughly where component had an event handler that triggered a state change.

Please note that the leaf node of this path might not be user code (if they use a UI library), and they may contain many wrapper components that just pass through children that aren't relevant to the actual click. So make you sure analyze the path and understand what the user code is doing

We have a set of high level, and low level data about the performance issue.

The click took ${time.toFixed(0)}ms from interaction start, to when a new frame was presented to a user.

We also provide you with a breakdown of what the browser spent time on during the period of interaction start to frame presentation.

- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run javascript event handlers (EXCLUDING REACT RENDERS): ${eHandlerTimeExcludingRenders.toFixed(0)}ms
- how long it took from the last event handler time, to the last request animation frame: ${toRafTime.toFixed(0)}ms
	- things like prepaint, style recalculations, layerization, async web API's like observers may occur during this time
- how long it took from the last request animation frame to when the dom was committed: ${commitTime.toFixed(0)}ms
	- during this period you will see paint, commit, potential style recalcs, and other misc browser activity. Frequently high times here imply css that makes the browser do a lot of work, or mutating expensive dom properties during the event handler stage. This can be many things, but it narrows the problem scope significantly when this is high
${framePresentTime&&`- how long it took from dom commit for the frame to be presented: ${framePresentTime.toFixed(0)}ms. This is when information about how to paint the next frame is sent to the compositor threads, and when the GPU does work. If this is high, look for issues that may be a bottleneck for operations occurring during this time`}


We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}

You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could of been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So the flow should be:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 

An important thing to note is that if you see a lot of react renders (some components with very high render counts), but javascript excluding renders is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run during the JS event handler period.

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one. And it may also be the case the comparison of the hooks dependency can be expensive, and that would not be tracked in render time.

If a node_module is the component with high renders, you can experiment to see if that component is the root issue (because of hooks). You should use the same instructions for node_module debugging mentioned previously.

`,"generateInteractionOptimizationPrompt"),generateFrameDropOptimizationPrompt=__name(({renderTime,otherTime,formattedReactData})=>`You will attempt to implement a performance improvement to a large slowdown in a react app

Your should split your goals into 2 parts:
- identifying the problem
- fixing the problem
	- it is okay to implement a fix even if you aren't 100% sure the fix solves the performance problem. When you aren't sure, you should tell the user to try repeating the interaction, and feeding the "Formatted Data" in the React Scan notifications optimize tab. This allows you to start a debugging flow with the user, where you attempt a fix, and observe the result. The user may make a mistake when they pass you the formatted data, so must make sure, given the data passed to you, that the associated data ties to the same interaction you were trying to debug.

Make sure to check if the user has the react compiler enabled (project dependent, configured through build tool), so you don't unnecessarily memoize components. If it is, you do not need to worry about memoizing user components

One challenge you may face is the performance problem lies in a node_module, not in user code. If you are confident the problem originates because of a node_module, there are multiple strategies, which are context dependent:
- you can try to work around the problem, knowing which module is slow
- you can determine if its possible to resolve the problem in the node_module by modifying non node_module code
- you can monkey patch the node_module to experiment and see if it's really the problem (you can modify a functions properties to hijack the call for example)
- you can determine if it's feasible to replace whatever node_module is causing the problem with a performant option (this is an extreme)


We have the high level time of how much react spent rendering, and what else the browser spent time on during this slowdown

- react component render time: ${renderTime.toFixed(0)}ms
- other time: ${otherTime}ms


We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}

You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could of been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So the flow should be:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 

An important thing to note is that if you see a lot of react renders (some components with very high render counts), but other time is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run outside of what we profile (just react render time).

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one. And it may also be the case the comparison of the hooks dependency can be expensive, and that would not be tracked in render time.

If a node_module is the component with high renders, you can experiment to see if that component is the root issue (because of hooks). You should use the same instructions for node_module debugging mentioned previously.

If renders don't seem to be the problem, see if there are any expensive CSS properties being added/mutated, or any expensive DOM Element mutations/new elements being created that could cause this slowdown. 
`,"generateFrameDropOptimizationPrompt"),generateFrameDropExplanationPrompt=__name(({renderTime,otherTime,formattedReactData})=>`Your goal will be to help me find the source of a performance problem in a React App. I collected a large dataset about this specific performance problem.

We have the high level time of how much react spent rendering, and what else the browser spent time on during this slowdown

- react component render time: ${renderTime.toFixed(0)}ms
- other time (other JavaScript, hooks like useEffect, style recalculations, layerization, paint & commit and everything else the browser might do to draw a new frame after javascript mutates the DOM): ${otherTime}ms


We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}

You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could of been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So a flow we can go through is:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 


An important thing to note is that if you see a lot of react renders (some components with very high render counts), but other time is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run outside of what we profile (just react render time).

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one, and this can add significant overhead when thousands of effects ran.

If it's not possible to explain the root problem from this data, please ask me for more data explicitly, and what we would need to know to find the source of the performance problem.
`,"generateFrameDropExplanationPrompt"),generateFrameDropDataPrompt=__name(({renderTime,otherTime,formattedReactData})=>`I will provide you with a set of high level, and low level performance data about a large frame drop in a React App:
### High level
- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run everything else (other JavaScript, hooks like useEffect, style recalculations, layerization, paint & commit and everything else the browser might do to draw a new frame after javascript mutates the DOM): ${otherTime}ms

### Low level
We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.
${formattedReactData}`,"generateFrameDropDataPrompt"),generateInteractionExplanationPrompt=__name(({interactionType,name,time,renderTime,eHandlerTimeExcludingRenders,toRafTime,commitTime,framePresentTime,formattedReactData})=>`Your goal will be to help me find the source of a performance problem. I collected a large dataset about this specific performance problem.

There was a ${interactionType} on a component named ${name}. This means, roughly, the component that handled the ${interactionType} event was named ${name}.

We have a set of high level, and low level data about the performance issue.

The click took ${time.toFixed(0)}ms from interaction start, to when a new frame was presented to a user.

We also provide you with a breakdown of what the browser spent time on during the period of interaction start to frame presentation.

- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run javascript event handlers (EXCLUDING REACT RENDERS): ${eHandlerTimeExcludingRenders.toFixed(0)}ms
- how long it took from the last event handler time, to the last request animation frame: ${toRafTime.toFixed(0)}ms
	- things like prepaint, style recalculations, layerization, async web API's like observers may occur during this time
- how long it took from the last request animation frame to when the dom was committed: ${commitTime.toFixed(0)}ms
	- during this period you will see paint, commit, potential style recalcs, and other misc browser activity. Frequently high times here imply css that makes the browser do a lot of work, or mutating expensive dom properties during the event handler stage. This can be many things, but it narrows the problem scope significantly when this is high
${framePresentTime&&`- how long it took from dom commit for the frame to be presented: ${framePresentTime.toFixed(0)}ms. This is when information about how to paint the next frame is sent to the compositor threads, and when the GPU does work. If this is high, look for issues that may be a bottleneck for operations occurring during this time`}

We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}


You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could of been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So a flow we can go through is:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 


An important thing to note is that if you see a lot of react renders (some components with very high render counts), but javascript excluding renders is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run during the JS event handler period.

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one. And it may also be the case the comparison of the hooks dependency can be expensive, and that would not be tracked in render time.

If it's not possible to explain the root problem from this data, please ask me for more data explicitly, and what we would need to know to find the source of the performance problem.
`,"generateInteractionExplanationPrompt"),getLLMPrompt=__name((activeTab,selectedEvent)=>iife(()=>{switch(activeTab){case"data":switch(selectedEvent.kind){case"dropped-frames":return generateFrameDropDataPrompt({formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),otherTime:selectedEvent.timing.otherTime});case"interaction":return generateInteractionDataPrompt({commitTime:selectedEvent.timing.frameConstruction,eHandlerTimeExcludingRenders:selectedEvent.timing.otherJSTime,formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),framePresentTime:selectedEvent.timing.frameDraw,renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),toRafTime:selectedEvent.timing.framePreparation})}case"explanation":switch(selectedEvent.kind){case"dropped-frames":return generateFrameDropExplanationPrompt({formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),otherTime:selectedEvent.timing.otherTime});case"interaction":return generateInteractionExplanationPrompt({commitTime:selectedEvent.timing.frameConstruction,eHandlerTimeExcludingRenders:selectedEvent.timing.otherJSTime,formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),framePresentTime:selectedEvent.timing.frameDraw,interactionType:selectedEvent.type,name:getComponentName(selectedEvent.componentPath),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),time:getTotalTime(selectedEvent.timing),toRafTime:selectedEvent.timing.framePreparation})}case"fix":switch(selectedEvent.kind){case"dropped-frames":return generateFrameDropOptimizationPrompt({formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),otherTime:selectedEvent.timing.otherTime});case"interaction":return generateInteractionOptimizationPrompt({commitTime:selectedEvent.timing.frameConstruction,componentPath:selectedEvent.componentPath.join(">"),eHandlerTimeExcludingRenders:selectedEvent.timing.otherJSTime,formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),framePresentTime:selectedEvent.timing.frameDraw,interactionType:selectedEvent.type,name:getComponentName(selectedEvent.componentPath),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),time:getTotalTime(selectedEvent.timing),toRafTime:selectedEvent.timing.framePreparation})}}}),"getLLMPrompt"),Optimize=__name(({selectedEvent})=>{const[activeTab,setActiveTab]=h$1("fix"),[copying,setCopying]=h$1(!1);return u("div",{className:cn(["w-full h-full"]),children:[u("div",{className:cn(["border border-[#27272A] rounded-sm h-4/5 text-xs overflow-hidden"]),children:[u("div",{className:cn(["bg-[#18181B] p-1 rounded-t-sm"]),children:u("div",{className:cn(["flex items-center gap-x-1"]),children:[u("button",{onClick:__name(()=>setActiveTab("fix"),"onClick"),className:cn(["flex items-center justify-center whitespace-nowrap py-1.5 px-3 rounded-sm",activeTab==="fix"?"text-white bg-[#7521c8]":"text-[#6E6E77] hover:text-white"]),children:"Fix"}),u("button",{onClick:__name(()=>setActiveTab("explanation"),"onClick"),className:cn(["flex items-center justify-center whitespace-nowrap py-1.5 px-3 rounded-sm",activeTab==="explanation"?"text-white bg-[#7521c8]":"text-[#6E6E77] hover:text-white"]),children:"Explanation"}),u("button",{onClick:__name(()=>setActiveTab("data"),"onClick"),className:cn(["flex items-center justify-center whitespace-nowrap py-1.5 px-3 rounded-sm",activeTab==="data"?"text-white bg-[#7521c8]":"text-[#6E6E77] hover:text-white"]),children:"Data"})]})}),u("div",{className:cn(["overflow-y-auto h-full"]),children:u("pre",{className:cn(["p-2 h-full","whitespace-pre-wrap break-words","text-gray-300 font-mono "]),children:getLLMPrompt(activeTab,selectedEvent)})})]}),u("button",{onClick:__name(async()=>{const text=getLLMPrompt(activeTab,selectedEvent);await navigator.clipboard.writeText(text),setCopying(!0),setTimeout(()=>setCopying(!1),1e3)},"onClick"),className:cn(["mt-4 px-4 py-2 bg-[#18181B] text-[#6E6E77] rounded-sm","hover:text-white transition-colors duration-200","flex items-center justify-center gap-x-2 text-xs"]),children:[u("span",{children:copying?"Copied!":"Copy Prompt"}),u("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:cn(["transition-transform duration-200",copying&&"scale-110"]),children:copying?u("path",{d:"M20 6L9 17l-5-5"}):u(k$1,{children:[u("rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2"}),u("path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"})]})})]})]})},"Optimize"),getTimeData=__name((selectedEvent,isProduction2)=>{switch(selectedEvent.kind){case"dropped-frames":return[...isProduction2?[{name:"Total Processing Time",time:getTotalTime(selectedEvent.timing),color:"bg-red-500",kind:"total-processing-time"}]:[{name:"Renders",time:selectedEvent.timing.renderTime,color:"bg-purple-500",kind:"render"},{name:"JavaScript, DOM updates, Draw Frame",time:selectedEvent.timing.otherTime,color:"bg-[#4b4b4b]",kind:"other-frame-drop"}]];case"interaction":return[...isProduction2?[]:[{name:"Renders",time:selectedEvent.timing.renderTime,color:"bg-purple-500",kind:"render"}],{name:isProduction2?"React Renders, Hooks, Other JavaScript":"JavaScript/React Hooks ",time:selectedEvent.timing.otherJSTime,color:"bg-[#EFD81A]",kind:"other-javascript"},{name:"Update DOM and Draw New Frame",time:getTotalTime(selectedEvent.timing)-selectedEvent.timing.renderTime-selectedEvent.timing.otherJSTime,color:"bg-[#1D3A66]",kind:"other-not-javascript"}]}},"getTimeData"),OtherVisualization=__name(({selectedEvent})=>{var _a2;const[isProduction2]=h$1(getIsProduction()??!1),{notificationState}=useNotificationsContext(),[expandedItems,setExpandedItems]=h$1((_a2=notificationState.routeMessage)!=null&&_a2.name?[notificationState.routeMessage.name]:[]),timeData=getTimeData(selectedEvent,isProduction2),root=x(ToolbarElementContext);y$1(()=>{var _a3;if((_a3=notificationState.routeMessage)!=null&&_a3.name){const container=root==null?void 0:root.querySelector("#overview-scroll-container"),element=root==null?void 0:root.querySelector(`#react-scan-overview-bar-${notificationState.routeMessage.name}`);if(container&&element){const elementTop=element.getBoundingClientRect().top,containerTop=container.getBoundingClientRect().top,scrollOffset=elementTop-containerTop;container.scrollTop=container.scrollTop+scrollOffset}}},[notificationState.route]),y$1(()=>{notificationState.route==="other-visualization"&&setExpandedItems(prev=>{var _a3;return(_a3=notificationState.routeMessage)!=null&&_a3.name?[notificationState.routeMessage.name]:prev})},[notificationState.route]);const totalTime=timeData.reduce((acc,item)=>acc+item.time,0);return u("div",{className:"rounded-sm border border-zinc-800 text-xs",children:[u("div",{className:"p-2 border-b border-zinc-800 bg-zinc-900/50",children:u("div",{className:"flex items-center justify-between",children:[u("h3",{className:"text-xs font-medium",children:"What was time spent on?"}),u("span",{className:"text-xs text-zinc-400",children:["Total: ",totalTime.toFixed(0),"ms"]})]})}),u("div",{className:"divide-y divide-zinc-800",children:timeData.map(entry=>{const isExpanded=expandedItems.includes(entry.kind);return u("div",{id:`react-scan-overview-bar-${entry.kind}`,children:[u("button",{onClick:__name(()=>setExpandedItems(prev=>prev.includes(entry.kind)?prev.filter(item=>item!==entry.kind):[...prev,entry.kind]),"onClick"),className:"w-full px-3 py-2 flex items-center gap-4 hover:bg-zinc-800/50 transition-colors",children:u("div",{className:"flex-1",children:[u("div",{className:"flex items-center justify-between mb-2",children:[u("div",{className:"flex items-center gap-0.5",children:[u("svg",{className:`h-4 w-4 text-zinc-400 transition-transform ${isExpanded?"rotate-90":""}`,fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:u("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 5l7 7-7 7"})}),u("span",{className:"font-medium flex items-center text-left",children:entry.name})]}),u("span",{className:" text-zinc-400",children:[entry.time.toFixed(0),"ms"]})]}),u("div",{className:"h-1 bg-zinc-800 rounded-full overflow-hidden",children:u("div",{className:`h-full ${entry.color} transition-all`,style:{width:`${entry.time/totalTime*100}%`}})})]})}),isExpanded&&u("div",{className:"bg-zinc-900/30 border-t border-zinc-800 px-2.5 py-3",children:u("p",{className:" text-zinc-400 mb-4 text-xs",children:iife(()=>{switch(selectedEvent.kind){case"interaction":switch(entry.kind){case"render":return u(Explanation,{input:getRenderInput(selectedEvent)});case"other-javascript":return u(Explanation,{input:getJSInput(selectedEvent)});case"other-not-javascript":return u(Explanation,{input:getDrawInput(selectedEvent)})}case"dropped-frames":switch(entry.kind){case"total-processing-time":return u(Explanation,{input:{kind:"total-processing",data:{time:getTotalTime(selectedEvent.timing)}}});case"render":return u(k$1,{children:u(Explanation,{input:{kind:"render",data:{topByTime:selectedEvent.groupedFiberRenders.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).slice(0,3).map(render2=>({name:render2.name,percentage:render2.totalTime/getTotalTime(selectedEvent.timing)}))}}})});case"other-frame-drop":return u(Explanation,{input:{kind:"other"}})}}})})})]},entry.kind)})})]})},"OtherVisualization"),getDrawInput=__name(event=>{const renderCount=event.groupedFiberRenders.reduce((prev,curr)=>prev+curr.count,0),renderTime=event.timing.renderTime,totalTime=getTotalTime(event.timing),renderPercentage=renderTime/totalTime*100;return renderCount>100?{kind:"high-render-count-update-dom-draw-frame",data:{count:renderCount,percentageOfTotal:renderPercentage,copyButton:u(CopyPromptButton,{})}}:{kind:"update-dom-draw-frame",data:{copyButton:u(CopyPromptButton,{})}}},"getDrawInput"),CopyPromptButton=__name(()=>{const[copying,setCopying]=h$1(!1),{notificationState}=useNotificationsContext();return u("button",{onClick:__name(async()=>{notificationState.selectedEvent&&(await navigator.clipboard.writeText(getLLMPrompt("explanation",notificationState.selectedEvent)),setCopying(!0),setTimeout(()=>setCopying(!1),1e3))},"onClick"),className:"bg-zinc-800 flex hover:bg-zinc-700 text-zinc-200 px-2 py-1 rounded gap-x-3",children:[u("span",{children:copying?"Copied!":"Copy Prompt"}),u("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:cn(["transition-transform duration-200",copying&&"scale-110"]),children:copying?u("path",{d:"M20 6L9 17l-5-5"}):u(k$1,{children:[u("rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2"}),u("path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"})]})})]})},"CopyPromptButton"),getRenderInput=__name(event=>event.timing.renderTime/getTotalTime(event.timing)>.3?{kind:"render",data:{topByTime:event.groupedFiberRenders.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).slice(0,3).map(e2=>({percentage:e2.totalTime/getTotalTime(event.timing),name:e2.name}))}}:{kind:"other"},"getRenderInput"),getJSInput=__name(event=>{const renderCount=event.groupedFiberRenders.reduce((prev,curr)=>prev+curr.count,0);return event.timing.otherJSTime/getTotalTime(event.timing)<.2?{kind:"js-explanation-base"}:event.groupedFiberRenders.find(render2=>render2.count>200)||event.groupedFiberRenders.reduce((prev,curr)=>prev+curr.count,0)>500?{kind:"high-render-count-high-js",data:{renderCount,topByCount:event.groupedFiberRenders.filter(groupedRender=>groupedRender.count>100).toSorted((a2,b2)=>b2.count-a2.count).slice(0,3)}}:event.timing.otherJSTime/getTotalTime(event.timing)>.3?event.timing.renderTime>.2?{kind:"js-explanation-base"}:{kind:"low-render-count-high-js",data:{renderCount}}:{kind:"js-explanation-base"}},"getJSInput"),Explanation=__name(({input})=>{switch(input.kind){case"total-processing":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:["This is the time it took to draw the entire frame that was presented to the user. To be at 60FPS, this number needs to be ","<=16ms"]}),u("p",{children:'To debug the issue, check the "Ranked" tab to see if there are significant component renders'}),u("p",{children:"On a production React build, React Scan can't access the time it took for component to render. To get that information, run React Scan on a development build"}),u("p",{children:["To understand precisely what caused the slowdown while in production, use the ",u("strong",{children:"Chrome profiler"})," and analyze the function call times."]}),u("p",{})]});case"render":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:"This is the time it took React to run components, and internal logic to handle the output of your component."}),u("div",{className:cn(["flex flex-col"]),children:[u("p",{children:"The slowest components for this time period were:"}),input.data.topByTime.map(item=>u("div",{children:[u("strong",{children:item.name}),":"," ",(item.percentage*100).toFixed(0),"% of total"]},item.name))]}),u("p",{children:'To view the render times of all your components, and what caused them to render, go to the "Ranked" tab'}),u("p",{children:'The "Ranked" tab shows the render times of every component.'}),u("p",{children:"The render times of the same components are grouped together into one bar."}),u("p",{children:"Clicking the component will show you what props, state, or context caused the component to re-render."})]});case"js-explanation-base":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:"This is the period when JavaScript hooks and other JavaScript outside of React Renders run."}),u("p",{children:["The most common culprit for high JS time is expensive hooks, like expensive callbacks inside of ",u("code",{children:"useEffect"}),"'s or a large number of useEffect's called, but this can also be JavaScript event handlers (",u("code",{children:"'onclick'"}),", ",u("code",{children:"'onchange'"}),") that performed expensive computation."]}),u("p",{children:"If you have lots of components rendering that call hooks, like useEffect, it can add significant overhead even if the callbacks are not expensive. If this is the case, you can try optimizing the renders of those components to avoid the hook from having to run."}),u("p",{children:["You should profile your app using the"," ",u("strong",{children:"Chrome DevTools profiler"})," to learn exactly which functions took the longest to execute."]})]});case"high-render-count-high-js":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:"This is the period when JavaScript hooks and other JavaScript outside of React Renders run."}),input.data.renderCount===0?u(k$1,{children:[u("p",{children:"There were no renders, which means nothing related to React caused this slowdown. The most likely cause of the slowdown is a slow JavaScript event handler, or code related to a Web API"}),u("p",{children:["You should try to reproduce the slowdown while profiling your website with the",u("strong",{children:"Chrome DevTools profiler"})," to see exactly what functions took the longest to execute."]})]}):u(k$1,{children:[" ",u("p",{children:["There were ",u("strong",{children:input.data.renderCount})," renders, which could have contributed to the high JavaScript/Hook time if they ran lots of hooks, like ",u("code",{children:"useEffects"}),"."]}),u("div",{className:cn(["flex flex-col"]),children:[u("p",{children:"You should try optimizing the renders of:"}),input.data.topByCount.map(item=>u("div",{children:["- ",u("strong",{children:item.name})," (rendered ",item.count,"x)"]},item.name))]}),"and then checking if the problem still exists.",u("p",{children:["You can also try profiling your app using the"," ",u("strong",{children:"Chrome DevTools profiler"})," to see exactly what functions took the longest to execute."]})]})]});case"low-render-count-high-js":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:"This is the period when JavaScript hooks and other JavaScript outside of React Renders run."}),u("p",{children:["There were only ",u("strong",{children:input.data.renderCount})," renders detected, which means either you had very expensive hooks like"," ",u("code",{children:"useEffect"}),"/",u("code",{children:"useLayoutEffect"}),", or there is other JavaScript running during this interaction that took up the majority of the time."]}),u("p",{children:["To understand precisely what caused the slowdown, use the"," ",u("strong",{children:"Chrome profiler"})," and analyze the function call times."]})]});case"high-render-count-update-dom-draw-frame":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:"These are the calculations the browser is forced to do in response to the JavaScript that ran during the interaction."}),u("p",{children:"This can be caused by CSS updates/CSS recalculations, or new DOM elements/DOM mutations."}),u("p",{children:["During this interaction, there were"," ",u("strong",{children:input.data.count})," renders, which was"," ",u("strong",{children:[input.data.percentageOfTotal.toFixed(0),"%"]})," of the time spent processing"]}),u("p",{children:"The work performed as a result of the renders may have forced the browser to spend a lot of time to draw the next frame."}),u("p",{children:'You can try optimizing the renders to see if the performance problem still exists using the "Ranked" tab.'}),u("p",{children:"If you use an AI-based code editor, you can export the performance data collected as a prompt."}),u("p",{children:input.data.copyButton}),u("p",{children:"Provide this formatted data to the model and ask it to find, or fix, what could be causing this performance problem."}),u("p",{children:'For a larger selection of prompts, try the "Prompts" tab'})]});case"update-dom-draw-frame":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:"These are the calculations the browser is forced to do in response to the JavaScript that ran during the interaction."}),u("p",{children:"This can be caused by CSS updates/CSS recalculations, or new DOM elements/DOM mutations."}),u("p",{children:"If you use an AI-based code editor, you can export the performance data collected as a prompt."}),u("p",{children:input.data.copyButton}),u("p",{children:"Provide this formatted data to the model and ask it to find, or fix, what could be causing this performance problem."}),u("p",{children:'For a larger selection of prompts, try the "Prompts" tab'})]});case"other":return u("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u("p",{children:["This is the time it took to run everything other than React renders. This can be hooks like ",u("code",{children:"useEffect"}),", other JavaScript not part of React, or work the browser has to do to update the DOM and draw the next frame."]}),u("p",{children:["To get a better picture of what happened, profile your app using the"," ",u("strong",{children:"Chrome profiler"})," when the performance problem arises."]})]})}},"Explanation"),highlightCanvas=null,highlightCtx=null,HighlightStore=d$1({kind:"idle",current:null}),currFrame=null,drawHighlights=__name(()=>{currFrame&&cancelAnimationFrame(currFrame),currFrame=requestAnimationFrame(()=>{if(!highlightCanvas||!highlightCtx)return;highlightCtx.clearRect(0,0,highlightCanvas.width,highlightCanvas.height);const color="hsl(271, 76%, 53%)",state=HighlightStore.value,{alpha,current}=iife(()=>{var _a2,_b2;switch(state.kind){case"transition":{const current2=(_a2=state.current)!=null&&_a2.alpha&&state.current.alpha>0?state.current:state.transitionTo;return{alpha:current2?current2.alpha:0,current:current2}}case"move-out":return{alpha:((_b2=state.current)==null?void 0:_b2.alpha)??0,current:state.current};case"idle":return{alpha:1,current:state.current}}});switch(current==null||current.rects.forEach(rect=>{highlightCtx&&(highlightCtx.shadowColor=color,highlightCtx.shadowBlur=6,highlightCtx.strokeStyle=color,highlightCtx.lineWidth=2,highlightCtx.globalAlpha=alpha,highlightCtx.beginPath(),highlightCtx.rect(rect.left,rect.top,rect.width,rect.height),highlightCtx.stroke(),highlightCtx.shadowBlur=0,highlightCtx.beginPath(),highlightCtx.rect(rect.left,rect.top,rect.width,rect.height),highlightCtx.stroke())}),state.kind){case"move-out":{if(state.current.alpha===0){HighlightStore.value={kind:"idle",current:null};return}state.current.alpha<=.01&&(state.current.alpha=0),state.current.alpha=Math.max(0,state.current.alpha-.03),drawHighlights();return}case"transition":{if(state.current&&state.current.alpha>0){state.current.alpha=Math.max(0,state.current.alpha-.03),drawHighlights();return}if(state.transitionTo.alpha===1){HighlightStore.value={kind:"idle",current:state.transitionTo};return}state.transitionTo.alpha=Math.min(state.transitionTo.alpha+.03,1),drawHighlights()}case"idle":return}})},"drawHighlights"),handleResizeListener=null,createHighlightCanvas=__name(root=>{if(highlightCanvas=document.createElement("canvas"),highlightCtx=highlightCanvas.getContext("2d",{alpha:!0}),!highlightCtx)return null;const dpr2=window.devicePixelRatio||1,{innerWidth,innerHeight}=window;highlightCanvas.style.width=`${innerWidth}px`,highlightCanvas.style.height=`${innerHeight}px`,highlightCanvas.width=innerWidth*dpr2,highlightCanvas.height=innerHeight*dpr2,highlightCanvas.style.position="fixed",highlightCanvas.style.left="0",highlightCanvas.style.top="0",highlightCanvas.style.pointerEvents="none",highlightCanvas.style.zIndex="2147483600",highlightCtx.scale(dpr2,dpr2),root.appendChild(highlightCanvas),handleResizeListener&&window.removeEventListener("resize",handleResizeListener);const handleResize=__name(()=>{if(!highlightCanvas||!highlightCtx)return;const dpr3=window.devicePixelRatio||1,{innerWidth:innerWidth2,innerHeight:innerHeight2}=window;highlightCanvas.style.width=`${innerWidth2}px`,highlightCanvas.style.height=`${innerHeight2}px`,highlightCanvas.width=innerWidth2*dpr3,highlightCanvas.height=innerHeight2*dpr3,highlightCtx.scale(dpr3,dpr3),drawHighlights()},"handleResize");return handleResizeListener=handleResize,window.addEventListener("resize",handleResize),HighlightStore.subscribe(()=>{requestAnimationFrame(()=>{drawHighlights()})}),cleanup2},"createHighlightCanvas");function cleanup2(){highlightCanvas!=null&&highlightCanvas.parentNode&&highlightCanvas.parentNode.removeChild(highlightCanvas),highlightCanvas=null,highlightCtx=null}__name(cleanup2,"cleanup2");var fadeOutHighlights=__name(()=>{var _a2;const curr=HighlightStore.value.current?HighlightStore.value.current:HighlightStore.value.kind==="transition"?HighlightStore.value.transitionTo:null;if(curr){if(HighlightStore.value.kind==="transition"){HighlightStore.value={kind:"move-out",current:((_a2=HighlightStore.value.current)==null?void 0:_a2.alpha)===0?HighlightStore.value.transitionTo:HighlightStore.value.current??HighlightStore.value.transitionTo};return}HighlightStore.value={kind:"move-out",current:{alpha:0,...curr}}}},"fadeOutHighlights"),RenderBarChart=__name(({selectedEvent})=>{const{setNotificationState,setRoute}=useNotificationsContext(),totalInteractionTime=getTotalTime(selectedEvent.timing),nonRender=totalInteractionTime-selectedEvent.timing.renderTime,[isProduction2]=h$1(getIsProduction()),bars=selectedEvent.groupedFiberRenders.map(event=>({event,kind:"render",totalTime:isProduction2?event.count:event.totalTime})),isShowingExtraInfo=iife(()=>{switch(selectedEvent.kind){case"dropped-frames":return selectedEvent.timing.renderTime/totalInteractionTime<.1;case"interaction":return(selectedEvent.timing.otherJSTime+selectedEvent.timing.renderTime)/totalInteractionTime<.2}});selectedEvent.kind==="interaction"&&!isProduction2&&bars.push({kind:"other-javascript",totalTime:selectedEvent.timing.otherJSTime}),isShowingExtraInfo&&!isProduction2&&(selectedEvent.kind==="interaction"?bars.push({kind:"other-not-javascript",totalTime:getTotalTime(selectedEvent.timing)-selectedEvent.timing.renderTime-selectedEvent.timing.otherJSTime}):bars.push({kind:"other-frame-drop",totalTime:nonRender}));const debouncedMouseEnter=A$1({lastCallAt:null,timer:null}),totalBarTime=bars.reduce((prev,curr)=>prev+curr.totalTime,0);return u("div",{onMouseLeave:__name(()=>{fadeOutHighlights()},"onMouseLeave"),className:cn(["flex flex-col h-full w-full gap-y-1"]),children:[iife(()=>{if(isProduction2&&bars.length===0)return u("div",{className:"flex flex-col items-center justify-center h-full text-zinc-400",children:[u("p",{className:"text-sm w-full text-left text-white mb-1.5",children:"No data available"}),u("p",{className:"text-x w-full text-lefts",children:"No data was collected during this period"})]});if(bars.length===0)return u("div",{className:"flex flex-col items-center justify-center h-full text-zinc-400",children:[u("p",{className:"text-sm w-full text-left text-white mb-1.5",children:"No renders collected"}),u("p",{className:"text-x w-full text-lefts",children:"There were no renders during this period"})]})}),bars.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).map((bar,index)=>u("button",{onMouseLeave:__name(()=>{debouncedMouseEnter.current.timer&&clearTimeout(debouncedMouseEnter.current.timer)},"onMouseLeave"),onMouseEnter:__name(async()=>{const highlightBars=__name(async()=>{if(debouncedMouseEnter.current.lastCallAt=Date.now(),bar.kind!=="render"){const curr=HighlightStore.value.current?HighlightStore.value.current:HighlightStore.value.kind==="transition"?HighlightStore.value.transitionTo:null;if(!curr){HighlightStore.value={kind:"idle",current:null};return}HighlightStore.value={kind:"move-out",current:{alpha:0,...curr}};return}const state=HighlightStore.value,currentState=iife(()=>{switch(state.kind){case"transition":return state.transitionTo;case"idle":case"move-out":return state.current}}),stateRects=[];if(state.kind==="transition"){const transitionState=getTransitionState(state);iife(()=>{switch(transitionState){case"fading-in":{HighlightStore.value={kind:"transition",current:state.transitionTo,transitionTo:{rects:stateRects,alpha:0,name:bar.event.name}};return}case"fading-out":{HighlightStore.value={kind:"transition",current:HighlightStore.value.current?{alpha:0,...HighlightStore.value.current}:null,transitionTo:{rects:stateRects,alpha:0,name:bar.event.name}};return}}})}else HighlightStore.value={kind:"transition",transitionTo:{rects:stateRects,alpha:0,name:bar.event.name},current:currentState?{alpha:0,...currentState}:null};const trueElements=bar.event.elements.filter(element=>element instanceof Element);for await(const entries of getBatchedRectMap(trueElements))entries.forEach(({boundingClientRect})=>{stateRects.push(boundingClientRect)}),drawHighlights()},"highlightBars");if(debouncedMouseEnter.current.lastCallAt&&Date.now()-debouncedMouseEnter.current.lastCallAt<200){debouncedMouseEnter.current.timer&&clearTimeout(debouncedMouseEnter.current.timer),debouncedMouseEnter.current.timer=setTimeout(()=>{highlightBars()},200);return}highlightBars()},"onMouseEnter"),onClick:__name(()=>{switch(bar.kind){case"render":{setNotificationState(prev=>({...prev,selectedFiber:bar.event})),setRoute({route:"render-explanation",routeMessage:null});return}case"other-not-javascript":case"other-javascript":case"other-frame-drop":{setRoute({route:"other-visualization",routeMessage:{kind:"auto-open-overview-accordion",name:bar.kind}});return}}},"onClick"),className:cn(["w-full flex items-center group hover:bg-[#0f0f0f] rounded-md relative transition-colors text-xs"]),children:[u("div",{className:cn(["h-full w-[90%]"]),children:u("div",{style:{minWidth:"fit-content",width:`${bar.totalTime/totalBarTime*100}%`},className:cn(["flex items-center  rounded-sm text-white text-xs relative h-[28px] transition-all",bar.kind==="render"&&"bg-[#412162] group-hover:bg-[#5b2d89]",bar.kind==="other-frame-drop"&&"bg-[#44444a] group-hover:bg-[#6a6a6a]",bar.kind==="other-javascript"&&"bg-[#efd81a6b] group-hover:bg-[#efda1a2f]",bar.kind==="other-not-javascript"&&"bg-[#214379d4] group-hover:bg-[#21437982]"]),children:u("div",{className:cn(["absolute left-2 top-1/2 -translate-y-1/2 flex gap-x-2"]),children:[u("span",{className:cn(["flex items-center whitespace-nowrap"]),children:iife(()=>{switch(bar.kind){case"other-frame-drop":return"JavaScript, DOM updates, Draw Frame";case"other-javascript":return"JavaScript/React Hooks";case"other-not-javascript":return"Update DOM and Draw New Frame";case"render":return bar.event.name}})}),bar.kind==="render"&&isRenderMemoizable(bar.event)&&u("div",{style:{lineHeight:"10px"},className:cn(["px-1 py-0.5 bg-[#6a369e] flex items-center  rounded-sm font-semibold text-[8px] w-fit"]),children:"Memoizable"})]})})}),u("div",{className:cn(["w-[5%] min-w-fit h-full flex items-center justify-end text-[10px] pr-1 gap-x-1"]),children:bar.kind==="render"&&u("span",{className:cn([""]),children:["x",bar.event.count]})}),(bar.kind!=="render"||!isProduction2)&&u("div",{className:cn(["w-[5%] min-w-fit text-[#7346a0] h-full flex items-center justify-end text-[10px] pr-1 gap-x-1"]),children:u("span",{children:[bar.totalTime<1?"<1":bar.totalTime.toFixed(0),"ms"]})}),u("div",{className:cn(["absolute right-0 top-1/2 transition-none  -translate-y-1/2 bg-white text-black px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity mr-16","pointer-events-none"]),children:"Click to learn more"})]},index))]})},"RenderBarChart"),getTransitionState=__name(state=>state.current&&state.current.alpha>0?"fading-out":"fading-in","getTransitionState"),RenderExplanation=__name(({selectedEvent:_3,selectedFiber})=>{const{setRoute}=useNotificationsContext(),[tipisShown,setTipIsShown]=h$1(!0),[isProduction2]=h$1(getIsProduction());_$2(()=>{const res=localStorage.getItem("react-scan-tip-shown"),asBool=res==="true"?!0:res==="false"?!1:null;if(asBool===null){setTipIsShown(!0),localStorage.setItem("react-scan-tip-is-shown","true");return}asBool||setTipIsShown(!1)},[]);const isMemoizable=selectedFiber.changes.context.length===0&&selectedFiber.changes.props.length===0&&selectedFiber.changes.state.length===0;return u("div",{className:cn(["w-full min-h-fit h-full flex flex-col py-4 pt-0 rounded-sm"]),children:[u("div",{className:cn(["flex items-start gap-x-4 "]),children:[u("button",{onClick:__name(()=>{setRoute({route:"render-visualization",routeMessage:null})},"onClick"),className:cn(["text-white hover:bg-[#34343b] flex gap-x-1 justify-center items-center mb-4 w-fit px-2.5 py-1.5 text-xs rounded-sm bg-[#18181B]"]),children:[u(ArrowLeft,{size:14})," ",u("span",{children:"Overview"})]}),u("div",{className:cn(["flex flex-col gap-y-1"]),children:[u("div",{className:cn(["text-sm font-bold text-white overflow-x-hidden"]),children:u("div",{className:"flex items-center gap-x-2 truncate",children:selectedFiber.name})}),u("div",{className:cn(["flex gap-x-2"]),children:[!isProduction2&&u(k$1,{children:u("div",{className:cn(["text-xs text-gray-400"]),children:["• Render time: ",selectedFiber.totalTime.toFixed(0),"ms"]})}),u("div",{className:cn(["text-xs text-gray-400 mb-4"]),children:["• Renders: ",selectedFiber.count,"x"]})]})]})]}),tipisShown&&!isMemoizable&&u("div",{className:cn(["w-full mb-4 bg-[#0A0A0A] border border-[#27272A] rounded-sm overflow-hidden flex relative"]),children:[u("button",{onClick:__name(()=>{setTipIsShown(!1),localStorage.setItem("react-scan-tip-shown","false")},"onClick"),className:cn(["absolute right-2 top-2 rounded-sm p-1 hover:bg-[#18181B]"]),children:u(CloseIcon,{size:12})}),u("div",{className:cn(["w-1 bg-[#d36cff]"])}),u("div",{className:cn(["flex-1"]),children:[u("div",{className:cn(["px-3 py-2 text-gray-100 text-xs font-semibold"]),children:"How to stop renders"}),u("div",{className:cn(["px-3 pb-2 text-gray-400 text-[10px]"]),children:"Stop the following props, state and context from changing between renders, and wrap the component in React.memo if not already"})]})]}),isMemoizable&&u("div",{className:cn(["w-full mb-4 bg-[#0A0A0A] border border-[#27272A] rounded-sm overflow-hidden flex"]),children:[u("div",{className:cn(["w-1 bg-[#d36cff]"])}),u("div",{className:cn(["flex-1"]),children:[u("div",{className:cn(["px-3 py-2 text-gray-100 text-sm font-semibold"]),children:"No changes detected"}),u("div",{className:cn(["px-3 pb-2 text-gray-400 text-xs"]),children:"This component would not of rendered if it was memoized"})]})]}),u("div",{className:cn(["flex w-full"]),children:[u("div",{className:cn(["flex flex-col border border-[#27272A] rounded-l-sm overflow-hidden w-1/3"]),children:[u("div",{className:cn(["text-[14px] font-semibold px-2 py-2 bg-[#18181B] text-white flex justify-center"]),children:"Changed Props"}),selectedFiber.changes.props.length>0?selectedFiber.changes.props.toSorted((a2,b2)=>b2.count-a2.count).map(change=>u("div",{className:cn(["flex flex-col justify-between items-center border-t overflow-x-auto border-[#27272A] px-1 py-1 text-wrap bg-[#0A0A0A] text-[10px]"]),children:[u("span",{className:cn(["text-white "]),children:change.name}),u("div",{className:cn([" text-[8px]  text-[#d36cff] pl-1 py-1 "]),children:[change.count,"/",selectedFiber.count,"x"]})]},change.name)):u("div",{className:cn(["flex items-center justify-center h-full bg-[#0A0A0A] text-[#A1A1AA] border-t border-[#27272A]"]),children:"No changes"})]}),u("div",{className:cn(["flex flex-col border border-[#27272A] border-l-0 overflow-hidden w-1/3"]),children:[u("div",{className:cn([" text-[14px] font-semibold px-2 py-2 bg-[#18181B] text-white flex justify-center"]),children:"Changed State"}),selectedFiber.changes.state.length>0?selectedFiber.changes.state.toSorted((a2,b2)=>b2.count-a2.count).map(change=>u("div",{className:cn(["flex flex-col justify-between items-center border-t overflow-x-auto border-[#27272A] px-1 py-1 text-wrap bg-[#0A0A0A] text-[10px]"]),children:[u("span",{className:cn(["text-white "]),children:["index ",change.index]}),u("div",{className:cn(["rounded-full  text-[#d36cff] pl-1 py-1 text-[8px]"]),children:[change.count,"/",selectedFiber.count,"x"]})]},change.index)):u("div",{className:cn(["flex items-center justify-center h-full bg-[#0A0A0A] text-[#A1A1AA] border-t border-[#27272A]"]),children:"No changes"})]}),u("div",{className:cn(["flex flex-col border border-[#27272A] border-l-0 rounded-r-sm overflow-hidden w-1/3"]),children:[u("div",{className:cn([" text-[14px] font-semibold px-2 py-2 bg-[#18181B] text-white flex justify-center"]),children:"Changed Context"}),selectedFiber.changes.context.length>0?selectedFiber.changes.context.toSorted((a2,b2)=>b2.count-a2.count).map(change=>u("div",{className:cn(["flex flex-col justify-between items-center border-t  border-[#27272A] px-1 py-1 bg-[#0A0A0A] text-[10px] overflow-x-auto"]),children:[u("span",{className:cn(["text-white "]),children:change.name}),u("div",{className:cn(["rounded-full text-[#d36cff] pl-1 py-1 text-[8px] text-wrap"]),children:[change.count,"/",selectedFiber.count,"x"]})]},change.name)):u("div",{className:cn(["flex items-center justify-center h-full bg-[#0A0A0A] text-[#A1A1AA] border-t border-[#27272A] py-2"]),children:"No changes"})]})]})]})},"RenderExplanation"),DetailsRoutes=__name(()=>{const{notificationState,setNotificationState}=useNotificationsContext(),[dots,setDots]=h$1("..."),containerRef=A$1(null);if(y$1(()=>{const interval=setInterval(()=>{setDots(prev=>prev==="..."?"":prev+".")},500);return()=>clearInterval(interval)},[]),!notificationState.selectedEvent)return u("div",{ref:containerRef,className:cn(["h-full w-full flex flex-col items-center justify-center relative py-2 px-4"]),children:[u("div",{className:cn(["p-2 flex justify-center items-center border-[#27272A] absolute top-0 right-0"]),children:u("button",{onClick:__name(()=>{signalWidgetViews.value={view:"none"}},"onClick"),children:u(CloseIcon,{size:18,className:"text-[#6F6F78]"})})}),u("div",{className:cn(["flex flex-col items-start pt-5 bg-[#0A0A0A] p-5 rounded-sm max-w-md"," shadow-lg"]),children:u("div",{className:cn(["flex flex-col items-start gap-y-4"]),children:[u("div",{className:cn(["flex items-center"]),children:u("span",{className:cn(["text-zinc-400 font-medium text-[17px]"]),children:["Scanning for slowdowns",dots]})}),notificationState.events.length!==0&&u("p",{className:cn(["text-xs"]),children:["Click on an item in the"," ",u("span",{className:cn(["text-purple-400"]),children:"History"})," list to get started"]}),u("p",{className:cn(["text-zinc-600 text-xs"]),children:"You don't need to keep this panel open for React Scan to record slowdowns"}),u("p",{className:cn(["text-zinc-600 text-xs"]),children:"Enable audio alerts to hear a delightful ding every time a large slowdown is recorded"}),u("button",{onClick:__name(()=>{if(notificationState.audioNotificationsOptions.enabled){setNotificationState(prev=>{var _a2,_b2;return((_a2=prev.audioNotificationsOptions.audioContext)==null?void 0:_a2.state)!=="closed"&&((_b2=prev.audioNotificationsOptions.audioContext)==null||_b2.close()),localStorage.setItem("react-scan-notifications-audio","false"),{...prev,audioNotificationsOptions:{audioContext:null,enabled:!1}}});return}localStorage.setItem("react-scan-notifications-audio","true");const audioContext=new AudioContext;playNotificationSound(audioContext),setNotificationState(prev=>({...prev,audioNotificationsOptions:{enabled:!0,audioContext}}))},"onClick"),className:cn(["px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-sm w-full"," text-sm flex items-center gap-x-2 justify-center"]),children:notificationState.audioNotificationsOptions.enabled?u(k$1,{children:u("span",{className:"flex items-center gap-x-1",children:"Disable audio alerts"})}):u(k$1,{children:u("span",{className:"flex items-center gap-x-1",children:"Enable audio alerts"})})})]})})]});switch(notificationState.route){case"render-visualization":return u(TabLayout,{children:u(RenderBarChart,{selectedEvent:notificationState.selectedEvent})});case"render-explanation":{if(!notificationState.selectedFiber)throw new Error("Invariant: must have selected fiber when viewing render explanation");return u(TabLayout,{children:u(RenderExplanation,{selectedFiber:notificationState.selectedFiber,selectedEvent:notificationState.selectedEvent})})}case"other-visualization":return u(TabLayout,{children:u("div",{className:cn(["flex w-full h-full flex-col overflow-y-auto"]),id:"overview-scroll-container",children:u(OtherVisualization,{selectedEvent:notificationState.selectedEvent})})});case"optimize":return u(TabLayout,{children:u(Optimize,{selectedEvent:notificationState.selectedEvent})})}notificationState.route},"DetailsRoutes"),TabLayout=__name(({children})=>{const{notificationState}=useNotificationsContext();if(!notificationState.selectedEvent)throw new Error("Invariant: d must have selected event when viewing render explanation");return u("div",{className:cn(["w-full h-full flex flex-col gap-y-2"]),children:[u("div",{className:cn(["h-[50px] w-full"]),children:u(NotificationTabs,{selectedEvent:notificationState.selectedEvent})}),u("div",{className:cn(["h-calc(100%-50px) flex flex-col overflow-y-auto px-3"]),children})]})},"TabLayout"),NotificationHeader=__name(({selectedEvent})=>{const severity=getEventSeverity(selectedEvent);switch(selectedEvent.kind){case"interaction":return u("div",{className:cn(["w-full flex border-b border-[#27272A] min-h-[48px]"]),children:u("div",{className:cn(["min-w-fit w-full justify-start flex items-center border-r border-[#27272A] pl-5 pr-2 text-sm gap-x-4"]),children:[u("div",{className:cn(["flex items-center gap-x-2 "]),children:[u("span",{className:cn(["text-[#5a5a5a] mr-0.5"]),children:selectedEvent.type==="click"?"Clicked ":"Typed in "}),u("span",{children:getComponentName(selectedEvent.componentPath)}),u("div",{className:cn(["w-fit flex items-center justify-center h-fit text-white px-1 rounded-sm font-semibold text-[10px] whitespace-nowrap",severity==="low"&&"bg-green-500/50",severity==="needs-improvement"&&"bg-[#b77116]",severity==="high"&&"bg-[#b94040]"]),children:[getTotalTime(selectedEvent.timing).toFixed(0),"ms processing time"]})]}),u("div",{className:cn(["flex items-center gap-x-2  justify-end ml-auto"]),children:u("div",{className:cn(["p-2 flex justify-center items-center border-[#27272A]"]),children:u("button",{onClick:__name(()=>{signalWidgetViews.value={view:"none"}},"onClick"),children:u(CloseIcon,{size:18,className:"text-[#6F6F78]"})})})})]})});case"dropped-frames":return u("div",{className:cn(["w-full flex border-b border-[#27272A] min-h-[48px]"]),children:u("div",{className:cn(["min-w-fit w-full justify-start flex items-center border-r border-[#27272A] pl-5 pr-2 text-sm gap-x-4"]),children:[u("div",{className:cn(["flex items-center gap-x-2 "]),children:["FPS Drop",u("div",{className:cn(["w-fit flex items-center justify-center h-fit text-white px-1 rounded-sm font-semibold text-[10px] whitespace-nowrap",severity==="low"&&"bg-green-500/50",severity==="needs-improvement"&&"bg-[#b77116]",severity==="high"&&"bg-[#b94040]"]),children:["dropped to ",selectedEvent.fps," FPS"]})]}),u("div",{className:cn(["flex items-center gap-x-2 w-2/4 justify-end ml-auto"]),children:u("div",{className:cn(["p-2 flex justify-center items-center border-[#27272A]"]),children:u("button",{onClick:__name(()=>{signalWidgetViews.value={view:"none"}},"onClick"),children:u(CloseIcon,{size:18,className:"text-[#6F6F78]"})})})})]})})}},"NotificationHeader"),useNestedFlash=__name(({flashingItemsCount,totalEvents})=>{const[newFlash,setNewFlash]=h$1(!1),flashedFor=A$1(0),lastFlashTime=A$1(0);return y$1(()=>{if(flashedFor.current>=totalEvents)return;const now=Date.now(),debounceTime=250,timeSinceLastFlash=now-lastFlashTime.current;if(timeSinceLastFlash>=debounceTime){setNewFlash(!1);const timeout2=setTimeout(()=>{flashedFor.current=totalEvents,lastFlashTime.current=Date.now(),setNewFlash(!0),setTimeout(()=>{setNewFlash(!1)},2e3)},50);return()=>clearTimeout(timeout2)}else{const delayNeeded=debounceTime-timeSinceLastFlash,timeout2=setTimeout(()=>{setNewFlash(!1),setTimeout(()=>{flashedFor.current=totalEvents,lastFlashTime.current=Date.now(),setNewFlash(!0),setTimeout(()=>{setNewFlash(!1)},2e3)},50)},delayNeeded);return()=>clearTimeout(timeout2)}},[flashingItemsCount]),newFlash},"useNestedFlash"),CollapsedItem=__name(({item,shouldFlash})=>{var _a2;const[expanded,setExpanded]=h$1(!1),severity=item.events.map(getEventSeverity).reduce((prev,curr)=>{switch(curr){case"high":return"high";case"needs-improvement":return prev==="high"?"high":"needs-improvement";case"low":return prev}},"low"),flashingItemsCount=item.events.reduce((prev,curr)=>shouldFlash(curr.id)?prev+1:prev,0),shouldFlashAgain=useNestedFlash({flashingItemsCount,totalEvents:item.events.length});return u("div",{className:cn(["flex flex-col gap-y-0.5"]),children:[u("button",{onClick:__name(()=>setExpanded(expanded2=>!expanded2),"onClick"),className:cn(["pl-2 py-1.5  text-sm flex items-center rounded-sm hover:bg-[#18181B] relative overflow-hidden",shouldFlashAgain&&!expanded&&"after:absolute after:inset-0 after:bg-purple-500/30 after:animate-[fadeOut_1s_ease-out_forwards]"]),children:[u("div",{className:cn(["w-4/5 flex items-center justify-start h-full text-xs truncate gap-x-1.5"]),children:[u("span",{className:cn(["min-w-fit"]),children:u(ChevronRight,{className:cn(["text-[#A1A1AA] transition-transform",expanded?"rotate-90":""]),size:14},`chevron-${item.timestamp}`)}),u("span",{className:cn(["text-xs"]),children:item.kind==="collapsed-frame-drops"?"FPS Drops":getComponentName(((_a2=item.events.at(0))==null?void 0:_a2.componentPath)??[])})]}),u("div",{className:cn(["ml-auto min-w-fit flex justify-end items-center"]),children:u("div",{style:{lineHeight:"10px"},className:cn(["w-fit flex items-center text-[10px] justify-center h-full text-white px-1 py-1 rounded-sm font-semibold",severity==="low"&&"bg-green-500/60",severity==="needs-improvement"&&"bg-[#b77116] text-[10px]",severity==="high"&&"bg-[#b94040]"]),children:["x",item.events.length]})})]}),expanded&&u(IndentedContent,{children:item.events.toSorted((a2,b2)=>b2.timestamp-a2.timestamp).map(event=>u(SlowdownHistoryItem,{event,shouldFlash:shouldFlash(event.id)}))})]})},"CollapsedItem"),IndentedContent=__name(({children})=>u("div",{className:"relative pl-6 flex flex-col gap-y-1",children:[u("div",{className:"absolute left-3 top-0 bottom-0 w-px bg-[#27272A]"}),children]}),"IndentedContent"),useFlashManager=__name(events=>{const prevEventsRef=A$1([]),[newEventIds,setNewEventIds]=h$1(new Set),isInitialMount=A$1(!0);return y$1(()=>{if(isInitialMount.current){isInitialMount.current=!1,prevEventsRef.current=events;return}const currentIds=new Set(events.map(e2=>e2.id)),prevIds=new Set(prevEventsRef.current.map(e2=>e2.id)),newIds=new Set;currentIds.forEach(id=>{prevIds.has(id)||newIds.add(id)}),newIds.size>0&&(setNewEventIds(newIds),setTimeout(()=>{setNewEventIds(new Set)},2e3)),prevEventsRef.current=events},[events]),id=>newEventIds.has(id)},"useFlashManager"),useFlash=__name(({shouldFlash})=>{const[isFlashing,setIsFlashing]=h$1(shouldFlash);return y$1(()=>{if(shouldFlash){setIsFlashing(!0);const timer2=setTimeout(()=>{setIsFlashing(!1)},1e3);return()=>clearTimeout(timer2)}},[shouldFlash]),isFlashing},"useFlash"),SlowdownHistoryItem=__name(({event,shouldFlash})=>{var _a2,_b2;const{notificationState,setNotificationState}=useNotificationsContext(),severity=getEventSeverity(event),isFlashing=useFlash({shouldFlash});switch(event.kind){case"interaction":return u("button",{onClick:__name(()=>{setNotificationState(prev=>({...prev,selectedEvent:event,route:"render-visualization",selectedFiber:null}))},"onClick"),className:cn(["pl-2 py-1.5  text-sm flex w-full items-center rounded-sm hover:bg-[#18181B] relative overflow-hidden",event.id===((_a2=notificationState.selectedEvent)==null?void 0:_a2.id)&&"bg-[#18181B]",isFlashing&&"after:absolute after:inset-0 after:bg-purple-500/30 after:animate-[fadeOut_1s_ease-out_forwards]"]),children:[u("div",{className:cn(["w-4/5 flex items-center justify-start h-full gap-x-1.5"]),children:[u("span",{className:cn(["min-w-fit text-xs"]),children:iife(()=>{switch(event.type){case"click":return u(PointerIcon,{size:14});case"keyboard":return u(KeyboardIcon,{size:14})}})}),u("span",{className:cn(["text-xs pr-1 truncate"]),children:getComponentName(event.componentPath)})]}),u("div",{className:cn([" min-w-fit flex justify-end items-center ml-auto"]),children:u("div",{style:{lineHeight:"10px"},className:cn(["gap-x-0.5 w-fit flex items-end justify-center h-full text-white px-1 py-1 rounded-sm font-semibold text-[10px]",severity==="low"&&"bg-green-500/50",severity==="needs-improvement"&&"bg-[#b77116] text-[10px]",severity==="high"&&"bg-[#b94040]"]),children:u("div",{style:{lineHeight:"10px"},className:cn(["text-[10px] text-white flex items-end"]),children:[getTotalTime(event.timing).toFixed(0),"ms"]})})})]});case"dropped-frames":return u("button",{onClick:__name(()=>{setNotificationState(prev=>({...prev,selectedEvent:event,route:"render-visualization",selectedFiber:null}))},"onClick"),className:cn(["pl-2 py-1.5  w-full text-sm flex items-center rounded-sm hover:bg-[#18181B] relative overflow-hidden",event.id===((_b2=notificationState.selectedEvent)==null?void 0:_b2.id)&&"bg-[#18181B]",isFlashing&&"after:absolute after:inset-0 after:bg-purple-500/30 after:animate-[fadeOut_1s_ease-out_forwards]"]),children:[u("div",{className:cn(["w-4/5 flex items-center justify-start h-full text-xs truncate"]),children:[u(TrendingDownIcon,{size:14,className:"mr-1.5"})," FPS Drop"]}),u("div",{className:cn([" min-w-fit flex justify-end items-center ml-auto"]),children:u("div",{style:{lineHeight:"10px"},className:cn(["w-fit flex items-center justify-center h-full text-white px-1 py-1 rounded-sm text-[10px] font-bold",severity==="low"&&"bg-green-500/60",severity==="needs-improvement"&&"bg-[#b77116] text-[10px]",severity==="high"&&"bg-[#b94040]"]),children:[event.fps," FPS"]})})]})}},"SlowdownHistoryItem"),collapseEvents=__name(events=>events.reduce((prev,curr)=>{const lastEvent=prev.at(-1);if(!lastEvent)return[{kind:"single",event:curr,timestamp:curr.timestamp}];switch(lastEvent.kind){case"collapsed-keyboard":return curr.kind==="interaction"&&curr.type==="keyboard"&&curr.componentPath.join("-")===lastEvent.events[0].componentPath.join("-")?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-keyboard",events:[...lastEvent.events,curr],timestamp:Math.max(...[...lastEvent.events,curr].map(e2=>e2.timestamp))}]:[...prev,{kind:"single",event:curr,timestamp:curr.timestamp}];case"single":return lastEvent.event.kind==="interaction"&&lastEvent.event.type==="keyboard"&&curr.kind==="interaction"&&curr.type==="keyboard"&&lastEvent.event.componentPath.join("-")===curr.componentPath.join("-")?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-keyboard",events:[lastEvent.event,curr],timestamp:Math.max(lastEvent.event.timestamp,curr.timestamp)}]:lastEvent.event.kind==="dropped-frames"&&curr.kind==="dropped-frames"?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-frame-drops",events:[lastEvent.event,curr],timestamp:Math.max(lastEvent.event.timestamp,curr.timestamp)}]:[...prev,{kind:"single",event:curr,timestamp:curr.timestamp}];case"collapsed-frame-drops":return curr.kind==="dropped-frames"?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-frame-drops",events:[...lastEvent.events,curr],timestamp:Math.max(...[...lastEvent.events,curr].map(e2=>e2.timestamp))}]:[...prev,{kind:"single",event:curr,timestamp:curr.timestamp}]}},[]),"collapseEvents"),useLaggedEvents=__name((lagMs=150)=>{const{notificationState}=useNotificationsContext(),[laggedEvents,setLaggedEvents]=h$1(notificationState.events);return y$1(()=>{setTimeout(()=>{setLaggedEvents(notificationState.events)},lagMs)},[notificationState.events]),[laggedEvents,setLaggedEvents]},"useLaggedEvents"),SlowdownHistory=__name(()=>{const{notificationState,setNotificationState}=useNotificationsContext(),shouldFlash=useFlashManager(notificationState.events),[laggedEvents,setLaggedEvents]=useLaggedEvents(),collapsedEvents=collapseEvents(laggedEvents).toSorted((a2,b2)=>b2.timestamp-a2.timestamp);return u("div",{className:cn(["w-full h-full gap-y-2 flex flex-col border-r border-[#27272A] pt-2 overflow-y-auto"]),children:[u("div",{className:cn(["text-sm text-[#65656D] pl-3 pr-1 w-full flex items-center justify-between"]),children:[u("span",{children:"History"}),u(Popover,{wrapperProps:{className:"h-full flex items-center justify-center ml-auto"},triggerContent:u("button",{className:cn(["hover:bg-[#18181B] rounded-full p-2"]),onClick:__name(()=>{toolbarEventStore.getState().actions.clear(),setNotificationState(prev=>({...prev,selectedEvent:null,selectedFiber:null,route:prev.route==="other-visualization"?"other-visualization":"render-visualization"})),setLaggedEvents([])},"onClick"),children:u(ClearIcon,{className:cn([""]),size:16})}),children:u("div",{className:cn(["w-full flex justify-center"]),children:"Clear all events"})})]}),u("div",{className:cn(["flex flex-col px-1 gap-y-1"]),children:[collapsedEvents.length===0&&u("div",{className:cn(["flex items-center justify-center text-zinc-500 text-sm py-4"]),children:"No Events"}),collapsedEvents.map(historyItem=>iife(()=>{switch(historyItem.kind){case"collapsed-keyboard":return u(CollapsedItem,{shouldFlash,item:historyItem});case"single":return u(SlowdownHistoryItem,{event:historyItem.event,shouldFlash:shouldFlash(historyItem.event.id)},historyItem.event.id);case"collapsed-frame-drops":return u(CollapsedItem,{shouldFlash,item:historyItem})}}))]})]})},"SlowdownHistory"),getGroupedFiberRenders=__name(fiberRenders=>Object.values(fiberRenders).map(render2=>({id:not_globally_unique_generateId(),totalTime:render2.nodeInfo.reduce((prev,curr)=>prev+curr.selfTime,0),count:render2.nodeInfo.length,name:render2.nodeInfo[0].name,deletedAll:!1,elements:render2.nodeInfo.map(node=>node.element),changes:{context:render2.changes.fiberContext.current.filter(change=>render2.changes.fiberContext.changesCounts.get(change.name)).map(change=>({name:String(change.name),count:render2.changes.fiberContext.changesCounts.get(change.name)??0})),props:render2.changes.fiberProps.current.filter(change=>render2.changes.fiberProps.changesCounts.get(change.name)).map(change=>({name:String(change.name),count:render2.changes.fiberProps.changesCounts.get(change.name)??0})),state:render2.changes.fiberState.current.filter(change=>render2.changes.fiberState.changesCounts.get(Number(change.name))).map(change=>({index:change.name,count:render2.changes.fiberState.changesCounts.get(Number(change.name))??0}))}})),"getGroupedFiberRenders"),useGarbageCollectElements=__name(notificationEvents=>{y$1(()=>{const intervalId=setInterval(__name(()=>{notificationEvents.forEach(event=>{event.groupedFiberRenders&&event.groupedFiberRenders.forEach(render2=>{if(render2.deletedAll)return;if(!render2.elements||render2.elements.length===0){render2.deletedAll=!0;return}const initialLength=render2.elements.length;render2.elements=render2.elements.filter(element=>element&&element.isConnected),render2.elements.length===0&&initialLength>0&&(render2.deletedAll=!0)})})},"checkElementsExistence"),5e3);return()=>{clearInterval(intervalId)}},[notificationEvents])},"useGarbageCollectElements"),useAppNotifications=__name(()=>{const log2=useToolbarEventLog(),notificationEvents=[];return useGarbageCollectElements(notificationEvents),log2.state.events.forEach(event=>{const fiberRenders=event.kind==="interaction"?event.data.meta.detailedTiming.fiberRenders:event.data.meta.fiberRenders,groupedFiberRenders=getGroupedFiberRenders(fiberRenders),renderTime=groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0);switch(event.kind){case"interaction":{const{commitEnd,jsEndDetail,interactionStartDetail,rafStart}=event.data.meta.detailedTiming,otherJSTime=Math.max(0,jsEndDetail-interactionStartDetail-renderTime),frameDraw=Math.max(event.data.meta.latency-(commitEnd-interactionStartDetail),0);notificationEvents.push({componentPath:event.data.meta.detailedTiming.componentPath,groupedFiberRenders,id:event.id,kind:"interaction",memory:null,timestamp:event.data.startAt,type:event.data.meta.detailedTiming.interactionType==="keyboard"?"keyboard":"click",timing:{renderTime,kind:"interaction",otherJSTime,framePreparation:rafStart-jsEndDetail,frameConstruction:commitEnd-rafStart,frameDraw}});return}case"long-render":{notificationEvents.push({kind:"dropped-frames",id:event.id,memory:null,timing:{kind:"dropped-frames",renderTime,otherTime:event.data.meta.latency},groupedFiberRenders,timestamp:event.data.startAt,fps:event.data.meta.fps});return}}}),notificationEvents},"useAppNotifications"),timeout=1e3,NotificationAudio=__name(()=>{const{notificationState,setNotificationState}=useNotificationsContext(),playedFor=A$1(null),debounceTimeout=A$1(null),lastPlayedTime=A$1(0),[laggedEvents]=useLaggedEvents(),alertEventsCount=laggedEvents.filter(event=>getEventSeverity(event)==="high").length;return y$1(()=>{const audioEnabledString=localStorage.getItem("react-scan-notifications-audio");if(audioEnabledString!=="false"&&audioEnabledString!=="true"){localStorage.setItem("react-scan-notifications-audio","false");return}if(audioEnabledString!=="false"){setNotificationState(prev=>prev.audioNotificationsOptions.enabled?prev:{...prev,audioNotificationsOptions:{enabled:!0,audioContext:new AudioContext}});return}},[]),y$1(()=>{const{audioNotificationsOptions}=notificationState;if(!audioNotificationsOptions.enabled||alertEventsCount===0||playedFor.current&&playedFor.current>=alertEventsCount)return;debounceTimeout.current&&clearTimeout(debounceTimeout.current);const timeSinceLastPlay=Date.now()-lastPlayedTime.current,remainingDebounceTime=Math.max(0,timeout-timeSinceLastPlay);debounceTimeout.current=setTimeout(()=>{playNotificationSound(audioNotificationsOptions.audioContext),playedFor.current=alertEventsCount,lastPlayedTime.current=Date.now(),debounceTimeout.current=null},remainingDebounceTime)},[alertEventsCount]),y$1(()=>{alertEventsCount===0&&(playedFor.current=null)},[alertEventsCount]),y$1(()=>()=>{debounceTimeout.current&&clearTimeout(debounceTimeout.current)},[]),null},"NotificationAudio"),NotificationWrapper=A((_3,ref)=>{const events=useAppNotifications(),[notificationState,setNotificationState]=h$1({detailsExpanded:!1,events,filterBy:"latest",moreInfoExpanded:!1,route:"render-visualization",selectedEvent:events.toSorted((a2,b2)=>a2.timestamp-b2.timestamp).at(-1)??null,selectedFiber:null,routeMessage:null,audioNotificationsOptions:{enabled:!1,audioContext:null}});return notificationState.events=events,u(NotificationStateContext.Provider,{value:{notificationState,setNotificationState,setRoute:__name(({route,routeMessage})=>{setNotificationState(prev=>{const newState={...prev,route,routeMessage};switch(route){case"render-visualization":return fadeOutHighlights(),{...newState,selectedFiber:null};case"optimize":return fadeOutHighlights(),{...newState,selectedFiber:null};case"other-visualization":return fadeOutHighlights(),{...newState,selectedFiber:null};case"render-explanation":return fadeOutHighlights(),newState}})},"setRoute")},children:[u(NotificationAudio,{}),u(Notifications,{ref})]})}),Notifications=A((_3,ref)=>{var _a2;const{notificationState}=useNotificationsContext();return u("div",{ref,className:cn(["h-full w-full flex flex-col"]),children:[notificationState.selectedEvent&&u("div",{className:cn(["w-full h-[48px] flex flex-col",notificationState.moreInfoExpanded&&"h-[235px]",notificationState.moreInfoExpanded&&notificationState.selectedEvent.kind==="dropped-frames"&&"h-[150px]"]),children:[u(NotificationHeader,{selectedEvent:notificationState.selectedEvent}),notificationState.moreInfoExpanded&&u(MoreInfo,{})]}),u("div",{className:cn(["flex ",notificationState.selectedEvent?"h-[calc(100%-48px)]":"h-full",notificationState.moreInfoExpanded&&"h-[calc(100%-200px)]",notificationState.moreInfoExpanded&&((_a2=notificationState.selectedEvent)==null?void 0:_a2.kind)==="dropped-frames"&&"h-[calc(100%-150px)]"]),children:[u("div",{className:cn(["h-full min-w-[200px]"]),children:u(SlowdownHistory,{})}),u("div",{className:cn(["w-[calc(100%-200px)] h-full overflow-y-auto"]),children:u(DetailsRoutes,{})})]})]})}),MoreInfo=__name(()=>{const{notificationState}=useNotificationsContext();if(!notificationState.selectedEvent)throw new Error("Invariant must have selected event for more info");const event=notificationState.selectedEvent;return u("div",{className:cn(["px-4 py-2 border-b border-[#27272A] bg-[#18181B]/50 h-[calc(100%-40px)]",event.kind==="dropped-frames"&&"h-[calc(100%-25px)]"]),children:u("div",{className:cn(["flex flex-col gap-y-4 h-full"]),children:iife(()=>{switch(event.kind){case"interaction":return u(k$1,{children:[u("div",{className:cn(["flex items-center gap-x-3"]),children:[u("span",{className:"text-[#6F6F78] text-xs font-medium",children:event.type==="click"?"Clicked component location":"Typed in component location"}),u("div",{className:"font-mono text-[#E4E4E7] flex items-center bg-[#27272A] pl-2 py-1 rounded-sm overflow-x-auto",children:event.componentPath.toReversed().map((part,i2)=>u(k$1,{children:[u("span",{style:{lineHeight:"14px"},className:"text-[10px] whitespace-nowrap",children:part},part),i2<event.componentPath.length-1&&u("span",{className:"text-[#6F6F78] mx-0.5",children:"‹"})]}))})]}),u("div",{className:cn(["flex items-center gap-x-3"]),children:[u("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Total Time"}),u("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:[getTotalTime(event.timing).toFixed(0),"ms"]})]}),u("div",{className:cn(["flex items-center gap-x-3"]),children:[u("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Occurred"}),u("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:`${((Date.now()-event.timestamp)/1e3).toFixed(0)}s ago`})]})]});case"dropped-frames":return u(k$1,{children:[u("div",{className:cn(["flex items-center gap-x-3"]),children:[u("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Total Time"}),u("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:[getTotalTime(event.timing).toFixed(0),"ms"]})]}),u("div",{className:cn(["flex items-center gap-x-3"]),children:[u("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Occurred"}),u("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:`${((Date.now()-event.timestamp)/1e3).toFixed(0)}s ago`})]})]})}})})})},"MoreInfo"),Toolbar=constant(()=>{var _a2;const events=useAppNotifications(),[laggedEvents,setLaggedEvents]=h$1(events);y$1(()=>{const timeout2=setTimeout(()=>{setLaggedEvents(events)},600);return()=>{clearTimeout(timeout2)}},[events]);const inspectState=Store.inspectState,isInspectActive=inspectState.value.kind==="inspecting",isInspectFocused=inspectState.value.kind==="focused",onToggleInspect=q$1(()=>{switch(Store.inspectState.value.kind){case"inspecting":{signalWidgetViews.value={view:"none"},Store.inspectState.value={kind:"inspect-off"};return}case"focused":{signalWidgetViews.value={view:"inspector"},Store.inspectState.value={kind:"inspecting",hoveredDomElement:null};return}case"inspect-off":{signalWidgetViews.value={view:"none"},Store.inspectState.value={kind:"inspecting",hoveredDomElement:null};return}case"uninitialized":return}},[]),onToggleNotifications=q$1(()=>{switch(Store.inspectState.value.kind!=="inspect-off"&&(Store.inspectState.value={kind:"inspect-off"}),signalWidgetViews.value.view){case"inspector":{Store.inspectState.value={kind:"inspect-off"},signalWidgetViews.value={view:"notifications"};return}case"notifications":{signalWidgetViews.value={view:"none"};return}case"none":{signalWidgetViews.value={view:"notifications"};return}}},[]),onToggleActive=q$1(e2=>{if(e2.preventDefault(),e2.stopPropagation(),!ReactScanInternals.instrumentation)return;const isPaused=!ReactScanInternals.instrumentation.isPaused.value;ReactScanInternals.instrumentation.isPaused.value=isPaused;const existingLocalStorageOptions=readLocalStorage$1("react-scan-options");saveLocalStorage$1("react-scan-options",{...existingLocalStorageOptions,enabled:!isPaused})},[]);useSignalEffect(()=>{Store.inspectState.value.kind==="uninitialized"&&(Store.inspectState.value={kind:"inspect-off"})});let inspectIcon=null,inspectColor="#999";return isInspectActive?(inspectIcon=u(Icon,{name:"icon-inspect"}),inspectColor="#8e61e3"):isInspectFocused?(inspectIcon=u(Icon,{name:"icon-focus"}),inspectColor="#8e61e3"):(inspectIcon=u(Icon,{name:"icon-inspect"}),inspectColor="#999"),u("div",{className:"flex max-h-9 min-h-9 flex-1 items-stretch overflow-hidden",children:[u("div",{className:"h-full flex items-center min-w-fit",children:u("button",{type:"button",id:"react-scan-inspect-element",title:"Inspect element",onClick:onToggleInspect,className:"button flex items-center justify-center h-full w-full pl-3 pr-2.5",style:{color:inspectColor},children:inspectIcon})}),u("div",{className:"h-full flex items-center justify-center",children:u("button",{type:"button",id:"react-scan-notifications",onClick:onToggleNotifications,className:"button flex items-center justify-center h-full pl-2.5 pr-2.5",style:{color:inspectColor},children:u(Notification,{events:laggedEvents.map(event=>getEventSeverity(event)==="high"),size:16,className:cn(["text-[#999]",signalWidgetViews.value.view==="notifications"&&"text-[#8E61E3]"])})})}),u(Toggle,{checked:!((_a2=ReactScanInternals.instrumentation)!=null&&_a2.isPaused.value),onChange:onToggleActive,className:"place-self-center"}),ReactScanInternals.options.value.showFPS&&u(FPSMeter,{})]})}),isInspecting=w(()=>Store.inspectState.value.kind==="inspecting"),headerClassName=w(()=>cn("relative","flex-1","flex flex-col","rounded-t-lg","overflow-hidden","opacity-100","transition-[opacity]",isInspecting.value&&"opacity-0 duration-0 delay-0")),isInspectorViewOpen=w(()=>signalWidgetViews.value.view==="inspector"),isNotificationsViewOpen=w(()=>signalWidgetViews.value.view==="notifications"),Content=__name(()=>u("div",{className:cn("flex flex-1 flex-col","overflow-hidden z-10","rounded-lg","bg-black","opacity-100","transition-[border-radius]","peer-hover/left:rounded-l-none","peer-hover/right:rounded-r-none","peer-hover/top:rounded-t-none","peer-hover/bottom:rounded-b-none"),children:[u("div",{className:headerClassName,children:[u(Header,{}),u("div",{className:cn("relative","flex-1 flex","text-white","bg-[#0A0A0A]","transition-opacity delay-150","overflow-hidden","border-b border-[#222]"),children:[u(ContentView,{isOpen:isInspectorViewOpen,children:u(ViewInspector,{})}),u(ContentView,{isOpen:isNotificationsViewOpen,children:u(NotificationWrapper,{})})]})]}),u(Toolbar,{})]}),"Content"),ContentView=__name(({isOpen,children})=>u("div",{className:cn("flex-1","opacity-0","overflow-y-auto overflow-x-hidden","transition-opacity delay-0","pointer-events-none",isOpen.value&&"opacity-100 delay-150 pointer-events-auto"),children:u("div",{className:"absolute inset-0 flex",children})}),"ContentView"),lerp2=__name((start2,end,t2)=>start2+(end-start2)*t2,"lerp2"),ANIMATION_CONFIG={frameInterval:1e3/60,speeds:{fast:.51,slow:.1,off:0}},OVERLAY_DPR=IS_CLIENT&&window.devicePixelRatio||1,ScanOverlay=__name(()=>{const refCanvas=A$1(null),refEventCatcher=A$1(null),refCurrentRect=A$1(null),refCurrentLockIconRect=A$1(null),refLastHoveredElement=A$1(null),refRafId=A$1(0),refTimeout=A$1(),refCleanupMap=A$1(new Map),refIsFadingOut=A$1(!1),refLastFrameTime=A$1(0),drawLockIcon=__name((ctx2,x2,y2,size)=>{ctx2.save(),ctx2.strokeStyle="white",ctx2.fillStyle="white",ctx2.lineWidth=1.5;const shackleWidth=size*.6,shackleHeight=size*.5,shackleX=x2+(size-shackleWidth)/2,shackleY=y2;ctx2.beginPath(),ctx2.arc(shackleX+shackleWidth/2,shackleY+shackleHeight/2,shackleWidth/2,Math.PI,0,!1),ctx2.stroke();const bodyWidth=size*.8,bodyHeight=size*.5,bodyX=x2+(size-bodyWidth)/2,bodyY=y2+shackleHeight/2;ctx2.fillRect(bodyX,bodyY,bodyWidth,bodyHeight),ctx2.restore()},"drawLockIcon"),drawStatsPill=__name((ctx2,rect,kind,fiber)=>{if(!fiber)return;const pillHeight=24,pillPadding=8,text=((fiber==null?void 0:fiber.type)&&getDisplayName(fiber.type))??"Unknown";ctx2.save(),ctx2.font="12px system-ui, -apple-system, sans-serif";const textWidth=ctx2.measureText(text).width,lockIconSize=kind==="locked"?14:0,lockIconPadding=kind==="locked"?6:0,pillWidth=textWidth+pillPadding*2+lockIconSize+lockIconPadding,pillX=rect.left,pillY=rect.top-pillHeight-4;if(ctx2.fillStyle="rgb(37, 37, 38, .75)",ctx2.beginPath(),ctx2.roundRect(pillX,pillY,pillWidth,pillHeight,3),ctx2.fill(),kind==="locked"){const lockX=pillX+pillPadding,lockY=pillY+(pillHeight-lockIconSize)/2+2;drawLockIcon(ctx2,lockX,lockY,lockIconSize),refCurrentLockIconRect.current={x:lockX,y:lockY,width:lockIconSize,height:lockIconSize}}else refCurrentLockIconRect.current=null;ctx2.fillStyle="white",ctx2.textBaseline="middle";const textX=pillX+pillPadding+(kind==="locked"?lockIconSize+lockIconPadding:0);ctx2.fillText(text,textX,pillY+pillHeight/2),ctx2.restore()},"drawStatsPill"),drawRect=__name((canvas2,ctx2,kind,fiber)=>{if(!refCurrentRect.current)return;const rect=refCurrentRect.current;ctx2.clearRect(0,0,canvas2.width,canvas2.height),ctx2.strokeStyle="rgba(142, 97, 227, 0.5)",ctx2.fillStyle="rgba(173, 97, 230, 0.10)",kind==="locked"?ctx2.setLineDash([]):ctx2.setLineDash([4]),ctx2.lineWidth=1,ctx2.fillRect(rect.left,rect.top,rect.width,rect.height),ctx2.strokeRect(rect.left,rect.top,rect.width,rect.height),drawStatsPill(ctx2,rect,kind,fiber)},"drawRect"),animate=__name((canvas2,ctx2,targetRect,kind,parentCompositeFiber,onComplete)=>{const speed=ReactScanInternals.options.value.animationSpeed,t2=ANIMATION_CONFIG.speeds[speed]??ANIMATION_CONFIG.speeds.off,animationFrame2=__name(timestamp=>{if(timestamp-refLastFrameTime.current<ANIMATION_CONFIG.frameInterval){refRafId.current=requestAnimationFrame(animationFrame2);return}if(refLastFrameTime.current=timestamp,!refCurrentRect.current){cancelAnimationFrame(refRafId.current);return}refCurrentRect.current={left:lerp2(refCurrentRect.current.left,targetRect.left,t2),top:lerp2(refCurrentRect.current.top,targetRect.top,t2),width:lerp2(refCurrentRect.current.width,targetRect.width,t2),height:lerp2(refCurrentRect.current.height,targetRect.height,t2)},drawRect(canvas2,ctx2,kind,parentCompositeFiber),Math.abs(refCurrentRect.current.left-targetRect.left)>.1||Math.abs(refCurrentRect.current.top-targetRect.top)>.1||Math.abs(refCurrentRect.current.width-targetRect.width)>.1||Math.abs(refCurrentRect.current.height-targetRect.height)>.1?refRafId.current=requestAnimationFrame(animationFrame2):(refCurrentRect.current=targetRect,drawRect(canvas2,ctx2,kind,parentCompositeFiber),cancelAnimationFrame(refRafId.current),ctx2.restore())},"animationFrame2");cancelAnimationFrame(refRafId.current),clearTimeout(refTimeout.current),refRafId.current=requestAnimationFrame(animationFrame2),refTimeout.current=setTimeout(()=>{cancelAnimationFrame(refRafId.current),refCurrentRect.current=targetRect,drawRect(canvas2,ctx2,kind,parentCompositeFiber),ctx2.restore()},1e3)},"animate"),setupOverlayAnimation=__name((canvas2,ctx2,targetRect,kind,parentCompositeFiber)=>{if(ctx2.save(),!refCurrentRect.current){refCurrentRect.current=targetRect,drawRect(canvas2,ctx2,kind,parentCompositeFiber),ctx2.restore();return}animate(canvas2,ctx2,targetRect,kind,parentCompositeFiber)},"setupOverlayAnimation"),drawHoverOverlay=__name(async(overlayElement,canvas2,ctx2,kind)=>{if(!overlayElement||!canvas2||!ctx2)return;const{parentCompositeFiber}=getCompositeComponentFromElement(overlayElement),targetRect=await getAssociatedFiberRect(overlayElement);!parentCompositeFiber||!targetRect||setupOverlayAnimation(canvas2,ctx2,targetRect,kind,parentCompositeFiber)},"drawHoverOverlay"),unsubscribeAll=__name(()=>{for(const cleanup3 of refCleanupMap.current.values())cleanup3==null||cleanup3()},"unsubscribeAll"),cleanupCanvas=__name(canvas2=>{const ctx2=canvas2.getContext("2d");ctx2&&ctx2.clearRect(0,0,canvas2.width,canvas2.height),refCurrentRect.current=null,refCurrentLockIconRect.current=null,refLastHoveredElement.current=null,canvas2.classList.remove("fade-in"),refIsFadingOut.current=!1},"cleanupCanvas"),startFadeOut=__name(onComplete=>{if(!refCanvas.current||refIsFadingOut.current)return;const handleTransitionEnd=__name(e2=>{!refCanvas.current||e2.propertyName!=="opacity"||!refIsFadingOut.current||(refCanvas.current.removeEventListener("transitionend",handleTransitionEnd),cleanupCanvas(refCanvas.current),onComplete==null||onComplete())},"handleTransitionEnd"),existingListener=refCleanupMap.current.get("fade-out");existingListener&&(existingListener(),refCleanupMap.current.delete("fade-out")),refCanvas.current.addEventListener("transitionend",handleTransitionEnd),refCleanupMap.current.set("fade-out",()=>{var _a2;(_a2=refCanvas.current)==null||_a2.removeEventListener("transitionend",handleTransitionEnd)}),refIsFadingOut.current=!0,refCanvas.current.classList.remove("fade-in"),requestAnimationFrame(()=>{var _a2;(_a2=refCanvas.current)==null||_a2.classList.add("fade-out")})},"startFadeOut"),startFadeIn=__name(()=>{refCanvas.current&&(refIsFadingOut.current=!1,refCanvas.current.classList.remove("fade-out"),requestAnimationFrame(()=>{var _a2;(_a2=refCanvas.current)==null||_a2.classList.add("fade-in")}))},"startFadeIn"),handleHoverableElement=__name(componentElement=>{componentElement!==refLastHoveredElement.current&&(refLastHoveredElement.current=componentElement,nonVisualTags.has(componentElement.tagName)?startFadeOut():startFadeIn(),Store.inspectState.value={kind:"inspecting",hoveredDomElement:componentElement})},"handleHoverableElement"),handleNonHoverableArea=__name(()=>{!refCurrentRect.current||!refCanvas.current||refIsFadingOut.current||startFadeOut()},"handleNonHoverableArea"),handlePointerMove=throttle(e2=>{if(Store.inspectState.peek().kind!=="inspecting"||!refEventCatcher.current)return;refEventCatcher.current.style.pointerEvents="none";const element=document.elementFromPoint((e2==null?void 0:e2.clientX)??0,(e2==null?void 0:e2.clientY)??0);if(refEventCatcher.current.style.removeProperty("pointer-events"),clearTimeout(refTimeout.current),element&&element!==refCanvas.current){const{parentCompositeFiber}=getCompositeComponentFromElement(element);if(parentCompositeFiber){const componentElement=findComponentDOMNode(parentCompositeFiber);if(componentElement){handleHoverableElement(componentElement);return}}}handleNonHoverableArea()},32),isClickInLockIcon=__name((e2,canvas2)=>{const currentRect=refCurrentLockIconRect.current;if(!currentRect)return!1;const rect=canvas2.getBoundingClientRect(),scaleX=canvas2.width/rect.width,scaleY=canvas2.height/rect.height,x2=(e2.clientX-rect.left)*scaleX,y2=(e2.clientY-rect.top)*scaleY,adjustedX=x2/OVERLAY_DPR,adjustedY=y2/OVERLAY_DPR;return adjustedX>=currentRect.x&&adjustedX<=currentRect.x+currentRect.width&&adjustedY>=currentRect.y&&adjustedY<=currentRect.y+currentRect.height},"isClickInLockIcon"),handleLockIconClick=__name(state=>{state.kind==="focused"&&(Store.inspectState.value={kind:"inspecting",hoveredDomElement:state.focusedDomElement})},"handleLockIconClick"),handleElementClick=__name(e2=>{var _a2;const clickableElements=["react-scan-inspect-element","react-scan-power"];if(e2.target instanceof HTMLElement&&clickableElements.includes(e2.target.id))return;const tagName=(_a2=refLastHoveredElement.current)==null?void 0:_a2.tagName;if(tagName&&nonVisualTags.has(tagName))return;e2.preventDefault(),e2.stopPropagation();const element=refLastHoveredElement.current??document.elementFromPoint(e2.clientX,e2.clientY);if(!element)return;const clickedEl=e2.composedPath().at(0);if(clickedEl instanceof HTMLElement&&clickableElements.includes(clickedEl.id)){const syntheticEvent=new MouseEvent(e2.type,e2);syntheticEvent.__reactScanSyntheticEvent=!0,clickedEl.dispatchEvent(syntheticEvent);return}const{parentCompositeFiber}=getCompositeComponentFromElement(element);if(!parentCompositeFiber)return;const componentElement=findComponentDOMNode(parentCompositeFiber);if(!componentElement){refLastHoveredElement.current=null,Store.inspectState.value={kind:"inspect-off"};return}Store.inspectState.value={kind:"focused",focusedDomElement:componentElement,fiber:parentCompositeFiber}},"handleElementClick"),handleClick=__name(e2=>{if(e2.__reactScanSyntheticEvent)return;const state=Store.inspectState.peek(),canvas2=refCanvas.current;if(!(!canvas2||!refEventCatcher.current)){if(isClickInLockIcon(e2,canvas2)){e2.preventDefault(),e2.stopPropagation(),handleLockIconClick(state);return}state.kind==="inspecting"&&handleElementClick(e2)}},"handleClick"),handleKeyDown=__name(e2=>{var _a2;if(e2.key!=="Escape")return;const state=Store.inspectState.peek();if(refCanvas.current&&((_a2=document.activeElement)==null?void 0:_a2.id)!=="react-scan-root"&&(signalWidgetViews.value={view:"none"},state.kind==="focused"||state.kind==="inspecting"))switch(e2.preventDefault(),e2.stopPropagation(),state.kind){case"focused":{startFadeIn(),refCurrentRect.current=null,refLastHoveredElement.current=state.focusedDomElement,Store.inspectState.value={kind:"inspecting",hoveredDomElement:state.focusedDomElement};break}case"inspecting":{startFadeOut(()=>{signalIsSettingsOpen.value=!1,Store.inspectState.value={kind:"inspect-off"}});break}}},"handleKeyDown"),handleStateChange=__name((state,canvas2,ctx2)=>{var _a2;(_a2=refCleanupMap.current.get(state.kind))==null||_a2(),refEventCatcher.current&&state.kind!=="inspecting"&&(refEventCatcher.current.style.pointerEvents="none"),refRafId.current&&cancelAnimationFrame(refRafId.current);let unsubReport;switch(state.kind){case"inspect-off":startFadeOut();return;case"inspecting":drawHoverOverlay(state.hoveredDomElement,canvas2,ctx2,"inspecting");break;case"focused":if(!state.focusedDomElement)return;refLastHoveredElement.current!==state.focusedDomElement&&(refLastHoveredElement.current=state.focusedDomElement),signalWidgetViews.value={view:"inspector"},drawHoverOverlay(state.focusedDomElement,canvas2,ctx2,"locked"),unsubReport=Store.lastReportTime.subscribe(()=>{if(refRafId.current&&refCurrentRect.current){const{parentCompositeFiber}=getCompositeComponentFromElement(state.focusedDomElement);parentCompositeFiber&&drawHoverOverlay(state.focusedDomElement,canvas2,ctx2,"locked")}}),unsubReport&&refCleanupMap.current.set(state.kind,unsubReport);break}},"handleStateChange"),updateCanvasSize=__name((canvas2,ctx2)=>{const rect=canvas2.getBoundingClientRect();canvas2.width=rect.width*OVERLAY_DPR,canvas2.height=rect.height*OVERLAY_DPR,ctx2.scale(OVERLAY_DPR,OVERLAY_DPR),ctx2.save()},"updateCanvasSize"),handleResizeOrScroll=__name(()=>{const state=Store.inspectState.peek(),canvas2=refCanvas.current;if(!canvas2)return;const ctx2=canvas2==null?void 0:canvas2.getContext("2d");ctx2&&(cancelAnimationFrame(refRafId.current),clearTimeout(refTimeout.current),updateCanvasSize(canvas2,ctx2),refCurrentRect.current=null,state.kind==="focused"&&state.focusedDomElement?drawHoverOverlay(state.focusedDomElement,canvas2,ctx2,"locked"):state.kind==="inspecting"&&state.hoveredDomElement&&drawHoverOverlay(state.hoveredDomElement,canvas2,ctx2,"inspecting"))},"handleResizeOrScroll"),handlePointerDown=__name(e2=>{const state=Store.inspectState.peek(),canvas2=refCanvas.current;canvas2&&(state.kind==="inspecting"||isClickInLockIcon(e2,canvas2))&&(e2.preventDefault(),e2.stopPropagation(),e2.stopImmediatePropagation())},"handlePointerDown");return y$1(()=>{const canvas2=refCanvas.current;if(!canvas2)return;const ctx2=canvas2==null?void 0:canvas2.getContext("2d");if(!ctx2)return;updateCanvasSize(canvas2,ctx2);const unSubState=Store.inspectState.subscribe(state=>{handleStateChange(state,canvas2,ctx2)});return window.addEventListener("scroll",handleResizeOrScroll,{passive:!0}),window.addEventListener("resize",handleResizeOrScroll,{passive:!0}),document.addEventListener("pointermove",handlePointerMove,{passive:!0,capture:!0}),document.addEventListener("pointerdown",handlePointerDown,{capture:!0}),document.addEventListener("click",handleClick,{capture:!0}),document.addEventListener("keydown",handleKeyDown,{capture:!0}),()=>{unsubscribeAll(),unSubState(),window.removeEventListener("scroll",handleResizeOrScroll),window.removeEventListener("resize",handleResizeOrScroll),document.removeEventListener("pointermove",handlePointerMove,{capture:!0}),document.removeEventListener("click",handleClick,{capture:!0}),document.removeEventListener("pointerdown",handlePointerDown,{capture:!0}),document.removeEventListener("keydown",handleKeyDown,{capture:!0}),refRafId.current&&cancelAnimationFrame(refRafId.current),clearTimeout(refTimeout.current)}},[]),u(k$1,{children:[u("div",{ref:refEventCatcher,className:cn("fixed inset-0 w-screen h-screen","z-[214748365]"),style:{pointerEvents:"none"}}),u("canvas",{ref:refCanvas,dir:"ltr",className:cn("react-scan-inspector-overlay","fixed inset-0 w-screen h-screen","pointer-events-none","z-[214748367]")})]})},"ScanOverlay"),WindowDimensions=(_e=class{constructor(width,height){this.width=width,this.height=height,this.maxWidth=width-SAFE_AREA*2,this.maxHeight=height-SAFE_AREA*2}rightEdge(width){return this.width-width-SAFE_AREA}bottomEdge(height){return this.height-height-SAFE_AREA}isFullWidth(width){return width>=this.maxWidth}isFullHeight(height){return height>=this.maxHeight}},__name(_e,"WindowDimensions"),_e),cachedWindowDimensions,getWindowDimensions=__name(()=>{const currentWidth=window.innerWidth,currentHeight=window.innerHeight;return cachedWindowDimensions&&cachedWindowDimensions.width===currentWidth&&cachedWindowDimensions.height===currentHeight||(cachedWindowDimensions=new WindowDimensions(currentWidth,currentHeight)),cachedWindowDimensions},"getWindowDimensions"),getOppositeCorner=__name((position,currentCorner,isFullScreen,isFullWidth,isFullHeight)=>{if(isFullScreen){if(position==="top-left")return"bottom-right";if(position==="top-right")return"bottom-left";if(position==="bottom-left")return"top-right";if(position==="bottom-right")return"top-left";const[vertical,horizontal]=currentCorner.split("-");if(position==="left")return`${vertical}-right`;if(position==="right")return`${vertical}-left`;if(position==="top")return`bottom-${horizontal}`;if(position==="bottom")return`top-${horizontal}`}if(isFullWidth){if(position==="left")return`${currentCorner.split("-")[0]}-right`;if(position==="right")return`${currentCorner.split("-")[0]}-left`}if(isFullHeight){if(position==="top")return`bottom-${currentCorner.split("-")[1]}`;if(position==="bottom")return`top-${currentCorner.split("-")[1]}`}return currentCorner},"getOppositeCorner"),calculatePosition=__name((corner,width,height)=>{const windowWidth=window.innerWidth,windowHeight=window.innerHeight,isMinimized=width===MIN_SIZE.width,effectiveWidth=isMinimized?width:Math.min(width,windowWidth-SAFE_AREA*2),effectiveHeight=isMinimized?height:Math.min(height,windowHeight-SAFE_AREA*2);let x2,y2;switch(corner){case"top-right":x2=windowWidth-effectiveWidth-SAFE_AREA,y2=SAFE_AREA;break;case"bottom-right":x2=windowWidth-effectiveWidth-SAFE_AREA,y2=windowHeight-effectiveHeight-SAFE_AREA;break;case"bottom-left":x2=SAFE_AREA,y2=windowHeight-effectiveHeight-SAFE_AREA;break;case"top-left":x2=SAFE_AREA,y2=SAFE_AREA;break;default:x2=SAFE_AREA,y2=SAFE_AREA;break}return isMinimized&&(x2=Math.max(SAFE_AREA,Math.min(x2,windowWidth-effectiveWidth-SAFE_AREA)),y2=Math.max(SAFE_AREA,Math.min(y2,windowHeight-effectiveHeight-SAFE_AREA))),{x:x2,y:y2}},"calculatePosition"),positionMatchesCorner=__name((position,corner)=>{const[vertical,horizontal]=corner.split("-");return position!==vertical&&position!==horizontal},"positionMatchesCorner"),getHandleVisibility=__name((position,corner,isFullWidth,isFullHeight)=>isFullWidth&&isFullHeight?!0:!isFullWidth&&!isFullHeight?positionMatchesCorner(position,corner):isFullWidth?position!==corner.split("-")[0]:isFullHeight?position!==corner.split("-")[1]:!1,"getHandleVisibility"),calculateBoundedSize=__name((currentSize,delta,isWidth)=>{const min=isWidth?MIN_SIZE.width:MIN_SIZE.initialHeight,max=isWidth?getWindowDimensions().maxWidth:getWindowDimensions().maxHeight,newSize=currentSize+delta;return Math.min(Math.max(min,newSize),max)},"calculateBoundedSize"),calculateNewSizeAndPosition=__name((position,initialSize,initialPosition,deltaX,deltaY)=>{const maxWidth=window.innerWidth-SAFE_AREA*2,maxHeight=window.innerHeight-SAFE_AREA*2;let newWidth=initialSize.width,newHeight=initialSize.height,newX=initialPosition.x,newY=initialPosition.y;if(position.includes("right")){const availableWidth=window.innerWidth-initialPosition.x-SAFE_AREA,proposedWidth=Math.min(initialSize.width+deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth))}if(position.includes("left")){const availableWidth=initialPosition.x+initialSize.width-SAFE_AREA,proposedWidth=Math.min(initialSize.width-deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth)),newX=initialPosition.x-(newWidth-initialSize.width)}if(position.includes("bottom")){const availableHeight=window.innerHeight-initialPosition.y-SAFE_AREA,proposedHeight=Math.min(initialSize.height+deltaY,availableHeight);newHeight=Math.min(maxHeight,Math.max(MIN_SIZE.initialHeight,proposedHeight))}if(position.includes("top")){const availableHeight=initialPosition.y+initialSize.height-SAFE_AREA,proposedHeight=Math.min(initialSize.height-deltaY,availableHeight);newHeight=Math.min(maxHeight,Math.max(MIN_SIZE.initialHeight,proposedHeight)),newY=initialPosition.y-(newHeight-initialSize.height)}return newX=Math.max(SAFE_AREA,Math.min(newX,window.innerWidth-SAFE_AREA-newWidth)),newY=Math.max(SAFE_AREA,Math.min(newY,window.innerHeight-SAFE_AREA-newHeight)),{newSize:{width:newWidth,height:newHeight},newPosition:{x:newX,y:newY}}},"calculateNewSizeAndPosition"),getClosestCorner=__name(position=>{const windowDims=getWindowDimensions(),distances={"top-left":Math.hypot(position.x,position.y),"top-right":Math.hypot(windowDims.maxWidth-position.x,position.y),"bottom-left":Math.hypot(position.x,windowDims.maxHeight-position.y),"bottom-right":Math.hypot(windowDims.maxWidth-position.x,windowDims.maxHeight-position.y)};let closest="top-left";for(const key in distances)distances[key]<distances[closest]&&(closest=key);return closest},"getClosestCorner"),getBestCorner=__name((mouseX,mouseY,initialMouseX,initialMouseY,threshold=100)=>{const deltaX=initialMouseX!==void 0?mouseX-initialMouseX:0,deltaY=initialMouseY!==void 0?mouseY-initialMouseY:0,windowCenterX=window.innerWidth/2,windowCenterY=window.innerHeight/2,movingRight=deltaX>threshold,movingLeft=deltaX<-threshold,movingDown=deltaY>threshold,movingUp=deltaY<-threshold;if(movingRight||movingLeft){const isBottom=mouseY>windowCenterY;return movingRight?isBottom?"bottom-right":"top-right":isBottom?"bottom-left":"top-left"}if(movingDown||movingUp){const isRight=mouseX>windowCenterX;return movingDown?isRight?"bottom-right":"bottom-left":isRight?"top-right":"top-left"}return mouseX>windowCenterX?mouseY>windowCenterY?"bottom-right":"top-right":mouseY>windowCenterY?"bottom-left":"top-left"},"getBestCorner"),ResizeHandle=__name(({position})=>{const refContainer=A$1(null),prevWidth=A$1(null),prevHeight=A$1(null),prevCorner=A$1(null);y$1(()=>{const container=refContainer.current;if(!container)return;const updateVisibility=__name(()=>{container.classList.remove("pointer-events-none");const isFocused=Store.inspectState.value.kind==="focused",shouldShow=signalWidgetViews.value.view!=="none";(isFocused||shouldShow)&&getHandleVisibility(position,signalWidget.value.corner,signalWidget.value.dimensions.isFullWidth,signalWidget.value.dimensions.isFullHeight)?container.classList.remove("hidden","pointer-events-none","opacity-0"):container.classList.add("hidden","pointer-events-none","opacity-0")},"updateVisibility"),unsubscribeSignalWidget=signalWidget.subscribe(state=>{prevWidth.current!==null&&prevHeight.current!==null&&prevCorner.current!==null&&state.dimensions.width===prevWidth.current&&state.dimensions.height===prevHeight.current&&state.corner===prevCorner.current||(updateVisibility(),prevWidth.current=state.dimensions.width,prevHeight.current=state.dimensions.height,prevCorner.current=state.corner)}),unsubscribeInspectState=Store.inspectState.subscribe(()=>{updateVisibility()});return()=>{unsubscribeSignalWidget(),unsubscribeInspectState(),prevWidth.current=null,prevHeight.current=null,prevCorner.current=null}},[]);const handleResize=q$1(e2=>{e2.preventDefault(),e2.stopPropagation();const widget=signalRefWidget.value;if(!widget)return;const containerStyle=widget.style,{dimensions}=signalWidget.value,initialX=e2.clientX,initialY=e2.clientY,initialWidth=dimensions.width,initialHeight=dimensions.height,initialPosition=dimensions.position;signalWidget.value={...signalWidget.value,dimensions:{...dimensions,isFullWidth:!1,isFullHeight:!1,width:initialWidth,height:initialHeight,position:initialPosition}};let rafId=null;const handlePointerMove=__name(e22=>{rafId||(containerStyle.transition="none",rafId=requestAnimationFrame(()=>{const{newSize,newPosition}=calculateNewSizeAndPosition(position,{width:initialWidth,height:initialHeight},initialPosition,e22.clientX-initialX,e22.clientY-initialY);containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`,containerStyle.width=`${newSize.width}px`,containerStyle.height=`${newSize.height}px`;const maxTreeWidth=Math.floor(newSize.width-MIN_SIZE.width/2),currentTreeWidth=signalWidget.value.componentsTree.width,newTreeWidth=Math.min(maxTreeWidth,Math.max(MIN_CONTAINER_WIDTH,currentTreeWidth));signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:!1,isFullHeight:!1,width:newSize.width,height:newSize.height,position:newPosition},componentsTree:{...signalWidget.value.componentsTree,width:newTreeWidth}},rafId=null}))},"handlePointerMove"),handlePointerUp=__name(()=>{rafId&&(cancelAnimationFrame(rafId),rafId=null),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerUp);const{dimensions:dimensions2,corner}=signalWidget.value,windowDims=getWindowDimensions(),isCurrentFullWidth=windowDims.isFullWidth(dimensions2.width),isCurrentFullHeight=windowDims.isFullHeight(dimensions2.height),isFullScreen=isCurrentFullWidth&&isCurrentFullHeight;let newCorner=corner;(isFullScreen||isCurrentFullWidth||isCurrentFullHeight)&&(newCorner=getClosestCorner(dimensions2.position));const newPosition=calculatePosition(newCorner,dimensions2.width,dimensions2.height),onTransitionEnd=__name(()=>{widget.removeEventListener("transitionend",onTransitionEnd)},"onTransitionEnd");widget.addEventListener("transitionend",onTransitionEnd),containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`,signalWidget.value={...signalWidget.value,corner:newCorner,dimensions:{isFullWidth:isCurrentFullWidth,isFullHeight:isCurrentFullHeight,width:dimensions2.width,height:dimensions2.height,position:newPosition},lastDimensions:{isFullWidth:isCurrentFullWidth,isFullHeight:isCurrentFullHeight,width:dimensions2.width,height:dimensions2.height,position:newPosition}},saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree})},"handlePointerUp");document.addEventListener("pointermove",handlePointerMove,{passive:!0}),document.addEventListener("pointerup",handlePointerUp)},[]),handleDoubleClick=q$1(e2=>{e2.preventDefault(),e2.stopPropagation();const widget=signalRefWidget.value;if(!widget)return;const containerStyle=widget.style,{dimensions,corner}=signalWidget.value,windowDims=getWindowDimensions(),isCurrentFullWidth=windowDims.isFullWidth(dimensions.width),isCurrentFullHeight=windowDims.isFullHeight(dimensions.height),isFullScreen=isCurrentFullWidth&&isCurrentFullHeight,isPartiallyMaximized=(isCurrentFullWidth||isCurrentFullHeight)&&!isFullScreen;let newWidth=dimensions.width,newHeight=dimensions.height;const newCorner=getOppositeCorner(position,corner,isFullScreen,isCurrentFullWidth,isCurrentFullHeight);position==="left"||position==="right"?(newWidth=isCurrentFullWidth?dimensions.width:windowDims.maxWidth,isPartiallyMaximized&&(newWidth=isCurrentFullWidth?MIN_SIZE.width:windowDims.maxWidth)):(newHeight=isCurrentFullHeight?dimensions.height:windowDims.maxHeight,isPartiallyMaximized&&(newHeight=isCurrentFullHeight?MIN_SIZE.initialHeight:windowDims.maxHeight)),isFullScreen&&(position==="left"||position==="right"?newWidth=MIN_SIZE.width:newHeight=MIN_SIZE.initialHeight);const newPosition=calculatePosition(newCorner,newWidth,newHeight),newDimensions={isFullWidth:windowDims.isFullWidth(newWidth),isFullHeight:windowDims.isFullHeight(newHeight),width:newWidth,height:newHeight,position:newPosition},maxTreeWidth=Math.floor(newWidth-MIN_SIZE.width/2),currentTreeWidth=signalWidget.value.componentsTree.width,defaultWidth=Math.floor(newWidth*.3),newTreeWidth=isCurrentFullWidth?MIN_CONTAINER_WIDTH:(position==="left"||position==="right")&&!isCurrentFullWidth?Math.min(maxTreeWidth,Math.max(MIN_CONTAINER_WIDTH,defaultWidth)):Math.min(maxTreeWidth,Math.max(MIN_CONTAINER_WIDTH,currentTreeWidth));requestAnimationFrame(()=>{signalWidget.value={corner:newCorner,dimensions:newDimensions,lastDimensions:dimensions,componentsTree:{...signalWidget.value.componentsTree,width:newTreeWidth}},containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",containerStyle.width=`${newWidth}px`,containerStyle.height=`${newHeight}px`,containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`}),saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:newDimensions,lastDimensions:dimensions,componentsTree:{...signalWidget.value.componentsTree,width:newTreeWidth}})},[]);return u("div",{ref:refContainer,onPointerDown:handleResize,onDblClick:handleDoubleClick,className:cn("absolute z-50","flex items-center justify-center","group","transition-colors select-none","peer",{"resize-left peer/left":position==="left","resize-right peer/right z-10":position==="right","resize-top peer/top":position==="top","resize-bottom peer/bottom":position==="bottom"}),children:u("span",{className:"resize-line-wrapper",children:u("span",{className:"resize-line",children:u(Icon,{name:"icon-ellipsis",size:18,className:cn("text-neutral-400",(position==="left"||position==="right")&&"rotate-90")})})})})},"ResizeHandle"),Widget=__name(()=>{const refWidget=A$1(null),refShouldOpen=A$1(!1),refInitialMinimizedWidth=A$1(0),refInitialMinimizedHeight=A$1(0),updateWidgetPosition=q$1((shouldSave=!0)=>{if(!refWidget.current)return;const{corner}=signalWidget.value;let newWidth,newHeight;if(refShouldOpen.current){const lastDims=signalWidget.value.lastDimensions;newWidth=calculateBoundedSize(lastDims.width,0,!0),newHeight=calculateBoundedSize(lastDims.height,0,!1)}else{const currentDims=signalWidget.value.dimensions;currentDims.width>refInitialMinimizedWidth.current&&(signalWidget.value={...signalWidget.value,lastDimensions:{isFullWidth:currentDims.isFullWidth,isFullHeight:currentDims.isFullHeight,width:currentDims.width,height:currentDims.height,position:currentDims.position}}),newWidth=refInitialMinimizedWidth.current,newHeight=refInitialMinimizedHeight.current}const newPosition=calculatePosition(corner,newWidth,newHeight),isTooSmall=newWidth<MIN_SIZE.width||newHeight<MIN_SIZE.initialHeight,shouldPersist=shouldSave&&!isTooSmall,container=refWidget.current,containerStyle=container.style;let rafId=null;const onTransitionEnd=__name(()=>{updateDimensions(),container.removeEventListener("transitionend",onTransitionEnd),rafId&&(cancelAnimationFrame(rafId),rafId=null)},"onTransitionEnd");container.addEventListener("transitionend",onTransitionEnd),containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",rafId=requestAnimationFrame(()=>{containerStyle.width=`${newWidth}px`,containerStyle.height=`${newHeight}px`,containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`,rafId=null});const newDimensions={isFullWidth:newWidth>=window.innerWidth-SAFE_AREA*2,isFullHeight:newHeight>=window.innerHeight-SAFE_AREA*2,width:newWidth,height:newHeight,position:newPosition};signalWidget.value={corner,dimensions:newDimensions,lastDimensions:refShouldOpen?signalWidget.value.lastDimensions:newWidth>refInitialMinimizedWidth.current?newDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree},shouldPersist&&saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:signalWidget.value.corner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree}),updateDimensions()},[]),handleDrag=q$1(e2=>{if(e2.preventDefault(),!refWidget.current||e2.target.closest("button"))return;const container=refWidget.current,containerStyle=container.style,{dimensions}=signalWidget.value,initialMouseX=e2.clientX,initialMouseY=e2.clientY,initialX=dimensions.position.x,initialY=dimensions.position.y;let currentX=initialX,currentY=initialY,rafId=null,hasMoved=!1,lastMouseX=initialMouseX,lastMouseY=initialMouseY;const handlePointerMove=__name(e22=>{rafId||(hasMoved=!0,lastMouseX=e22.clientX,lastMouseY=e22.clientY,rafId=requestAnimationFrame(()=>{const deltaX=lastMouseX-initialMouseX,deltaY=lastMouseY-initialMouseY;currentX=Number(initialX)+deltaX,currentY=Number(initialY)+deltaY,containerStyle.transition="none",containerStyle.transform=`translate3d(${currentX}px, ${currentY}px, 0)`,rafId=null}))},"handlePointerMove"),handlePointerEnd=__name(()=>{if(!container)return;rafId&&(cancelAnimationFrame(rafId),rafId=null),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerEnd);const totalDeltaX=Math.abs(lastMouseX-initialMouseX),totalDeltaY=Math.abs(lastMouseY-initialMouseY),totalMovement=Math.sqrt(totalDeltaX*totalDeltaX+totalDeltaY*totalDeltaY);if(!hasMoved||totalMovement<60)return;const newCorner=getBestCorner(lastMouseX,lastMouseY,initialMouseX,initialMouseY,Store.inspectState.value.kind==="focused"?80:40);if(newCorner===signalWidget.value.corner){containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)";const currentPosition=signalWidget.value.dimensions.position;requestAnimationFrame(()=>{containerStyle.transform=`translate3d(${currentPosition.x}px, ${currentPosition.y}px, 0)`});return}const snappedPosition=calculatePosition(newCorner,dimensions.width,dimensions.height);if(currentX===initialX&&currentY===initialY)return;const onTransitionEnd=__name(()=>{containerStyle.transition="none",updateDimensions(),container.removeEventListener("transitionend",onTransitionEnd),rafId&&(cancelAnimationFrame(rafId),rafId=null)},"onTransitionEnd");container.addEventListener("transitionend",onTransitionEnd),containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",requestAnimationFrame(()=>{containerStyle.transform=`translate3d(${snappedPosition.x}px, ${snappedPosition.y}px, 0)`}),signalWidget.value={corner:newCorner,dimensions:{isFullWidth:dimensions.isFullWidth,isFullHeight:dimensions.isFullHeight,width:dimensions.width,height:dimensions.height,position:snappedPosition},lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree},saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree})},"handlePointerEnd");document.addEventListener("pointermove",handlePointerMove),document.addEventListener("pointerup",handlePointerEnd)},[]);y$1(()=>{if(!refWidget.current)return;refWidget.current.style.width="min-content",refInitialMinimizedHeight.current=36,refInitialMinimizedWidth.current=refWidget.current.offsetWidth,refWidget.current.style.maxWidth=`calc(100vw - ${SAFE_AREA*2}px)`,refWidget.current.style.maxHeight=`calc(100vh - ${SAFE_AREA*2}px)`,Store.inspectState.value.kind!=="focused"&&(signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:!1,isFullHeight:!1,width:refInitialMinimizedWidth.current,height:refInitialMinimizedHeight.current,position:signalWidget.value.dimensions.position}}),signalRefWidget.value=refWidget.current;const unsubscribeSignalWidget=signalWidget.subscribe(widget=>{if(!refWidget.current)return;const{x:x2,y:y2}=widget.dimensions.position,{width,height}=widget.dimensions,container=refWidget.current;requestAnimationFrame(()=>{container.style.transform=`translate3d(${x2}px, ${y2}px, 0)`,container.style.width=`${width}px`,container.style.height=`${height}px`})}),unsubscribeSignalWidgetViews=signalWidgetViews.subscribe(state=>{refShouldOpen.current=state.view!=="none",updateWidgetPosition()}),unsubscribeStoreInspectState=Store.inspectState.subscribe(state=>{refShouldOpen.current=state.kind==="focused",updateWidgetPosition()}),handleWindowResize=__name(()=>{updateWidgetPosition(!0)},"handleWindowResize");return window.addEventListener("resize",handleWindowResize,{passive:!0}),()=>{window.removeEventListener("resize",handleWindowResize),unsubscribeSignalWidgetViews(),unsubscribeStoreInspectState(),unsubscribeSignalWidget(),saveLocalStorage$1(LOCALSTORAGE_KEY,{...defaultWidgetConfig,corner:signalWidget.value.corner})}},[]);const[_3,setTriggerRender]=h$1(!1);return y$1(()=>{setTriggerRender(!0)},[]),u(k$1,{children:[u(ScanOverlay,{}),u(ToolbarElementContext.Provider,{value:refWidget.current,children:u("div",{id:"react-scan-toolbar",dir:"ltr",ref:refWidget,onPointerDown:handleDrag,className:cn("fixed inset-0 rounded-lg shadow-lg","flex flex-col","font-mono text-[13px]","user-select-none","opacity-0","cursor-move","z-[124124124124]","animate-fade-in animation-duration-300 animation-delay-300","will-change-transform","[touch-action:none]"),children:[u(ResizeHandle,{position:"top"}),u(ResizeHandle,{position:"bottom"}),u(ResizeHandle,{position:"left"}),u(ResizeHandle,{position:"right"}),u(Content,{})]})})]})},"Widget"),ToolbarElementContext=J$1(null),SvgSprite=__name(()=>u("svg",{xmlns:"http://www.w3.org/2000/svg",style:"display: none;",children:[u("title",{children:"React Scan Icons"}),u("symbol",{id:"icon-inspect",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("path",{d:"M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z"}),u("path",{d:"M5 3a2 2 0 0 0-2 2"}),u("path",{d:"M19 3a2 2 0 0 1 2 2"}),u("path",{d:"M5 21a2 2 0 0 1-2-2"}),u("path",{d:"M9 3h1"}),u("path",{d:"M9 21h2"}),u("path",{d:"M14 3h1"}),u("path",{d:"M3 9v1"}),u("path",{d:"M21 9v2"}),u("path",{d:"M3 14v1"})]}),u("symbol",{id:"icon-focus",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("path",{d:"M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z"}),u("path",{d:"M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"})]}),u("symbol",{id:"icon-next",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u("path",{d:"M6 9h6V5l7 7-7 7v-4H6V9z"})}),u("symbol",{id:"icon-previous",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u("path",{d:"M18 15h-6v4l-7-7 7-7v4h6v6z"})}),u("symbol",{id:"icon-close",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("line",{x1:"18",y1:"6",x2:"6",y2:"18"}),u("line",{x1:"6",y1:"6",x2:"18",y2:"18"})]}),u("symbol",{id:"icon-replay",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("path",{d:"M3 7V5a2 2 0 0 1 2-2h2"}),u("path",{d:"M17 3h2a2 2 0 0 1 2 2v2"}),u("path",{d:"M21 17v2a2 2 0 0 1-2 2h-2"}),u("path",{d:"M7 21H5a2 2 0 0 1-2-2v-2"}),u("circle",{cx:"12",cy:"12",r:"1"}),u("path",{d:"M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0"})]}),u("symbol",{id:"icon-ellipsis",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("circle",{cx:"12",cy:"12",r:"1"}),u("circle",{cx:"19",cy:"12",r:"1"}),u("circle",{cx:"5",cy:"12",r:"1"})]}),u("symbol",{id:"icon-copy",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2"}),u("path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"})]}),u("symbol",{id:"icon-check",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u("path",{d:"M20 6 9 17l-5-5"})}),u("symbol",{id:"icon-chevron-right",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u("path",{d:"m9 18 6-6-6-6"})}),u("symbol",{id:"icon-settings",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"}),u("circle",{cx:"12",cy:"12",r:"3"})]}),u("symbol",{id:"icon-flame",viewBox:"0 0 24 24",children:u("path",{d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"})}),u("symbol",{id:"icon-function",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2"}),u("path",{d:"M9 17c2 0 2.8-1 2.8-2.8V10c0-2 1-3.3 3.2-3"}),u("path",{d:"M9 11.2h5.7"})]}),u("symbol",{id:"icon-triangle-alert",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"}),u("path",{d:"M12 9v4"}),u("path",{d:"M12 17h.01"})]}),u("symbol",{id:"icon-gallery-horizontal-end",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("path",{d:"M2 7v10"}),u("path",{d:"M6 5v14"}),u("rect",{width:"12",height:"18",x:"10",y:"3",rx:"2"})]}),u("symbol",{id:"icon-search",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("circle",{cx:"11",cy:"11",r:"8"}),u("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]}),u("symbol",{id:"icon-lock",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2"}),u("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"})]}),u("symbol",{id:"icon-lock-open",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2"}),u("path",{d:"M7 11V7a5 5 0 0 1 9.9-1"})]}),u("symbol",{id:"icon-sanil",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u("path",{d:"M2 13a6 6 0 1 0 12 0 4 4 0 1 0-8 0 2 2 0 0 0 4 0"}),u("circle",{cx:"10",cy:"13",r:"8"}),u("path",{d:"M2 21h12c4.4 0 8-3.6 8-8V7a2 2 0 1 0-4 0v6"}),u("path",{d:"M18 3 19.1 5.2"})]})]}),"SvgSprite"),ToolbarErrorBoundary=(_f=class extends x$1{constructor(){super(...arguments),this.state={hasError:!1,error:null},this.handleReset=()=>{this.setState({hasError:!1,error:null})}}static getDerivedStateFromError(error){return{hasError:!0,error}}render(){var _a2;return this.state.hasError?u("div",{className:"fixed bottom-4 right-4 z-[124124124124]",children:u("div",{className:"p-3 bg-black rounded-lg shadow-lg w-80",children:[u("div",{className:"flex items-center gap-2 mb-2 text-red-400 text-sm font-medium",children:[u(Icon,{name:"icon-flame",className:"text-red-500",size:14}),"React Scan ran into a problem"]}),u("div",{className:"p-2 bg-black rounded font-mono text-xs text-red-300 mb-3 break-words",children:((_a2=this.state.error)==null?void 0:_a2.message)||JSON.stringify(this.state.error)}),u("button",{type:"button",onClick:this.handleReset,className:"px-3 py-1.5 bg-red-500 hover:bg-red-600 text-white rounded text-xs font-medium transition-colors flex items-center justify-center gap-1.5",children:"Restart"})]})}):this.props.children}},__name(_f,"ToolbarErrorBoundary"),_f),createToolbar=__name(root=>{const container=document.createElement("div");container.id="react-scan-toolbar-root",window.__REACT_SCAN_TOOLBAR_CONTAINER__=container,root.appendChild(container),D$1(u(ToolbarErrorBoundary,{children:u(k$1,{children:[u(SvgSprite,{}),u(Widget,{})]})}),container);const originalRemove=container.remove.bind(container);return container.remove=()=>{window.__REACT_SCAN_TOOLBAR_CONTAINER__=void 0,container.hasChildNodes()&&(D$1(null,container),D$1(null,container)),originalRemove()},container},"createToolbar"),package_default={version:"0.2.14"},rootContainer=null,shadowRoot=null,initRootContainer=__name(()=>{if(rootContainer&&shadowRoot)return{rootContainer,shadowRoot};rootContainer=document.createElement("div"),rootContainer.id="react-scan-root",shadowRoot=rootContainer.attachShadow({mode:"open"});const cssStyles=document.createElement("style");return cssStyles.textContent=styles_default,shadowRoot.appendChild(cssStyles),document.documentElement.appendChild(rootContainer),{rootContainer,shadowRoot}},"initRootContainer"),Store={wasDetailsOpen:d$1(!0),isInIframe:d$1(IS_CLIENT&&window.self!==window.top),inspectState:d$1({kind:"uninitialized"}),monitor:d$1(null),fiberRoots:new Set,reportData:new Map,legacyReportData:new Map,lastReportTime:d$1(0),interactionListeningForRenders:null},ReactScanInternals={instrumentation:null,componentAllowList:null,options:d$1({enabled:!0,log:!1,showToolbar:!0,animationSpeed:"fast",dangerouslyForceRunInProduction:!1,showFPS:!0}),onRender:null,scheduledOutlines:new Map,activeOutlines:new Map,Store,version:package_default.version};function isOptionKey(key){return key in ReactScanInternals.options.value}__name(isOptionKey,"isOptionKey");var validateOptions=__name(options=>{const errors=[],validOptions={};for(const key in options){if(!isOptionKey(key))continue;const value=options[key];switch(key){case"enabled":case"log":case"showToolbar":case"dangerouslyForceRunInProduction":case"showFPS":typeof value!="boolean"?errors.push(`- ${key} must be a boolean. Got "${value}"`):validOptions[key]=value;break;case"animationSpeed":["slow","fast","off"].includes(value)?validOptions[key]=value:errors.push(`- Invalid animation speed "${value}". Using default "fast"`);break;case"onCommitStart":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions.onCommitStart=value;break;case"onCommitFinish":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions.onCommitFinish=value;break;case"onRender":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions.onRender=value;break;case"onPaintStart":case"onPaintFinish":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions[key]=value;break;default:errors.push(`- Unknown option "${key}"`)}}return errors.length>0&&console.warn(`[React Scan] Invalid options:
${errors.join(`
`)}`),validOptions},"validateOptions"),setOptions=__name(userOptions=>{const validOptions=validateOptions(userOptions);if(Object.keys(validOptions).length===0)return;const shouldInitToolbar="showToolbar"in validOptions&&validOptions.showToolbar!==void 0,newOptions={...ReactScanInternals.options.value,...validOptions},{instrumentation}=ReactScanInternals;return instrumentation&&"enabled"in validOptions&&(instrumentation.isPaused.value=validOptions.enabled===!1),ReactScanInternals.options.value=newOptions,saveLocalStorage$1("react-scan-options",newOptions),shouldInitToolbar&&initToolbar(!!newOptions.showToolbar),newOptions},"setOptions"),getOptions=__name(()=>ReactScanInternals.options,"getOptions"),isProduction=null,rdtHook,getIsProduction=__name(()=>{if(isProduction!==null)return isProduction;rdtHook??(rdtHook=getRDTHook());for(const renderer of rdtHook.renderers.values())detectReactBuildType(renderer)==="production"&&(isProduction=!0);return isProduction},"getIsProduction"),start=__name(()=>{try{if(!IS_CLIENT||getIsProduction()&&!ReactScanInternals.options.value.dangerouslyForceRunInProduction)return;const localStorageOptions=readLocalStorage$1("react-scan-options");if(localStorageOptions){const validLocalOptions=validateOptions(localStorageOptions);Object.keys(validLocalOptions).length>0&&(ReactScanInternals.options.value={...ReactScanInternals.options.value,...validLocalOptions})}const options=getOptions();initReactScanInstrumentation(()=>{initToolbar(!!options.value.showToolbar)});const isUsedInBrowserExtension=IS_CLIENT;!Store.monitor.value&&!isUsedInBrowserExtension&&setTimeout(()=>{isInstrumentationActive()||console.error("[React Scan] Failed to load. Must import React Scan before React runs.")},5e3)}catch(e2){ReactScanInternals.options.value._debug==="verbose"&&console.error("[React Scan Internal Error]","Failed to create notifications outline canvas",e2)}},"start"),initToolbar=__name(showToolbar=>{var _a2;(_a2=window.reactScanCleanupListeners)==null||_a2.call(window);const cleanupTimingTracking=startTimingTracking(),cleanupOutlineCanvas=createNotificationsOutlineCanvas();window.reactScanCleanupListeners=()=>{cleanupTimingTracking(),cleanupOutlineCanvas==null||cleanupOutlineCanvas()};const windowToolbarContainer=window.__REACT_SCAN_TOOLBAR_CONTAINER__;if(!showToolbar){windowToolbarContainer==null||windowToolbarContainer.remove();return}windowToolbarContainer==null||windowToolbarContainer.remove();const{shadowRoot:shadowRoot2}=initRootContainer();createToolbar(shadowRoot2)},"initToolbar"),createNotificationsOutlineCanvas=__name(()=>{try{const highlightRoot=document.documentElement;return createHighlightCanvas(highlightRoot)}catch(e2){ReactScanInternals.options.value._debug==="verbose"&&console.error("[React Scan Internal Error]","Failed to create notifications outline canvas",e2)}},"createNotificationsOutlineCanvas"),scan=__name((options={})=>{setOptions(options),!Store.isInIframe.value&&(options.enabled===!1&&options.showToolbar!==!0||start())},"scan"),ignoredProps=new WeakSet;const STORAGE_KEY="react-scan-options",EXTENSION_STORAGE_KEY="react-scan-extension",isIframe=window!==window.top,isPopup=window.opener!==null,canLoadReactScan=!isIframe&&!isPopup,ReactDetection={limits:{MAX_DEPTH:10,MAX_ELEMENTS:30,ELEMENTS_PER_LEVEL:5},nonVisualTags:new Set(["HTML","HEAD","META","TITLE","BASE","SCRIPT","STYLE","LINK","NOSCRIPT","SOURCE","TRACK","EMBED","OBJECT","PARAM","TEMPLATE","PORTAL","SLOT","AREA","XML","DOCTYPE","COMMENT"]),reactMarkers:{root:"_reactRootContainer",fiber:"__reactFiber",instance:"__reactInternalInstance$"}},childrenCache=new WeakMap,hasReactFiber=__name(()=>{const rootElement=document.body;let elementsChecked=0;const getChildren=__name(element=>{let children=childrenCache.get(element);if(!children){const childNodes=element.children;children=[];for(let i2=0;i2<childNodes.length;i2++){const child=childNodes[i2];ReactDetection.nonVisualTags.has(child.tagName)||children.push(child)}childrenCache.set(element,children)}return children},"getChildren"),checkElement=__name((element,depth)=>{var _a2,_b2;if(elementsChecked>=ReactDetection.limits.MAX_ELEMENTS)return!1;elementsChecked++;const props=Object.getOwnPropertyNames(element);if(ReactDetection.reactMarkers.root in element){const rootContainer2=element._reactRootContainer;return((_b2=(_a2=rootContainer2==null?void 0:rootContainer2._internalRoot)==null?void 0:_a2.current)==null?void 0:_b2.child)!=null}for(const key of props)if(key.startsWith(ReactDetection.reactMarkers.fiber)||key.startsWith(ReactDetection.reactMarkers.instance))return!0;if(depth<ReactDetection.limits.MAX_DEPTH){const children=getChildren(element),maxCheck=Math.min(children.length,ReactDetection.limits.ELEMENTS_PER_LEVEL);for(let i2=0;i2<maxCheck;i2++)if(checkElement(children[i2],depth+1))return!0}return!1},"checkElement");return checkElement(rootElement,0)},"hasReactFiber"),readLocalStorage=__name(storageKey=>{if(typeof window>"u")return null;try{const stored=localStorage.getItem(storageKey);return stored?JSON.parse(stored):null}catch{return null}},"readLocalStorage"),saveLocalStorage=__name((storageKey,state)=>{if(!(typeof window>"u"))try{window.localStorage.setItem(storageKey,JSON.stringify(state))}catch{}},"saveLocalStorage"),noReactStyles="html.freeze>body{pointer-events:none}html.freeze{overflow:auto;overscroll-behavior-x:contain}html.freeze svg{pointer-events:none}html.freeze #react-scan-toast{pointer-events:auto}#react-scan-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;background-color:#00000003;-webkit-backdrop-filter:blur(94px) saturate(180%);backdrop-filter:blur(94px) saturate(180%);animation-duration:.3s;opacity:0;pointer-events:none;transition:opacity .5s;z-index:2147483650}#react-scan-toast{position:fixed;top:50%;left:50%;display:flex;padding:12px 40px 12px 16px;min-width:320px;max-width:480px;color:#fff;font-size:12px;font-family:Menlo,Consolas,Monaco,Liberation Mono,Lucida Console,monospace;line-height:1.5;background:#000000f2;border:1px solid rgba(255,255,255,.1);border-radius:8px;box-shadow:0 4px 12px #0003;transform:translate(-50%,-50%);transition:opacity .3s ease-in-out;z-index:2147483651}#react-scan-toast .icon{font-size:.75rem;margin-right:8px}@media (max-width: 320px){#react-scan-toast{flex-direction:column;min-width:auto;width:calc(100% - 36px)}}@media (max-width: 720px){br{display:none}}#react-scan-toast-close-button{position:absolute;top:10px;right:8px;display:flex;align-items:center;width:23px;height:23px;padding:4px;border:none;border-radius:4px;color:#fff;cursor:pointer;background:#ffffff03;transition:background-color .3s ease}#react-scan-toast-close-button:hover{background-color:#ffffff26}";let backdrop=null,isAnimating=!1;const defaultMessage="React is not detected on this page. Please ensure you're visiting a React application!",createNotificationUI=__name((message=defaultMessage)=>{if(U$1("react-scan:send-to-background",{type:"react-scan:is-enabled",data:{state:!1}}),backdrop)return;backdrop=document.createElement("div"),backdrop.id="react-scan-backdrop",backdrop.style.opacity="0",backdrop.style.pointerEvents="none";const toast=document.createElement("div");toast.id="react-scan-toast",toast.onclick=e2=>{e2.stopPropagation()};const messageElement=document.createElement("span");messageElement.id="react-scan-toast-message";const icon=document.createElement("span");icon.className="icon",icon.textContent="⚛️",messageElement.appendChild(icon);const text=document.createElement("span");text.textContent=message.replace(/<br \/>/,`
`),messageElement.appendChild(text),toast.appendChild(messageElement);const button=document.createElement("button");button.id="react-scan-toast-close-button";const svg=document.createElementNS("http://www.w3.org/2000/svg","svg");svg.setAttribute("width","15"),svg.setAttribute("height","15"),svg.setAttribute("viewBox","0 0 24 24"),svg.setAttribute("fill","none"),svg.setAttribute("stroke","currentColor"),svg.setAttribute("stroke-width","2"),svg.setAttribute("stroke-linecap","round"),svg.setAttribute("stroke-linejoin","round");const line1=document.createElementNS("http://www.w3.org/2000/svg","line");line1.setAttribute("x1","18"),line1.setAttribute("y1","6"),line1.setAttribute("x2","6"),line1.setAttribute("y2","18");const line2=document.createElementNS("http://www.w3.org/2000/svg","line");line2.setAttribute("x1","6"),line2.setAttribute("y1","6"),line2.setAttribute("x2","18"),line2.setAttribute("y2","18"),svg.appendChild(line1),svg.appendChild(line2),button.appendChild(svg),toast.appendChild(button),backdrop.appendChild(toast),backdrop.onclick=toggleNotification;const style=document.createElement("style");style.id="react-scan-no-react-styles",style.appendChild(document.createTextNode(noReactStyles));const fragment=document.createDocumentFragment();fragment.appendChild(style),fragment.appendChild(backdrop),document.documentElement.appendChild(fragment)},"createNotificationUI"),toggleNotification=__name(()=>{if(!backdrop||isAnimating)return;isAnimating=!0;const handleTransitionEnd=__name(()=>{isAnimating=!1,backdrop==null||backdrop.removeEventListener("transitionend",handleTransitionEnd)},"handleTransitionEnd");backdrop.addEventListener("transitionend",handleTransitionEnd);const isVisible=backdrop.style.opacity==="1";backdrop.style.opacity=isVisible?"0":"1",backdrop.style.pointerEvents=isVisible?"none":"auto",document.documentElement.classList.toggle("freeze",!isVisible)},"toggleNotification"),isTargetPageAlreadyUsedReactScan=__name(()=>{var _a2,_b2;const reactScanExtensionVersion=ReactScanInternals.version,currentReactScanVersion=(_a2=window.__REACT_SCAN__)==null?void 0:_a2.ReactScanInternals.version;return(_b2=window.__REACT_SCAN__)!=null&&_b2.ReactScanInternals.Store.monitor.value?!1:!!window.__REACT_SCAN__&&reactScanExtensionVersion!==currentReactScanVersion},"isTargetPageAlreadyUsedReactScan"),getInitialOptions=__name(async()=>{const storedOptions=readLocalStorage(STORAGE_KEY);let isEnabled=!1;try{isEnabled=await $$2(EXTENSION_STORAGE_KEY,"isEnabled")??!1}catch{}return{...storedOptions,enabled:isEnabled,showToolbar:isEnabled,dangerouslyForceRunInProduction:!0}},"getInitialOptions"),initializeReactScan=__name(async()=>{const options=await getInitialOptions();window.hideIntro=!0,scan(options),window.reactScan=void 0},"initializeReactScan");let timer;const updateReactScanState=__name(async isEnabled=>{clearTimeout(timer);const toggledState=isEnabled===null?!0:!isEnabled;try{await L$1(EXTENSION_STORAGE_KEY,"isEnabled",toggledState)}catch{}const updatedOptions={...readLocalStorage(STORAGE_KEY)??{},enabled:toggledState,showToolbar:toggledState,dangerouslyForceRunInProduction:!0};saveLocalStorage(STORAGE_KEY,updatedOptions),window.location.reload()},"updateReactScanState");return initializeReactScan(),window.addEventListener("DOMContentLoaded",async()=>{if(!canLoadReactScan)return;let isReactAvailable=!1;if(await m$2(1e3),isReactAvailable=await hasReactFiber(),!isReactAvailable){createNotificationUI(),U$1("react-scan:send-to-background",{type:"react-scan:is-enabled",data:{state:!1}}),N$2("react-scan:toggle-state",async()=>{toggleNotification()});return}if(isTargetPageAlreadyUsedReactScan()){createNotificationUI("React Scan is already initialized!"),U$1("react-scan:send-to-background",{type:"react-scan:is-enabled",data:{state:!1}}),N$2("react-scan:toggle-state",async()=>{toggleNotification()});return}const storedOptions=readLocalStorage(STORAGE_KEY);storedOptions!==null&&U$1("react-scan:send-to-background",{type:"react-scan:is-enabled",data:{state:storedOptions.showToolbar}}),window.reactScan=setOptions,N$2("react-scan:toggle-state",async()=>{if(!isReactAvailable||isTargetPageAlreadyUsedReactScan()){toggleNotification();return}try{const isEnabled=await $$2(EXTENSION_STORAGE_KEY,"isEnabled");await updateReactScanState(isEnabled)}catch{await updateReactScanState(null)}})}),exports.isTargetPageAlreadyUsedReactScan=isTargetPageAlreadyUsedReactScan,Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"}),exports}({});
